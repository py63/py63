<?php
/**
 * Template Name: Submit Proposal
 *
 * @package OnePress
 */
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
get_header('admin');

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
global $current_user;
if (isset($_GET['opid']) && !empty($_GET['opid'])) {
  $opid = $_GET['opid'];
} else {
  $opid = '';
}
// $cdate = date("m-d-Y", current_time("timestamp"));
// $spdatelined = get_field('nstxl_proposal_deadline', $opid);
 $spdatelined = get_field('nstxl_proposal_deadline', $opid, false, false);

    $cdate = date("Y-m-d H:i:s", current_time("timestamp"));
    $after15minut = strtotime("-15 minutes", current_time('timestamp'));
    $cdate = date("Y-m-d H:i:s", $after15minut);
?>
 

<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  // [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' );  ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>
              <?php
              if (!empty($spdatelined)) {
                if ($cdate > $spdatelined) {
                  echo '<div class="submitproposal-container dashboard-inner-wrapper dashboard-bg-white"> 
                  <div class="clearfix page-header-wrapper text-center">
                  <h4>The proposal submission period has ended</h4><p>Thank you for your interest. Please check our opportunities page for other opportunities you may be interested in.</p>  
                  </div>
                  </div>';
                } else {
                  ob_start();
                  include nstxl_extention_path . 'includes/template/submitproposalform.php';
                  echo $form = ob_get_clean();
                }
              } else {
                ob_start();
                include nstxl_extention_path . 'includes/template/submitproposalform.php';
                echo $form = ob_get_clean();
              }
              ?>

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->



  </div><!--#content-inside -->
</div><!-- #content -->
<!-- Modal -->
<div class="modal fade custom-popup" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/assets/images/close-icon.svg"></span>
      </button>  
      <div class="update-personalinfo-box-success-container">
        <p></p> 
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
</div> 
<!-- /.modal -->  
<script type="text/javascript">
  var currentTime = "<?php echo current_time('mysql'); ?>";
  jQuery(document).ready(function ($) {

    if ( jQuery( 'div.nontraditional_requirement_container' ).length ) {
      $( 'div.nontraditional_requirement_container input[type=checkbox]' ).on( 'change', function () {
        $( 'div.nontraditional_requirement_container input[type=checkbox]' ).not( this ).prop( 'checked', false );
      } );
    }  

    jQuery('.btn-updproposal').click(function () {
      jQuery('#proposaldoc').click();
    });
    jQuery('#duedate').datetimepicker({minDate: currentTime, format: 'YYYY-MM-DD HH:mm:s'}).data('autoclose', true);

    jQuery('#opportunities_list').on('change', function () {
      //e.preventDefault();
      var oprid = jQuery(this).val();
      var data = {oprid: oprid, action: 'nstxl_opportunity_duedate'};
      jQuery.ajax({
        url: nstxl_ajaxurl,
        type: "POST",
        data: data,
        beforeSend: function () {
          jQuery('.nstxl-loader').show();
          jQuery('.loader-overlay').show()
        },
        complete: function () {
          jQuery('.nstxl-loader').css('display', 'none');
          jQuery('.loader-overlay').css('display', 'none');
        },
        success: function (response, data) {
          console.log(response);
          if (response.data.status == "success") {
            //	alert(response.data.duedate);
            jQuery('#duedate').val(response.data.duedate);
          } else {
            //	alert(response.data.duedate);
            jQuery('#duedate').val(response.data.duedate);
          }
        },

      });
    }).trigger('change');

    jQuery('.pmpro_asterisk').remove();
    var redirectUrl = siteurl + '/your-sponsored-companies';
    $("#submitproposal").validate({
      rules: {
        // opportunity_title: {
        //   required: true,
        // },
        action: "required",
        opportunities_list: {
          required: true,
        },
        duedate: {
          required: true,
        },
        proposaldoc: {
          required: true,
        },
      },
      messages: {
        // opportunity_title: {
        //   required: "Please enter the opportunity title",
        // },
        opportunities_list: {
          required: "Please select the opportunity",
        },
        duedate: {
          required: "Please select the due date",
        },
        proposaldoc: {
          required: "Please upload the proposal doc",
        },
      },
      errorClass: "form-invalid",
      errorElement: 'div',
      highlight: function (element, errorClass, validClass) {
        $(element).closest("div.field").addClass("error").removeClass("success");
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).closest(".error").removeClass("error").addClass("success");
      },
      errorPlacement: function (error, element) {

        if (element.parent().find("div.help-block.with-errors").length === 0) {
          if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
            element.parent().append(error);
          } else {
            error.addClass("help-block with-errors").appendTo(element.closest('div.form-group'));
          }
        } else {
          if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
            element.parent().append(error);
          } else {
            error.appendTo(element.parent().find("div.help-block.with-errors"));
          }
        }
      },
      submitHandler: function (form) {
        var form = jQuery('form#submitproposal')[0];
        var formData = new FormData(form);
        formData.append("action", "nstxl_submitproposal");
        $.ajax({
          url: nstxl_ajaxurl,
          type: "POST",
          data: formData,
          beforeSend: function () {
            jQuery('.preloader').fadeIn();
          },
          success: function (response, textStatus, jqXHR) {
            jQuery('.preloader').fadeOut();
            if (response.data.status == "success") {
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container p').addClass(response.data.status).removeClass('error').removeClass('false');
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container p').html(response.data.msg);
              jQuery('#update-personalinfo-modal-success').modal('show');
            }
            if (response.data.status == "error") {
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container p').addClass(response.data.status).addClass('error').removeClass('success');
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container p').html(response.data.msg);
              jQuery('#update-personalinfo-modal-success').modal('show');
            }

          },
          error: function (jqXHR, textStatus, errorThrown) {
            add_message(textStatus, "danger");
          },
          complete: function () {
            form.reset();
          },
          cache: false,
          contentType: false,
          processData: false
        });
      }
    });
    jQuery('.close').on('click', function (e) {
      jQuery('#update-personalinfo-modal-success').modal('hide');
    });
    jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
      //window.location.href = redirectUrl;
      location.reload(true);
    })

    $.fn.select2.defaults.set("theme", "bootstrap");

    //var placeholder = "Select opportunity";

    $("#opportunities_list").select2({
      //placeholder: placeholder,
      width: null,
      containerCssClass: ':all:'
    });

    // copy Bootstrap validation states to Select2 dropdown
    //
    // add .has-waring, .has-error, .has-succes to the Select2 dropdown
    // (was #select2-drop in Select2 v3.x, in Select2 v4 can be selected via
    // body > .select2-container) if _any_ of the opened Select2's parents
    // has one of these forementioned classes (YUCK! ;-))
    $("#opportunities_list").on("select2:open", function () {
      if ($(this).parents("[class*='has-']").length) {
        var classNames = $(this).parents("[class*='has-']")[ 0 ].className.split(/\s+/);

        for (var i = 0; i < classNames.length; ++i) {
          if (classNames[ i ].match("has-")) {
            $("body > .select2-container").addClass(classNames[ i ]);
          }
        }
      }
    });
    if (window.location.href.indexOf('?') > -1) {
      history.pushState('', document.title, window.location.pathname);
    }
  });
</script> 
<?php get_footer('admin'); ?>
