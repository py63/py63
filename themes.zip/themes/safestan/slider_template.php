<?php 	
	global $wpdb;
	if(isset($_REQUEST['post_id']) && isset($_REQUEST['user_id']))
	{
		$post_id 	= $_REQUEST['post_id'];
		$user_id 	= $_REQUEST['user_id'];
		$post_title = $_REQUEST['post_title'];

		$numrows_approved = $wpdb->get_results("SELECT * FROM wpsft_post_slider_image WHERE wpsft_post_slider_image.post_id = $post_id AND wpsft_post_slider_image.status = 1");
		
		$numrows_approved = count($numrows_approved);

		$numrows = $wpdb->get_results("SELECT * FROM wpsft_post_slider_image WHERE wpsft_post_slider_image.post_id = $post_id GROUP by image_id DESC");
		//echo '<pre>';print_r($numrows);

		if(!empty($numrows) && $numrows > 0)
		{
			$numrows_unapproved = count($numrows);

			echo '<div id="errordelete_Message" style="display:none;">successfully delete image</div>';
			//echo '<div id="errorlimit_Message" style="display:none;">More then 10  image Approved</div>';
			echo '<h2 class="heading2">'.$post_title.'</h2>';
			echo '<h2 class="heading2">Total number of approved images ('.$numrows_approved.')</h2>';
			echo '<h2 class="heading2">Total Number of unapproved images ('.$numrows_unapproved.')</h2>';
			echo '<p id="errorlimit_Message" class="heading2">Maximum number of approved images can be 10</p>';

			//echo '<pre>';print_r($numrows);die;
			/*
			echo '<pre>';print_r($numrows);die;
			foreach ($numrows as $numrow) {
				
			}*/
			echo '<div class="admin-table-responsive">
			<table id="example_admin_inner" class="display" width="100%" cellspacing="0">
                <thead>
                    <tr>
			            <th>Serial Number</th>
			            <th>Image Name</th>
			            <th>Thumbnail</th>
			            <th>User Name</th>
			            <th>Status</th>
			        </tr>
			    </thead>
			    <tbody>';
					$countInner = 1;
					//echo '<pre>';print_r($numrows);die;
					foreach ($numrows as $numrow) 
					{
						echo '<tr class="imageRow"><td>'.$countInner.'</td>';
						echo '<td>'.$numrow->image_name.'</td>';
						echo '<td><img src="'.$numrow->image_path.'" style="width:80px;height:80px;"></td>';
						echo '<td>'.$numrow->user_name.'</td>';
						if($numrow->status == 0)
						{
							echo '<td><a href="javascript:;" imgId = "'.$numrow->image_id.'" imgStatus = "'.$numrow->status.'" postId ="'.$numrow->post_id.'" onclick="approvedUnapprovedImage(jQuery(this))" class="unaprvdbtn btn-disapproved btn-cmn">approve</a>';
							
							//echo '<a href="javascript:;" imgdeleteId = "'.$numrow->image_id.'"  onclick="deleteImg(jQuery(this))">Delete</a>';

							echo '<a href="javascript:;" imgdeleteId = "'.$numrow->image_id.'" imgDeleteName = "'.$numrow->image_name.'" onclick="deleteImg(jQuery(this))" class="dltbtn btn-1 btn-cmn">Delete</a>';

							//echo '<input type="hidden" name="delete_image_name" id="imgdelete_id" value="'.$numrow->image_id.'"/>';
							echo '</td>';
						}
						else
						{
							echo '<td><a href="javascript:;" imgId = "'.$numrow->image_id.'" imgStatus = "'.$numrow->status.'" postId ="'.$numrow->post_id.'" onclick="approvedUnapprovedImage(jQuery(this))" class="aprvdbtn btn-approved btn-cmn">Unapprove</a>';
							
							echo '<a href="javascript:;" imgdeleteId = "'.$numrow->image_id.'" imgDeleteName = "'.$numrow->image_name.'" onclick="deleteImg(jQuery(this))" class="dltbtn btn-1 btn-cmn">Delete</a>';
							
							//echo '<input type="hidden" name="delete_image_name" id="imgdelete_id" value="'.$numrow->image_id.'" />';
							echo '<a href="javascript:;" imgFetauredId = "'.$numrow->image_id.'" imgFeaturedStatus = "'.$numrow->image_featured_status.'" postId ="'.$numrow->post_id.'" onclick="SetimgFetaured(jQuery(this))" id="sliderfeatured"> ';
								if($numrow->image_featured_status == 0)
								{	
									echo '<span class="btn-makefeatured btn-cmn">Make Featured<span>';
								}
								else
								{
									echo '<span class="btn-featured btn-cmn">Featured</span>';
								}		
								echo '</a>';
							echo '</td>';
						}
						echo '</tr>';
						$countInner++;
					}
					echo '
				</tbody>
            </table></div>
		                ';
		}
		else
		{
			echo '<h1>Not fount records</h1>';
		}
	}		
?>
<script type="text/javascript">
var homeurl = "<?php echo home_url();?>";

function SetimgFetaured(imgfetauredid) {
	var featuredText = imgfetauredid.text();
	var imgFetauredID = imgfetauredid.attr("imgFetauredId");
	var imgFeaturedSTATUS = imgfetauredid.attr("imgFeaturedStatus");
	var postID = imgfetauredid.attr("postId");
	
	jQuery.ajax({
		        	cache: false,
		        	type : "post",
		        	context: this,
		         	dataType : "json",
		         	url : homeurl+"/wp-content/themes/safestan/approvedUnapprovedImg.php",
		         	data : {imgFetauredId:imgFetauredID, imgFeaturedStatus:imgFeaturedSTATUS, postId : postID},
		         	success: function(response) 
		         	{
						if(response==1){
							window.location.reload();
						}
						/*else
						{
							img.attr("imgStatus",0);		
							img.text('Unapproved');
							window.location.reload();
						}*/
						jQuery(window).data('ajaxready', true);
		         	}
	      		});
}

function deleteImg(imgdelete){
	var imgDelete = imgdelete.attr("imgdeleteId");
	var imgDeleteName = imgdelete.attr("imgDeleteName");
	
	jQuery.ajax({
				        	cache: false,
				        	type : "post",
				        	context: this,
				         	dataType : "json",
				         	url : homeurl+"/wp-content/themes/safestan/approvedUnapprovedImg.php",
				         	data : {imgDelete:imgDelete, imgDeleteName:imgDeleteName},
				         	success: function(response) {
					         							if( response == '1' )
					         							{
					         								window.location.reload();
					         							}
														jQuery(window).data('ajaxready', true);
				         	}

				      	});

}

function approvedUnapprovedImage(img){
	var anchorText = img.text();
	var imageID = img.attr("imgId");
	var imageStatus = img.attr("imgStatus");
	var postId =img.attr("postId");
	jQuery.ajax({
				        	cache: false,
				        	type : "post",
				        	context: this,
				         	dataType : "json",
				         	url : homeurl+"/wp-content/themes/safestan/approvedUnapprovedImg.php",
				         	data : {imgId:imageID, imgStatus:imageStatus, postId : postId},
				         	success: function(response) {
				         								if(response==1){
								 							img.attr("imgStatus",1);
								 							img.text('Approved');
								 							window.location.reload();
								 						}
								 						else
								 						{
								 							img.attr("imgStatus",0);		
								 							img.text('Unapproved');
								 							window.location.reload();
								 						}
															jQuery(window).data('ajaxready', true);
				         	},
				         	error: function() {
						        //alert("Maximun 10 image Approved");
						        jQuery('html, body').animate({ scrollTop: 0 }, 0);
						       	jQuery("#errorlimit_Message").addClass("error-clr");
								setTimeout(function()
									{
										jQuery("#errorlimit_Message").removeClass("error-clr");
									}, 3000);
						    }

				      	});

}
</script>
<!-- <script type="text/javascript">
	jQuery(document).ready(function($) {
	//$('#myslidgallery_table').DataTable();
    $('#myslidgallery_table_detail').DataTable();
    
} );
</script> -->
