<div class='opportunity-tabcontainer container'>
	<ul class="nav nav-pills nav-justified" id="opportunityTab" role="tablist">
		<li class="nav-item active">
			<a class="nav-link active" id="overview-tab-md" data-toggle="tab" href="#overview-md" role="tab" aria-controls="overview-md" aria-selected="true"><div class="icon-img-back1"></div><p><?php _e('Overview','polar'); ?></p></a>
		</li>
		<li class="nav-item">
			<a class="nav-link" id="keydocuments-tab-md" data-toggle="tab" href="#keydocuments-md" role="tab" aria-controls="keydocuments-md"  aria-selected="false"><div class="icon-img-back2"></div><p><?php _e('Key Documents','polar'); ?></p></a>
		</li>
		<li class="nav-item">
			<a class="nav-link" id="events-tab-md" data-toggle="tab" href="#events-md" role="tab" aria-controls="events-md" aria-selected="false"><div class="icon-img-back3"></div><p><?php _e('Calendar and Events','polar'); ?></p></a>
		</li>

		<li class="nav-item">
			<a class="nav-link" id="submitquestion-tab-md" data-toggle="tab" href="#submitquestion-md" role="tab" aria-controls="submitquestion-md" aria-selected="false"><div class="icon-img-back4"></div><p><?php _e('Submit a Question','polar'); ?></p></a>
		</li>

		<li class="nav-item">
			<a class="nav-link" id="submitproposal-tab-md" data-toggle="tab" href="#submitproposal-md" role="tab" aria-controls="submitproposal-md" aria-selected="false"><div class="icon-img-back5"></div><p><?php _e('Submit a Proposal','polar'); ?></p></a>
		</li>

		<li class="nav-item">
			<a class="nav-link" id="trackopportunity-tab-md center-inner" data-toggle="tab" href="#trackopportunity-md" role="tab" aria-controls="trackopportunity-md" aria-selected="false"><div class="icon-img-back6"></div><p><?php _e('Track Opportunity','polar'); ?></p></a>
		</li>
	</ul>
	<div class="tab-content card pt-5" id="opportunityTabContent">
		<div class="tab-pane fade in active" id="overview-md" role="tabpanel" aria-la	belledby="overview-tab-md">
			<?php  echo wp_trim_words( the_field( 'nstxl_overview', get_the_ID()), 500,'...' );?>
		</div>
		<div class="tab-pane fade" id="keydocuments-md" role="tabpanel" aria-labelledby="keydocuments-tab-md">
			<?php get_template_part( 'templates/opportunity/tabs/keydocuments' ); ?>
		</div>
		<div class="tab-pane fade" id="events-md" role="tabpanel" aria-labelledby="events-tab-md">
			<?php get_template_part( 'templates/opportunity/tabs/events' ); ?>
		</div>
		<div class="tab-pane fade" id="submitquestion-md" role="tabpanel" aria-labelledby="submitquestion-tab-md">
			<?php include(locate_template('templates/opportunity/tabs/submitquestion.php')); ?>
		</div>
		<div class="tab-pane fade" id="submitproposal-md" role="tabpanel" aria-labelledby="submitproposal-tab-md">
			<?php get_template_part( 'templates/opportunity/tabs/submitproposal' ); ?>
		</div>
		<div class="tab-pane fade text-center" id="trackopportunity-md" role="tabpanel" aria-labelledby="trackopportunity-tab-md">
			<?php get_template_part( 'templates/opportunity/tabs/trackopportunity' ); ?>
		</div>
	</div>
</div>
<script type="text/javascript">
	jQuery(document).ready( function($){
		let url = location.href.replace(/\/$/, "");
		if (location.hash) {
			const hash = url.split("#");
			$('#opportunityTab a[href="#'+hash[1]+'"]').trigger("click");
			window.location.hash = '';//remove hash text
			window.location.href.replace('#', '');//remove hash
			//history.replaceState(null, null, window.location.pathname);//replace state
			history.replaceState(null, null, window.location.pathname);//replace state
		}
	});
</script>	