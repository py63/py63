<?php 
	global $wpdb, $pmpro_invoice, $pmpro_msg, $pmpro_msgt, $current_user;
 $gda = get_user_meta($current_user->ID,'',true);
//echo '<pre>';
//print_r($pmpro_invoice);
//echo '</pre>';

?>
<?php 
	if($pmpro_invoice) 
	{ 
		?>
<?php
			$pmpro_invoice->getUser();
      
			//print_r($pmpro_invoice->getMembershipLevel());
			$getdetails = $pmpro_invoice->getMembershipLevel();

			
		?>
<?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) { ?>

<div class="col-md-12">
  <h2 class="titlesingle">Receipt</h2>
</div>
<div class="printpdf clearfix">
  <button id="cmd">
  <?php _e('Save Receipt', 'paid-memberships-pro' ); ?>
  </button>
  <a class="pmpro_a-print" href="javascript:window.print()">
  <?php _e('Print Receipt', 'paid-memberships-pro' ); ?>
  </a> </div>
<?php } else { ?>
<div class="col-md-12">
  <h2 class="titlesingle">invoice</h2>
</div>
<div class="printpdf clearfix">
  <button id="cmd">
  <?php _e('Save Invoice', 'paid-memberships-pro' ); ?>
  </button>
  <a class="pmpro_a-print" href="javascript:window.print()">
  <?php _e('Print Invoice', 'paid-memberships-pro' ); ?>
  </a> </div>
<?php } ?>
<style>

  td,tr {
    border-bottom: 0px dotted silver;
}
  .titlewel{
    display:none;
  }
  h2.titlesingle::after {
    background-color: #d2232a;
    position: absolute;
    left: 0;
    bottom: 25px;
    width: 50px;
    height: 3px;
    z-index: 13;
    content: "";
    right: 0;
    margin: auto;
}

.titlesingle
{
text-align: center;
font-size: 24px;
margin-bottom: 35px !important;
text-transform: uppercase;
}

.cstm-tbl{ border-collapse:collapse !important;}
.cstm-tbl td, .cstm-tbl th {
       border: 1px solid #687279 !important;
	   border-collapse:collapse !important;
}
	.side-padding-inner {padding-left: 0px !important;padding-right: 0px !important;}
.side-padding {padding: 0px;}
.page-template-invoices .page-wrapper{padding:45px 0px !important}
.cstm-td td {
    padding-right: 0px;
}
.cstm-td td,.cstm-td th {padding-right: 0px; text-align:center;}
.cstm-tbl td {padding: 10px;}
.titlewel {margin-top: 20px;}

#element-to-print-invoice td {padding: 0px;}

.cstm-tbl{-fs-table-paginate:paginate !important ;border-spacing:0 !important}

.cstm-tbl td{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child td{border-top-width:2px !important} 
.cstm-tbl td:first-child{border-left-width:2px !important}  

.cstm-tbl tr th{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child th{border-top-width:2px !important} 
.cstm-tbl tr th:first-child{border-left-width:2px !important}

@media print {
    .cstm-td td b {color: #ed193e !important;}
	.cstm-tbl td,.cstm-tbl th{ border:1px solid #687279 !important;}
  .titlesingle {display: none}
.cstm-tbl td{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child td{border-top-width:2px !important} 
.cstm-tbl td:first-child{border-left-width:2px !important}  

.cstm-tbl tr th{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child th{border-top-width:2px !important} 
.cstm-tbl tr th:first-child{border-left-width:2px !important}

}


@media (max-width:991px) {

}
@media (max-width:575px) {
.side-padding-inner {
	padding: 0px !important;
}
.side-padding-inner td.cstm-td {
	display: block !important;
	width: 100% !important;
	padding: 30px 0px !important;
}
.side-padding-inner td {
	text-align: left !important;
}
.side-padding-inner td table {
	border: none !important;
}
.side-padding-inner td table.cstm-tbl td {
	padding: 5px 15px !important;
}
.side-padding-inner th {
	padding: 5px 15px !important;
	text-align: left;
}

}
</style>

<!-- strat new  -->

<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F0F0F0" id="element-to-print-invoice">
  <tr>
    <td align="center"><!--[if gte mso 9]>
  <table id="tableForOutlook" align="center"><tr><td>
<![endif]-->
      
      <div style="max-width:750px; margin:0 auto;">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width:750px; margin:0px auto;" class="contenttable">
          <tbody>
            
            <!--  <tr>
              <td style="background-color:#fff;" bgcolor="#fff" height="40">&nbsp;</td>
            </tr>-->
            <tr>
              <td valign="middle" style="background-color:#fff; text-align:center; border-top:3px solid #ff0000; padding-top:30px; padding-bottom:30px; " class="side-padding"><a href="https:www.nstxl.org" target="_blank"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/nstxl-large-logo.png" height="75" alt="" border="0"/></a></td>
            </tr>
            <tr>
              <td valign="middle" style="background-color:#fff; text-align:center;border-top:3px solid #ff0000; " class="side-padding"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/header-bg.jpg" height="140px" width="100%" alt="" border="0"/></td>
            </tr>
            <tr>
              <td style="background-color:#fff; padding-top:20px; padding-bottom:10px; padding-left:15px; padding-right:15px;" class="side-padding-inner"><table width="100%" border="0" cellpadding="0" cellspacing="10">
                  <tbody>
                    <tr>
                      <td class="cstm-td" width="70%" style="font-family: Arial, sans-serif; font-size:16px; 
								 line-height:26px;   background-color: #fff;color: #000;padding: 8px 15px;padding-left: 0px;"><?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) { ?>
                        <b style="margin-bottom: 0; text-transform:uppercase;font-size:40px; color:#000; text-align:left;">RECEIPT<br>
                        <br>
                        </b>
                        <?php  } else { ?>
                        <b style="margin-bottom: 0; text-transform:uppercase;font-size:40px; color:#000; text-align:left;">INVOICE<br>
                        <br>
                        </b>
                        <?php } ?>
                        <table class="cstm-tbl" width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; text-align:center;">
                          <tr>
                            <th style="padding:5px 40px">Description</th>
                            <th style="padding:5px 20px">QTY</th>
                            <th style="padding:5px 40px">Price</th>
                          </tr>
                          <tr>
                            <td>1-year NSTXL Membership</br>
                              <?php
                              if(!empty($getdetails))
                              	{
                               		echo $getdetails->name; 
                           		}
                           		else{
                           			$getdetails = '';
                           		}

                               ?></td>
                            <td>1</td>
                            <td><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></td>
                          </tr>
                          <tr>
                            <th></th>
                            <th>Total</th>
                            <th><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></th>
                          </tr>
                        </table></td>
                      <td  class="cstm-td"  width="30%" style="font-family: Arial, sans-serif; font-size:16px; 
								 line-height:26px; text-align:right;  background-color: #fff;color: #fff;padding: 8px 15px;padding-right: 0px;"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; border-left:2px solid #687279" >
                          <tr>
                            <?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) { ?>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:50px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Amount Paid</b> <br>
                              <span style="font-size:24px; color:#000;"><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></span></td>
                            <?php } else { ?>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:50px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Amount Due</b> <br>
                              <span style="font-size:24px; color:#000;"><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></span></td>
                            <?php } ?>
                          </tr>
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Billed To</b> <br>
                              <?php if(!empty($pmpro_invoice->billing->name)) { ?>
                              <span style="font-size:16px; color:#000;"><?php echo $pmpro_invoice->billing->name?><br>
                              <?php echo $pmpro_invoice->billing->street?><br>
                              <?php echo $pmpro_invoice->billing->city; ?>, <?php echo $pmpro_invoice->billing->state; ?>, <?php echo $pmpro_invoice->billing->zip; ?> </span>
                              <?php } ?></td>
                          </tr>
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Invoice Number</b> <br>
                              <span style="font-size:16px; color:#000;"><?php printf(__('%s', 'paid-memberships-pro' ), $pmpro_invoice->code, date_i18n(get_option('date_format'), $pmpro_invoice->timestamp));?></span></td>
                          </tr>
                          <tr>
                            <?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) { ?>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Paid On</b> <br>
                              <span style="font-size:16px; color:#000;"><?php echo date_i18n(get_option('date_format'), $pmpro_invoice->timestamp);?></span></td>
                            <?php } else { ?>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Start Date</b> <br>
                              <span style="font-size:16px; color:#000;"><?php echo date_i18n(get_option('date_format'), $pmpro_invoice->timestamp);?></span></td>
                            <?php } ?>
                          </tr>
                          <tr>
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:10px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Membership Expires</b> <br>
                              <span style="font-size:16px; color:#000;"> <?php echo date_i18n(get_option('date_format'), $current_user->membership_level->enddate)?> </span></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr>
                      <td style="background-color:#fff;" bgcolor="#fff" height="80">&nbsp;</td>
                    </tr>
                    <tr>
                      <td colspan="2" valign="top" align="center" style="font-family:Arial, sans-serif; color:#5F5F5F; font-size:14px; padding-bottom:0px;"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/nstxl-small-logo.png" width="30" alt="" border="0"/> | National Security Technology Accelerator | 1-800-364-1545 | <a href="https://www.nstxl.org" target="_blank" style="font-family:Arial, sans-serif; color:#ff0000; font-size:14px; text-decoration:none;">www.nstxl.org</a></td>
                    </tr>
                    
                    <!--table order list-->
                    
                  </tbody>
                </table></td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <!--[if gte mso 9]>
  </td></tr></table>
<![endif]--></td>
  </tr>
</table>

<!-- End -->

<?php 
	} else 
	  {
	//Show all invoices for user if no invoice ID is passed	
		$invoices = $wpdb->get_results("SELECT o.*, UNIX_TIMESTAMP(o.timestamp) as timestamp, l.name as membership_level_name FROM $wpdb->pmpro_membership_orders o LEFT JOIN $wpdb->pmpro_membership_levels l ON o.membership_id = l.id WHERE o.user_id = '$current_user->ID' ORDER BY timestamp DESC");
		if($invoices)
		{
			?>
<table id="pmpro_invoices_table" class="pmpro_invoice" width="100%" cellpadding="0" cellspacing="0" border="0">
  <thead>
    <tr>
      <th><?php _e('Date', 'paid-memberships-pro' ); ?></th>
      <th><?php _e('Invoice #', 'paid-memberships-pro' ); ?></th>
      <th><?php _e('Level', 'paid-memberships-pro' ); ?></th>
      <th><?php _e('Total Billed', 'paid-memberships-pro' ); ?></th>
    </tr>
  </thead>
  <tbody>
    <?php
				foreach($invoices as $invoice)
				{ 
					?>
    <tr>
      <?php if(is_page('invoices')){ ?>
      <td><a href="<?php echo pmpro_url("invoice", "?invoice=" . $invoice->code)?>"><?php echo date_i18n(get_option("date_format"), $invoice->timestamp)?></a></td>
      <td><a href="<?php echo pmpro_url("invoice", "?invoice=" . $invoice->code)?>"><?php echo $invoice->code; ?></a></td>
      <?php } else{ ?>
      <td><a href="<?php echo pmpro_url("invoice", "?invoice=" . $invoice->code)?>&receipt=1"><?php echo date_i18n(get_option("date_format"), $invoice->timestamp)?></a></td>
      <td><a href="<?php echo pmpro_url("invoice", "?invoice=" . $invoice->code)?>&receipt=1"><?php echo $invoice->code; ?></a></td>
      <?php } ?>
      <td><?php echo $invoice->membership_level_name;?></td>
      <td><?php echo str_replace(".00","",pmpro_formatPrice($invoice->total));?></td>
    </tr>
    <?php
				}
			?>
  </tbody>
</table>
<?php
		}
		else
		{
			?>
<p>
  <?php _e('No invoices found.', 'paid-memberships-pro' );?>
</p>
<?php
		}
	} 
?>
<?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) { ?>
<script type="text/javascript">
jQuery('#cmd').click(function() {
  /*var options = {
  };
  var pdf = new jsPDF('p', 'pt', 'a4');
  pdf.addHTML(jQuery(".membership-recipt"), 15, 15, options, function() {
    pdf.save('invoice.pdf');
  });*/
    var element = document.getElementById('element-to-print-invoice');
var opt = {
  margin:       .5,
  filename:     'receipt.pdf',
  image:        { type: 'jpeg', quality: 0.98 },
  html2canvas:  { scale: 2 },
  jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
};

// New Promise-based usage:
html2pdf().from(element).set(opt).save();
});
</script>
<?php } else { ?>
<script type="text/javascript">
jQuery('#cmd').click(function() {
  /*var options = {
  };
  var pdf = new jsPDF('p', 'pt', 'a4');
  pdf.addHTML(jQuery(".membership-recipt"), 15, 15, options, function() {
    pdf.save('invoice.pdf');
  });*/
    var element = document.getElementById('element-to-print-invoice');
var opt = {
  margin:       .5,
  filename:     'invoice.pdf',
  image:        { type: 'jpeg', quality: 0.98 },
  html2canvas:  { scale: 2 },
  jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
};

// New Promise-based usage:
html2pdf().from(element).set(opt).save();
});
</script>
<?php } ?>
<style type="text/css">
	@media print {
    @page { size: auto;  margin: 0mm; }
}
</style>
