<?php
/**
 * Template for Email Invoices
 *
 * @since 1.8.6
 */
?>
<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center">
		<thead>
			<tr><td style=" padding: 25px 0 0;text-align: center"><a><img src="<?php echo site_url(); ?>/wp-content/uploads/logo-mailer.png" alt="logo-mailer"></a></td></tr>
		<tr>
		<td>
		<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
		<tr>
		<td style=" text-align: center; color: #fff;">
		<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Receipt for NSTXL membership</p>
		</td>
		</tr>
		</table>
		</td>
		</tr>
		</thead>
		<tbody>
		<tr>
<td >

<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
<tr>
<td>

<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;"><?php echo __('Thank you for your membership to !!sitename!!. Below is your Receipt for order #:', 'paid-memberships-pro' ) . '&nbsp;' . $order->code; ?></p>

	<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;"><?php echo __('Receipt #: ', 'paid-memberships-pro' ) . '&nbsp;' . $order->code; ?></p>
<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">
			<?php echo __( 'Date:', 'paid-memberships-pro' ) . '&nbsp;' . date_i18n(get_option('date_format'), $order->timestamp);?></p>

	<?php if(!empty($order->billing->name)): ?>
		<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">
				<strong><?php _e( 'Bill to:', 'paid-memberships-pro' ); ?></strong><br>
				<?php
					echo pmpro_formatAddress(
						$order->billing->name,
						$order->billing->street,
						"",
						$order->billing->city,
						$order->billing->state,
						$order->billing->zip,
						$order->billing->country,
						$order->billing->phone
					); 
				?>
				<?php endif; ?>
	</p>
	<tr>
		<td colspan="2">
			<table style="width:100%;border-width:1px;border-style:solid;border-collapse:collapse;">
				<tr style="border-width:1px;border-style:solid;border-collapse:collapse;">
					<th style="text-align:center;border-width:1px;border-style:solid;border-collapse:collapse;"><?php _e('ID', 'paid-memberships-pro' ); ?></th>
					<th style="border-width:1px;border-style:solid;border-collapse:collapse;"><?php _e('Item', 'paid-memberships-pro' ); ?></th>
					<th style="border-width:1px;border-style:solid;border-collapse:collapse;"><?php _e('Price', 'paid-memberships-pro' ); ?></th>
				</tr>
				<tr style="border-width:1px;border-style:solid;border-collapse:collapse;">
					<td style="text-align:center;border-width:1px;border-style:solid;border-collapse:collapse;"><?php echo $level->id; ?></td>
					<td style="border-width:1px;border-style:solid;border-collapse:collapse;"><?php echo $level->name; ?></td>
					<td style="text-align:right;"><?php echo $order->subtotal; ?></td>
				</tr>
				<tr style="border-width:1px;border-style:solid;border-collapse:collapse;">
					<th colspan="2" style="text-align:right;border-width:1px;border-style:solid;border-collapse:collapse;"><?php _e('Subtotal', 'paid-memberships-pro' ); ?></th>
					<td style="text-align:right;border-width:1px;border-style:solid;border-collapse:collapse;"><?php echo $order->subtotal; ?></td>
				</tr>
				<tr style="border-width:1px;border-style:solid;border-collapse:collapse;">
					<th colspan="2" style="text-align:right;border-width:1px;border-style:solid;border-collapse:collapse;"><?php _e('Tax', 'paid-memberships-pro' ); ?></th>
					<td style="text-align:right;border-width:1px;border-style:solid;border-collapse:collapse;"><?php echo $order->tax; ?></td>
				</tr>
				<tr style="border-width:1px;border-style:solid;border-collapse:collapse;">
					<th colspan="2" style="text-align:right;border-width:1px;border-style:solid;border-collapse:collapse;"><?php _e('Total', 'paid-memberships-pro' ); ?></th>
					<th style="text-align:right;border-width:1px;border-style:solid;border-collapse:collapse;"><?php echo pmpro_formatPrice($order->total); ?></th>
				</tr>
			</table>
	

