=== Duplicate Page and Post ===
Contributors: pluspt2001
Donate link: http://wordpresshowtos.blogspot.com/2015/10/duplicate-page-plugin.html
Tags: duplicate, duplication, Post, posts, clone page, clone post, duplicate page and post, page duplicator, post duplicator, duplicate post, duplicate page
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Duplicate Page and Post plugin creates a duplicate of page or posts quickly

== Description ==
This plugin can be really useful as you don't have to do the styling of a page from scratch and you can create replica or clone of a post or post with one click.

Installation Guide
https://vimeo.com/143097324

Important Link (Support)
I give full support to my clients so catch up with me 

	http://wordpresshowtos.blogspot.com/2015/10/duplicate-page-or-post-plugin.html

Major features of this plugin include:

*   Create duplicate of a page retaining all the styling and content and title
*   Create duplicate of a post retaining all the styling and content and title

How to Use and Install

	* Install and Activate the plugin
	* To clone pages just go to all pages on your dashboard and then hover cursor over a page and click on "Clone Me" option
	* To clone posts just go to all posts under posts in your dashboard and then hover cursor over a post to see an option called "Clone Me" ... just click on it and you'll be redirected to draft copy of it. Just change and click save.

About

	The Duplicate Page and Post plugin is maintained by http://wordpresshowtos.blogspot.com/2015/10/duplicate-page-plugin.html

== Installation ==

Below are the steps to install New Page Link plugin

* Upload plugin to the `/wp-content/plugins/` directory
* Activate the plugin through the 'Plugins' menu in WordPress
* Now go to all pages or all posts page on your dashboard
* Hover your cursor over any page on all page or on any post on all post section ... you'll see a "Clone Me" Button
* Just Click on this button to clone your page which will retain all the css and html styling of your previous page.

== Frequently Asked Questions ==
 
= How to create the duplicate of a page or a post ? =

* Activate the plugin through the 'Plugins' menu in WordPress
* Now go to all pages or all posts page on your dashboard
* Hover your cursor over any page on all page or on any post on all post section ... you'll see a "Clone Me" Button
* Just Click on this button to clone your page which will retain all the css and html styling of your previous page.

== Changelog ==
 
= 1.0 =
*   First release
= 1.1 =
*   First release
 
== Upgrade Notice ==
 
There is no need to upgrade just yet.
 
== Screenshots ==

1. screenshot-1.png
2. icon-128x128.png
3. banner-720x250.png