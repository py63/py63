<?php
/**
 * Tsemplate Name: Add Members
 */
global $wpdb, $current_user;
if (!is_user_logged_in() && !pmpro_hasMembershipLevel('6') || !pmpro_hasMembershipLevel('Incubator')) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
?>
<div class="addsponsor-container">
  <div class="clearfix page-header-wrapper">
    <h3 class="rgs_title clearfix"><?php _e(the_title(), 'paid-memberships-pro'); ?></h3>
  </div> 
  <div class="addsponsor-form-container">
    <form method="post" class="addsponsor-form" enctype="multipart/form-data" name="addsponsor" id="addsponsor">
      <div class="row">
        <div class="form-group col-lg-12 col-md-12"> 
          <label for="first_name"><?php _e('First Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="first_name" required type="text">          
        </div>
        <div class="form-group col-lg-12 col-md-12">             
          <label for="last_name"><?php _e('Last Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="last_name" required type="text">
        </div>
      </div>
      <div class="row">
        <div class="form-group col-lg-12 col-md-12">          
          <label for="semail"><?php _e('Email', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="semail" required type="email">
        </div> 
        <div class="form-group col-lg-12 col-md-12">
          <label for="username"><?php _e('Username', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="username" type="text">          
        </div> 
      </div>
      <div class="row">
        <div class="form-group col-lg-12 col-md-12">          
          <label for="companyname"><?php _e('Company Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="companyname" type="text">          
        </div>      
      </div>     
      <div class="btn-group">
        <button type="submit" class="btn btn-txt mt-4" name="addsponsor-save"><?php _e('Add Company', 'paid-memberships-pro'); ?></button>
      </div>
    </form>
  </div>
</div>
<?php /* ?>
  <!-- Modal -->
  <div class="modal fade" id="add-sponsor-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-body">
  <button type="button" class="close" aria-hidden="true">&times;</button>
  <div class="add-sponsor-modal-success-container">
  <p>Member has been registred successfully.</p>
  </div>
  </div>
  <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
  </div>
  </div>
  <!-- /.modal -->
  <?php */ ?>
<?php
//Modal box add sponsor success message
//$add_sponsor_modalbox_success_modal_id = 'add-sponsor-modal-success';
//$add_sponsor_modalbox_success_modal_body_container_class = 'add-sponsor-modal-success-container';
//$add_sponsor_modalbox_success_content_html = '<h4>Company has been registered successfully.</h4> ';
//nstxl_modal_popup($add_sponsor_modalbox_success_content_html, $add_sponsor_modalbox_success_modal_id, $add_sponsor_modalbox_success_modal_body_container_class);
?>  
<script>
  jQuery(document).ready(function ($) {
    jQuery('.pmpro_asterisk').remove();
    var redirectUrl = siteurl + '/your-sponsored-companies';
    $("#addsponsor").validate({
      rules: {
        first_name: {
          required: true,
        },
        action: "required",
        last_name: {
          required: true,
        },
        companyname: {
          required: true,
          remote: {
            url: nstxl_ajaxurl,
            type: 'post',
            data: {
              action: 'nstxl_check_userbemail',
              companyname: function () {
                return jQuery.trim($("input[name='companyname']").val());
              }
            },
          }
        },
        semail: {
          required: true,
         // validemail: true,
          remote: {
            url: nstxl_ajaxurl,
            type: 'post',
            data: {
              action: 'nstxl_check_userbemail',
              semail: function () {
                return $(".addsponsor-form-container input[name='semail']").val();
              }
            },
          }
        },
        username: {
          required: true,
          remote: {
            url: nstxl_ajaxurl,
            type: 'post',
            data: {
              action: 'nstxl_check_userbemail',
              username: function () {
                return $("input[name='username']").val();
              }
            },
          }
        },
      },
      messages: {
        first_name: {
          required: "Please enter the First Name",
        },
        last_name: {
          required: "Please enter the Last Name",
        },
        companyname: {
          required: "Please enter the Company Name",
          remote: 'Good news. This company is already a member. Please choose another firm to sponsor.'
        },
        semail: {
          required: "Please enter the Email",
          //validemail: "Please enter the valid Email",
          remote: 'Email is already taken.'
        },
        username: {
          required: "Please enter the Username",
          remote: 'Username is already taken.'
        }
      },
      errorClass: "form-invalid",
      errorElement: 'div',
      highlight: function (element, errorClass, validClass) {
        $(element).closest("div.field").addClass("error").removeClass("success");
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).closest(".error").removeClass("error").addClass("success");
      },
      errorPlacement: function (error, element) {

        if (element.parent().find("div.help-block.with-errors").length === 0) {
          if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
            element.parent().append(error);
          } else {
            error.addClass("help-block with-errors").appendTo(element.closest('div.form-group'));
          }
        } else {
          if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
            element.parent().append(error);
          } else {
            error.appendTo(element.parent().find("div.help-block.with-errors"));
          }
        }
      },
      submitHandler: function (form) {
        var form = jQuery('form#addsponsor')[0];
        var formData = new FormData(form);
        formData.append("action", "nstxl_add_single_sponsor");
        $.ajax({
          url: nstxl_ajaxurl,
          type: "POST",
          data: formData,
          beforeSend: function () {
            jQuery('.preloader').fadeIn();
          },
          success: function (response, textStatus, jqXHR) {
            jQuery('.preloader').fadeOut();
            jQuery('#add-scompany-modal-success').modal('hide');
            if (response.data.response == "success") {
              jQuery('#add-sponsor-modal-success  .add-sponsor-modal-success-container').html('<h4>' + response.data.msg + '</h4>');
              jQuery('#add-sponsor-modal-success').modal('show');
            }
            if (response.data.response == "error") {
              jQuery('#add-sponsor-modal-success  .add-sponsor-modal-success-container').html('<p style="color:red">' + response.data.msg + '</p>');
              var redirectUrl = siteurl + '/add-sponsor';
              jQuery('#add-sponsor-modal-success').modal('show');
            }

          },
          error: function (jqXHR, textStatus, errorThrown) {
            add_message(textStatus, "danger");
          },
          complete: function () {
            form.reset();
          },
          cache: false,
          contentType: false,
          processData: false
        });
      }
    });
    jQuery('.close').on('click', function (e) {
      jQuery('#add-sponsor-modal-success').modal('hide');
    });
    jQuery('#add-sponsor-modal-success').on('hidden.bs.modal', function () {
      window.location.href = redirectUrl;
    });
  });
</script>  