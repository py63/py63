<?php
/**
 * Template Name: Edit Company Profile
 *
 * @package OnePress
 */
global $wpdb, $current_user;
global $gateway, $pmpro_review, $skip_account_fields, $pmpro_paypal_token, $wpdb, $current_user, $pmpro_msg, $pmpro_msgt, $pmpro_requirebilling, $pmpro_level, $pmpro_levels, $tospage, $pmpro_show_discount_code, $pmpro_error_fields;
global $username, $bfirstname, $blastname, $baddress1, $baddress2, $bcity, $bstate, $bzipcode, $bcountry, $bphone, $bemail;
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
if (is_user_logged_in() && empty(nstxl_is_poc($current_user->ID))) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
get_header('admin');
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');

if(!empty($current_user)){
  $cur_id = $current_user->ID;
  $name_on_card = get_user_meta($cur_id,'name_on_card',true);
  if(empty($bfirstname)) {
    $bfirstname = $current_user->user_firstname;
  }
  if(empty($blastname)){
    $blastname = $current_user->user_lastname;
  }

//if( !empty($blastname)){
  $user_login = $current_user->user_login;
//}

  if(empty($bemail)){
    $bemail = $current_user->user_email;
  }

  if(empty($bconfirmemail)){
    $bconfirmemail = $current_user->user_email;
  }
  if(empty($username)){
    $username = $current_user->user_login;
  }
  if( !empty($cur_id) ) {
    $datitle = get_user_meta($cur_id,'datitle',true);
    $business_duns = get_user_meta($cur_id,'business_duns',true);
    $cage_code = get_user_meta($cur_id,'cage_code',true);
    $corganization_type = get_user_meta($cur_id,'corganization_type',true);
    $cnumberofemployees = get_user_meta($cur_id,'cnumberofemployees',true);
    $annual_revenues = get_user_meta($cur_id,'annual_revenues',true);
    $publicly_traded = get_user_meta($cur_id,'publicly_traded',true);
    $ticker_symbol = get_user_meta($cur_id,'ticker_symbol',true);
    $current_technology_expertise = get_user_meta($cur_id,'current_technology_expertise',true);
    $technology_expertise_in_development = get_user_meta($cur_id,'technology_expertise_in_development',true);
    $technology_solutions_services = get_user_meta($cur_id,'technology_solutions_services',true);
    $products_services_offered = get_user_meta($cur_id,'products_services_offered',true);
    $are_you_start_up = get_user_meta($cur_id,'are_you_start_up',true);
    $is_your_website_live = get_user_meta($cur_id,'is_your_website_live',true);
    $have_you_incorporated = get_user_meta($cur_id,'have_you_incorporated',true);
    $how_are_you_financed = get_user_meta($cur_id,'how_are_you_financed',true);
    $traditional_or_non_traditional_govt_contractor = get_user_meta($cur_id,'traditional_or_non_traditional_govt_contractor',true);
    $call_apply = get_user_meta($cur_id,'call_apply',true);    
    $uploaded_doc_url = get_user_meta($cur_id,'uploaded_doc',true);
    $uploaded_doc_urdl = get_user_meta($cur_id,'uploaded_doc1',true);
    $incorporated_state = get_user_meta($cur_id,'incorporated_state',true);
    $website_live_url = get_user_meta($cur_id,'website_live_url',true);
    $uploaded_doc_path = get_user_meta($cur_id, "uploaded_doc_path",true);
    $uploaded_doc_url = get_user_meta($cur_id, "uploaded_doc",true);
    $uploaded_comp_url  = get_user_meta($cur_id, "uploaded_comp",true);
    $uploaded_comp_path = get_user_meta($cur_id, "uploaded_comp_path",true); 
    $have_your_company_logo = get_user_meta($cur_id, "have_your_company_logo",true);   

    $company_name = get_user_meta($cur_id, "company_name", true);  
  }

}
?>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">

    <?php get_sidebar('dashboard'); ?>

    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' );     ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>

              <div class="personal-info-container personal-profile-dashboard dashboard-bg-white company-container">
                <form method="post" class="pmpro_form" enctype="multipart/form-data" name="personal-info" id="personal-info">
                  <div class=""> 
                    <div class="person-name"><h2><?php if (!empty($company_name)) { echo $company_name; } ?></h2> </div>
                         <div id="step-2">
                      <h3 class="pt-3">Basic Info</h3>
                      <div id="form-step-1" role="form">
                        <div class="after_billing_fields">
                          <div class="row">
                            <?php do_action("pmpro_checkout_after_billing_fields");
                            ?>
                          </div></div>
                          <!-- Start step4 content -->
                          <div class="cprofile-container">
                            <div class="checkbox_container" style="display:none">
                              <?php /*  ?><h3>Company Profile</h3> <?php */ ?>
                              <p><b>Main point of Contact</b></p>
                              <label class="checkbox-inline">
                                <input type="checkbox" name="company_profile" value="yes" class="cprofile"/>
                                <span>if diffrent from the account owner</span>
                                <span class="checkmark"></span>
                              </label>
                            </div>
                            <div class="mainpoint row" id="pmpro_billing_address_fields" > 
                             <div class="col-sm-12">  <h3>Contact Info</h3></div>     
                             <div id="business_duns_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
                              <div class="form-group">
                                <label for="business_duns"  class="mb-2 mt-2"><?php _e('Business DUNS', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                                <input id="business_duns" name="business_duns" required type="text" value="<?php echo $business_duns; ?>">

                                <div class="help-block with-errors"></div>
                              </div>
                            </div> 
                            <div id="cage_code_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
                              <div class="form-group">
                              <div class="tooltip1"><small class="lite"><label for="CAGE Code" class="mb-2 mt-2"><?php _e('CAGE Code', 'paid-memberships-pro' );?> <img src="<?php echo nstxl_tooltip_icon; ?>" width="17px" height="17px"> </label> 
                                    <span class="tooltiptext1"> NSTXL is required to collect a Cage code for each member. Many firms have multiple cage codes. if your are one of those, we have you covered. You will be able to submit a proposal under any one of the your cage codes.</span>
                                  </small></div>  
                               <input id="cage_code" name="cage_code" type="text" value="<?php echo $cage_code; ?>">

                               <div class="help-block with-errors"></div>
                             </div>
                           </div>  
                           <div id="organization_type_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
                            <div class="form-group">
                              <label for="organization_type" class="mb-2 mt-2"><?php _e('Organization Type', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                              <select id="corganization_type" class="custom-select" name="corganization_type" required="" class="input custom-select">
                                <option  data-levelid="1" value="Corporate:_Less_than_$10M_Annual_Revenue" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Corporate:_Less_than_$10M_Annual_Revenue');
                                }
                                ?>>Corporate: Less than $10M Annual Revenue</option>
                                <option data-levelid="2" value="Corporate:_$10M-$50M_Annual_Revenue" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Corporate:_$10M-$50M_Annual_Revenue');
                                }
                                ?>>Corporate: $10M-$50M Annual Revenue</option>
                                <option data-levelid="3" value="Corporate:_$50M-$100M_Annual_Revenue" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Corporate:_$50M-$100M_Annual_Revenue');
                                }
                                ?> >Corporate: $50M-$100M Annual Revenue</option>
                                <option data-levelid="4" value="Corporate:_More_than_$100M_Annual_Revenue" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Corporate:_More_than_$100M_Annual_Revenue');
                                }
                                ?>>Corporate: More than $100M Annual Revenue</option>
                                <option data-levelid="7" value="Non-Corporate:_College_or_University"  <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Non-Corporate:_College_or_University');
                                }
                                ?>>Non-Corporate: College or University</option>
                                <option data-levelid="8" value="Non-Corporate:_Laboratory" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Non-Corporate:_Laboratory');
                                }
                                ?>>Non-Corporate: Laboratory</option>
                                <option data-levelid="6" value="Non-Corporate:_Technology_Incubator_or_Accelerator" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Non-Corporate:_Technology_Incubator_or_Accelerator');
                                }
                                ?>>Non-Corporate: Technology Incubator or Accelerator</option>
                                <option data-levelid="9" value="Non-Corporate:_Investor" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Non-Corporate:_Investor');
                                }
                                ?>>Non-Corporate: Investor</option>
                                <option data-levelid="5" value="Non-Profit:_Less_than_$50M_Annual_ Revenue" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Non-Profit:_Less_than_$50M_Annual_ Revenue');
                                }
                                ?>>Non-Profit: Less than $50M Annual Revenue</option>
                                <option data-levelid="10" value="Non-Profit:_$50M-$100M_Annual_Revenue" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Non-Profit:_$50M-$100M_Annual_Revenue');
                                }
                                ?>>Non-Profit:$50M-$100M Annual Revenue</option>

                                <option data-levelid="11" value="Non-Profit:_More_than_$100M_Annual_Revenue" <?php
                                if (!empty($corganization_type)) {
                                  selected($corganization_type, 'Non-Profit:_More_than_$100M_Annual_Revenue');
                                }
                                ?>>Non-Profit:More than $100M Annual Revenue</option>
                              </select>

                              <div class="help-block with-errors"></div>
                            </div>
                            <div class="organization_type_toggle" style="display:none">
                              <div id="selectall_div" class="pmpro_checkout-field form-group">
                                <div class="form-group">
                                  <label for="call_apply"><?php _e('Additional Details', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                                  <select id="call_apply" name="call_apply[]" required multiple="multiple" class="input custom-select">
                                    <option value="small_business" <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, 'small_business');
                                    }
                                    ?>>Small Business</option>
                                    <option value="HUBZone"  <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, 'HUBZone');
                                    }
                                    ?>>HUBZone</option>
                                    <option value="Women-owned"  <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, 'Women-owned');
                                    }
                                    ?>>Women-owned</option>
                                    <option value="SDVOSB" <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, 'SDVOSB');
                                    }
                                    ?>>SDVOSB</option>
                                    <option value="Minority-owned" <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, 'Minority-owned');
                                    }
                                    ?>>Minority-owned</option>
                                    <option value="<$50M_of_work_with_DoD_last_year" <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, '<$50M_of_work_with_DoD_last_year');
                                    }
                                    ?>><$50M of work with DoD last year</option>
                                    <option value="Synthetic_Terrain" <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, 'Synthetic_Terrain');
                                    }
                                    ?>>Synthetic Terrain</option>
                                    <option value="Other" <?php
                                    if (!empty($call_apply)) {
                                      echo nstxl_multiselect_selected($call_apply, 'Other');
                                    }
                                    ?>>Other</option>
                                  </select>

                                  <div class="help-block with-errors"></div>
                                </div>
                              </div> 
                            </div>
                          </div>

                          <div id="numberofemployees_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
                            <div class="form-group">
                              <label for="cnumberofemployees" class="mb-2 mt-2"><?php _e('Number Of Employees', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                              <select id="cnumberofemployees" name="cnumberofemployees" required="" class="input custom-select">
                                <option value="">Number Of Employees</option>
                                <option value="1-19_Employees" <?php
                                if (!empty($cnumberofemployees)) {
                                  selected($cnumberofemployees, '1-19_Employees');
                                }
                                ?>>1-19 Employees</option>
                                <option value="20-99_Employees" <?php
                                if (!empty($cnumberofemployees)) {
                                  selected($cnumberofemployees, '20-99_Employees');
                                }
                                ?>>20-99 Employees</option>
                                <option value="100-499_Employees"  <?php
                                if (!empty($cnumberofemployees)) {
                                  selected($cnumberofemployees, '100-499_Employees');
                                }
                                ?>>100-499 Employees</option>
                                <option value="500-2,499_Employees" <?php
                                if (!empty($cnumberofemployees)) {
                                  selected($cnumberofemployees, '500-2,499_Employees');
                                }
                                ?>>500-2,499 Employees</option>
                                <option value="5,000+_Employees" <?php
                                if (!empty($cnumberofemployees)) {
                                  selected($cnumberofemployees, '5,000+_Employees');
                                }
                                ?>>5,000+ Employees</option>
                              </select>

                              <div class="help-block with-errors"></div>
                            </div>
                          </div>  
                          <div id="publicly_traded_div" class="pmpro_checkout-field col-sm-12 clearfix">            
                           <label class="mb-2 mt-2"><?php _e('Is your firm publicly traded?', 'paid-memberships-pro'); ?></label>
                            <label class="pmprorh_checkbox_label checkbox" for="publicly_traded">      
                              <input name="publicly_traded" value="yes" class="publicly_traded" type="radio" <?php
                              if (!empty($publicly_traded)) {
                                checked($publicly_traded, 'yes');
                              }
                              ?>>&nbsp;<?php _e('Yes', 'paid-memberships-pro'); ?></input>
                              &nbsp;&nbsp;<input name="publicly_traded" value="no" class="publicly_traded" type="radio" <?php
                              if (!empty($publicly_traded)) {
                                checked($publicly_traded, 'no');
                              }
                              ?>>&nbsp;<?php _e('No', 'paid-memberships-pro'); ?></input>
                            </label>
                            <div class="publicly_traded_toggle clearfix"  <?php
                            if ($publicly_traded == 'yes') {
                              echo 'style="display:block"';
                            } else {
                              echo 'style="display:none"';
                            }
                            ?>>            
                            <div class="pmpro_checkout-field pmpro_checkout-field-tricker-symbol mt-4">
                              <label class="mb-2 mt-2"><?php _e('Ticker Symbol?', 'paid-memberships-pro'); ?></label>
                              <div class="form-group">
                                <input id="ticker_symbol" pattern="^[_A-z0-9]{1,}$" name="ticker_symbol" type="text" class="input" size="30" value="<?php echo $ticker_symbol; ?>">
                                <label class="pmprorh_checkbox_label checkbox mb-2 mt-2" for="ticker_symbol"><?php _e('Please enter your Stock Symbol', 'paid-memberships-pro'); ?></label>
                                <div class="help-block with-errors"></div>
                              </div>
                            </div>
                          </div><div>
                            <div id="are_you_start_up_div" class="pmpro_checkout-field clearfix">
                            <label class="mb-2 mt-2"><?php _e('Is your firm a start-up?', 'paid-memberships-pro'); ?></label> 
                              <label class="pmprorh_checkbox_label checkbox" for="are_you_start_up">
                                <input name="are_you_start_up" <?php checked($are_you_start_up, 'yes'); ?> value="yes" class="are_you_start_up" type="radio">&nbsp;<?php _e('Yes', 'paid-memberships-pro'); ?></input>
                                &nbsp;&nbsp;<input name="are_you_start_up" <?php checked($are_you_start_up, 'no'); ?> value="no" class="are_you_start_up" type="radio">&nbsp;<?php _e('No', 'paid-memberships-pro'); ?></input>
                              </label>
                            </div>
                            <div id="are_you_start_up_toggle_div" class="pmpro_checkout-field" <?php
                            if ($are_you_start_up == 'yes') {
                              echo 'style="display:block"';
                            } else {
                              echo 'style="display:none"';
                            }
                            ?>>
                            <p class="mb-2 mt-2" >We love working with start-ups!  But to verify that your firm meets the criteria for membership, we need a bit more information.</p>

                            <div id="have_you_incorporated_div" class="clearfix">
                              <label class="pmprorh_checkbox_label checkbox" for="have_you_incorporated"><input name="have_you_incorporated" value="yes" id="have_you_incorporated" type="checkbox" <?php checked($have_you_incorporated, 'yes'); ?>><span>Have you incorporated?  If so, in what state and under what name?</span><span class="checkmark"></span></label>
                              <div class="have_you_incorporated_div_toggle" style="display:none">
                                <div class="pmpro_checkout-field pmpro_checkout-field-have-you-incorporated">
                                  <div class="form-group">
                                    <label for="incorporated_state"  class="mb-2 mt-2" >State of Incorporation</label>
                                    <select id="incorporated_state" name="incorporated_state" class="custom-select ">
                                      <option value=""><?php _e('State of Incorporation', 'paid-memberships-pro'); ?></option>
                                      <option value="AL" <?php selected($incorporated_state, 'AL'); ?> >Alabama</option>
                                      <option value="AK" <?php selected($incorporated_state, 'AK'); ?>>Alaska</option>
                                      <option value="AZ" <?php selected($incorporated_state, 'AZ'); ?>>Arizona</option>
                                      <option value="AR" <?php selected($incorporated_state, 'AR'); ?>>Arkansas</option>
                                      <option value="CA" <?php selected($incorporated_state, 'CA'); ?>>California</option>
                                      <option value="CO" <?php selected($incorporated_state, 'CO'); ?>>Colorado</option>
                                      <option value="CT" <?php selected($incorporated_state, 'CT'); ?>>Connecticut</option>
                                      <option value="DE" <?php selected($incorporated_state, 'DE'); ?>>Delaware</option>
                                      <option value="DC" <?php selected($incorporated_state, 'DC'); ?>>District Of Columbia</option>
                                      <option value="FL" <?php selected($incorporated_state, 'FL'); ?>>Florida</option>
                                      <option value="GA" <?php selected($incorporated_state, 'GA'); ?>>Georgia</option>
                                      <option value="HI" <?php selected($incorporated_state, 'HI'); ?>>Hawaii</option>
                                      <option value="ID" <?php selected($incorporated_state, 'ID'); ?>>Idaho</option>
                                      <option value="IL" <?php selected($incorporated_state, 'IL'); ?>>Illinois</option>
                                      <option value="IN" <?php selected($incorporated_state, 'IN'); ?>>Indiana</option>
                                      <option value="IA" <?php selected($incorporated_state, 'IA'); ?>>Iowa</option>
                                      <option value="KS" <?php selected($incorporated_state, 'KS'); ?>>Kansas</option>
                                      <option value="KY" <?php selected($incorporated_state, 'KY'); ?>>Kentucky</option>
                                      <option value="LA" <?php selected($incorporated_state, 'LA'); ?>>Louisiana</option>
                                      <option value="ME" <?php selected($incorporated_state, 'ME'); ?>>Maine</option>
                                      <option value="MD" <?php selected($incorporated_state, 'MD'); ?>>Maryland</option>
                                      <option value="MA" <?php selected($incorporated_state, 'MA'); ?>>Massachusetts</option>
                                      <option value="MI" <?php selected($incorporated_state, 'MI'); ?>>Michigan</option>
                                      <option value="MN" <?php selected($incorporated_state, 'MN'); ?>>Minnesota</option>
                                      <option value="MS" <?php selected($incorporated_state, 'MS'); ?>>Mississippi</option>
                                      <option value="MO" <?php selected($incorporated_state, 'MO'); ?>>Missouri</option>
                                      <option value="MT" <?php selected($incorporated_state, 'MT'); ?>>Montana</option>
                                      <option value="NE" <?php selected($incorporated_state, 'NE'); ?>>Nebraska</option>
                                      <option value="NV" <?php selected($incorporated_state, 'NV'); ?>>Nevada</option>
                                      <option value="NH" <?php selected($incorporated_state, 'NH'); ?>>New Hampshire</option>
                                      <option value="NJ" <?php selected($incorporated_state, 'NJ'); ?>>New Jersey</option>
                                      <option value="NM" <?php selected($incorporated_state, 'NM'); ?>>New Mexico</option>
                                      <option value="NY" <?php selected($incorporated_state, 'NY'); ?>>New York</option>
                                      <option value="NC" <?php selected($incorporated_state, 'NC'); ?>>North Carolina</option>
                                      <option value="ND" <?php selected($incorporated_state, 'ND'); ?>>North Dakota</option>
                                      <option value="OH" <?php selected($incorporated_state, 'OH'); ?>>Ohio</option>
                                      <option value="OK" <?php selected($incorporated_state, 'OK'); ?>>Oklahoma</option>
                                      <option value="OR" <?php selected($incorporated_state, 'OR'); ?>>Oregon</option>
                                      <option value="PA" <?php selected($incorporated_state, 'PA'); ?>>Pennsylvania</option>
                                      <option value="RI" <?php selected($incorporated_state, 'RI'); ?>>Rhode Island</option>
                                      <option value="SC" <?php selected($incorporated_state, 'SC'); ?>>South Carolina</option>
                                      <option value="SD" <?php selected($incorporated_state, 'SD'); ?>>South Dakota</option>
                                      <option value="TN" <?php selected($incorporated_state, 'TN'); ?>>Tennessee</option>
                                      <option value="TX" <?php selected($incorporated_state, 'TX'); ?>>Texas</option>
                                      <option value="UT" <?php selected($incorporated_state, 'UT'); ?>>Utah</option>
                                      <option value="VT" <?php selected($incorporated_state, 'VT'); ?>>Vermont</option>
                                      <option value="VA" <?php selected($incorporated_state, 'VA'); ?>>Virginia</option>
                                      <option value="WA" <?php selected($incorporated_state, 'WA'); ?>>Washington</option>
                                      <option value="WV" <?php selected($incorporated_state, 'WV'); ?>>West Virginia</option>
                                      <option value="WI" <?php selected($incorporated_state, 'WI'); ?>>Wisconsin</option>
                                      <option value="WY" <?php selected($incorporated_state, 'WY'); ?>>Wyoming</option>
                                      <option value="outside_us" <?php selected($incorporated_state, 'outside_us'); ?>>Outside the United States</option>
                                    </select>

                                  </div>
                                </div>
                              </div>
                            </div>
                            <div id="how_are_you_financed_div" class="pmpro_checkout-field"> 
                                     <label for="how_are_you_financed" class="mb-2 mt-2">How are you financed?</label>             
                              <select id="how_are_you_financed" multiple  name="how_are_you_financed[]" class="input custom-select">
                                <option value="">How are you financed?</option>
                                <option value="Self-financed" <?php
                                if (!empty($how_are_you_financed)) {
                                  nstxl_multiselect_selected($how_are_you_financed, 'Self-financed');
                                }
                                ?> >Self-financed</option>>Self-financed</option>
                                <option value="Venture capital" <?php
                                if (!empty($how_are_you_financed)) {
                                  nstxl_multiselect_selected($how_are_you_financed, 'Venture capital');
                                }
                                ?>>Venture capital</option>
                                <option value="Angel financing" <?php
                                if (!empty($how_are_you_financed)) {
                                  nstxl_multiselect_selected($how_are_you_financed, 'Angel financing');
                                }
                                ?>>Angel financing</option>
                                <option value="Loans" <?php
                                if (!empty($how_are_you_financed)) {
                                  nstxl_multiselect_selected($how_are_you_financed, 'Loans');
                                }
                                ?>>Loans</option>
                                <option value="Friends and family" <?php
                                if (!empty($how_are_you_financed)) {
                                  nstxl_multiselect_selected($how_are_you_financed, 'Friends and family');
                                }
                                ?>>Friends and family</option>
                              </select>
                     
                            </div>
                          </div>
                        </div>
                      </div>

                      <div id="technology_solutions_or_services_div" class="pmpro_checkout-field col-sm-12 mt-3">
                        <div class="form-group">
                          <label for="technology_solutions_services" class="mb-2 mt-2" >Tell us more about your firm.</label>
                          <textarea id="technology_solutions_or_services" name="technology_solutions_services" rows="2" cols="60" class="input text" ><?php echo $technology_solutions_services; ?></textarea>

                        </div>
                        <div class="help-block with-errors"></div>
                      </div>  

                      <!-- Start of Have your company logo section-->
                      <div id="have_your_company_logo_div" class="pmpro_checkout-field col-md-12 clearfix">
                        <label class="pmprorh_checkbox_label checkbox" for="have_your_company_logo"><input name="have_your_company_logo" value="yes" id="have_your_company_logo" type="checkbox" <?php
                        if (!empty($have_your_company_logo)) {
                          checked($have_your_company_logo, 'yes');
                        }
                        ?>><span class="checkmark_text"><?php _e('Check here to have your company name and/or logo appear on our Membership page', 'paid-memberships-pro'); ?></span><span class="checkmark"></span></label>
                        <div class="have_your_company_logo_div_toggle1">
                          <div class="pmpro_checkout-field pmpro_checkout-field-is-have-your-company-logo mb-4 mt-4">
                            <a class="upload_comp_btn" href="#"><?php _e('Upload Your Company Logo', 'paid-memberships-pro'); ?></a>
                            <div class="ibenic_upload_message"></div>
                            <div id="ibenic_file_upload" class="file-upload" style="display:none;">
                              <input id="upload_comp_file" name="upload_comp_file" type="file" style="opacity:0;" style="display:none;">
                              <p class="ibenic_file_upload_text"></p>
                            </div> <!-- End ibenic_file_upload div-->

                            <div id="ibenic_comp_file_upload_preview" class="file-upload file-preview" <?php
                            if (empty($uploaded_comp_url)) {
                              echo 'style="display:none"';
                            }
                            ?> >
                            <div class="ibenic_comp_file_preview"><?php
                            if (!empty($uploaded_comp_url)) {
                              echo '<img src="' . $uploaded_comp_url . '" alt="Company Logo" title="Company Logo">';
                            }
                            ?> 
                          </div><!-- End ibenic_comp_file_preview div-->
                          <button data-fileurl="<?php
                          if (!empty($uploaded_comp_url)) {
                            echo $uploaded_comp_url;
                          }
                          ?>" class="ibenic_file_delete_comp btn btn-secondary">
                          <i class="fa fa-close"></i><?php //_e( 'Delete', 'paid-memberships-pro' );    ?>
                        </button> 
                        <input type="hidden" name="chk_comp_doc" id="chk_comp_doc">
                      </div><!-- End ibenic_file_upload_preview div-->
                    </div><!-- End pmpro_checkout-field-is-have-your-company-logo div-->
                  </div><!-- End have_your_company_logo_div_toggle div-->
                </div><!-- End of Have your company logo div-->
                <!-- End of Have your company logo section-->

              </div>
            </div><!--End step2 content-->
          </div>
        </div>
        <div class="btn-group">
          <button class="btn btn-txt pp-update" type="submit"><?php _e('Update', 'paid-memberships-pro'); ?></button>          
        </div>
      </form>
    </div>
  </div>

<?php /**
  <!-- Modal -->
<div class="modal fade custom-popup" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/assets/images/close-icon.svg"></span>
        </button>
           <p>Company profile has been updated.</p> 
       </div> 
     
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div> 
</div>  
**/?>

</div><!-- .entry-content -->
</article><!-- #post-## -->

<?php endwhile; // End of the loop.    ?>

</main><!-- #main -->
</div><!-- #primary -->



</div><!--#content-inside -->
</div><!-- #content -->      



<script type="text/javascript">
  jQuery.noConflict();
  (function( $ ) {
    jQuery(function() {
  jQuery("#technology_solutions_or_services").textareaCounter({ limit: 500 });       
      /*update edit profile*/
      $.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z\s]+$/i.test(value);
      }, "Letters only please");
      $.validator.addMethod("validemail", function(value, element) {
        return this.optional(element) || /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/i.test(value);
      }, "Enter a valid email only please");   
      $("#personal-info").validate({
        rules: {
          bfirstname: {
            required: true,
          },
          action: "required",
          bemail: {
            required: true,    
            validemail: true,      
            remote: {
              url: nstxl_ajaxurl,
              type: 'post',        
              data: {
                action: 'nstxl_check_userbemail',
                bemail: function () {
                  return $("input[name='bemail']").val();
                }
              },
            }         
          },
          blastname: {
           required: true,
         }, 
         bphone: {
           required: true,
         },
         baddress1: {
           required: true,
         },
         bcity: {
           required: true,
         },              
         user_name: {
          required: true,
          minlength: 5,
        },
      },
      messages: {      
        bemail: {
         required: "Please enter email",
         validemail:"Please enter valid email address",
         remote: 'Email is already taken.'
       }      
     },
     errorClass: "form-invalid",
   // errorLabelContainer:'.help-block.with-errors',
   errorElement: 'div',
   highlight: function(element, errorClass, validClass) {
    $(element).closest("div.field").addClass("error").removeClass("success");
  },
  unhighlight: function(element, errorClass, validClass){
    $(element).closest(".error").removeClass("error").addClass("success");
  },
  errorPlacement: function (error, element) {

    if(element.parent().find("div.help-block.with-errors").length === 0) {
      if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {          
        element.parent().append(error); 
      } else {

        error.addClass("help-block with-errors").appendTo( element.closest('div.form-group'));          
      }
    } else {
      if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
          element.parent().append(error); // this would append the label after all your checkboxes/labels (so the error-label will be the last element in <div class="controls"> )
        } else {
          error.appendTo(element.parent().find("div.help-block.with-errors"));
        }

      }
    },   
    submitHandler: function(form) {       
      var form = jQuery('form#personal-info')[0]; 
      var formData = new FormData(form);
      formData.append("action", "nstxl_update_personal_profile");     
      $.ajax({
        url: nstxl_ajaxurl,
        type: "POST",
        data: formData,
        async: false,
        beforeSend: function() {
          console.log('253512');
        // jQuery('.next-step-loader').css('display', 'block');
        $(".preloader").show();
        jQuery('.preloader').css('display', 'block'); 
      },        
      success: function (response, textStatus, jqXHR)
      {               
       if (response.data.response == "success") {
        jQuery('#update-personalinfo-modal-success').modal('show');
      }

    },
    error: function(jqXHR, textStatus, errorThrown) { 
      add_message( textStatus, "danger" );
    },
    complete: function(){
      $(".preloader").hide();        
    },
    cache: false,
    contentType: false,
    processData: false
  });
    }    
  });


      jQuery('.form-group.required').each( function(){
        jQuery(this).find('input').prop('required',true);
        jQuery(this).find('select').prop('required',true);
        if(jQuery(this).find('.help-block').length == 0) {
      //jQuery(this).find('input').after('<div class="help-block with-errors"></div>');
      jQuery(this).append('<div class="help-block with-errors"></div>');
    }
  }); 
    });
})(jQuery); 
</script>   
<?php $modal_id = 'update-personalinfo-modal-success';
  $modal_body_container_class  = 'update-personalinfo-modal-success-container';
  $content_html = '<h4>Company profile has been updated.</h4>';
   nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class); ?> 
<?php
get_footer('admin');
