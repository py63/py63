<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package OnePress
 */
$show_thumbnail = true;
if (get_theme_mod('onepress_hide_thumnail_if_not_exists', false)) {
  if (!has_post_thumbnail()) {
    $show_thumbnail = false;
  }
}
?>
<div class="card">
  <article id="post-<?php the_ID(); ?>" <?php post_class(array('list-article', 'clearfix')); ?>>
    <?php if ($show_thumbnail) { ?>
      <div class="list-article-thumb">
        <a href="<?php echo esc_url(get_permalink()); ?>">
          <?php
          if (has_post_thumbnail()) {
            //the_post_thumbnail( 'onepress-blog-small' );
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'onepress-blog-small');
            echo '<img class="card-img-top" data-src="' . $featured_img_url . '" alt="blog" style="height: 200px; width: 100%; display: block;" src="' . $featured_img_url . '" data-holder-rendered="true">';
          } else {
            echo '<img class="card-img-top" alt="placholder" src="' . get_template_directory_uri() . '/assets/images/placholder2.png' . '" data-holder-rendered="true">';
          }
          ?>
        </a>
      </div>
    <?php } ?>

    <div class="card-body">
      <h4 class="card-title"><?php
        $wordcount = str_word_count(get_the_title());
        if ($wordcount > 10) {
          ?> 
          <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo wp_trim_words(get_the_title(), 10, ''); ?></a>
        <?php } else { ?>
          <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo get_the_title(); ?></a>
        <?php } ?></h4>
      <h6 class="card-subtitle mb-2 text-muted"><?php echo get_the_date(); ?></h6>
      <div class="entry-excerpt"><p class="card-text"><?php echo wp_trim_words(get_the_content(), 12, ''); ?></p></div>
      <div class="readmore-button-section">
        <a class="btn btn-secondary-outline btn-lg" href="<?php echo esc_url(get_permalink()); ?>"><?php _e('Read More', 'onepress'); ?></a>
      </div> 
    </div>

  </article><!-- #post-## -->
</div>