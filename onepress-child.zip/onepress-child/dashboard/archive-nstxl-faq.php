<?php
global $wpdb, $current_user;
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
if (is_user_logged_in() && empty(nstxl_is_poc($current_user->ID))) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
get_header('admin');
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
//do_action('onepress_page_before_content');
$cat = get_queried_object(); 
?>
<div class="page-header">
 <div class="container">
 <h1 class="entry-title">Faqs</h1> </div>
 </div>
<div id="content" class="site-content">
  <?php
 // onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
   <?php get_sidebar('dashboard'); ?>
   <div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

      <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <header class="entry-header">
          <?php //the_title( '<h1 class="entry-title">', '</h1>' );   ?>
        </header><!-- .entry-header -->

        <div class="entry-content">
          <div class="faqs-container">
            <div class="form-01 archive-search">
             <?php
             $terms = get_terms(array(
              'taxonomy' => 'nstxl-faq-type',
              'hide_empty' => 'false',
               'parent' =>0
            ));
             echo '<select class="faqcategoryfilter custom-select" id="faqcategoryfilter" name="faqcategoryfilter"><option value="'.$cat->term_id.'">Select Category</option>';
             foreach ($terms as $term) :
              echo '<option id="searchfaqpost" value="' . $term->term_id . '">' . $term->name . '</option>';    
            endforeach;
            echo '</select>';
            ?>

            <form role="search" method="get" class="search-form faqcategorysearch" action="<?php echo get_bloginfo('url');?>/search-faqs/">  
              <input type="search" id="faqcategorysearch" class="faqcategorysearch-field" placeholder="<?php echo esc_attr_x('Search', 'placeholder', 'polar'); ?>" value="<?php echo get_search_query(); ?>" name="sa" />
              <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text"><?php echo _x('Search', 'submit button', 'polar'); ?></span></button>  
            </form>   
          </div>

          <!--   <div class="row"> -->
           <div class="faqs-container-archive faqs-dashboard dashboard-bg-white" >


            <h4><?php echo $cat->name;?></h4>  
            <?php 
            if(!empty($cat->description))
            {
              echo "<p>".$cat->description."</p>";   
            } 
            ?>

            <table width="100%">
             <thead> <tr>
              <th align="left">Title</th>
              <th align="right">Likes</th></thead>
              <tbody>

                <?php
                $args = array(
                  'post_type' => 'nstxl-faq',
                  'posts_per_page' => -1, 
                  'post_status' => 'publish',
                  'tax_query' => array(
                    array(
                      'taxonomy' => 'nstxl-faq-type',
                      'field' => 'term_id',
                      'terms' => array($cat->term_id),
                    )
                  )
                );
                query_posts( $args ); 

                if ( have_posts() ) : ?>
                  <?php
      // Start the Loop.
                  while ( have_posts() ) :
                    the_post(); 
                    $total_like = nstxl_faq_article_like_total(get_the_ID());  
                    ?>
                    <tr>
                      <td><a href="<?php the_permalink();?>"><?php the_title(); ?></a></td>  
                      <td align="right"><?php echo $total_like; ?></td> 
                    </tr>
                  <?php   endwhile;
           else : ?> 
                  <p class="mt-4">No FAQ's found.</p>   
              <?php endif; ?>   
              </tbody>
            </table>


            <p class="mt-4 small">Can't find what you're looking for? Try asking on our <a href="<?php echo get_bloginfo('url');?>/forums/">Forum</a></p>  
            

          </div>

        </div><!-- .entry-content -->
      </div>   
    </article><!-- #post-## -->


  </main><!-- #main -->
</div><!-- #primary -->



</div><!--#content-inside -->
</div><!-- #content -->  

<script type="text/javascript">
 jQuery(document).ready(function(){
   jQuery('#faqcategoryfilter').change(function () {
    var termid = jQuery(this).val();
    jQuery.ajax({
     url: nstxl_ajaxurl,
     type: 'post',
     cache: false,
     data: {termid:termid,action:'nstxl_faq_category_termid'},
     beforeSend: function () {  
       jQuery( '.nstxl-loader' ).show();
       jQuery( '.loader-overlay' ).show();
     },
     complete: function () {
       jQuery( '.nstxl-loader' ).hide();
       jQuery( '.loader-overlay' ).hide();
     },
     success: function(data){     
       jQuery('.faqs-dashboard').html(data);       
     }
   });

  });
 });
</script>   


<?php
get_footer('admin'); 

