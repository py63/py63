<?php

/**
 * Template Name: Engage & Collaborate
 *
 */

if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
get_header('admin');

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>

<script type="text/javascript">
	jQuery(document).ready(function($){
  
  // Remove empty fields from GET forms
  // Author: Bill Erickson
  // URL: http://www.billerickson.net/code/hide-empty-fields-get-form/
  
  	// Change 'form' to class or ID of your specific form
	$("form").submit(function() {
		$(this).find(":input").filter(function(){ return !this.value; }).attr("disabled", "disabled");
		return true; // ensure form still submits
	});
	
	// Un-disable form fields when page loads, in case they click back after submission
	$( "form" ).find( ":input" ).prop( "disabled", false );
	
});
</script>

<script>
jQuery(document).ready(function(){
  jQuery(".filter-button").click(function(){
	jQuery(this).toggleClass("gray-back");
    jQuery(".select-list").slideToggle();
  });
});

jQuery(function () {
  jQuery(".checkorgtype").change(function() {
    var val = jQuery(this).val();
    if(val === "1,2,3,4") {
        jQuery(".corporatesize").show();
        jQuery(".corporatesize").find('select').attr('name','l');
        jQuery(".nonprofitsize").hide();
        jQuery(".nonprofitsize").find('select').attr('name','ln');
    }
    else if(val === "5,10,11") {
        jQuery(".nonprofitsize").show();
        jQuery(".nonprofitsize").find('select').attr('name','l');
        jQuery(".corporatesize").hide();
        jQuery(".corporatesize").find('select').attr('name','ln');
    }
    else{
    	jQuery(".corporatesize").hide();
    	jQuery(".nonprofitsize").hide();
    	jQuery(".corporatesize").find('select').attr('name','ln');
    	jQuery(".nonprofitsize").find('select').attr('name','ln');
    }
  });
});
</script>

<?php
	//only admins can get this
	// if(!function_exists("current_user_can") || (!current_user_can("manage_options") && !current_user_can("pmpro_memberslist")))
	// {
	// 	die(__("You do not have permissions to perform this action.", 'paid-memberships-pro' ));
	// }

	//vars
	global $wpdb;
	if(isset($_REQUEST['sw']))
		$s = sanitize_text_field(trim($_REQUEST['sw']));
	else
		$s = "";

	if(isset($_REQUEST['doesorg']))
		$doesorg = sanitize_text_field(trim($_REQUEST['doesorg']));
	else
		$doesorg = "";

	if(isset($_REQUEST['otai']))
		$otai = sanitize_text_field(trim($_REQUEST['otai']));
	else
		$otai = "";	

	if(isset($_REQUEST['tnt']))
		$tnt = sanitize_text_field(trim($_REQUEST['tnt']));
	else
		$tnt = "";

	if(isset($_REQUEST['level']))
		$level = sanitize_text_field(trim($_REQUEST['level']));
	else
		$level = "";

	if(isset($_REQUEST['l']))
	{
		$level = sanitize_text_field(trim($_REQUEST['l']));
		$l = $level;
	}
	else{
		$level = $level;
		$l = '';
	}
	

	if(isset($_REQUEST['noe']))
		$noe = sanitize_text_field(trim($_REQUEST['noe']));
	else
		$noe = "";

	if(isset($_REQUEST['omc']))
		$omc = trim($_REQUEST['omc']);
	else
		$omc = "";

	if(isset($_REQUEST['soi']))
		$soi = sanitize_text_field(trim($_REQUEST['soi']));
	else
		$soi = "";

	if(isset($_REQUEST['cn']))
		$cn = sanitize_text_field(trim($_REQUEST['cn']));
	else
		$cn = "";

	if(isset($_REQUEST['howfin']))
		$howfin = sanitize_text_field(trim($_REQUEST['howfin']));
	else
		$howfin = "";


	if(isset($_REQUEST['startjoindate']))
		$startjoindate = sanitize_text_field($_REQUEST['startjoindate']);
	else
		$startjoindate = false;

	if(isset($_REQUEST['endjoindate']))
		$endjoindate = sanitize_text_field($_REQUEST['endjoindate']);
	else
		$endjoindate = false;

?>

<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  // [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
<?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area search-member">
      <main id="main" class="site-main" role="main">

		<div class="filterby-btndiv"><button class="filter-button"><i class="fas fa-filter"></i> Filter </button></div>
		<!-- Form Start -->
	 <form id="posts-filter" method="get" action="">
		<div class="row select-list" style="display: none">
   	<?php /*	 <div class="col-sm-12  col-lg-6 ipad-width">
			<li class="datesstart">
		    <script>
		    jQuery(document).ready(function($) {
		        $("#mjoindatefrom").datepicker(
		        	{ 
		        		dateFormat: 'M d, yy' 
		        	}

	        	);
	        	   $("#mjoindateto").datepicker(
		        	{ 
		        		dateFormat: 'M d, yy' 
		        	}
	        	);
		    });
			</script>
			<div class="keyword-searching form-grp-default">
				<label><?php _e('Date Joined', 'paid-memberships-pro' );?></label>
				<input type="text" id="mjoindatefrom" name="startjoindate" value="<?php echo $startjoindate; ?>" />
			</div>  
			</li>
		</div>
		<div class="col-sm-12  col-lg-6 ipad-width">
			<li class="dateend">
			<div class="keyword-searching form-grp-default">
				<label><?php _e('Expiration Date', 'paid-memberships-pro' );?></label>
				<input type="text" id="mjoindateto" name="endjoindate" value="<?php echo $endjoindate; ?>" />
			</div>
			</li>	

		</div> */?> 

			<div class="col-sm-12  col-lg-6 ipad-width">
			<li><div class="keyword-searching form-grp-default">
				<label><?php _e('Company Name', 'paid-memberships-pro' );?></label>
					<input id="post-search-input" type="text" value="<?php echo esc_attr($cn);?>" name="cn"/>
				</div>
			</li>
			<li>
				<label><?php _e('Traditional or Non Traditional Organization?', 'paid-memberships-pro' );?></label>
				<select name="tnt" class="custom-select">
					<option value="" <?php if(!$tnt) { ?>selected="selected"<?php } ?>><?php _e('Traditional or Non Traditional Organization?', 'paid-memberships-pro' );?></option>
					<option value="traditional" <?php if($tnt == "traditional") { ?>selected="selected"<?php } ?>><?php _e('Traditional', 'paid-memberships-pro' );?></option>
					<option value="non-traditional" <?php if($tnt == "non-traditional") { ?>selected="selected"<?php } ?>><?php _e('Non Traditional', 'paid-memberships-pro' );?></option>
				</select>
			
			</li>
			<li>
				<?php 
				if(isset($_GET['level'])) {
					$formlevel = $_GET['level'];
				} else{
					$formlevel = '';
				} 

					?>
					<label>	<?php _e('Organization Type', 'paid-memberships-pro' );?></label>
				 <select name="level" class="checkorgtype custom-select">
					<option value="" <?php if(!$formlevel) { ?>selected="selected"<?php } ?>>All Levels</option>

					<option value="1,2,3,4" <?php if($formlevel == '1,2,3,4' ) { ?>selected="selected"<?php } ?>><?php _e('Corporate', 'paid-memberships-pro' );?> </option>
					<option value="5,10,11" <?php if($formlevel == "5,10,11") { ?>selected="selected"<?php } ?>><?php _e('Non-profit', 'paid-memberships-pro' );?></option>
					<option class="orgsizehide" value="7" <?php if($formlevel == 7) { ?>selected="selected"<?php } ?>><?php _e('University', 'paid-memberships-pro' );?></option>
					<option class="orgsizehide" value="8" <?php if($formlevel == 8) { ?>selected="selected"<?php } ?>><?php _e('Laboratory', 'paid-memberships-pro' );?></option>
					<option class="orgsizehide" value="6" <?php if($formlevel == 6) { ?>selected="selected"<?php } ?>><?php _e('Incubator', 'paid-memberships-pro' );?></option>
					<option class="orgsizehide" value="9" <?php if($formlevel == 9) { ?>selected="selected"<?php } ?>><?php _e('Investor', 'paid-memberships-pro' );?></option>
			</select>
			
			</li>

			<li class="corporatesize" <?php if($formlevel == '1,2,3,4' ) { ?> style="display: block;" <?php } else { ?>style="display: none;" <?php } ?>>
				<label>	<?php _e('Organization Size (Revenue)', 'paid-memberships-pro' );?></label>
			 <select name="l" class="custom-select">
				<option value="" <?php if(!$l) { ?>selected="selected"<?php } ?>><?php _e('Organization Size', 'paid-memberships-pro' );?></option>
				<option value="1" <?php if($l == 1) { ?>selected="selected"<?php } ?>><?php _e('<$10M', 'paid-memberships-pro' );?></option>
				<option value="2" <?php if($l == 2) { ?>selected="selected"<?php } ?>><?php _e('$10-50M', 'paid-memberships-pro' );?></option>
				<option value="3" <?php if($l == 3) { ?>selected="selected"<?php } ?>><?php _e('$50-$100M', 'paid-memberships-pro' );?></option>
				<option value="4" <?php if($l == 4) { ?>selected="selected"<?php } ?>><?php _e('+$100M', 'paid-memberships-pro' );?></option>
				</select>
			</li>
			<li class="nonprofitsize" <?php if($formlevel == '5,10,11' ) { ?> style="display: block;" <?php } else { ?>style="display: none;" <?php } ?>>
				<label>	<?php _e('Organization Size (Revenue)', 'paid-memberships-pro' );?></label>
			 <select name="l" class="custom-select">
				<option value="" <?php if(!$l) { ?>selected="selected"<?php } ?>><?php _e('Organization Size', 'paid-memberships-pro' );?></option>
				<option value="5" <?php if($l == 5) { ?>selected="selected"<?php } ?>><?php _e('< $50M', 'paid-memberships-pro' );?></option>
				<option value="10" <?php if($l == 10) { ?>selected="selected"<?php } ?>><?php _e('$15-100M', 'paid-memberships-pro' );?></option>
				<option value="11" <?php if($l == 11) { ?>selected="selected"<?php } ?>><?php _e('+$100M', 'paid-memberships-pro' );?></option>
			</select>
			</li>
		
			<li>
				<label><?php _e('Number Of Employees', 'paid-memberships-pro' );?></label>
				<select name="noe" class="custom-select">
					<option value="" <?php if(!$noe) { ?>selected="selected"<?php } ?>><?php _e('Number Of Employees', 'paid-memberships-pro' );?></option>
					<option value="1-19_Employees" <?php if($noe == "1-19_Employees") { ?>selected="selected"<?php } ?>><?php _e('1-19 Employees', 'paid-memberships-pro' );?></option>
					<option value="20-99_Employees" <?php if($noe == "20-99_Employees") { ?>selected="selected"<?php } ?>><?php _e('20-99 Employees', 'paid-memberships-pro' );?></option>
					<option value="100-499_Employees" <?php if($noe == "100-499_Employees") { ?>selected="selected"<?php } ?>><?php _e('100-499 Employees', 'paid-memberships-pro' );?></option>
					<option value="500-2,499_Employees" <?php if($noe == "500-2,499_Employees") { ?>selected="selected"<?php } ?>><?php _e('500-2,499 Employees', 'paid-memberships-pro' );?></option>
					<option value="5,000+_Employees" <?php if($noe == "5,000+_Employees") { ?>selected="selected"<?php } ?>><?php _e('5,000+ Employees', 'paid-memberships-pro' );?></option>
				</select>
			</li>
			
		</div>
			<div class="col-sm-12 col-lg-6 ipad-width">
			<li>
				<label>	<?php _e('Other Member Characteristics', 'paid-memberships-pro' );?></label>
			  <select name="omc" class="custom-select">
					<option value="" <?php if(!$omc) { ?>selected="selected"<?php } ?>><?php _e('Please Select', 'paid-memberships-pro' );?></option>
					<option value="small_business" <?php if($omc == "small_business") { ?>selected="selected"<?php } ?>><?php _e('Small Business', 'paid-memberships-pro' );?></option>
					<option value="HUBZone" <?php if($omc == "HUBZone") { ?>selected="selected"<?php } ?>><?php _e('Hub-Zone', 'paid-memberships-pro' );?></option>
					<option value="Women-owned" <?php if($omc == "Women-owned") { ?>selected="selected"<?php } ?>><?php _e('Women-owned', 'paid-memberships-pro' );?></option>
					<option value="SDVOSB" <?php if($omc == "SDVOSB") { ?>selected="selected"<?php } ?>><?php _e('SDVOSB', 'paid-memberships-pro' );?></option>
					<option value="Minority-owned" <?php if($omc == "Minority-owned") { ?>selected="selected"<?php } ?>><?php _e('Minority-owned', 'paid-memberships-pro' );?></option>
					<option value="<$50M_of_work_with_DoD_last_year" <?php if($omc == "<$50M_of_work_with_DoD_last_year") { ?>selected="selected"<?php } ?>><?php _e('<$50M of work with DoD last year', 'paid-memberships-pro' );?></option>
					<option value="Synthetic_Terrain" <?php if($omc == "Synthetic_Terrain") { ?>selected="selected"<?php } ?>><?php _e('Synthetic Terrain', 'paid-memberships-pro' );?></option>
					<option value="Other" <?php if($omc == "Other") { ?>selected="selected"<?php } ?>><?php _e('Other', 'paid-memberships-pro' );?></option>
				
				</select>
			</li>	
			<li>
				<label>	<?php _e('OTA Interest', 'paid-memberships-pro' );?></label>
			  <select name="otai" class="custom-select">
					<option value="" <?php if(!$otai) { ?>selected="selected"<?php } ?>><?php _e('Please Select', 'paid-memberships-pro' );?></option>
					<option value="Training-Accelerator-TReX" <?php if($otai == "Training-Accelerator-TReX") { ?>selected="selected"<?php } ?>><?php _e('TReX', 'paid-memberships-pro' );?></option>
					<option value="DTIC-Energy" <?php if($otai == "DTIC-Energy") { ?>selected="selected"<?php } ?>><?php _e('DTIC', 'paid-memberships-pro' );?></option>
					<option value="Trusted-Electronics-S2MARTS" <?php if($otai == "Trusted-Electronics-S2MARTS") { ?>selected="selected"<?php } ?>><?php _e('S2MARTS', 'paid-memberships-pro' );?></option>
				
				</select>
			</li>
					<li>
				<label><?php _e('Technology Expertise', 'paid-memberships-pro' );?></label>
			  <select name="doesorg" class="custom-select">
					<option value="" <?php if(!$doesorg) { ?>selected="selected"<?php } ?>><?php _e('Please Select', 'paid-memberships-pro' );?></option>
					<option value="Artificial_Intelligence" <?php if($doesorg == "Artificial_Intelligence") { ?>selected="selected"<?php } ?>><?php _e('Artificial Intelligence', 'paid-memberships-pro' );?></option>
					<option value="Cloud_Computing" <?php if($doesorg == "Cloud_Computing") { ?>selected="selected"<?php } ?>><?php _e('Cloud Computing', 'paid-memberships-pro' );?></option>
					<option value="Cyber_Operations_&_Training" <?php if($doesorg == "Cyber_Operations_&_Training") { ?>selected="selected"<?php } ?>><?php _e('Cyber Operations & Training', 'paid-memberships-pro' );?></option>
					<option value="Instrumentation,_Test_&_Training" <?php if($doesorg == "Instrumentation,_Test_&_Training") { ?>selected="selected"<?php } ?>><?php _e('Instrumentation, Test & Training', 'paid-memberships-pro' );?></option>
					<option value="Medical_Modeling_&_Simulation" <?php if($doesorg == "Medical_Modeling_&_Simulation") { ?>selected="selected"<?php } ?>><?php _e('Medical Modeling & Simulation', 'paid-memberships-pro' );?></option>
					<option value="Gaming_Applications" <?php if($doesorg == "Gaming_Applications") { ?>selected="selected"<?php } ?>><?php _e('Gaming Applications' );?></option>
					<option value="Immersion_(VR/AR)" <?php if($doesorg == "Immersion_(VR/AR)") { ?>selected="selected"<?php } ?>><?php _e('Immersion (VR/AR)', 'paid-memberships-pro' );?></option>
					<option value="Synthetic_Terrain" <?php if($doesorg == "Synthetic_Terrain") { ?>selected="selected"<?php } ?>><?php _e('Synthetic Terrain', 'paid-memberships-pro' );?></option>
					<option value="high-energy-lasers" <?php if($doesorg == "high-energy-lasers") { ?>selected="selected"<?php } ?>><?php _e('High Energy Lasers', 'paid-memberships-pro' );?></option>
					<option value="hypersonics" <?php if($doesorg == "hypersonics") { ?>selected="selected"<?php } ?>><?php _e('Hypersonics', 'paid-memberships-pro' );?></option>
					<option value="logistics-software" <?php if($doesorg == "logistics-software") { ?>selected="selected"<?php } ?>><?php _e('Logistics Software', 'paid-memberships-pro' );?></option>
					<option value="machine-learning" <?php if($doesorg == "machine-learning") { ?>selected="selected"<?php } ?>><?php _e('Machine Learning', 'paid-memberships-pro' );?></option>
					<option value="multispectral-sensing" <?php if($doesorg == "multispectral-sensing") { ?>selected="selected"<?php } ?>><?php _e('Multispectral Sensing', 'paid-memberships-pro' );?></option>
					<option value="workforce-development" <?php if($doesorg == "workforce-development") { ?>selected="selected"<?php } ?>><?php _e('Workforce Development', 'paid-memberships-pro' );?></option>
					<option value="strategic-missions-hardware" <?php if($doesorg == "strategic-missions-hardware") { ?>selected="selected"<?php } ?>><?php _e('Strategic Missions Hardware', 'paid-memberships-pro' );?></option>
					<option value="Other" <?php if($doesorg == "Other") { ?>selected="selected"<?php } ?>><?php _e('Other', 'paid-memberships-pro' );?></option>
				</select>
			</li>
			<li><div class="keyword-searching form-grp-default">
				<label><?php _e('Search Keywords', 'paid-memberships-pro' );?></label>
					<input id="post-search-input" type="text" value="<?php echo esc_attr($s);?>" name="sw"/>
						
				</div>
			</li>
			
	</div>
	<div class="search-members-box col-sm-12">
		<button class="btn-txt polar_button polar-shape-square polar-size-custom polar-style-flat polar-icon-left" title="View More" target="_blank"><?php _e('Filter', 'paid-memberships-pro' );?></button>
	</div>
	</div>
	<?php


		$expirydate = date('Y-m-d', strtotime($endjoindate. "+1 days"));
		$datejoined = date('Y-m-d', strtotime($startjoindate));


		if(isset($_REQUEST['pn']))
			$pn = intval($_REQUEST['pn']);
		else
			$pn = 1;

		if(isset($_REQUEST['limit']))
			$limit = intval($_REQUEST['limit']);
		else
		{
			/**
			 * Filter to set the default number of items to show per page
			 * on the Members List page in the admin.
			 *
			 * @since 1.8.4.5
			 *
			 * @param int $limit The number of items to show per page.
			 */
			$limit = apply_filters('pmpro_memberslist_per_page', 15);
		}

		$end = $pn * $limit;
		$start = $end - $limit;
		$strrr = str_replace(' ','_', $s);


		if($s)
		{
			$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email, UNIX_TIMESTAMP(u.user_registered) as joindate, mu.membership_id, mu.initial_payment, mu.billing_amount, mu.cycle_period, mu.cycle_number, mu.billing_limit, mu.trial_amount, mu.trial_limit, UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership 
			FROM $wpdb->users u 
			
			LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id 
			

			LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id 
			LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id INNER JOIN user_x_meta uxm ON (u.ID = uxm.user_id)";

			if($l == "oldmembers" || $l == "expired" || $l == "cancelled")
				$sqlQuery .= " LEFT JOIN $wpdb->pmpro_memberships_users mu2 ON u.ID = mu2.user_id AND mu2.status = 'active' ";

			$sqlQuery .= " WHERE mu.membership_id > 0 AND (u.user_login LIKE '%" . esc_sql($s) . "%' OR u.user_email LIKE '%" . esc_sql($s) . "%' OR MATCH um.meta_value  AGAINST ('" . esc_sql($s) . "') OR MATCH um.meta_value  AGAINST ('" .$strrr. "') OR u.display_name LIKE '%" . esc_sql($s) . "%' OR  um.meta_value LIKE '%" . esc_sql($s) . "%') ";

			if($doesorg)
			{
		 	$sqlQuery .= " AND uxm.primary_application LIKE '%" . esc_sql($doesorg) . "%'";
			}
			if($cn)
			{
			$sqlQuery .= " AND uxm.company_name LIKE '%" . esc_sql($cn) . "%'";
			}
			if($omc)
			{
				$sqlQuery .= " AND uxm.call_apply LIKE '%" . esc_sql($omc) . "%'";
			}
			if($otai)
			{
			$sqlQuery .= " AND uxm.primary_domain_interest LIKE '%" . esc_sql($otai) . "%'";
			}

			// if($newotai)
			// {
			// $sqlQuery .= " AND uxm.primary_domain_interest LIKE '%" . esc_sql($newotai) . "%'";
			// }
			if($tnt)
			{
			$sqlQuery .= " AND uxm.traditional_or_nontraditional_organization = '" . esc_sql($tnt) . "'";
			}
			if($noe)
			{
				//echo $noe;
			$sqlQuery .= " AND uxm.cnumberofemployees= '" . esc_sql($noe) . "'";
			}
			if($soi)
			{
			$sqlQuery .= " AND uxm.incorporated_state = '" . esc_sql($soi) . "'";
			}
			if($howfin)
			{
			$sqlQuery .= " AND uxm.how_are_you_financed LIKE '%" . esc_sql($howfin) . "%'";
			}

			if($startjoindate)
			{
			$sqlQuery .= " AND mu.startdate LIKE '%" . esc_sql($datejoined) . "%'";
			}
			if($endjoindate)
			{
			$sqlQuery .= " AND enddate LIKE '%" . esc_sql($expirydate) . "%'";
			}
			if($level){
				$sqlQuery .= " AND mu.status = 'active' AND mu.membership_id IN  (".esc_sql($level).") GROUP BY u.ID ";
			}
			else{
				$sqlQuery .= " AND mu.status = 'active' ";
				$sqlQuery .= "GROUP BY u.ID ";
			}
			

			if($l == "oldmembers" || $l == "expired" || $l == "cancelled")
				$sqlQuery .= "ORDER BY enddate DESC ";
			else
				$sqlQuery .= "ORDER BY u.user_registered DESC ";

			$sqlQuery .= "LIMIT $start, $limit";
		//echo "if  ".$sqlQuery;
		}
		else
		{
			$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email, UNIX_TIMESTAMP(u.user_registered) as joindate, mu.membership_id, mu.initial_payment, mu.billing_amount, mu.cycle_period, mu.cycle_number, mu.billing_limit, mu.trial_amount, mu.trial_limit, UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership FROM $wpdb->users u LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id 
			LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id INNER JOIN user_x_meta uxm ON (u.ID = uxm.user_id)";

			if($l == "oldmembers" || $l == "expired" || $l == "cancelled") {
				$sqlQuery .= " LEFT JOIN $wpdb->pmpro_memberships_users mu2 ON u.ID = mu2.user_id AND mu2.status = 'active' ";
			}

			$sqlQuery .= " WHERE 1=1 AND mu.membership_id > 0  ";

			if($doesorg)
			{
			$sqlQuery .= " AND uxm.primary_application LIKE '%" . esc_sql($doesorg) . "%'";
			}
			if($cn)
			{
			$sqlQuery .= " AND uxm.company_name LIKE '%" . esc_sql($cn) . "%'";
			}
			if($omc)
			{
				$sqlQuery .= " AND uxm.call_apply LIKE '%" . esc_sql($omc) . "%'";
			}
			if($otai)
			{
			$sqlQuery .= " AND uxm.primary_domain_interest LIKE '%" . esc_sql($otai) . "%'";
			}
			// if($newotai)
			// {
			// $sqlQuery .= " AND uxm.primary_domain_interest LIKE '%" . esc_sql($newotai) . "%'";
			// }
			if($tnt)
			{
			$sqlQuery .= " AND uxm.traditional_or_nontraditional_organization = '" . esc_sql($tnt) . "'";
			}
			if($noe)
			{
				//echo $noe;
			$sqlQuery .= " AND uxm.cnumberofemployees= '" . esc_sql($noe) . "'";
			}
			if($soi)
			{
			$sqlQuery .= " AND uxm.incorporated_state = '" . esc_sql($soi) . "'";
			}
			if($howfin)
			{
			$sqlQuery .= " AND uxm.how_are_you_financed LIKE '%" . esc_sql($howfin) . "%'";
			}
			if($startjoindate)
			{
			$sqlQuery .= " AND mu.startdate LIKE '%" . esc_sql($datejoined) . "%'";
			}
			if($endjoindate)
			{
			$sqlQuery .= " AND enddate LIKE '%" . esc_sql($expirydate) . "%'";
			}
		   if($level){
				$sqlQuery .= " AND mu.status = 'active' AND mu.membership_id IN  (".esc_sql($level).") ";
			}
			else{
			$sqlQuery .= " AND mu.status = 'active' ";
			$sqlQuery .= "GROUP BY u.ID ";
			}
			

			if($l == "oldmembers" || $l == "expired" || $l == "cancelled")
				$sqlQuery .= "ORDER BY enddate DESC ";
			else
				$sqlQuery .= "ORDER BY u.user_registered DESC ";

			$sqlQuery .= "LIMIT $start, $limit";
			//echo "else  ".$sqlQuery;
		}

		$sqlQuery = apply_filters("pmpro_members_list_sql", $sqlQuery);
		$theusers = $wpdb->get_results($sqlQuery);
		$totalrows = $wpdb->get_var("SELECT FOUND_ROWS() as found_rows");

		if($theusers)
		{
			$calculate_revenue = apply_filters("pmpro_memberslist_calculate_revenue", false);
			if($calculate_revenue)
			{
				$initial_payments = pmpro_calculateInitialPaymentRevenue($s, $l);
				$recurring_payments = pmpro_calculateRecurringRevenue($s, $l);
				?>
				<p class="clear"><?php echo strval($totalrows)?> members found. These members have paid <strong>$<?php echo number_format($initial_payments)?> in initial payments</strong> and will generate an estimated <strong>$<?php echo number_format($recurring_payments)?> in revenue over the next year</strong>, or <strong>$<?php echo number_format($recurring_payments/12)?>/month</strong>. <span class="pmpro_lite">(This estimate does not take into account trial periods or billing limits.)</span></p>
				<?php
			}
			else
			{
			?>
			<p class="clear result-view"><?php printf(__("%d members found.", 'paid-memberships-pro' ), $totalrows);?></span></p>
			<?php
			}
		}
	?>
	<!-- Table Start -->
	<div class=" table-search-result filter-parent">
	<table class="wp-list-table widefat fixed striped table table-striped  proposals">
		<thead>
			<tr class="thead">
			<th style="min-width: 120px;"><?php _e('Compnay NAME', 'paid-memberships-pro' );?></th>
			<th ><?php _e('POC', 'paid-memberships-pro' );?></th>
			<th style="min-width: 160px;"><?php _e('ORG Type', 'paid-memberships-pro' );?></th>
			<th><?php _e('TECH AREA', 'paid-memberships-pro' );?></th>
			</tr>
		</thead>
		<tbody id="users" class="list:user user-list">
			<?php
				global $current_user;

				foreach($theusers as $auser)
				{

					$auser = apply_filters("pmpro_members_list_user", $auser);
					//get meta
					
					$theuser = get_userdata($auser->ID);

					$puid = nstxl_get_parent_userid($auser->ID);
				    if (!empty($puid)) {
				      $cur_id = $puid;
				    } else {
				      $cur_id = $auser->ID;
				    }
				    $poc_user_id = get_user_meta($cur_id, "poc", true);
				    $poc_name = get_userdata($poc_user_id);
				    $poc_fullname = $poc_name->first_name.' '.$poc_name->last_name;

					$ota_interest = get_user_meta($auser->ID,'primary_domain_interest', true);
					$otas = nstxl_formated_ota_interest(maybe_unserialize($ota_interest));
					     
					
					$count = 0;
					?>
						<tr <?php if($count++ % 2 == 0) { ?>class="alternate"<?php } ?>>
							<td><?php echo $theuser->company_name; ?></td>
							<td><?php echo $poc_fullname; ?></td>
							<td><?php echo $auser->membership; ?></td>
							<td><?php  
							if(is_array($otas)){
					        echo implode(", ", $otas);
					      } else {
					        echo $otas;
					      } ?></td>
								
								</tr>
					<?php
				}

				if(!$theusers)
				{
				?>
				<tr>
					<td colspan="9"><p><?php _e("No members found.", 'paid-memberships-pro' );?> <?php if($l) { ?><a href="?page=pmpro-memberslist&s=<?php echo esc_attr($s);?>"><?php _e("Search all levels", 'paid-memberships-pro' );?></a>.<?php } ?></p></td>
				</tr>
				<?php
				}
			?>
		</tbody>
	</table></div>
	<!-- Table End -->
	</form>
	<!-- Form End  -->

</main>
</div>
</div>
</div>
	<?php
	echo pmpro_getPaginationString($pn, $totalrows, $limit, 1, add_query_arg(array("sw" => urlencode($s), "l" => $l, "limit" => $limit)));
	?>

      </main><!-- #main -->
    </div><!-- #primary -->

    

  </div><!--#content-inside -->
</div><!-- #content -->

<?php get_footer('admin'); ?>
