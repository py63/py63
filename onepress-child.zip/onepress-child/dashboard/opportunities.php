<?php
/* Template Name: Remote Opportunities
 */
//get_header();
global $current_user;
$cusr_id = $current_user->ID;
?><?php /* ?>
  <style type="text/css">
  #opportunity-info-modal  #wpadminbar {display: none;}
  .loadmorenew {display: table;max-width: 250px;text-align: center;margin: 30px auto 0;}
  .loadmorenew a, .loadmorenew div {padding: 18px 30px !important;max-width: 205px;border-radius: 4px;display: inline-block;margin: auto;width: auto;background-color: #dc323e !important;border: 1px solid #dc323e !important;color: #fff !important;font-weight: 100 !important;font-family: 'robotomedium' !important;font-size: 18px !important;margin: 45px 0 15px !important;text-transform: uppercase !important;background-image: none !important;transition: all 0.2s;border-radius: 4px !important;line-height: 16px !important;}
  .loadmorenew a:hover {color: #fff;background-color: #e35e67;}
  </style>
  <?php */ ?>
<div class='opportunities'>
  <!-- Blog Query  -->
  <div class="opportunity-post-remote remote">
    <div class='card-deck'>
      <?php
      $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
      // $args = array('post_type' => 'post','category__not_in' => 34, 'posts_per_page' => 6, 'paged' => $paged );
      $args = array('post_type' => 'opportunity', 'posts_per_page' => 6, 'paged' => $paged);
      $mytrackIDs = get_user_meta($current_user->ID, 'myopportunitiesposts', true);
      if (!empty($mytrackIDs)) {
       //$mytrackIDs = implode(",",$mytrackIDs);
        $args['post__not_in'] = $mytrackIDs;
      }
      //print_r($args);
      query_posts($args);
      ?>
      <!-- the loop -->
      <?php
      if (have_posts()) : while (have_posts()) : the_post();
          include(locate_template('templates/opportunity/main-tabs/content-opportunities.php'));
          ?>
        <?php endwhile; ?>
      <?php else : ?>
        <!-- No posts found -->
      <?php endif; ?>
      <div class="loadmorenew loadmore" id="loadmores"><?php echo get_next_posts_link('Load more'); ?></div>
      <!-- End of Blog Query -->
    </div>
    <?php wp_reset_query(); ?>
  </div>

</div>
<!-- Modal -->
<div class="modal fade" id="update-personalinfo-modal-success" style="width:80%" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" aria-hidden="true">&times;</button> 
        <div class="update-personalinfo-box-success-container">
          <p></p> 
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 
<!-- /.modal --> 
<script type="text/javascript">
  jQuery(document).ready(function ($) {
    trackOpportunity();
    untrackOpportunity();
    $('body').on('click', '.opportunities .loadmorenew a', function (e) {
      e.preventDefault();
      var temphref = $(this).attr('href');
      $(".opportunities .loadmorenew").html("<div class='loadmorenew wow animated fadeInUp loadmoreloading'> <img src='" + loademoreimg + "' /> Loading...</div>");

      $.post(temphref, function (response) {
        $(".opportunities .loadmorenew").remove();
        var tempdata = $(response).find('.opportunities .opportunity-post-remote.remote').html();
        $(".opportunities .opportunity-post-remote.remote").append(tempdata);
        trackOpportunity();
        untrackOpportunity();
      });

    });
    jQuery('#opportunity-info-modal-remote').modal('hide');
    jQuery('#opportunity-info-modal-remote').removeClass('in');
    jQuery('#opportunity-info-modal-remote').css('display:none');
    jQuery('.close').on('click', function (e) {
      jQuery('#update-personalinfo-modal-success').modal('hide');
      jQuery('#opportunity-info-modal-remote').modal('hide');
    });
    jQuery('.opportunities #update-personalinfo-modal-success').on('hidden.bs.modal', function () {
      jQuery('#opportunity-info-modal-remote').modal('hide');
      location.reload(true);
    });
    jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
      location.reload(true);
    })
    jQuery('#update-personalinfo-modal-success').on('shown.bs.modal', function () {
      //jQuery('#opportunity-info-modal').modal('hide');
      jQuery('#opportunity-info-modal-remote').removeClass('in');
      jQuery('#opportunity-info-modal-remote').css('display:none');
    });
  });
</script>
<?php //get_footer();