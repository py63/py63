<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OnePress
 */
?>

<div id="submitquestion" class="submitquestion-sidebar widget-area sidebar" role="complementary">
  
</div><!-- #secondary -->