<?php

/**
 * OnePress Child Theme Functions
 *
 */

/**
 * Dequeue the jQuery UI styles.
 *
 * Hooked to the wp_print_styles action, with a late priority (100),
 * so that it is after the style was enqueued.
 */
function wp_67472455() {

 wp_dequeue_style('onepress-style');
 wp_dequeue_style('onepress-animate');
 wp_dequeue_style('onepress-fa');
 wp_dequeue_style('onepress-bootstrap');
 wp_dequeue_style('onepress-gallery-lightgallery');
 wp_dequeue_style('nstxl-bootstrap-css');
 wp_dequeue_style('ap-overrides-css');
 wp_dequeue_style('font-awesome');
 wp_dequeue_style('nstxl-bootstrap-css');


  //Denque javascripts 
 wp_dequeue_script('nstxl-bootstrap-js');
 wp_dequeue_script('onepress-js-bootstrap');
 wp_dequeue_script('onepress-gallery-masonry');
 wp_dequeue_script('onepress-gallery-justified');
 wp_dequeue_script('onepress-gallery-carousel');
 wp_dequeue_script('onepress-js-bootstrap');
}

add_action('wp_print_styles', 'wp_67472455', 1000);

/**
 * Enqueue child theme style
 */
function onepress_child_enqueue_styles() { 

// wp_enqueue_script( 'slick-min-js', get_stylesheet_directory_uri() . '/js/slick.min.js', array( 'jquery' ), true );
 wp_enqueue_style( 'slick-theme-css', get_stylesheet_directory_uri() . '/css/slick-theme.css' );  
 wp_enqueue_style( 'colorbox-css', get_stylesheet_directory_uri() . '/assets/colorbox/colorbox.css' ); 
 wp_enqueue_style( 'colorbox-scroll-css', get_stylesheet_directory_uri() . '/assets/colorbox/mCustomScrollbar.css' ); 
 
 wp_enqueue_script( 'colorbox-scroll-js', get_stylesheet_directory_uri() . '/assets/js/mCustomScrollbar.js', array( 'jquery' ), true );  

  //wp_enqueue_style( 'onepress-child-style', get_stylesheet_directory_uri() . '/style.css' );
 wp_enqueue_style('onepress-child-theme', get_stylesheet_directory_uri() . '/css/theme.min.css');
 $custom_css = onepress_custom_inline_style();    
 wp_add_inline_style( 'onepress-style', $custom_css );
 wp_add_inline_style( 'onepress-child-theme', $custom_css );
 wp_register_script('onepress-child-main-js', get_stylesheet_directory_uri() . '/js/theme.min.js', array('jquery'), true);
 wp_enqueue_script('onepress-child-main-js');  
}

add_action('wp_enqueue_scripts', 'onepress_child_enqueue_styles', 10);
if (file_exists(get_stylesheet_directory() . '/extra-functions/extra-functions.php')) {
  require_once(get_stylesheet_directory() . '/extra-functions/extra-functions.php');
}

/**
 * Hook to add custom section after about section
 *
 * @see wp-content/themes/onepress/template-frontpage.php
 */
/*
  function add_my_custom_section(){
  ?>
  <section id="my_section" class="my_section section-padding onepage-section">
  <div class="container">
  <div class="section-title-area">
  <h5 class="section-subtitle"> My section subtitle</h5>
  <h2 class="section-title"> My section title</h2>
  </div>
  <div class="row">
  <!-- Your section content here, you can use bootstrap 4 elements :) -->
  <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.</p>

  </div>
  </div>
  </section>
  <?php
  }
  add_action( 'onepress_after_section_about', 'add_my_custom_section'  );
 */

/**
 * Add Copyright and Credit text to footer
 *
 * @since 1.1.3
 */
function onepress_footer_site_info() { ?>
  <div class="row">
   <div class="col-lg-6 col-md-12 col-sm-12">
    <?php 
    wp_nav_menu( array(    
      'theme_location' => 'footer_menu',
    'fallback_cb'    => false // Do not fall back to wp_page_menu()
  ) );
  ?>
</div>
<div class="col-lg-6 col-md-12 col-sm-12 copyright">
  <a href="https://www.linkedin.com/company/national-security-technology-accelerator/" target="_blank"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/Linkedin-Footer.svg" alt="Linkedin" class="Linkedin"></a>
  <?php
  echo '<span class="copyright-text">'; printf(esc_html__('Copyright %1$s %2$s %3$s. All Rights Reserved. | Site Design: Dark Roast Media', 'onepress'), '&copy;', esc_attr(date('Y')), esc_attr(get_bloginfo())); echo '</span>';
//onepress_footer_social_icons(); ?>
</div>
</div>  
<?php }

/**
 * Register new footer menu
 */
function nstxl_register_footer_nav_menus() {
  /* This theme uses wp_nav_menu() in one location. */
  register_nav_menus(
    array(
      'footer_menu' => esc_html__('Footer Menu', 'onepress'),
    )
  );
}

add_action('after_setup_theme', 'nstxl_register_footer_nav_menus');


/**
 * opportunity
 */

function nstxl_body_class( $classes ) {
  if ( is_page_template( 'tmpl-opportunity.php' ) ) {
    $classes[] = 'opportunity-front';
  }
  return $classes;
}

add_filter( 'body_class', 'nstxl_body_class' );

add_action( 'init', 'nstxl_remove_actions_parent_theme',100);

function nstxl_remove_actions_parent_theme() {
  remove_action( 'onepress_page_before_content', 'onepress_display_page_title' );
};



  /**
   * Display page header
   *
   * @since 2.0.0
   */

  function onepress_display_page_title() {
    if ( get_theme_mod( 'onepress_page_title_bar_disable' ) == 1 ) {
      return;
    }

    $return = false;

    if ( is_home() ) {
      $page_id = get_option( 'page_for_posts' );
    } else {
      $page_id = get_the_ID();
    }
    $el = 'h1';
    if ( is_singular( 'post' ) ) {
      if ( ! apply_filters( 'onepress_single_show_page_header', false ) ) {
        return;
      }
      $page_id = get_option( 'page_for_posts' );
      $el = 'h2';
    }

    $apply_shop = false;
    $is_single_product = false;

    if ( onepress_is_wc_active() ) {
      if ( is_shop() || is_product_category() || is_product_tag() || is_product() || is_singular( 'product' ) || is_product_taxonomy() ) {

        $page_id = wc_get_page_id( 'shop' );
        if ( is_product() ) {
          $el = 'h2';
          $is_single_product = true;
          $apply_shop = get_post_meta( $page_id, '_wc_apply_product', true );
        }
        $return = false;

        remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10 );
        remove_action( 'woocommerce_archive_description', 'woocommerce_product_archive_description', 10 );
        add_action( 'woocommerce_show_page_title', '__return_false', 95 );
      }
    }

    if ( $return ) {
      return;
    }

    $classes = array( 'page-header' );
    $img = '';
    $hide_page_title = get_post_meta( $page_id, '_hide_page_title', true );

    if ( ! $is_single_product || ( $apply_shop && $is_single_product ) ) {
      if ( get_post_meta( $page_id, '_cover', true ) ) {
        if ( has_post_thumbnail( $page_id ) ) {
          $classes[] = 'page--cover';
          $img = get_the_post_thumbnail_url( $page_id, 'full' );
        }
        if ( onepress_is_transparent_header() ) {
          $classes[] = 'is-t-above';
        }
      }
    }

    $excerpt = '';
    if ( onepress_is_wc_archive() ) {
      $title = get_the_archive_title();
      $excerpt = category_description();

      $term = get_queried_object();
      $thumbnail_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
      $t_image = wp_get_attachment_url( $thumbnail_id );
      if ( $t_image ) {
        $img = $t_image;
      }
    } else {
      $title = get_the_title( $page_id );
      if ( get_post_meta( $page_id, '_show_excerpt', true ) ) {
        $post = get_post( $page_id );
        if ( $post->post_excerpt ) {
          $excerpt = apply_filters( 'the_excerpt', get_post_field('post_excerpt', $page_id) );
        }
      }
    }
    if ( ! $apply_shop && $is_single_product ) {
      $excerpt = '';
    }

    ?>
    <?php if ( ! $hide_page_title ) { ?>
      <div class="<?php echo esc_attr( join( ' ', $classes ) ); ?>"<?php echo ( $img ) ? ' style="background-image: url(\'' . esc_url( $img ) . '\')" ' : ''; ?>>
        <div class="container">
          <?php
          // WPCS: XSS OK.
          echo '<' . $el . ' class="entry-title">' . $title . '</' . $el . '>';
          if ( $excerpt ) {
            echo '<div class="entry-tagline">' . $excerpt . '</div>';
          }
          ?>
        </div>
      </div>
    <?php } ?>
    <?php
  }


  function nstxl_page_header(){ 

    if ( is_home() ) {
      $page_id = get_option( 'page_for_posts' );
    } else {
      $page_id = get_the_ID();
    }
    $el = 'h1';
    if ( is_singular( 'post' ) ) {
      if ( ! apply_filters( 'onepress_single_show_page_header', false ) ) {
        return;
      }
      $page_id = get_option( 'page_for_posts' );
      $el = 'h2';
    }


    if ( is_page( 'event' ) ) { 
      $featured_events_select_postid = get_theme_mod('featured_events_select_postid'); 
      $post_data = get_post( $featured_events_select_postid );
      $headersubtitle= $post_data->post_title;

      $headerdescription = substr($post_data->post_content, 0, 255);

      $post_char_count = strlen($post_data->post_content);

      $headerbuttontext = "Read More";
      $headerbuttonurl = get_permalink( $featured_events_select_postid );

// $featured_image = wp_get_attachment_url( get_post_thumbnail_id($featured_events_select_postid, 'full') )
      ?>
      <section id="hero" class="hero-slideshow-wrapper hero-slideshow-normal loaded" style="position: relative; z-index: 0; background: rgba(0, 0, 0, 0) none repeat scroll 0% 0%;">

        <div class="container" style="padding-top: 10%; padding-bottom: 10%;">
          <div class="row hero__content hero-content-style2">
            <div class="col-md-12 ">
              <div class="hcl2-content">
                <?php 
                if(!empty($headersubtitle)){ 
                  echo '<h1>'.$headersubtitle.'</h1>';
                } 
                if(!empty($headerdescription)){ 
                  if($post_char_count > 255 ) 
                  {
                    echo '<p>'.$headerdescription.'...</p>';
                  }
                  else
                  {
                    echo '<p>'.$post_data->post_content.'</p>'; 
                  } 

                } 
                if(!empty($headerbuttontext)){ 
                  if(!empty($headerbuttonurl)){ 
                    echo '<p><a class="btn btn-secondary-outline btn-lg" href="'.$headerbuttonurl.'">'.$headerbuttontext.'</a></p>';
                  }
                  else{
                    echo '<p><a class="btn btn-secondary-outline btn-lg" href="#">'.$headerbuttontext.'</a></p>';
                  }
                } 
                ?>

              </div>
            </div>

          </div>
          <a href="#content" class="down-arrow"><img src="<?php echo site_url(); ?>/wp-content/themes/onepress-child/images/arrow.png"></a>
        </div>
        <div class="backstretch" style="left: 0px; top: 0px; overflow: hidden; margin: 0px; padding: 0px; height: 913px; width: 1525px; z-index: -999998; position: absolute;"><img style="position: absolute; margin: 0px; padding: 0px; border: medium none; width: 1623.11px; height: 913px; max-height: none; max-width: none; z-index: -999999; left: -49.0556px; top: 0px;" src="<?php if ( has_post_thumbnail( $featured_events_select_postid ) ) { echo $img = get_the_post_thumbnail_url( $featured_events_select_postid, 'full' ); }?>">
        </div>

      </section>

    <?php  }

    else {
      if(get_field('display_hero_section') == 'yes')
      {
        $headersubtitle = get_field('header_subtitle');
        $headerdescription = get_field('header_description');
        $headerbuttontext = get_field('header_button_text');
        $headerbuttonurl = get_field('header_button_url');
        ?>
        <section id="hero" class="hero-slideshow-wrapper hero-slideshow-normal loaded" style="position: relative; z-index: 0; background: rgba(0, 0, 0, 0) none repeat scroll 0% 0%;">

          <div class="container" style="padding-top: 10%; padding-bottom: 10%;">
            <div class="row hero__content hero-content-style2">
              <div class="col-md-12 ">
                <div class="hcl2-content">
                  <?php 
                  if(!empty($headersubtitle)){ 
                    echo '<h1>'.$headersubtitle.'</h1>';
                  } 
                  if(!empty($headerdescription)){ 
                    echo '<p>'.$headerdescription.'</p>';
                  } 
                  if(!empty($headerbuttontext)){ 
                    if(!empty($headerbuttonurl)){ 
                      echo '<p><a class="btn btn-secondary-outline btn-lg" href="'.$headerbuttonurl.'">'.$headerbuttontext.'</a></p>';
                    }
                    else{
                      echo '<p><a class="btn btn-secondary-outline btn-lg" href="#">'.$headerbuttontext.'</a></p>';
                    }
                  } 
                  ?>

                </div>
              </div>

            </div>
            <a href="#content" class="down-arrow"><img src="<?php echo site_url(); ?>/wp-content/themes/onepress-child/images/arrow.png"></a>
          </div>
          <div class="backstretch" style="left: 0px; top: 0px; overflow: hidden; margin: 0px; padding: 0px; height: 913px; width: 1525px; z-index: -999998; position: absolute;"><img style="position: absolute; margin: 0px; padding: 0px; border: medium none; width: 1623.11px; height: 913px; max-height: none; max-width: none; z-index: -999999; left: -49.0556px; top: 0px;" src="<?php if ( has_post_thumbnail( $page_id ) ) { echo $img = get_the_post_thumbnail_url( $page_id, 'full' ); }?>">
          </div>

        </section>
        <?php
      }

      else
      {
        onepress_display_page_title();
      }
    }

  }  

  add_action( 'onepress_page_before_content', 'nstxl_page_header',100 );



  /* Dashboard Sidebar */

/**
 * Add a sidebar.
 */
function nstxl_dashboard_sidebar() {
  register_sidebar( array(
    'name'          => __( 'Dashboard Sidebar', 'textdomain' ),
    'id'            => 'sidebar-dashboard',
    'description'   => __( 'Widgets in this area will be shown dashboard items.', 'textdomain' ),
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget'  => '</aside>',
    'before_title'  => '<h2 class="widgettitle">',
    'after_title'   => '</h2>',
  ) );
}
add_action( 'widgets_init', 'nstxl_dashboard_sidebar' );


/**
 *  Shortcode for fetch team member start
 */

function nstxl_team_slider_shortcode( $atts ) {
 global $current_user;

 global $wp_query, $post;

 $atts = shortcode_atts(
   array(
     'posts_per_page' => -1,
     'post_type'      => 'team',
     'orderby'         => 'date',
     'order'          => 'DESC',
   ), $atts );

 $args = array(
   'post_type'      => array( $atts[ 'post_type' ] ),
   'posts_per_page' => $atts[ 'posts_per_page' ],
 );

 // run the query

 $Newquery    = new WP_Query( $args );
 $team = ''; 
 ob_start();
 $team = '';
 $team .= '<div class="team-slider">';
 if ( $Newquery->have_posts() ) : while ( $Newquery->have_posts() ) : $Newquery->the_post();

   $teamposition = get_field('position', $Newquery->ID);
   $linkedinid_url = get_field('linkedin_link', $Newquery->ID);   

   $team .= '<div class="team-slider-content">';
   $team .=  '<a class="inline" href="#team'.get_the_ID().'">'; 
   if (has_post_thumbnail()) {

    $featured_img_url = get_the_post_thumbnail_url($Newquery->ID, 'medium');
    $team .= '<img class="" data-src="'. $featured_img_url.'" alt="'.get_the_title().'"  src="'.$featured_img_url.'"  data-holder-rendered="true">';
  } else {
    $team .= '<img class="" src="'.get_bloginfo('stylesheet_directory').'/images/placeholder-team.jpg" data-holder-rendered="true" />';
  } 
  $team .= '<h5>'.get_the_title().'</h5>';
  $team .= '<span>'.$teamposition.'</span>';
  $team .= '</a>'; 
  $team .= '<div style="display:none">
  <div id="team'.get_the_ID().'" style="padding:10px; background:#000;">
  <div class="container">
  <div class="row">';

  $team .= '<div class="col-md-6">';

  if (has_post_thumbnail()) {

    $featured_img_url = get_the_post_thumbnail_url($Newquery->ID, 'full');
    $team .= '<img class="" data-src="'. $featured_img_url.'" alt="'.get_the_title().'"  src="'.$featured_img_url.'"  data-holder-rendered="true">';
  } else {
    $team .= '<img class="" src="'.get_bloginfo('stylesheet_directory').'/images/placeholder-team.jpg" data-holder-rendered="true" />';
  } 

  $team .= '</div>';

  $team .= '<div class="col-md-6">';
  $team .= '<div class="team-content-box">';

  $team .= '<h5>'.get_the_title().'</h5>';
  $team .= '<h6>'.$teamposition.'</h6>';    
  $team .= '<p class="team-white-text mCustomScrollbar" >'.get_the_content().'</p>';   
  if ( ! empty( $linkedinid_url ) ) {
    $team .= '<p><a href="'.$linkedinid_url.'" target="_blank">
    <img class="" src="'.get_bloginfo('stylesheet_directory').'/images/Linkedin-Footer.svg" alt="Linkedin" id="linkedin" />        
    </a></p>';
  }       
  else   {
    $team .= '<p><a href="#"><img class="" src="'.get_bloginfo('stylesheet_directory').'/images/Linkedin-Footer.svg" alt="Linkedin" id="linkedin" /></a></p>';     
  }  
  $team .= '</div>';
  $team .= '</div>';




  $team .= '</div></div>'; 
  $team .= '</div></div>';             
  $team .= '</div>';   

endwhile; 
endif;

wp_reset_query();
$team .= ob_get_contents();
$team .= ob_get_clean();
$team .= '</div>';
$team .= '<script type="text/javascript">
jQuery(document).ready(function(){
 jQuery(".team-slider").slick({
   arrows: true,
   autoplay: true,
   autoplaySpeed: 3000,
   slidesToShow: 5,
   dots: false,
   slidesToScroll: 5, 
   responsive: [
   {
     breakpoint: 768,
     settings: {
       slidesToShow: 3,
       slidesToScroll: 1,
     }
     },
     {
       breakpoint: 767,
       settings: {
         slidesToShow: 2,
         slidesToScroll: 1,
       }
     }
     ]
     });
     jQuery(".inline").colorbox({inline:true,fixed:true,width:"100%",transition: "none", 
     fadeOut: "0"}); 
     });
     </script> 
     ';

return $team; 
}

add_shortcode( 'team', 'nstxl_team_slider_shortcode' );



   /**
 * Members alphabat list ajax callback start
 */
   function nstxl_display_member_list() {
    global $wpdb;
    $short_val = stripcslashes( $_POST[ 'short_val' ] );
    if ( empty( $short_val ) ) {
      $short_val = 'a';
    }
    ob_start();

    $condition = "um.meta_key ='company_name' AND um.meta_value LIKE '{$short_val}%' ";

    $sqlQuery = "SELECT SQL_CALC_FOUND_ROWS DISTINCT u.ID, u.user_login, u.user_email FROM $wpdb->users u  LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->usermeta um1 ON u.ID = um1.user_id
    LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id "; 
    
    $sqlQuery .= " WHERE {$condition} AND mu.status = 'active' AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

    $sqlQuery .= " ORDER BY u.user_login ASC";

  //echo $sqlQuery;

    $theusers = $wpdb->get_results( $sqlQuery );
    if ( !empty( $theusers ) ) {
      $count_user = count((array) $theusers);
      echo '<ul id="members-list">';
      foreach ( $theusers as $row ) {
        $userID = $row->ID;
        $suspended_user = get_user_meta( $userID, 'suspended_user', true );
        $company_name = get_user_meta( $userID, 'company_name', true );
        if( empty($suspended_user) || $suspended_user !=1){
          echo '<li>' . $company_name  . '</li>';
        }else {
          if($count_user == 1){
            echo '<li>'.__('No Results Found','paid-membership-pro').'</li>';
          }
        }     
      }
      echo '</ul>';
      $result  = 'success';
      $result  = ob_get_clean();
    }else{
      $result = '<ul id="members-list"><li>No Result Found</li></ul>';
    }
    return wp_send_json_success( $result );
  }

  add_action( 'wp_ajax_nstxl_display_member_list', 'nstxl_display_member_list' );
  add_action( 'wp_ajax_nopriv_nstxl_display_member_list', 'nstxl_display_member_list' ); 


  /*********************************************Member list Input Seach Ajax ********************************/

  function nstxl_display_member_list_input() {
    global $wpdb;
    $short_val = stripcslashes( $_POST[ 'short_val' ] );

    if ( empty( $short_val ) ) {
      $short_val = 'a';
      $condition = "um.meta_key ='company_name' AND um.meta_value LIKE '{$short_val}%' ";
    }
    else
    {
      $condition = "um.meta_key ='company_name' AND um.meta_value LIKE '%{$short_val}%' ";  
    } 
    ob_start();

    
    $sqlQuery = "SELECT SQL_CALC_FOUND_ROWS DISTINCT u.ID, u.user_login, u.user_email FROM $wpdb->users u  LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->usermeta um1 ON u.ID = um1.user_id
    LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id "; 
    
    $sqlQuery .= " WHERE {$condition} AND mu.status = 'active' AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

    $sqlQuery .= " ORDER BY u.user_login ASC";

    $theusers = $wpdb->get_results( $sqlQuery );
    if ( !empty( $theusers ) ) {
      $count_user = count((array) $theusers);
      echo '<ul id="members-list">';
      foreach ( $theusers as $row ) {
        $userID = $row->ID;
        $suspended_user = get_user_meta( $userID, 'suspended_user', true );
        $company_name = get_user_meta( $userID, 'company_name', true );
        if( empty($suspended_user) || $suspended_user !=1){
          echo '<li>' . $company_name  . '</li>';
        }else {
          if($count_user == 1){
            echo '<li>'.__('No Results Found','paid-membership-pro').'</li>';
          }
        }     
      }
      echo '</ul>';
      $result  = 'success';
      $result  = ob_get_clean();
    }else{
      $result = '<ul id="members-list"><li>No Result Found</li></ul>';
    }
    return wp_send_json_success( $result );
  }

  add_action( 'wp_ajax_nstxl_display_member_list_input', 'nstxl_display_member_list_input' );
  add_action( 'wp_ajax_nopriv_nstxl_display_member_list_input', 'nstxl_display_member_list_input' );


  /* Custom post type stories */

  function nstxl_post_type_stories() {         

    register_post_type( 'stories',
    // CPT Options
      array(
        'labels' => array(
          'name' => __( 'Stories' ),
          'singular_name' => __( 'Stories' )
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'stories'),
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields' ),
      )
    );
  }
  add_action( 'init', 'nstxl_post_type_stories' );



/**
 *  Shortcode for fetch stories start
 */


function nstxl_stories_slider_shortcode( $atts ) {
 global $current_user;

 global $wp_query, $post;

 $atts = shortcode_atts(
   array(
     'posts_per_page' => -1,
     'post_type'      => 'stories',
     'orderby'         => 'date',
     'order'          => 'ASC',
   ), $atts );

 $args = array(
   'post_type'      => array( $atts[ 'post_type' ] ),
   'posts_per_page' => $atts[ 'posts_per_page' ],
 );

 // run the query
 $stories = ''; 

 $Newquery    = new WP_Query( $args );
 ob_start();

 $stories .= ' <div class="slider-nav-thumbnails">';
 if ( $Newquery->have_posts() ) : while ( $Newquery->have_posts() ) : $Newquery->the_post();
   $stories .= '<div class="tab">'.get_the_title().' <img src="'.get_bloginfo('stylesheet_directory').'/assets/images/arrow-red.svg"/></div>';              
 endwhile; 
endif;
wp_reset_query();

$stories .= ' </div>';


$stories .= '<div class="stories-slider">';
if ( $Newquery->have_posts() ) : while ( $Newquery->have_posts() ) : $Newquery->the_post();

 $stories_image = get_field('stories_image', $Newquery->ID);
 $stories_list = get_field('stories_list', $Newquery->ID);
 $stories_link_title = get_field('stories_link_title', $Newquery->ID);
 $stories_link_description = get_field('stories_link_description', $Newquery->ID);


 $stories .= '<div class="stories-slider-content">';
 $stories .= '<div class="stories-desciption">';
 $stories .= '<div class="container">';
 $stories .= '<div class="row">';

 $stories .= '<div class="col-md-2">';

 if ( ! empty( $stories_image ) ) {

  $stories .= '<img class="" data-src="'. $stories_image.'" alt="'.get_the_title().'"  src="'.$stories_image.'"  data-holder-rendered="true">';
} else {
  $stories .= '<img class="" src="'.get_bloginfo('stylesheet_directory').'/images/placeholder-team.jpg" data-holder-rendered="true" />';
} 

$stories .= '</div>';

$stories .= '<div class="col-md-5">';
$stories .= '<div class="stories-content-box">';
$stories .= '<h2>'.get_the_title().'</h2>';
$stories .= '<p>'.get_the_content().'</p>';

// if ( ! empty( $stories_link_title ) && ! empty( $stories_link_description ) ) {
//   $stories .= '<h4>'.'<a href="#" class="popupstory" data-id="'.get_the_ID().'" data-toggle="modal" data-target="#see-success-stories-'.get_the_ID().'">'.$stories_link_title.' <img src="'.get_bloginfo('stylesheet_directory').'/assets/images/arrow-red.svg"/></a></h4>';      
// }

$stories .= '</div>';
$stories .= '</div>';


$stories .= '<div class="col-md-5">';
$stories .= '<div class="team-content-list">';
$stories .= '<p>'.$stories_list.'</p>';    
$stories .= '</div>';
$stories .= '</div>';

$stories .= '</div>';
$stories .= '</div>';
$stories .= '</div>';
$stories .= '</div>';    


endwhile; 
endif;

wp_reset_query();
$stories .= ob_get_contents();
$stories .= ob_get_clean();
$stories .= '</div>';

$stories .= '<div id="cpoup">';
$stories .= '</div>';    
 
$stories .= '<script type="text/javascript">
jQuery(document).ready(function(){

 jQuery(".slider-nav-thumbnails").slick({
  slidesToShow: 6, 
  slidesToScroll: 6,   
  asNavFor: ".stories-slider",
  dots: false,
  autoplay: false,
  infinite: false,
  focusOnSelect: true 
  });

  jQuery(".stories-slider").slick({
   arrows: true, 
   autoplay: true,
   autoplaySpeed: 3000,
   slidesToShow: 1,
   dots: false,
   slidesToScroll: 1,  
   asNavFor: ".slider-nav-thumbnails",
   responsive: [
   {
     breakpoint: 768,
     settings: {
       slidesToShow: 1,
       slidesToScroll: 1,
     }
     },
     {
       breakpoint: 767,
       settings: {
         slidesToShow: 1, 
         slidesToScroll: 1,
       }
     }
     ]
     });

     var wid = jQuery(window).width();
     jQuery.fn.equalHeights = function () { 
      var max_height = 0;
      jQuery(this).each(function () {
        max_height = Math.max(jQuery(this).height(), max_height);
        });
        jQuery(this).each(function () {
          jQuery(this).height(max_height);
          });
        };
        jQuery(".stories-slider-content").equalHeights();
        });
        </script> 
        ';

        $stories .= "<script type='text/javascript'>
        jQuery(document).on('click','.popupstory',function () {
          var popup_id = jQuery(this).attr('data-id');     
          var data = { popup_id: popup_id, action: 'nstxl_story_popup' }; 
          jQuery.ajax( {
            url: nstxl_ajaxurl,
            type: 'POST',
            data: data,   
            cache: false,
            beforeSend: function () {  
              jQuery( '.nstxl-loader' ).show();
              jQuery( '.loader-overlay' ).show();
              },
              complete: function () {
                jQuery( '.nstxl-loader' ).hide();
                jQuery( '.loader-overlay' ).hide();
                },
                success: function(response){    
                 jQuery('#cpoup').html(response);     
                 jQuery('#see-success-stories-'+popup_id).modal('show');    
               }
               });
               });
               </script>";  

return $stories;
}

add_shortcode( 'stories', 'nstxl_stories_slider_shortcode' );   



add_action( 'wp_ajax_nstxl_story_popup', 'nstxl_story_popup' );
add_action( 'wp_ajax_nopriv_nstxl_story_popup', 'nstxl_story_popup' );

function nstxl_story_popup() {
  $popup_id = $_POST['popup_id'];
  $stories_link_description = get_post_meta( $popup_id, 'stories_link_description', true );
  $modal_id = 'see-success-stories-'.$popup_id;        
  $modal_body_container_class  = 'see-success-stories-container';
  $content_html = $stories_link_description;       
  nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class); 
  exit();   
}       


add_action( 'onepress_site_start', 'onepress_site_header' );

function onepress_site_header() {

  $menu_mobile ='';
  $menu ='';

  $header_width = get_theme_mod( 'onepress_header_width', 'contained' );
  $is_disable_sticky = sanitize_text_field( get_theme_mod( 'onepress_sticky_header_disable' ) );
  $classes = array(
    'site-header',
    'header-' . $header_width,
  );

  if ( $is_disable_sticky != 1 ) {
    $classes[] = 'is-sticky no-scroll';
  } else {
    $classes[] = 'no-sticky no-scroll';
  }

  $transparent = 'no-t';
  if ( onepress_is_transparent_header() ) {
    $transparent = 'is-t';
  }
  $classes[] = $transparent;

  $pos = sanitize_text_field( get_theme_mod( 'onepress_header_position', 'top' ) );
  if ( $pos == 'below_hero' ) {
    $classes[] = 'h-below-hero';
  } else {
    $classes[] = 'h-on-top';
  }

  ?>
  <header id="masthead" class="<?php echo esc_attr( join( ' ', $classes ) ); ?>" role="banner">
    <div class="container">
      <div class="site-branding">
        <?php
        onepress_site_logo();
        ?>
      </div>
      <div class="header-right-wrapper">
        <a href="#0" id="nav-toggle"><?php _e( 'Menu', 'onepress' ); ?><span></span></a>



        <?php

        $url = $_SERVER['REQUEST_URI'];

        $url_components = parse_url($url); 
        if (isset($url_components['query']))
        {
          parse_str($url_components['query'], $params); 

        }

        if(isset($params['elementor-preview']))
        {

          $search_result = $params['elementor-preview'];
        }


        if(empty($search_result))
        {
          $menu .= '<ul class="show-search-mobile"><li class="menu-item search"><a href="#" class="search-toggle-mobile"><i class="fa fa-search" aria-hidden="true"></i></a></li></ul>';

          if(is_user_logged_in()){
            global $current_user;
            $menu_mobile .= '<ul class="show-user-mobile"><li class="menu-item profile-info-box"><a href="#" class="profile-info-box-toggle-mobile"> <i class="fa fa-user" aria-hidden="true"></i></a></li>';

            $menu_mobile .= '<div class="header-profile-info-box-mobile">
            <ul>
            <li>   
            <p class="headerprofile">
            <span><a href="javascript:void(0)">'.ucfirst($current_user->first_name).' '.ucfirst($current_user->last_name).'</a></span>
            <span class="profileemail"><a href = "mailto: '.$current_user->user_email.'">'.$current_user->user_email.'</a></span>
            </p>
            </li>
            <li><a href="'.site_url().'/edit-personal-profile/">Edit My profile</a></li>';

            if(current_user_can('administrator') ){
              $menu_mobile .= '<li><a href="'.admin_url().'/users.php?page=wp2sv">2-Step Verification</a></li>';
            }
            $menu_mobile .=  '<li><a href="'.wp_logout_url( home_url() ).'">Log Out</a></li>
            </ul>
            </div>
            </ul>';
          } 

          echo $menu_mobile;


          $menu .= '<div class="header-search-mobile">'.get_search_form( false ).'<a href="#" class="search-close-mobile"><i class="fa fa-times-circle" aria-hidden="true"></i></a></div>';

          echo $menu;

        }
        ?>


        <nav id="site-navigation" class="main-navigation" role="navigation">
          <ul class="onepress-menu">
            <?php wp_nav_menu(
              array(
                'theme_location' => 'primary',
                'container' => '',
                'items_wrap' => '%3$s',
              )
            ); ?>
          </ul>
        </nav>
        <!-- #site-navigation -->
      </div>
    </div>
  </header><!-- #masthead -->
  <?php
}


/**
* Featured post On Event page select customize control class.  
*/

class nstxl_featured_news_select_Select extends WP_Customize_Control {
  public function render_content() {

    $args = array('post_type' => 'post', 'posts_per_page' =>-1, 'cat' =>46);        

    $args = new WP_Query($args); 

    ?>
    <label>
      <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
      <select id="featured_news_select" <?php $this->link(); ?>>
        <?php 
        while( $args->have_posts() ) {
          $args->the_post();
          echo "<option " . selected( $this->value(), get_the_ID() ) . " value='" . get_the_ID() . "'>" . the_title( '', '', false ) . "</option>";
        }
        ?>
      </select>
    </label> 
 <?php /*     <script type="text/javascript">
      var siteurl = '<?php echo get_bloginfo("url"); ?>';   
      jQuery(document).ready(function(){
        jQuery('#featured_news_select').multiselect({
          includeSelectAllOption: true,
          nonSelectedText: "Please Select"
        });

        if (jQuery('#featured_news_select').find(':selected').val() == null || jQuery('#featured_news_select').val() == null) {
          jQuery('#featured_news_select').trigger('change');  
        }
      });       
      </script>  */ ?>
      <?php
    }  
  }  



/**
* Featured post On News page
*/

function nstxl_news_featured_post( $wp_customize ) {
  global $current_user; 

  $wp_customize->add_section('featured_events_select_postid', array(
    'title'    => __('Events Featured Post'),
    'description' => '',
    'priority' => 26, 
  ));

  $val = array(); 

  $wp_customize->add_setting( 'featured_events_select_postid', array(
    'default' => array(),  
  ) );

  $wp_customize->add_control(
    new nstxl_featured_news_select_Select(
      $wp_customize,
      'featured_events_select_postid', 
      array(
        'settings' => 'featured_events_select_postid', 
        'label'    => 'Select Events Featured Post',
        'section'  => 'featured_events_select_postid', 
        'type'     => 'select',  
        'choices' => $val,  
      )
    )
  );


  
} 

add_action( 'customize_register', 'nstxl_news_featured_post' );     


/** 
* Two Factor Authentication show popup
**/

function nstxl_two_factor_popup()
{  
  global $current_user; 
  $usser_id = $current_user->ID;
  if(  $usser_id == 7){ return; }
  $wp2sv_enabled = get_user_meta($current_user->ID, 'wp2sv_enabled', true );
  if (current_user_can('administrator'))  
  { 
    if(empty($wp2sv_enabled)) 
    { 
      $url = admin_url( 'users.php?page=wp2sv' ); 
      $modal_id = 'two_factor_model';        
      $modal_body_container_class  = '';
      $content_html = '<div class="redirect-box-success-container text-center">
      <h4>2-Factor Authentication is disabled on NSTXL.</h4>
      <p class="renew-des">To enable the authentication on your site click on the below button.
      </p>
      <div class="renew-button text-center">
      <a class="btn btn-txt" href="'.$url.'">Enable</a> 
      </div>
      </div>';       
      nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class); 
      ?>

      <style type="text/css">.two_factor_model{z-index: 99999;}</style>
      <script>
        jQuery(document).ready(function () {
          jQuery('#two_factor_model').modal('show', {
            backdrop: 'static',
            keyboard: false
          });
          jQuery("#two_factor_model").on("hidden.bs.modal", function () {
            window.location = "<?php echo site_url(); ?>";
          });
        });
      </script>  
      <!-- /.modal -->
      <?php
    }
  }
}

add_action( 'wp_footer', 'nstxl_two_factor_popup' );

function nstxl_two_factor_redirect()
{ 
  global $current_user; 
  $usser_id = $current_user->ID;
  if(  $usser_id == 7){ return; } 
  $wp2sv_enabled = get_user_meta($current_user->ID, 'wp2sv_enabled', true );
  $url = admin_url('users.php?page=wp2sv');
  if (current_user_can('administrator'))  
  { 
    if(empty($wp2sv_enabled)) 
    { 
      if ( is_admin() ) { 
        $screen = get_current_screen();
      //  echo $screen->base;
        if ( 'users_page_wp2sv' == $screen->base )
          return;     
        wp_redirect( admin_url( 'users.php?page=wp2sv' ) ); 
        exit;  
      }  
    } 
  }   
}    
add_action('current_screen', 'nstxl_two_factor_redirect');    




/**
* Register a custom post type Faqs
*/
function nstxl_faq_init() {
  $labels = array(
    'name'               => _x( 'Faqs', 'Post type general name', 'NSTXL' ),
    'singular_name'      => _x( 'Faqs', 'Post type singular name', 'NSTXL' ),
    'menu_name'          => _x( 'Faqs', 'Admin Menu text', 'NSTXL' ),
    'name_admin_bar'     => _x( 'Faqs', 'Add New on Toolbar', 'NSTXL' ),
    'add_new'            => __( 'Add New', 'NSTXL' ),
    'add_new_item'       => __( 'Add New Faq', 'NSTXL' ),
    'new_item'           => __( 'New Faq', 'NSTXL' ),
    'edit_item'          => __( 'Edit Faq', 'NSTXL' ),
    'view_item'          => __( 'View Faq', 'NSTXL' ),
    'all_items'          => __( 'All Faqs', 'NSTXL' ),
    'search_items'       => __( 'Search Faqs', 'NSTXL' ),
    'parent_item_colon'  => __( 'Parent faq:', 'NSTXL' ),
    'not_found'          => __( 'No faq found.', 'NSTXL' ),
    'not_found_in_trash' => __( 'No faq found in Trash.', 'NSTXL' ),
  );

  $args = array(
    'labels'             => $labels,
    'public'             => true,
    'show_ui'            => true,
    'show_in_menu'       => true,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'nstxl-faq' ),
    'capability_type'    => 'post',
    'map_meta_cap'       => true,
    //'has_archive'        => true,
    'has_archive'        => false,
    'taxonomies'         => array( 'nstxl-faq-type' ),
    //'hierarchical'       => false,
    'menu_position'      => null,
    'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
  );

  register_post_type( 'nstxl-faq', $args );

  register_taxonomy( 'nstxl-faq-type', 'nstxl-faq', array(
    'label'        => __( 'Categories', 'NSTXL' ),
    'show_admin_column' => true,
    'rewrite'      => array( 'slug' => 'nstxl-faq-type' ),
    'hierarchical' => true,
  ) );
}

add_action( 'init', 'nstxl_faq_init' );



/* NSTXL Faq Article Like Dislike */

add_action( 'wp_ajax_nstxl_faq_article_like_dislike', 'nstxl_faq_article_like_dislike' );
add_action( 'wp_ajax_nopriv_nstxl_faq_article_like_dislike', 'nstxl_faq_article_like_dislike' );

function nstxl_faq_article_like_dislike() {
  global $wpdb;   
  global $current_user; 


  $userid = $current_user->ID;
  $postid = $_POST['postid'];
  $type = $_POST['type'];

  $sqlQuery = "SELECT COUNT(*) FROM nstxl_faq_article_like_unlike WHERE postid='".$postid."' and userid='".$userid."'";
  $count  = $wpdb->get_var( $sqlQuery ); 

  if($count == 0){
    $insertquery = "INSERT INTO nstxl_faq_article_like_unlike (userid, postid, type) VALUES('" .$userid. "', '" . $postid . "', '" . $type . "')"; 
    $wpdb->query($insertquery); 
    echo "Liked";
  }else {
    $updatequery = "UPDATE nstxl_faq_article_like_unlike SET type ='".$type."' where userid='".$userid."' and postid='".$postid."'";
    $wpdb->query($updatequery);
    echo "UnLiked";
  }
}     

/** 
*  FaQ Category Total like count 
*/

function nstxl_faq_article_like_total($postid){
  global $wpdb;
  $sqlQuery = "SELECT COUNT(*) FROM nstxl_faq_article_like_unlike WHERE type=1 and postid='".$postid."'";
  $total_likes = $wpdb->get_var( $sqlQuery ); 
  if (!empty( $total_likes ) ) {
    return $total_likes; 
  }
  else
  {
    return $total_likes = 0;
  }
} 


/* NSTXL Faq category dropdown Ajax */

add_action( 'wp_ajax_nstxl_faq_category_termid', 'nstxl_faq_category_termid' );
add_action( 'wp_ajax_nstxl_faq_category_termid', 'nstxl_faq_category_termid' );

function nstxl_faq_category_termid() {
 global $post;
 $term_id = $_POST['termid']; 
 $cat = get_term( $term_id ) 
 ?>


            <h4><?php echo $cat->name;?></h4> 
            <?php 
            if(!empty($cat->description))
            {
              echo "<p>".$cat->description."</p>";    
            } 
            ?>

            <table width="100%">
             <thead> <tr>
              <th align="left">Title</th>
              <th align="right">Likes</th></thead>
              <tbody>

                <?php
                $args = array(
                  'post_type' => 'nstxl-faq',
                  'posts_per_page' => -1, 
                  'post_status' => 'publish',
                  'tax_query' => array(
                    array(
                      'taxonomy' => 'nstxl-faq-type',
                      'field' => 'term_id',
                      'terms' => array($term_id ),
                    )
                  )
                );
                query_posts( $args ); 

                if ( have_posts() ) : ?>
                  <?php
      // Start the Loop.
                  while ( have_posts() ) :
                    the_post(); 
                    $total_like = nstxl_faq_article_like_total(get_the_ID());  
                    ?>
                    <tr>
                      <td><a href="<?php the_permalink();?>"><?php the_title(); ?></a></td>  
                      <td align="right"><?php echo $total_like; ?></td> 
                    </tr>
                 <?php   endwhile;
           else : ?> 
               <div class="text-center"><h3>No Faqs found</h3></div>
              <?php endif; ?> 
              </tbody>
            </table>


            <p class="mt-4 small">Can't find what you're looking for? Try asking on our <a href="<?php echo get_bloginfo('url');?>/forums/">Forum</a></p>  


<?php wp_die(); } 