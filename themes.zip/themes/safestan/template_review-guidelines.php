<?php
/**
 * Template Name: Review Guidelines

 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();?>
	<!-- Start Head Section -->
	<div class="top-banner">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12">
				   <h1 class="banner-hadding"><?php the_title();?></h1>
				   <?php if(CFS()->get( 'title_description' ))
	                		{	echo '<p class="mt-3">'.CFS()->get( 'title_description' ).'</p>';
	                        }
	                ?>				   
				</div>
		  	</div>
		</div>
	</div>
	<!-- End Head Section -->
	<div class="clearfix"></div>
	<section class="revu-guide">
		<div class="container">
			<div class="review-guidelinesDiv">
				<?php the_content();?>
		    </div>
	    </div>
	</section>
	<?php // End of the loop.
	endwhile;
	?>

<?php get_footer(); ?>
