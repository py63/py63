<?php 
/**
 *	Template Name: Mail attachment extractor
 */
get_header();

?>
<?php
set_time_limit(3000);

/* connect to Email Box with your credentials */
$hostname = '{imap.gmail.com:993/imap/ssl}INBOX';
$username = 'docs.nstxl@gmail.com';
$password = 'nstxl@12345';

$upload_dir  = wp_upload_dir();
$upload_path = $upload_dir["basedir"] . "/welcome-doc/";
$upload_url  = $upload_dir["baseurl"] . "/welcome-doc/";

/* try to connect */
if (function_exists('imap_open')) {

$inbox = imap_open($hostname,$username,$password) or die('Cannot connect to Email Box: ' . imap_last_error());
 
 
/* 
 * Get unseen email having following subject.
 */
$emails = imap_search($inbox, 'SUBJECT "An applicant has submitted a form to NSTXL Email:" UNSEEN'); 
 
/* if any emails found, iterate through each email */
if($emails) {
    $count = 1;
 
    /* put the newest emails on top */
    rsort($emails);
 
    /* for every email... */
    foreach($emails as $email_number) 
    { 
        /* get mail structure */
        $structure = imap_fetchstructure($inbox, $email_number);
 
        $attachments = array();

        /* if any attachments found... */
        if(isset($structure->parts) && count($structure->parts)) 
        {
            for($i = 0; $i < count($structure->parts); $i++) 
            {
                $attachments[$i] = array(
                    'is_attachment' => false,
                    'filename' => '',
                    'name' => '',
                    'attachment' => ''
                );
 
                if($structure->parts[$i]->ifdparameters) 
                {
                    foreach($structure->parts[$i]->dparameters as $object) 
                    {
                        if(strtolower($object->attribute) == 'filename') 
                        {
                            $attachments[$i]['is_attachment'] = true;
                            $attachments[$i]['filename'] = $object->value;
                        }
                    }
                }
 
                if($structure->parts[$i]->ifparameters) 
                {
                    foreach($structure->parts[$i]->parameters as $object) 
                    {
                        if(strtolower($object->attribute) == 'name') 
                        {
                            $attachments[$i]['is_attachment'] = true;
                            $attachments[$i]['name'] = $object->value;
                        }
                    }
                }
 
                if($attachments[$i]['is_attachment']) 
                {
                    $attachments[$i]['attachment'] = imap_fetchbody($inbox, $email_number, $i+1);
 
                    /* 4 = QUOTED-PRINTABLE encoding */
                    if($structure->parts[$i]->encoding == 3) 
                    { 
                        $attachments[$i]['attachment'] = base64_decode($attachments[$i]['attachment']);
                    }
                    /* 3 = BASE64 encoding */
                    elseif($structure->parts[$i]->encoding == 4) 
                    { 
                        $attachments[$i]['attachment'] = quoted_printable_decode($attachments[$i]['attachment']);
                    }
                }
            }
        }
        /* iterate through each attachment and save it */
        if (!empty($attachments)) 
        {
            foreach($attachments as $attachment)
            {
                if($attachment['is_attachment'] == 1)
                {
                    $h = imap_header($inbox, $email_number);
                    $emailSub = $h->subject;
                    $explo_email = explode("NSTXL Email:", $emailSub);

                    $filename = $attachment['name'];
                    // if(!empty($explo_email[1])) $filename = trim($explo_email[1]);

                    if(empty($filename)) $filename = $attachment['filename'];
     
                    if(empty($filename)) $filename = time() . ".dat";
     
                    /* prefix the email number to the filename in case two emails
                     * have the attachment with the same file name.
                     */

                    /** Send email to user and save file to folder**/
                    if(!empty($explo_email[1]))
                    {
                        $user = get_user_by( 'email', $explo_email[1] );
                        $dest_file = $upload_path.$user->user_login."/"."verified-".$filename;
                        $verif_url = $upload_url.$user->user_login."/"."verified-".$filename; 
                        $fp = fopen($dest_file, "w+");
                        if (fwrite($fp, $attachment['attachment'])) 
                        {
                            echo "File successfully created: ".$dest_file."<br>";
                        }
                        else
                        {
                            echo "File not created(Error): ".$dest_file."<br>";
                        }    
                        fclose($fp);

                        /** update the document url and path in the database **/
                        update_user_meta($user->ID, 'uploaded_doc', $verif_url);
                        update_user_meta($user->ID, 'uploaded_doc_path', $dest_file);
                        /** update the document url and path in the database **/

                        $to        = $explo_email[1];
                        $subject   = 'Verified document by NSTXL';
                        $blogurl = get_bloginfo( 'url' )."/uploaded-documents/";
                        $email_message = '<div class="container" style="padding: 25px;">
      <p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px; margin-bottom:15px;">Your document is verified by NSTXL, Please check with help of <a href="'.$blogurl.'">'.$blogurl.'</a>.</p></div>';
                        $headers   = array('Content-Type: text/html; charset=UTF-8');
                        $headers[] = 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";
                        if (wp_mail( $to, $subject, nstxl_emailContainer($subject, $message), $headers)) 
                        {
                            echo "Email sent to: ".$to."<br>";
                        }
                        else
                        {
                            echo "Email not sent to(Error): ".$to."<br>";
                        }
                    }
                    /** Send email to user **/
                }
     
            }
        }
        $count++;

        /* delete email */
        imap_delete($inbox, $email_number);
    }
 
} else{
  error_log('NO Email Found Email Box: ' . imap_last_error());
}

} else {    
    error_log('Imap function not found or extension is not enabled');
    die('Cannot connect to Email Box:');
}
/* close the connection */
imap_close($inbox);
echo "Done";
?>
<?php 
get_footer();
?>