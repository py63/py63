<?php
/**
 * Template Name: About Us
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();?>

	<!--top-hader-bg-->
	<div class="top-banner">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12">
				   <h1 class="banner-hadding"><?php the_title();?></h1>
				   <?php if(CFS()->get( 'title_description' ))
	                		{	echo CFS()->get( 'title_description' );
	                        }
	                ?>				   
				</div>
		  	</div>
		</div>
	</div>
	<div class="main-content">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12">
				<?php the_content(); ?>
				</div>
			</div>
		</div>
	</div>

	<div class="reliability">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-sm-8">
					<?php echo CFS()->get( '_media_body' ); ?>
				</div>
				<div class="col-md-4 col-sm-4">
					<img src="<?php echo CFS()->get( '_media_review_image' ); ?>" class=" img-responsive pull-right" alt=""/>
				</div>
			</div>
		</div>
	</div>

	<div class="ratings-1">
		  <div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-4">
					<?php 
	            		if(CFS()->get( '_review_box_image' ))
	            		{	?>
		                	<img src="<?php echo CFS()->get( '_review_box_image' ); ?>" class="img-responsive" alt=""/>
		                	<?php 
		                } ?>						
					</div>
					<div class="col-md-8 col-sm-8">
					<?php echo CFS()->get( '_review_box_content' ); ?>
					</div>
				</div>
		  </div>
	</div>	
	
	<?php // End of the loop.
	endwhile;
	?>
<?php get_footer(); ?>
