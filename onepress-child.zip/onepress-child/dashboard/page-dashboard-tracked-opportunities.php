<?php
/*
 * Template Name: Dashboard Tracked Opportunities
 *
 * @package OnePress
 */
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
get_header('admin');
//$term = get_term_by('slug', 'current-opportunities', 'opportunity-type');
//if (!empty($term)) {
//  $termID = $term->term_id;
//} else {
//  $termID = "";
//}

global $current_user;
$cusr_id = $current_user->ID;
$mytrackIDs = get_user_meta($current_user->ID, 'myopportunitiesposts', true);

  /**
   * @since 2.0.0
   * @see onepress_display_page_title
   */
  do_action('onepress_page_before_content');
  ?>
  <div id="content" class="site-content">
    <?php
    onepress_breadcrumb();
    // [show_loggedin_as]
    ?>
    <div id="content-inside" class="container left-sidebar">
      <?php get_sidebar('dashboard'); ?>
      <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">

          <?php while (have_posts()) : the_post(); ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
              <header class="entry-header">
                <?php //the_title( '<h1 class="entry-title">', '</h1>' );  ?>
              </header><!-- .entry-header -->

              <div class="entry-content">
                <?php the_content(); ?>
                <!--Star of container -->
                <div class="opportunity-tracker-container opportunity-dashbaord-grid dashboard-inner-wrapper">
                  <div class="row">
                    <?php /* ?>
                      <div class="clearfix col-sm-12">
                      <h3 class="rgs_title clearfix"><?php _e(the_title(), 'paid-memberships-pro'); ?></h3>
                      </div>
                      <?php */ ?>
                      <div class="search-wrapper clearfix col-sm-12">   
                        <?php ?>         
                        <div class="member-search-container pull-right form-01">
                          <?php $unique_id = esc_attr(uniqid('search-form-')); ?>
                          <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>/dashboard-search" style="display:none;">
                            <input type="search" id="<?php echo $unique_id; ?>" class="search-field" placeholder="<?php echo esc_attr_x('Search', 'placeholder', 'polar'); ?>" value="<?php echo get_search_query(); ?>" name="sa" />
                            <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text"><?php echo _x('Search', 'submit button', 'polar'); ?></span></button>
                          </form>
                          <div class="track-opportunity-btn-group pull-right mb-3"><button class="btn btn-txt opportunityinfo" type="button" data-toggle="modal" data-target="#opportunity-info-modal-remote"><?php _e('Track Opportunities', 'paid-memberships-pro'); ?></button></div>
                        </div>
                        <?php ?>           
                      <?php /* ?><div class="btn-group pull-right"><button class="btn btn-magenta" type="button"><?php _e('Tracked Opportunities','paid-memberships-pro'); ?></button>
                        </div>
                        <?php */ ?>
                      </div>
                    </div>  


                    <div class="opportunity-tracker-inner opportunity-content">         
                      <!-- Blog Query  -->
                      <div class="opportunity-posts">
                        <?php if (!empty($mytrackIDs)) { 

                          $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                      // $args = array('post_type' => 'post','category__not_in' => 34, 'posts_per_page' => 6, 'paged' => $paged );

                          $args = array('post_type' => 'opportunity', 'posts_per_page' => 6, 'post__in' => $mytrackIDs, 'paged' => $paged);

                      //query_posts($args); 
                          $Newquery = new WP_Query($args);
                          ?>
                          <!-- the loop -->
                          <div class="card-deck">
                            <?php
                            if ($Newquery->have_posts()) : while ($Newquery->have_posts()) : $Newquery->the_post();
                              include(locate_template('templates/opportunity/main-tabs/content-opportunities.php'));
                            endwhile;
                            ?>
                            <?php else : ?>
                              <!-- No posts found -->
                              <div class="text-center no-opportunities"><p>No tracked opportunities found</p></div>
                            <?php endif; ?>
                          </div>   

                          <div class="loadmore wow animated fadeInUp" id="loadmores"><?php echo get_next_posts_link('Load more', $Newquery->max_num_pages); ?></div>
                          <!-- End of Blog Query -->
                        </div>
                        <?php wp_reset_query(); ?>
                      </div>

                      <?php
                    } else {  
                      echo '<div class="text-center dashboard-bg-white no-opportunities"><h4>No tracked opportunities found</h4></div>';
                    } ?>           



                  </div> 

                </div><!-- .entry-content -->
              </article><!-- #post-## -->

            <?php endwhile; // End of the loop.  ?>

          </main><!-- #main -->
        </div><!-- #primary -->



      </div><!--#content-inside -->
    </div><!-- #content -->

    <script>
      jQuery(document).ready(function ($) {
        trackOpportunity();
        untrackOpportunity();
        $('body').on('click', '.opportunity-tracker-container .loadmore a', function (e) {
          e.preventDefault();
          var temphref = $(this).attr('href');
          $(".opportunity-tracker-container #loadmores").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> Loading...</div>");

          $.post(temphref, function (response) {
            $(".opportunity-tracker-container #loadmores").remove();
            var tempdata = $(response).find('.opportunity-tracker-container .opportunity-posts').html();
            $(".opportunity-tracker-container .opportunity-posts").append(tempdata);
            trackOpportunity();
            untrackOpportunity();
          });
        });

      //    jQuery('.close').on('click', function (e) {
      //      jQuery('#update-personalinfo-modal-success').modal('hide');
      //    });
      //    jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
      //      location.reload(true);
      //    })
      jQuery('#opportunity-info-modal-remote .modal').on('hidden.bs.modal', function () {
        location.reload(true);
      })
    });
  </script>



  <div class="modal fade custom-popup" id="opportunity-info-modal-remote" tabindex="-1" role="dialog" aria-labelledby="opportunity-info-modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
          </button>
          <div class="modal-body-container  opportunity-info-modal-box-success-container success">
            <!-- Blog Query  -->

            <?php
            
            include(locate_template('dashboard/opportunities.php'));
            
            ?>
            
            <!-- End of Blog Query -->
          </div>
        </div>      
        <?php wp_reset_query(); ?>
      </div>
    </div><!-- /.modal-body -->            
  </div><!-- /.modal-content -->
  <!-- /.modal-dialog -->
</div> 
</div>
<?php get_footer('admin'); ?>
