<?php
/**
 * Template Name: Property
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<?php

    session_start(); // needs to be before anything else on page to use $_SESSION
    $value = "";
    if(isset($_POST['searchValue'])){
        $_SESSION['searchValue'] = $_POST['searchValue'];
    }
    if(isset($_GET['posearch'])) 
    {
    	$_SESSION['searchValue'] = $_GET['posearch'];
    }

?>

<?php 
global $wpdb, $args1, $args2;
//echo do_shortcode('[wpdreams_ajaxsearchlite]');

 ?>
 	<?php
 	if(!empty($_GET['posearch'])) 
 	{
 		$form_vl = $_GET['posearch'];
		$value =  trim($_GET['posearch']);

 	}
 	else
 	{
 		$form_vl = $_POST['searchValue'];
		$value =  trim($_POST['searchValue']);	
 	} 	

	//ltrim zero value from string for numeric value
	$valueArray = explode(' ', $value);
	foreach ($valueArray as $key => $val) {
		if(is_numeric($val))
		{
			$newValue = ltrim($val, "0");
			$valueArray[$key] = $newValue;
		}	
	}
	$value = implode(' ', $valueArray);
	//print_r($valueArray);
	// Start the loop.
	while ( have_posts() ) : the_post();?>
	<!-- Start Head Section -->
	<div class="top-banner search-banner">
		<div class="container">
    		<div class="row">
            	<div class="col-md-12 col-sm-12">
                         <div class="input-group">
				            <form role="form" class="form-inline" method="post">
	                            	<input type="text" placeholder="Enter your landlord address" value="<?php echo $form_vl; ?>" class="form-control" name="searchValue" />
	                                    <span class="input-group-btn">
	                                    	<button type="submit" class="btn btn-primary">Search</button>
	                            	</span>
	                        </form>
                        </div>
                </div>
            </div>
	        </div>
	</div>
	<!-- End Head Section -->
	<div class="card-review">
		<div class="container">
			<div class="row">
	     	<?php
	     	//echo $_GET
	     	/*$bits = parse_url($url);
	     	print_r($_GET);*/
			/*parse_str($bits['query'], $query);
			echo $query['foo']*/


	     	if($value != '')
	     	{
	     		$value = str_replace(",", '', $value);
	     		$ex_value = strtolower ($value);	     		
	     		$search = array(); $replace = array();

	     		$val = explode(' ', $ex_value);
	     		$str = ''; $count = 0;
	     		//echo "<pre>";print_r($val);
	     		if( !empty($val) ) {
	     			foreach($val as $key => $values) {
		     			if( !empty($values) ) { $count++;
		     				if( $count == 1)
		     					$str.= "search_term = '$values' ";
		     				else
		     					$str.= "OR search_term = '$values' ";
		     			}
	     			}
	     		}
	     		$searchrows = $wpdb->get_results("SELECT search_term,term_prefix FROM wpsft_search_term WHERE $str ");
	     		//echo "SELECT search_term,term_prefix FROM wpsft_search_term WHERE $str ";die();
	     		if( !empty($searchrows) ) {
	     			foreach ($searchrows as $searchrow) { 
	    				$search[] = $searchrow->search_term;
	    				$replace[] = $searchrow->term_prefix;
	    			}
	     		}
	     		//echo "<pre>";print_r($search);print_r($replace);
	     		$param1 = str_replace($search, $replace, $ex_value);
	     		
	     	}
	     	else
	     	{
	     		$ex_value = '';
	     	}
	     		//print_r($ex_value);die;
	     		//if(!empty($value) && count($value) >= 1)
	     	
		    if($ex_value !='') 
      		{
      			
      			$searchnewRows1 = $wpdb->get_results("SELECT search_term FROM wpsft_search_term WHERE term_prefix = '$param1'");

      			if(count($searchnewRows1)){
					foreach($searchnewRows1 as $abc){
						//$where_cond .= " OR t1.address1 LIKE '%".$abc->search_term."% 0' OR t1.address1 LIKE '0 %".$abc->search_term."%' ";
						$where_cond .= " OR t1.address1 LIKE '%".$abc->search_term."% 0' OR t1.address1 LIKE '0 %".$abc->search_term."%' OR t1.address1 LIKE '%".$abc->search_term."%'";
					}
				}
				$where = ltrim($where_cond, " OR ");
				$where = rtrim($where, " ");

      			$searchnewRows2 = $wpdb->get_results("SELECT term_prefix FROM wpsft_search_term WHERE term_prefix = '$param1'");
      			//print_r($searchnewRows2);/*

      			if(count($searchnewRows2)){
					foreach($searchnewRows2 as $abc){
						$array_searchTerm[] = $abc->term_prefix;
					}
				}
      			
      			if(is_array($array_searchTerm))
				{      				
	      			if(in_array($param1, $array_searchTerm))
			     	{
			     		
			     		/*$myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state' OR meta_key ='postflag' ) GROUP BY p.ID ) as t1 WHERE $where ORDER by post_name LIMIT 0, 10");

			     		$myrows_count = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') AND (p.post_type = 'property') GROUP BY p.ID ) as t1 WHERE $where");*/

			     		$myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') AND (p.post_type = 'property') GROUP BY p.ID ) as t1 WHERE $where ORDER by post_name LIMIT 0, 10");

			     		$myrows_count = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') AND (p.post_type = 'property') GROUP BY p.ID ) as t1 WHERE $where");

			     		/*echo "count result else search: ".count($myrows_count);//die;
			     		echo "<pre>";
			     		echo "count result";
			     		print_r($myrows_count);*/


			     		//SELECT * FROM ( SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state' OR meta_key ='postflag' ) GROUP BY p.ID ) as t1 WHERE (meta_key = 'postflag' AND meta_value = 0) ) as t2 WHERE t2.address1 LIKE '%Lubbock%' 

			     	}
			    } 	
		     	else
                {
                    //$myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state' OR meta_key = 'postflag')  GROUP BY p.ID ) as t1 WHERE (address LIKE '%".$value."% 0' OR address LIKE '%".$param1."% 0' OR address LIKE '0 %".$value."%' OR address LIKE '0 %".$param1."%' ) ORDER by post_name LIMIT 0, 10");

                    $myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') AND (p.post_type = 'property') GROUP BY p.ID ) as t1 WHERE (address LIKE '%".$value."% 0' OR address LIKE '%".$param1."% 0' OR address LIKE '0 %".$value."%' OR address LIKE '0 %".$param1."%' OR address LIKE '%".$value."%') ORDER by post_name LIMIT 0, 10");

                    //$myrows_count = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state' OR meta_key = 'postflag')  GROUP BY p.ID ) as t1 WHERE (address LIKE '%".$value."% 0' OR address LIKE '%".$param1."% 0' OR address LIKE '0 %".$value."%' OR address LIKE '0 %".$param1."%' )");

                    
                     $myrows_count = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') AND (p.post_type = 'property') GROUP BY p.ID ) as t1 WHERE (address LIKE '%".$value."% 0' OR address LIKE '%".$param1."% 0' OR address LIKE '0 %".$value."%' OR address LIKE '0 %".$param1."%' OR address LIKE '%".$value."%' )");                     	

                     	/*echo "count result else search: ".count($myrows_count);
                     	echo "value: ".$value;
			     		echo "<pre>";
					    print_r($myrows_count);
					    die;*/

                }
            }
            else
            {
                $myrows = $wpdb->get_results("SELECT *, pm.meta_value FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (p.post_type = 'property') GROUP BY p.ID DESC LIMIT 0, 10");
                //echo "count rows: ".count($myrows);die;
                //$myrows_count = $wpdb->get_results("SELECT *, pm.meta_value FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = 'postflag') AND (meta_value = 0) GROUP BY p.ID");
                $myrows_count = $wpdb->get_results("SELECT *, pm.meta_value FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (p.post_type = 'property')  GROUP BY p.ID");

                //echo count($myrows);
                /*echo "count result ".count($myrows_count);
                echo "<pre>";
			    print_r($myrows_count);
			    die;*/
            }
			
		    

		    //echo count($myrows);
		    //echo '<pre>';print_r($myrows);
	     	if((isset($_POST) && !empty($_POST)) || (!empty($_GET['posearch']))){
				if(count($myrows_count) == 1)
		        {
		        	echo '<div class="col-md-12 col-sm-12 text-center"><h4 class="containt-hadding">'.count($myrows_count).' Property found</h4>
		     		<p><span>Matching with your keywords</p></span></div>';	
		        }
		        else if(empty(count($myrows_count)))
		        {	
		        	if(!empty($value))
		        	{
		        		if(!empty($_GET['posearch'])) 
		        		{
		        			$red_url = get_bloginfo("url").'/?searchval='.$_GET['posearch'];
		        		}
		        		else
		        		{
		        			$red_url = get_bloginfo("url").'/?searchval='.$_POST['searchValue'];
		        		}	
		        		echo '<div class="col-md-12 col-sm-12 text-center"><h4 class="containt-hadding">No Properties Found</h4>
		     		          <p><span>Matching with your keywords "'.$value.'"</span></p>';
		     		         ?> 
		     		          <img src="<?php bloginfo("stylesheet_directory") ?>/images/buildings.png" alt="property" class="mt-1 mb-3">		     		          
		     				<p>Do you want add this property ? </p>
		     				<a class="btn btn-primary w-auto" href="<?php echo $red_url; ?>">Click Here</a>
		     			<?php echo '</div>';
		     		}
		        }
		        else
		        {	
		        	echo '<div class="col-md-12 col-sm-12 text-center"><h4 class="containt-hadding">'.count($myrows_count).' Properties found</h4>
		     		<p><span>Matching with your keywords</p></span></div>';
		        }
	        }
	     	?>
	     	<input type="hidden" value="" name="post_id" id="post_id" />
            <input type="hidden" value="<?php echo $ex_value;?>" name="searchValue" id="SearchValue" />
	     	<div id="searchWrappper" class="col-md-12 col-sm-12">
				<?php
				if($myrows > 0)
				{
				    foreach ($myrows as $myrow)
				    {
					 	?>
				 		<div class="card-box">
					          	<div class="col-md-5 col-sm-5">
					            	<div class="set-map">
					   		 		 	<?php 
					   		 		 		$imfeatureds = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id = ".$myrow->ID." AND image_featured_status = 1");
					   		 		 		//echo '<pre>';print_r($imfeatureds);
					   		 		 		/*$image = wp_get_attachment_image_src( get_post_thumbnail_id( $myrow->ID ), 'single-post-thumbnail' );*/ 
						   		 		 	if($imfeatureds[0]->image_path)
						   		 		 	{	?>
						                        <img src="<?php echo $imfeatureds[0]->image_path; ?>" class="img-responsive" alt=""/>
						                    	<?php 
						                    }
						                    else
						                    {
						                    	/*echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found.jpg" class="img-responsive feature-img" alt=""/>';*/
						                    	if(CFS()->get('_property_address',$myrow->ID))
						                        {
						                            $property_address = CFS()->get('_property_address', $myrow->ID);
						                        }
						                        if(CFS()->get('_property_city', $myrow->ID))
						                        {
						                            $property_city = CFS()->get('_property_city', $myrow->ID);
						                        }
						                        if(CFS()->get('_property_state', $myrow->ID))
						                        {
						                            $property_state = CFS()->get('_property_state', $myrow->ID);
						                        }
						                        if(CFS()->get('_property_zip_code', $myrow->ID))
						                        {
						                            $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
						                        }
						                    	
						    $property_fulladdr = array('property_address' => urlencode($property_address),
						                    	'property_city' => urlencode($property_city),
						                    	'property_state' => urlencode($property_state),
						                    	'_property_zip_code' => urlencode($property_zip_code)
						                    	);
						                    	//print_r($property_fulladdr);
						    				   $op = '<div class="effect google-map-embed">';
											   $op .= '<iframe  width="470" height="275" frameborder="0" style="border:0" allowfullscreen ';
											   $op .= 'src="https://www.google.com/maps/embed/v1/place?q=';
											   $op .= implode(',', $property_fulladdr);
											   $op .= '&key=AIzaSyCUpXt8H-Wd6-_SHbSmnYwdBPXLDQD-gc0';  
											   $op .= '&zoom=11"></iframe></div>';

											   print $op;
						                    }
					                    ?>
					                 	<!--<div class="img-overlay">&nbsp;</div>-->
					                <?php /*    <div class="content">	
					                        <div class="top-content">
					                        	<?php 
					                        	$fields = CFS()->get('_propery_gallery', $myrow->ID);
					                        	
					                        	$countPhoto = count($fields);
					                        	if($countPhoto > 0)
					                        	{
					                        		if($countPhoto == 1)
					                        		{	
					                        			echo '<div class="num-photo">'.$countPhoto.' Photo</div>';	
					                        		}
					                        		else
					                        		{
					                        			echo '<div class="num-photo">'.$countPhoto.' Photos</div>';
					                        		}
					                        	}	
					                        	?>
					                            <!-- <div class="like-dislike"><a href="javascript:" class="favorite-property">&nbsp;</a></div> -->
					                        </div>
					                        <div class="bottom-content">
					                            <span class="common-align-center">
					                            	 <img src="<?php bloginfo('template_directory');?>/images/ready-icon.png"  alt=""/>
					                             </span>
					                             <span class="common-align-center">
					                            	<!--<span class="property-move">Upload Images ( New Property) </span>-->
					                             	<?php 
					                             		if(CFS()->get('_property_price', $myrow->ID))
					                                    {
					                                        $property_price = CFS()->get('_property_price', $myrow->ID);
					                                    	echo '<div class="property-price">$'.$property_price.'</div>';
					                                    }
					                             	?>
					                             </span>
					                        </div>
					                    </div> */ ?>
					                </div>
					            </div>
					            <div class="col-md-7 col-sm-7 mb-3">
					            		<h4 class="card-hadding mt-2"><a href="<?php echo $myrow->guid;?>" class="ptl">
	                            <?php echo $myrow->post_title;?>
	                          </a>
					            		<?php 
					                 		if(CFS()->get('_property_size', $myrow->ID))
					                        {
					                            $property_size = CFS()->get('_property_size', $myrow->ID);
					                        	echo '<br class="visible-xs"><span>'.$property_size.' sqft</span>';
					                        }
					                 	?>
					                 	</h4>
					                	<p>
					                		<?php
					                        if(CFS()->get('_property_address',$myrow->ID))
					                        {
					                            $property_address = CFS()->get('_property_address', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_city', $myrow->ID))
					                        {
					                            $property_city = CFS()->get('_property_city', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_state', $myrow->ID))
					                        {
					                            $property_state = CFS()->get('_property_state', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_zip_code', $myrow->ID))
					                        {
					                            $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
					                        	
					                        	$numlength = strlen((string)$property_zip_code);
			                                    if($numlength == 1)
			                                    {
			                                      $property_zip_code = '0000'.$property_zip_code;
			                                    }
			                                    elseif ($numlength == 2) {
			                                      $property_zip_code = '000'.$property_zip_code;
			                                    }
			                                    elseif ($numlength == 3) {
			                                      $property_zip_code = '00'.$property_zip_code;
			                                    }
			                                    elseif ($numlength == 4) {
			                                      $property_zip_code = '0'.$property_zip_code;
			                                    }
			                                    else {
			                                      $property_zip_code = $property_zip_code;
			                                    }
					                        }
					                        $pro_fulladr = array($property_address,$property_city,$property_state,$property_zip_code);
                                            $pro_fulladr = array_filter($pro_fulladr);
                                            echo implode(', ', $pro_fulladr);				                        
					                        ?>                                        
					                		</p>
					                		<?php
					                          $content = $myrow->post_content;
					                          //echo "contents: ".$content;
					                          if(!empty($content)){
					                          	echo '<p>';
					                          	echo $contentnew = substr($content, 0, 200);
					                          	echo '</p>';
					                          }
					                         
					                        ?>
					                	
					                    <div class="col-md-6 col-sm-12">    
					                    <div class="row">
               								 <p class="m-0"><strong>Reviews</strong></p>
                							<div class="star"> 														  		
											<?php 
							            echo do_shortcode('[RICH_REVIEWS_SNIPPET category="post" id="'.$myrow->ID.'" stars_only="true"]');
							            ?>
							            </div> 
					                      <?php /*  	<img src="<?php bloginfo('template_directory');?>/images/review-icon.png" class="mr-5"  alt=""/> 
					                        <a href="<?php echo $myrow->guid;?>">
					                        	<?php 
					                        		$ID = $myrow->ID;
					                        		$myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$ID' and review_status='1' ORDER BY id DESC");
					                        		$count_reviews = count($myrows);
					                        		if($count_reviews == 1)
					                        		{
					                        			echo '1 + Review';
					                        		}
					                        		if($count_reviews == 0)
					                        		{
					                        			echo 'No Reviews';
					                        		}
					                        		else
					                        		{
					                        			if($count_reviews != 1)
					                        			{
					                        				echo $count_reviews.'+ Reviews';
					                        			}
					                        		}
					                        	?>
					                        </a>
					                        */ ?>
              								</div>     		
					                        </div>
					                        <div class="col-md-6 col-sm-12">
					                        <a href="<?php echo $myrow->guid;?>" class="btn btn-primary btn-block pull-right w-autos">
					                        Write a review
					                        </a>
					                
					                  	</div>
					              	
					            </div>
					        </div>

						<?php 
						$count++; 
					}
				}     
			    ?>
			</div>
			</div>
			<?php

	        if(count($myrows_count) > 10 || count($myrows_count) > 10)
	   		{
	   			?>
		   		<div class="text-center">
		   		<!-- <img src="<?php //bloginfo('template_directory');?>/images/loader.svg" width="32" height="30" alt=""/> -->
		   		<a href="javascript:void(0);" class="load_more" data-nonce="<?php echo wp_create_nonce('load_posts') ?>">
	                  <img src="<?php bloginfo('template_directory');?>/images/loader.svg" alt="" width="32" height="30">
	            </a>
		   		</div>
	    		<?php 
	    	}
	    	?>
</div>
	</div>
	<?php // End of the loop.
	endwhile;
	?>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			var uri = window.location.toString();
			if (uri.indexOf("?") > 0) 
			{
				var clean_uri = uri.substring(0, uri.indexOf("?"));
				window.history.replaceState({}, document.title, clean_uri);
			}
		});
	</script>
<?php get_footer(); ?>
