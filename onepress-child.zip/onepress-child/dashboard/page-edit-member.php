<?php
/**
*Template Name: Edit Member
*/

global $wpdb, $current_user;
    if (isset($_GET['member']) && !empty($_GET['member']) ) {
    $cur_id = $_GET['member'];
  } else {
    wp_redirect( get_bloginfo('url').'/manage-your-users', 301 ); exit;
  }
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}

if (is_user_logged_in() && empty(nstxl_is_poc($current_user->ID))) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}

get_header('admin'); 

  if( !empty($cur_id) ) {  
  $poc_user_id = get_user_meta($cur_id,'poc',true); 
    if(empty($poc_user_id)){
   $puid = nstxl_get_parent_userid($cur_id);      
      $poc_user_id = get_user_meta($puid,'poc',true); 
    } else {
      $poc_user_id = $poc_user_id;
    }

  //  echo'pocuserid after checking the puid'.$poc_user_id;
    // if( $userid = nstxl_is_poc($cur_id) ) {
    //   $userdata = nstxl_company_additional_userdata($cur_id);      
    //   $poc_user_id = get_user_meta($userid, "poc",true);
    //   if($poc_user_id == $cur_id ) {
    //     $poc_checked = 'yes';    
    //   } else {
    //     $poc_checked = '';
    //   }  
    // } 
      if($poc_user_id == $cur_id ) {
        $poc_checked = 'yes';    
      } else {
        $poc_checked = '';
      }
    $single_user_data = get_userdata($cur_id);
    $uploaded_comp_url  = nstxl_get_company_logo($cur_id); 
  // $company_name  = get_user_meta($cur_id, "company_name",true);  
    $company_name  = $single_user_data->company_name;  
    //$linkedin_id  = get_user_meta($cur_id, "linkedin_id",true);
    $linkedin_id  = $single_user_data->linkedin_id;
    $join_lists = get_user_meta($cur_id,'join-our-mailing-list',true);
    $first_name  = $single_user_data->first_name;
    $last_name  = $single_user_data->last_name;
    $email  = $single_user_data->user_email;
  }
  do_action('onepress_page_before_content');
  ?>
  <div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">
  <div class="edituser-container adduser-container dashboard-inner-wrapper dashboard-bg-white personal-profile-dashboard personal-info-container">
     <a class="arrow-back" href="<?php echo site_url(); ?>/manage-your-users/"><img src="<?php echo get_stylesheet_directory_uri().'/images/arrow-back.png'; ?>" /></a>
    <div class="wrap-apple-icon person-name">
      <?php if(!empty($first_name) && !empty($last_name)) { 
        echo '<h2 class="rgs_title">'.esc_attr(stripslashes_deep(ucfirst($first_name))).' '.esc_attr(stripslashes_deep(ucfirst($last_name))).'<img class="editmember" src="'.get_stylesheet_directory_uri().'/assets/images/edit-red-large.svg"></h2>';
      } 
    ?> 
    </div>
 <div class="clearfix"></div>
    <div class="edituser-form-container dashboard-form-wrapper">
      <form method="post" class="edituser-form" enctype="multipart/form-data" name="edituser" id="edituser">
        <div class="row mt-4" id="editmember">
          <div class="form-group col-lg-6 col-md-6"> 
             <label for="first_name"><?php _e('First Name','paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input name="first_name" required value="<?php echo esc_attr(stripslashes_deep($first_name)); ?>" type="text">
           
          </div>
          <div class="form-group col-lg-6 col-md-6"> 
            <label for="last_name"><?php _e('Last Name','paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input name="last_name" required value="<?php echo esc_attr(stripslashes_deep($last_name)); ?>" type="text">  
            
          </div>
        </div>
        <div class="row mt-4">
          <div class="form-group col-lg-12 col-md-12">
            <label for="email"><?php _e('Email','paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
              <input name="email" required readonly value="<?php echo esc_attr(stripslashes_deep($email)); ?>" type="email">
          </div> 
        </div>
         <div class="row mt-3 mb-3">
          <div class="form-group editSection col-lg-6 col-md-6">
            <div class="poc_radio">
               <label for="poc"><?php _e('Assign POC','paid-memberships-pro'); ?></label></br>
              <label class="switch">
                <input class="poc" type="checkbox" value="yes" <?php if('yes' == $poc_checked) { echo 'onclick="return false;"'; } ?> <?php checked( 'yes' == $poc_checked ); ?> name="poc">
                <span class="slider round"></span>
              </label>
              </span>
            </div> 
 
          </div>
        </div>
        <div class="row">
          <div class="form-group editSection col-lg-6 col-md-6">
              <label for="membernewpass"><?php _e('Reset Password','paid-memberships-pro'); ?></label>
              <input type="password" name="membernewpass" id="membernewpass" class="form-control" value="">
          </div>
          <div class="form-group editSection col-lg-6 col-md-6">
              <label for="memberconfirmpass"><?php _e('Confirm Password','paid-memberships-pro'); ?></label>
               <input type="password" name="memberconfirmpass" id="memberconfirmpass" class="form-control" value="">
          </div>
        </div>

        <input name="cusrid" value="<?php if(!empty($cur_id)) { echo $cur_id; } ?>" type="hidden">
        <input name="pocid" value="<?php if(!empty($poc_user_id)) { echo $poc_user_id; } ?>" type="hidden">

        <div class="btn-group row">
          <div class="form-group editSection col-lg-12 col-md-12">
            <button type="button" class="btn-txt mr-3 mt-4 btn-magenta" name="editmember-update" id="editmember-update"><?php _e( 'Update','paid-memberships-pro'); ?></button>
            <?php 
            $poc = nstxl_is_poc($cur_id);
            if(empty($poc)) { 
              ?>
               <input type="submit" name="remove-member" id="remove-member" class="remove-member btn-txt mt-4" value="Remove User"> 
            <?php } ?>

            <?php 

if (isset($_POST['remove-member']))
 {
    $deleteuser = wp_delete_user($cur_id);

     if($deleteuser){
        $delete_content_html = '<h4>User deleted successfully.</h4> ';
     } else {
      $delete_content_html  = is_wp_error('Something is wrong');
     }
   
$delete_modal_id = 'delete-user-modal-' . $cur_id;
$delete_modal_body_container_class = 'delete-opportunity-modal-container';
nstxl_modal_popup($delete_content_html, $delete_modal_id, $delete_modal_body_container_class);
?>

<script type="text/javascript">
  jQuery(document).ready(function ($) {
    jQuery('#<?php echo $delete_modal_id; ?>').modal('show');
    jQuery('#<?php echo $delete_modal_id; ?> .close').on('click', function (e) {
      jQuery('#<?php echo $delete_modal_id; ?>').modal('hide');
    });
     jQuery('#<?php echo $delete_modal_id; ?>').on('hidden.bs.modal', function () {
      window.location.href = siteurl + '/manage-your-users/';
    })
  }); 
</script>

<?php
 }

?>
          </div>
        </div>
      </form>
    </div>
  </div>
</main>
</div>
</div>
</div>
  <!-- Modal -->
  <div class="modal fade custom-popup" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
          </button>
          <div class="update-personalinfo-box-success-container modal-body-container">
            <h4>Member has been edited successfully.</h4> 
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
  </div> 
  <!-- /.modal -->  





  <script>
    var curuid = '<?php echo $cur_id; ?>';
    mainemail = "<?php echo $current_user->user_email; ?>";
  </script>
  <script>
    jQuery(document).ready( function($) {

      jQuery("#editmember").hide();

      jQuery(".editmember").click(function(){
        jQuery("#editmember").toggle();
      }); 

      jQuery.validator.addMethod("validemail", function(value, element) {
           var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
          // allow any non-whitespace characters as the host part
          return this.optional( element ) || filter.test( value );
          }, 'Please enter an valid email.');
      jQuery.validator.addMethod("domaincheck", function(value, element) {
        var this_field = jQuery('#edituser [name=email]');
        var useremail = jQuery('#edituser [name=email]').val();  
        var cmp_email = mainemail;  
        var sp = cmp_email.split('@');
        var cmp_domain = sp[1];   
        var spls = cmp_domain.split('.');
        var d;
        var ext;
        if(spls.length > 2 ){ 
          d = spls[spls.length - 1];
          ext = spls[spls.length];
        } else {
          d = spls[0];
          ext = spls[1];
        }  
        var re = new RegExp('^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?('+d+')\.'+ext+'$');
          // allow any non-whitespace characters as the host part
        return this.optional( element ) || re.test( value );
      }, 'Domains must match.');

      jQuery('.pmpro_asterisk').remove();      
      jQuery('ul.multiselect-container.dropdown-menu li label.checkbox').each(function (index) {
        spclength1 = jQuery(this).find('span.checkmark').length;
        if (spclength1 == 0) {
          jQuery(this).append('<span class="checkmark"></span>');
        } 
      });
      $("#edituser").validate({
        rules: {
          first_name: {
            required: true,
          },
          action: "required",
          email: {
            required: true,    
            validemail: true,      
            //domaincheck: true, 
            remote: {
              url: nstxl_ajaxurl,
              type: 'post',        
              data: {
                action: 'nstxl_check_editmemberemail',
                curuid: curuid,
                email: function () {
                  return $("input[name='email']").val();
                }
              },
            }         
          },
          last_name: {
            required: true,
          }, 
      membernewpass: {
        minlength: 5
      },
      memberconfirmpass: {
        minlength: 5,
        equalTo: "#edituser [name=membernewpass]"
      },        
        },
        messages: {      
          email: {
            required: "Please enter email",
            validemail:"Please enter valid email address",
            //domaincheck:'Email domain must match with company domain',
            remote: 'Email is already taken.'
          }      
        },
        
        errorClass: "form-invalid",
        // errorLabelContainer:'.help-block.with-errors',
        errorElement: 'div',
        highlight: function(element, errorClass, validClass) {
          $(element).closest("div.field").addClass("error").removeClass("success");
        },
        unhighlight: function(element, errorClass, validClass){
          //jQuery('.preloader').fadeIn();
          //jQuery('.preloader').css('display', 'block');
          $(element).closest(".error").removeClass("error").addClass("success");
        },
        errorPlacement: function (error, element) {

          if(element.parent().find("div.help-block.with-errors").length === 0) {
            if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {         
              element.parent().append(error); 
            } else {
              error.addClass("help-block with-errors").appendTo( element.closest('div.form-group'));          
            }
          } else {
            if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
              element.parent().append(error); 
            } else {            
              error.appendTo(element.parent().find("div.help-block.with-errors"));
            }              
          }
        },   
        
      });

      jQuery('.join_our_mailing_list').multiselect({                 
        nonSelectedText: "Stay Informed",
        includeSelectAllOption: true,
      });

      jQuery('#editmember-update').on('click', function(e){
        e.preventDefault();
        if(jQuery('#edituser').valid()){  
          var form = jQuery('form#edituser')[0]; 
          var formData = new FormData(form);
          formData.append("action", "nstxl_update_single_member");
          $.ajax({
            url: nstxl_ajaxurl,
            type: "POST",
            data: formData,
            beforeSend: function() {   
              jQuery('.preloader').fadeIn();
            },        
            success: function (response, textStatus){
              jQuery('.preloader').fadeOut("slow");
              if (response.data.response == "success") {
                jQuery('#update-personalinfo-modal-success').modal('show');
              }

            },
            error: function(textStatus, errorThrown) { 
              add_message( textStatus, "danger" );
            },
            complete: function(){
            },
            cache: false,
            contentType: false,
            processData: false
          });

        }
      //jQuery('#update-personalinfo-modal-success').modal('hide');      
      });   
      jQuery('.close').on('click', function(e){
        jQuery('#update-personalinfo-modal-success').modal('hide');      
      });     
      jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
        window.location.href = siteurl+'/manage-your-users';
      });
    });
</script> 

<?php
get_footer('admin');