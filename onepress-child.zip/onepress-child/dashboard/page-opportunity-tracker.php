<?php
/*
 * Template Name: Opprtunity tracker 
 *
 * @package OnePress
 */
get_header( 'admin' );
global $current_user;
if ( ! is_user_logged_in() ) {
	wp_redirect( get_bloginfo( 'url' ) . '/login', 301 );
	exit;
}

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');

  onepress_breadcrumb();

$mytrackIDs = get_user_meta( $current_user->ID, 'myopportunitiesposts', true );
if ( ! empty( $mytrackIDs ) ) {
	?>
	<!--Star of container -->
	<div class="opportunity-tracker-container dashboard-inner-wrapper">
		<div class="row">
			<div class="clearfix col-sm-12">
				<h3 class="rgs_title clearfix"><?php _e( the_title(), 'paid-memberships-pro' ); ?></h3>
			</div>
			<div class="search-wrapper clearfix col-sm-12">            
				<div class="btn-group pull-right"><button class="btn btn-magenta opportunityinfo" type="button"><?php _e( 'Track Opportunities', 'paid-memberships-pro' ); ?></button>
				</div>
			</div>
		</div>  
		<div class="opportunity-tracker-inner">         
			<!-- Blog Query  -->
			<div class="polar-posts">
				<div class='row'>
					<?php
					$paged = (get_query_var( 'paged' )) ? get_query_var( 'paged' ) : 1;
					// $args = array('post_type' => 'post','category__not_in' => 34, 'posts_per_page' => 6, 'paged' => $paged );
					$args	 = array( 'post_type' => 'opportunity', 'posts_per_page' => 6, 'paged' => $paged, 'post__in' => $mytrackIDs );
					query_posts( $args );
					?>
					<!-- the loop -->
					<?php
					if ( have_posts() ) : while ( have_posts() ) : the_post();
							$posttitle = get_field( 'nstxl_short_title', get_the_ID() );
							$wordcount = str_word_count( $posttitle );
							?>
							<div class="col-sm-6 col-md-4 wow animated fadeInUp opportunity-panel">
								<article id="post-<?php the_ID(); ?>" <?php echo post_class( 'polar-post polar-isotope-item' ) ?>>
									<?php
									if ( has_post_thumbnail() ) {
										echo '<div class="featured-media"><a href="' . esc_url( get_permalink() ) . '">';
										the_post_thumbnail( 'polar_grid_thumbnail_fixed', array( 'class' => 'featured-image' ) );
										echo '</a></div>';
									} else {
										echo '<div class="featured-media"><a href="' . esc_url( get_permalink() ) . '">';
										echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/assets/images/placeholder.png" />';
										echo '</a></div>';
									}
									?>
									<div class="card-content">
										<p class='post-title'>
											<?php if ( $wordcount > 8 ) { ?> 
												<a href='<?php echo esc_url( get_permalink() ); ?>'><?php echo wp_trim_words( $posttitle, 8, '' ); ?></a>
											<?php } else { ?>
												<a href='<?php echo esc_url( get_permalink() ); ?>'><?php echo $posttitle; ?></a>
											<?php } ?>
										</p>
										<ul class="opporutnity-info-list">
											<li>
												<?php echo get_ota_logos(); ?>
											</li>
											<li>                
												<a class="untrackopportunity" data-id="<?php echo get_the_ID(); ?>" href="#"><img src="<?php echo content_url(); ?>/uploads/2018/11/track-opportunity.png"><?php _e( 'Untrack Opportunity', 'polar' ); ?></a>
											</li>
											<li>
												<a href="<?php echo esc_url( get_permalink() ); ?>#keydocuments-md"><img src="<?php echo content_url(); ?>/uploads/2018/11/key-documents.png"><?php _e( 'Key Documents', 'polar' ); ?></a>
											</li>
											<li>
												<a href="<?php echo esc_url( get_permalink() ); ?>#submitquestion-md"><img src="<?php echo content_url(); ?>/uploads/2018/11/submit-a-question.png"><?php _e( 'Submit a Question', 'polar' ); ?></a>
											</li>
											<li>
												<a href="<?php echo esc_url( get_permalink() ); ?>#events-md"><img src="<?php echo content_url(); ?>/uploads/2018/11/Dates-and-events.png"><?php _e( 'Dates and Events', 'polar' ); ?></a>
											</li>                                                                                       
											<?php
											$url = get_bloginfo( 'url' ) . '/submit-aproposal?opid=' . get_the_ID();
											$url = add_query_arg( '_wpnonce', wp_create_nonce( 'submitproposallink' ), $url );
											?>
											<li>
												<a href="<?php echo $url; ?>"><img src="<?php echo content_url(); ?>/uploads/2018/11/submit-a-proposal.png"><?php _e( 'Submit a Proposal', 'polar' ); ?></a>
											</li>
										</ul>
									</div>
									<!-- the title, the content etc.. -->
								</article>
							</div>
						<?php endwhile; ?>
					<?php else : ?>
						<!-- No posts found -->
					<?php endif; ?>
				</div>
				<div class="loadmore wow animated fadeInUp" id="loadmores"><?php echo get_next_posts_link( 'Load more' ); ?></div>
				<!-- End of Blog Query -->
			</div>
			<?php wp_reset_query(); ?>
		</div>
	</div> 
	</div>   
	<!-- Modal -->
	<div class="modal fade" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" aria-hidden="true">&times;</button> 
					<div class="update-personalinfo-box-success-container">
						<p></p> 
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
	</div> 
	<!-- /.modal -->

	<style>
		#update-personalinfo-modal-success {
			z-index: 99999;
		}
		#update-personalinfo-modal-success {
			z-index: 9999;
		}
	</style>
	<!-- Modal -->
	<div class="modal fade" id="opportunity-info-modal" tabindex="-1" role="dialog" aria-labelledby="opportunity-info-modal-modalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" aria-hidden="true">&times;</button> 
					<div class="opportunity-info-modal-box-success-container">
						<?php include(locate_template( 'opportunities.php' )); ?>
					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
	</div> 
	<!-- /.modal -->
	<script type="text/javascript">
	</script>
	<script>
		jQuery( document ).ready( function ( $ ) {
			trackOpportunity();
			untrackOpportunity();
			$( 'body' ).on( 'click', '.opportunity-tracker-inner .loadmore a', function ( e ) {
				e.preventDefault();
				var temphref = $( this ).attr( 'href' );
				$( ".opportunity-tracker-inner #loadmores" ).html( "<div class='loadmore wow animated fadeInUp loadmoreloading'> <img src='" + loademoreimg + "' /> Loading...</div>" );

				$.post( temphref, function ( response ) {
					$( ".opportunity-tracker-inner #loadmores" ).remove();
					var tempdata = $( response ).find( '.opportunity-tracker-inner .polar-posts' ).html();
					$( ".opportunity-tracker-inner .polar-posts" ).append( tempdata );
					untrackOpportunity();
				} );
			} );
			jQuery( '#update-personalinfo-modal-success .close' ).on( 'click', function ( e ) {
				jQuery( '#update-personalinfo-modal-success' ).modal( 'hide' );
			} );

			jQuery( '#update-personalinfo-modal-success' ).on( 'hidden.bs.modal', function () {
				location.reload( true );
			} )

			$( '.opportunityinfo' ).on( 'click', function ( e ) {
				e.preventDefault();
				jQuery( '.preloader' ).fadeIn();
				$( '#opportunity-info-modal' ).modal( 'show' );
				// $('#opportunity-info-modal .opportunity-info-modal-box-success-container').load(siteurl+'/remote-opportunities/',function(result){
				//     $('#opportunity-info-modal').modal('show');
				// });
				jQuery( '.preloader' ).fadeOut();
			} );

			jQuery( '#update-personalinfo-modal-success' ).on( 'shown.bs.modal', function () {
				//jQuery('#opportunity-info-modal').modal('hide');
				jQuery( '#opportunity-info-modal' ).removeClass( 'in' );
				jQuery( '#opportunity-info-modal' ).css( 'display:none' );
			} );

			jQuery( '.opportunity-info-modal-box-success-container' ).on( 'shown.bs.modal', function () {
				jQuery( '.preloader' ).fadeOut();
			} );

			jQuery( 'body' ).on( 'click', '.close', function ( e ) {
				jQuery( '#opportunity-info-modal' ).removeClass( 'in' );
				jQuery( '#opportunity-info-modal' ).css( 'display:none' );
				jQuery( '.modal-backdrop' ).remove();
				location.reload( true );

			} );
			jQuery( '#opportunity-info-modal' ).on( 'hidden.bs.modal', function () {
				location.reload( true );
			} );
		} );
	</script>
<?php } else {
	?>
	<div class="text-center no-opportunities"><p>No tracked opportunities found</p></div>
	<?php
}
get_footer( 'admin' );
