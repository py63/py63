<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/* custom icon to menu */
add_action('admin_head', 'aco_menu_icon');
function aco_menu_icon(){
	echo '<style>
	#woocommerce-product-data ul.wc-tabs li.cart_custom_opt_options.cart_custom_opt_tab a:before{
		content: "\f510";
	}
	.cart_opt_panel.woocommerce_options_panel input[type=url] {
		width: 50%;
		float: left;
	}
	p.aco-mxlimit {
		padding: 0;
		color: darkred;
	}
	</style>';
}

