=== ADD TO CART OPTION ===

Contributors: TFL
Tags: woocommerce, cart, product, options, add to cart 
Requires at least: WordPress 5.0 or higher
Tested up to: 5.8
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The "Add to cart option" is a very simple woocommerce addon plugin that helps you put more features to your woocommerce store. It allows us to hide/rename/redirect the "add to cart" button for customer user role and visitors. It also adds more features to disable any specific product for customer role or visitors.

== Description ==

The plugin is very easy to use just install and edit the product where you will find the "Add to cart option" menu.

== Features ==
This plugin provides the following features:
	* Disable product being added to the cart from users having customer role.
	* Disable this product being added to the cart for visitors.
	* Replaces the "Add to Cart" label.
	* Redirect the user on click add to cart button when product is disabled

== Installation ==

Installation Steps

1. Upload the folder to `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Edit the product from the backend and go to the "Add to cart option" tab.

== Frequently Asked Questions ==

= Can we disable the product for any specific user role? =
Yes, there is an option for disabling products for customer role and visitors.

= Does it replace the "add to cart" label for all user roles? =
No, you can replace the "add to cart" button label for customer role and visitors only. 

== Screenshots ==

1. Add to cart option
2. Label changed


== Changelog ==

= 1.0 =
First Stable Release

== Upgrade Notice ==
 
= 1.0 =
First Stable Release.