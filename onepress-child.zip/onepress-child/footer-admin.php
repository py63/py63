<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OnePress
 */

$hide_footer = false;
$page_id = get_the_ID();

if ( is_page() ){
    $hide_footer = get_post_meta( $page_id, '_hide_footer', true );
}

if ( onepress_is_wc_active() ) {
    if ( is_shop() ) {
        $page_id =  wc_get_page_id('shop');
        $hide_footer = get_post_meta( $page_id, '_hide_footer', true );
    }
}

if ( ! $hide_footer ) {
    ?>
    <footer id="colophon" class="site-footer" role="contentinfo">
        <?php
        /**
         * @since 2.0.0
         * @see onepress_footer_widgets
         * @see onepress_footer_connect
         */
        do_action('onepress_before_site_info');
        $onepress_btt_disable = sanitize_text_field(get_theme_mod('onepress_btt_disable'));

        ?>

        <div class="site-info">
            <div class="container">
                <?php if ($onepress_btt_disable != '1') : ?>
                    <div class="btt">
                        <a class="back-to-top" href="#page" title="<?php echo esc_html__('Back To Top', 'onepress') ?>"><i class="fa fa-angle-double-up wow flash" data-wow-duration="2s"></i></a>
                    </div>
                <?php endif; ?>
                <?php
                /**
                 * hooked onepress_footer_site_info
                 * @see onepress_footer_site_info
                 */
                do_action('onepress_footer_site_info');
                ?>
            </div>
        </div>
        <!-- .site-info -->

    </footer><!-- #colophon -->
    <?php
}
/**
 * Hooked: onepress_site_footer
 *
 * @see onepress_site_footer
 */
do_action( 'onepress_site_end' );
?>
</div><!-- #page -->

<?php do_action( 'onepress_after_site_end' ); ?>


<script type="text/javascript">


    jQuery( document ).ready(function() 
    {   
        jQuery('li .elementor-item').click(function (e) {
            e.preventDefault();
            window.location = (jQuery(e.currentTarget).attr("href"));        
        });

        jQuery('.current-menu-item ul').show();
        jQuery('.current-menu-item ul').attr('aria-expanded', true);

        jQuery('.current-menu-item').parents('ul').show();
        jQuery('.current-menu-item').parents('.current-menu-parent').find('a').attr('aria-expanded', true);

    });

</script>
<?php
if (is_user_logged_in()) {
global $current_user;
$poc = nstxl_is_poc( $current_user->ID );
if(empty($poc))
{ ?>
 <style>
     .addtionalnonpoc{
        display: block;
     }
     .pocuser{
        display: none;
     }
 </style>   

<?php
} else{ ?>
<style>
 .addtionalnonpoc{
        display: none;
     }
      .pocuser{
        display: block;
     }

</style>
<?php } }?>
<?php if(file_exists(nstxl_extention_path.'includes/template/dashboard-restrict-modals.php')){ include nstxl_extention_path.'includes/template/dashboard-restrict-modals.php'; } ?>
<?php wp_footer(); ?>
<script>
/**
   * Detect OS & browsers
   */
  / Add class for mac /
  if(navigator.appVersion.indexOf("Win")!=-1) {
    jQuery('body').addClass('window-os');
  }
  if(navigator.platform.toUpperCase().indexOf('MAC')>=0) {
    jQuery('body').addClass('mac-os');
  }
  if(navigator.appVersion.indexOf("Linux")!=-1) {
    jQuery('body').addClass('linux-os');
  }
  
  if(navigator.appVersion.indexOf("Edge") != -1){
	   jQuery('body').addClass('edge');

}
  / Add class for all ie version /
  var trident = !!navigator.userAgent.match(/Trident\/7.0/);
  var net = !!navigator.userAgent.match(/.NET4.0E/);
  var IE11 = trident && net;
  var IEold = ( navigator.userAgent.match(/MSIE/i) ? true : false );
  if(IE11 || IEold){
    jQuery('body').addClass('ie');
  }
  var ua = navigator.userAgent.toLowerCase();
  if (ua.indexOf('safari') != -1) {
    if (ua.indexOf('chrome') > -1) {
      jQuery('body').addClass('chrome');
    } else {
      jQuery('body').addClass('safari');
    }
  }
  var FF = !(window.mozInnerScreenX == null);
  if(FF) {
    jQuery('body').addClass('fire-fox'); 
  } else { 
    jQuery('body').addClass('not-fire-fox');
  }
  / End /
</script>
</body>
</html>
