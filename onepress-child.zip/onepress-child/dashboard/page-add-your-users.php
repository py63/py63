<?php
/**
*Tsemplate Name: Add/Edit your users
*/
get_header('admin');
if(is_user_logged_in()) { 

  global $gateway, $pmpro_review, $skip_account_fields, $pmpro_paypal_token, $wpdb, $current_user, $pmpro_msg, $pmpro_msgt, $pmpro_requirebilling, $pmpro_level, $pmpro_levels, $tospage, $pmpro_show_discount_code, $pmpro_error_fields;
  global $username, $bfirstname, $blastname, $baddress1, $baddress2, $bcity, $bstate, $bzipcode, $bcountry, $bphone, $bemail;
  if( !empty($current_user) ) {
    $cur_id = $current_user->ID;
    $name_on_card = get_user_meta($cur_id,'name_on_card',true);
    if(empty($bfirstname)) {
      $bfirstname = $current_user->user_firstname;
    }
    if(empty($blastname)){
      $blastname = $current_user->user_lastname;
    }

//if( !empty($blastname)){
    $user_login = $current_user->user_login;
//}

    if(empty($bemail)){
      $bemail = $current_user->user_email;
    }

    if(empty($bconfirmemail)){
      $bconfirmemail = $current_user->user_email;
    }
    if(empty($username)){
      $username = $current_user->user_login;
    }
    if( !empty($cur_id) ) {
      $poc_user_id = get_user_meta($cur_id, "poc",true);
      if($poc_user_id == $cur_id ){
        $poc_checked = 'yes';
      } else {
        $poc_checked = '';
      }
      $linkedin_id = get_user_meta($cur_id,'linkedin_id',true);
      $cmp_users_data = get_user_meta($cur_id, 'company_data', true);
    }

  }
  ?>
<style>
.pmpro_form .rgs_title { text-align: center;}
input[type='text'] {
  border-left: 0 none !important;
  border-top: 0 none !important;
  border-right: 0 none !important;
}
.form-invalid {
  color: #a94442;
  font-size: 12px;
  font-weight: normal;
  line-height: 18px;
}
</style>
<div class="row">
  <div class="editusers-container">
    <form method="post" class="pmpro_form" enctype="multipart/form-data" name="manageuser" id="manageuser">
      <div class="col-md-12">
<div id="step-3">
  <div id="form-step-2" role="form">
    <h3 class="rgs_title"><?php _e(the_title(),'paid-memberships-pro'); ?></h3>
    <div class="repeater-default container" style="margin:20px auto;">
      <?php if(!empty($cmp_users_data)){ ?>
        <?php foreach ($cmp_users_data as $key=> $val) {
          if(isset($val['poc'])){
            $poc_checked = $val['poc'][0];
          } else {
            $poc_checked = '';
          }
          //echo '<pre>';  print_r($val); echo '</pre>'; ?>
          <div data-repeater-list="cmpdata" class="row cmp_users_data">
            <div data-repeater-item class="col-md-12 item">
              <!--<div class="form-group">-->
              <div class="lusrsec_div pmpro_checkout-field col-md-10">
                <div class="row">
                  <div class="col-sm-3">
                    <div class="form-group">
                      <input class="lfirstname" name="lfirstname" type="text" class="input" size="30" value="<?php echo esc_attr($val['lfirstname']); ?>" />
                      <label class="control-label" for="lfirstname"><?php _e('First Name', 'paid-memberships-pro'); ?></label>
                    </div>
                  </div>
                  <div class="col-sm-3">   
                    <div class="form-group">          
                      <input class="llastname" name="llastname" type="text" class="input" size="30" value="<?php echo esc_attr($val['llastname']); ?>" />
                      <label class="control-label" for="llastname"><?php _e('Last Name', 'paid-memberships-pro'); ?></label>
                    </div>
                  </div>
                  <div class="col-sm-3 lemail"> 
                    <div class="form-group">
                      <input class="lemail" name="lemail" type="email" class="input" size="30" value="<?php echo esc_attr($val['lemail']); ?>" />
                      <label class="control-label" for="lemail"><?php _e('Email', 'paid-memberships-pro'); ?></label>
                      <div class="help-block with-errors"></div>
                    </div>
                  </div> 

                  <div class="col-sm-3">
                    <div class="form-group"> 
                      <input class="llinkedin_id" name="llinkedin_id" type="text" class="input" size="30" value="<?php echo esc_attr($val['llinkedin_id']); ?>" />
                      <label class="control-label" for="llinkedin_id"><?php _e('LinkedIn ID', 'paid-memberships-pro'); ?></label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-1 poc-div">
                <label class="checkbox"><input  class="poc" value="yes" name="poc" <?php echo checked( $poc_checked, 'yes' ); ?> type="checkbox"><span>POC</span><span class="checkmark"></span></label>

              </div>
              <div class="col-sm-1">
                <span data-repeater-delete class="btn btn-danger btn-sm btn-remove">    
                  <?php $delete_img_url = WP_PLUGIN_URL . '/nstxl-memberhip-extension/images/delete.png'; ?>
                  <img src="<?php echo $delete_img_url; ?>">
                </span>
              </div> 
            </div>      
          </div> 
          <?php } ?>
          <?php } else { ?>
            <div data-repeater-list="cmpdata" class="row repeater-first-section">
              <div data-repeater-item class="col-md-12 item">
                <div class="lusrsec_div pmpro_checkout-field col-md-10">
                  <div class="row">
                    <div class="col-sm-3">
                      <div class="form-group">
                        <input class="lfirstname" name="lfirstname" type="text" class="input" size="30" value="" />
                        <label class="control-label" for="lfirstname"><?php _e('First Name', 'paid-memberships-pro'); ?></label>
                      </div>
                    </div>
                    <div class="col-sm-3">   
                      <div class="form-group">          
                        <input class="llastname" name="llastname" type="text" class="input" size="30" value="" />
                        <label class="control-label" for="llastname"><?php _e('Last Name', 'paid-memberships-pro'); ?></label>
                      </div>
                    </div>
                    <div class="col-sm-3 lemail"> 
                      <div class="form-group">            
                        <input class="lemail" name="lemail" type="email" class="input" size="30" value="" />
                        <label class="control-label" for="lemail"><?php _e('Email', 'paid-memberships-pro'); ?></label>
                        <div class="help-block with-errors"></div>
                      </div>
                    </div> 
                    <div class="col-sm-3">
                      <div class="form-group"> 
                        <input class="llinkedin_id" name="llinkedin_id" type="text" class="input" size="30" />
                        <label class="control-label" for="llinkedin_id"><?php _e('LinkedIn ID', 'paid-memberships-pro'); ?></label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-1 poc-div">
                  <label class="checkbox"><input  class="poc" value="yes" name="poc"  <?php echo checked( $poc_checked, 'yes' ); ?> type="checkbox"><span>POC</span><span class="checkmark"></span></label>
                </div>
                <div class="col-sm-1">
                  <span data-repeater-delete class="btn btn-danger btn-sm btn-remove">
                    <?php /* ?><span class="glyphicon glyphicon-minus"></span> <?php */ ?>
                    <?php $delete_img_url = WP_PLUGIN_URL . '/nstxl-memberhip-extension/images/delete.png'; ?>
                    <img src="<?php echo $delete_img_url; ?>">
                  </span>
                </div> 
              </div>      
            </div>
            <?php } ?>
            <div data-repeater-list="cmpdata" class="row">
              <div data-repeater-item class="col-md-12 item">
                <div class="lusrsec_div pmpro_checkout-field col-md-10">
                  <div class="row">
                    <div class="col-sm-3">
                      <div class="form-group">
                        <input class="lfirstname" name="lfirstname" type="text" class="input" size="30" value="" />
                        <label class="control-label" for="lfirstname"><?php _e('First Name', 'paid-memberships-pro'); ?></label>
                      </div>
                    </div>
                    <div class="col-sm-3">   
                      <div class="form-group">          
                        <input class="llastname" name="llastname" type="text" class="input" size="30" value="" />
                        <label class="control-label" for="llastname"><?php _e('Last Name', 'paid-memberships-pro'); ?></label>
                      </div>
                    </div>
                    <div class="col-sm-3 lemail"> 
                      <div class="form-group">            
                        <input class="lemail" name="lemail" type="email" class="input" size="30" value="" />
                        <label class="control-label" for="lemail"><?php _e('Email', 'paid-memberships-pro'); ?></label>
                        <div class="help-block with-errors"></div>
                      </div>
                    </div>   
                    <div class="col-sm-3">
                      <div class="form-group"> 
                        <input class="llinkedin_id" name="llinkedin_id" type="text" class="input" size="30" value="" />
                        <label class="control-label" for="llinkedin_id"><?php _e('LinkedIn ID', 'paid-memberships-pro'); ?></label>
                      </div>
                    </div>
                  </div>

                </div>
                <div class="col-sm-1 poc-div">
                  <label class="checkbox"><input class="poc" value="yes" name="poc" type="checkbox"><span>POC</span><span class="checkmark"></span></label>
                </div>
                <div class="col-sm-1">
                  <span data-repeater-delete class="btn btn-danger btn-sm btn-remove">    
                    <?php $delete_img_url = WP_PLUGIN_URL . '/nstxl-memberhip-extension/images/delete.png'; ?>
                    <img src="<?php echo $delete_img_url; ?>">
                  </span>
                </div> 

              </div>      
            </div>

            <div class="form-group">
              <div class="col-sm-12">
                <span data-repeater-create class="btn btn-info btn-md btn-add pull-right">     
                  <?php $add_img_url = WP_PLUGIN_URL . '/nstxl-memberhip-extension/images/plus.png'; ?>
                  <img src="<?php echo $add_img_url; ?>">
                </span>
              </div>
            </div>
          </div><!-- End of repeater default content-->

        </div><!-- End of #form-step-3-->
      </div><!-- End of #step-3-->  

      </div>
      <div class="btn-group">
        <button class="btn btn-secondary manage-user" type="submit"><?php _e('Update','paid-memberships-pro'); ?></button>          
      </div>
    </form>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> 
        <div class="update-personalinfo-box-success-container">
          <p>Your request has been submited successfully.</p> 
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->  
  <script>
  jQuery(document).ready( function() {
    jQuery('.pmpro_asterisk').remove();
  });  
  </script> 
  <?php
} 
get_footer('admin');