<?php
/**
 * Template Name: Renew Membership
 *
 * @package OnePress
 */
global $current_user;
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}

get_header('admin');
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">

<?php get_sidebar('dashboard'); ?>

    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' );     ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>
              <?php
              $puid = nstxl_get_parent_userid($current_user->ID);
              if ($puid !== $current_user->ID) {
                if (!empty($puid)) {
                  $cur_id = $puid;                  
                } else {
                  $cur_id = $current_user->ID;
                }

                $company_name = get_user_meta($cur_id, 'company_name', true);
                $poc = get_user_meta($cur_id, 'poc', true);
                if (!empty($poc)) {
                  $userData = get_userdata($poc);
                  $poc_fname = $userData->first_name;
                  $poc_lname = $userData->last_name;
                  $company_name = $userData->company_name;
                }
              }

              if (empty(nstxl_is_poc($current_user->ID))) {

                $level = pmpro_getMembershipLevelForUser($poc);
                if (!empty($level) && isset($level->enddate) && !empty($level->enddate)) {
                  $expire_date = date("M d, Y g:i A", $level->enddate);
                } else {
                  $expire_date = '';
                }
                ?>
                <div class="renewmembership-container dashboard-inner-wrapper dashboard-bg-white">
                  <div class="clearfix page-header-wrapper">
                    <h3 class="rgs_title clearfix"><?php _e($company_name, 'paid-memberships-pro'); ?></h3>
                  </div> 
                  <div class="renewmembership dashboard-form-wrapper">
                    <div class="white-shadow-box">
                      <p>Your firm's membership will expire on <?php echo $expire_date; ?>. We are thrilled to have your firm as a member. Your firm's Point of Contact (POC), <?php echo ucfirst($poc_fname); ?> <?php echo ucfirst($poc_lname); ?>, is the only person who can renew the account. Please contact them directly to ensure continuity of your membership.</p>
                    </div>
                  </div>
                </div>
              <?php
              } else {
                $level = pmpro_getMembershipLevelForUser($poc);
                if (!empty($level) && isset($level->enddate) && !empty($level->enddate)) {
                  $expire_date = date("M d, Y g:i A", $level->enddate);
                } else {
                  $expire_date = '';
                }
                ?>

                <div class="renewmembership-container dashboard-inner-wrapper dashboard-bg-white">
                  <div class="clearfix page-header-wrapper">
                    <h3 class="rgs_title clearfix"><?php _e($company_name, 'paid-memberships-pro'); ?></h3>
                  </div> 
                  <div class="renewmembership dashboard-form-wrapper">
                    <div class="white-shadow-box">
                      <p>Your firm's membership will expire on <?php echo $expire_date; ?>. You can renew by selecting the button below. You'll be taken to an application page with all of your current information pre-populated. Just confirm that the information is still valid, fill in any additional information required by the govt, and then proceed to the payment page.</p>
                      <div class='btn-container'><a  href="/membership-levels/"><button type="button" class="btn btn-secondary-outline btn-lg btn-txt" name="addmember-save"><?php _e('Renew Now', 'pmpro'); ?></button></a></div>
                    </div>
                  </div>
                </div>
              <?php } ?>

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.     ?>

      </main><!-- #main -->
    </div><!-- #primary -->

    

  </div><!--#content-inside -->
</div><!-- #content -->      
<?php
get_footer('admin');
