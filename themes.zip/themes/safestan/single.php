<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<!--top-hader-bg-->
<div class="top-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
              <h1 class="banner-hadding">Blog</h1>
            </div>
        </div>
    </div>
</div>

<div class="blog-detail">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-sm-9">
                <div class="card-box d-block">
                    <?php
                    // Start the loop.
                    while ( have_posts() ) : the_post();

                        // Include the single post content template.
                        get_template_part( 'template-parts/content', 'single' );

                        // If comments are open or we have at least one comment, load up the comment template.
                        if ( comments_open() || get_comments_number() ) {
                            comments_template();
                        }

                        /*if ( is_singular( 'attachment' ) ) {
                            // Parent post navigation.
                            the_post_navigation( array(
                                'prev_text' => _x( '<span class="meta-nav">Published in</span><span class="post-title">%title</span>', 'Parent post link', 'twentysixteen' ),
                            ) );
                        } elseif ( is_singular( 'post' ) ) {
                            // Previous/next post navigation.
                            the_post_navigation( array(
                                'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next', 'twentysixteen' ) . '</span> ' .
                                    '<span class="screen-reader-text">' . __( 'Next post:', 'twentysixteen' ) . '</span> ' .
                                    '<span class="post-title">%title</span>',
                                'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous', 'twentysixteen' ) . '</span> ' .
                                    '<span class="screen-reader-text">' . __( 'Previous post:', 'twentysixteen' ) . '</span> ' .
                                    '<span class="post-title">%title</span>',
                            ) );
                        }*/

                        // End of the loop.
                    endwhile;
                    ?>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
jQuery(document).ready(function($) {
    // Base URL
    //var baseUrl = window.location.href;
    //alert(baseUrl);
    // You need to target your sidebar here, change #sidebar to your sidebar identifier (id)
    /*$(".widget_recent_entries li a").each(function(){
        var href = $(this).attr('href');
        if (href == baseUrl) {
            $(this).addClass('current');
        }
    });*/

    $(document).ready(function(){
        $('#coment-feild').click(function(){
              $(".coment-form").show();
             $(".button-coment").hide();
        });
        $(".close-form").click(function(){
                          $(".coment-form").hide();
             $(".button-coment").show();
        });

        /*$('.comment-reply-link').click(function(){
             $(".button-coment").hide();
             $(".coment-form").hide();
        });
        $('.cancel-comment-reply-link').click(function(){
             $(".button-coment").show();
             //$(".coment-form").show();
        });*/
    });
});
</script>
<?php get_footer(); ?>
