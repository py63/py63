<?php
/**
 * Template Name: Manage your users
 *
 * @package OnePress
 */
global $wpdb, $current_user;
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
if (is_user_logged_in() && empty(nstxl_is_poc($current_user->ID))) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
get_header('admin');
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
if (!empty($current_user)) {
  //$cur_id = nstxl_get_parent_userid($current_user->ID);
  $puid = nstxl_get_parent_userid($current_user->ID);
  if (!empty($puid)) {
    $cur_id = $puid;
  } else {
    $cur_id = $current_user->ID;
  }
  $poc_user_id = get_user_meta($cur_id, "poc", true);
  $cmp_users_ids = get_user_meta($cur_id, 'company_users_ids', true);
  if (!empty($cmp_users_ids)) {
    $users_ids = $cmp_users_ids;
  } else {
    $users_ids = $poc_user_id;
  }
  $limit = 5;
  $current_page = max(1, get_query_var('paged'));
  $offset = ($current_page - 1) * $limit;
  $args = array(
      'include' => $users_ids,
      'number' => $limit,
      'offset' => $offset,
      'orderby' => 'id',
      'order' => 'ASC',
  );

  $args1 = array('include' => $users_ids);
  $number_of_users = (int) count(get_users($args1));
  $user_query = new WP_User_Query($args);
  $total_pages = ceil($number_of_users / $limit);
  $uploaded_comp_url = nstxl_get_company_logo($cur_id);
  $company_name = get_user_meta($cur_id, "company_name", true);
}
?>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' ); ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>
              <div class="manageuser-container dashboard-inner-wrapper">
                <div class="row">
                <div class="wrap-apple-icon col-sm-12">
                  <?php
                  if (!empty($company_name)) {
                    echo '<h3 class="rgs_title">' . $company_name . '<span class="active-user">'.$number_of_users.' active users</span></h3>';
                  }
          
                  ?> 
                </div>
                  <div class="search-wrapper clearfix col-sm-12">
                    <div class="member-search-container pull-left">
                      <!--<form name="member-search-form" type="post">-->
                      <input type="search" placeholder="<?php _e('Search', 'paid-memberships-pro'); ?>" name="member-search" class="member-search" id="member-search">
                      <!--</form>-->
                    </div>
                    <div class="btn-group pull-right"><button class="btn btn-magenta" onclick="location.href = '<?php echo get_bloginfo("url"); ?>/add-members'" type="button"><?php _e('Add Users', 'paid-memberships-pro'); ?></button>
                    </div>
                  </div>
                </div>
                <div class="manageuser-form-container">
                  <form method="post" class="manageuser-form" enctype="multipart/form-data" name="manageuser" id="manageuser">
                    <div class="form-row-wrapper">
                      <?php
                      if (!empty($user_query->results)) {
                        foreach ($user_query->results as $user) {// print_r($user); 
                          $user_ID = $user->ID;
                          $display_name = $user->display_name;
                          $join_lists = get_user_meta($user_ID, 'join-our-mailing-list', true);
                          if (empty($display_name)) {
                            $display_name = $user->first_name . ' ' . $user->last_name;
                          }
                          $user_email = $user->user_email;
                          if ($poc_user_id == $user_ID) {
                            $poc_checked = 'yes';
                            $member_type = 'Point of Contact';
                          } else {
                            $poc_checked = '';
                            $member_type = 'Member';
                          }
                          ?>
                          <div class="manageuser-row card">
							          <div class="row">
                            <div class="form-group col-lg-6 col-md-6">                  
                              <span class="poc-name"><input class="fullname" readonly disabled name="display_name" size="30" value="<?php echo ucfirst($user->first_name); ?> <?php echo ucfirst($user->last_name); ?>" type="text"></span>
                            </div>
                            <div class="form-group editSection col-lg-6 col-md-6">
                              <div class="edit-button-section">
                                <a class="btn-edit ml-auto" href="<?php echo get_bloginfo('url'); ?>/edit-member?member=<?php echo $user_ID; ?>" data-id="<?php echo esc_attr($user_ID); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/edit-name.png"></a>
                              </div> 
                            </div>
                              <div class="col-lg-5 col-md-6"> 
                                <input class="email" readonly disabled  size="30" value="<?php echo esc_attr(stripslashes_deep($member_type)); ?>" type="email">
                            </div>
                            <div class="col-lg-7 col-md-6">
                              <input class="email" readonly disabled name="email" size="30" value="<?php echo esc_attr(stripslashes_deep($user_email)); ?>" type="email">
                            </div> 
                         </div></div>
            
                          <?php
                        } //End of foreach
                      } else {
// no users found
                      }
                      ?>
                    </div>
                  </form>
                </div>
                <div class="loadmore btn-group load-more-wrapper">
                  <a data-offset="<?php echo $limit; ?>" data-total="<?php echo $number_of_users; ?>" class="load_more_posts" href="#" id="load_more_posts"><?php _e('Load More', 'paid-memberships-pro'); ?></a>
                  <a data-offset="0<?php //echo $limit;      ?>" style="display:none" data-total="<?php echo $number_of_users; ?>" class="load_more_btn" href="#" id="load_more_search"><?php _e('Load More', 'paid-memberships-pro'); ?></a>
                </div>
              </div>
              <script>
                var limit = '<?php echo $limit; ?>';
              </script>
              <script>
                jQuery(document).ready(function ($) {
                  jQuery('.pmpro_asterisk').remove();
                  if ($('#manageuser div.manageuser-row').length >= $('#load_more_posts').attr('data-total')) {
                    jQuery('#load_more_posts').hide();
                  }
                  $('#load_more_posts').on('click', function (e) {
                    // console.log('hi');
                    e.preventDefault();
                    var $offset = $(this).attr('data-offset');
                    var $total = $(this).attr('data-total');
                    var userRowLength = $('#manageuser div.manageuser-row').length;
                    // console.log('var'+$offset);
                    $.ajax({
                      method: 'POST',
                      url: nstxl_ajaxurl,
                      type: 'JSON',
                      data: {
                        offset: $offset,
                        limit: limit,
                        action: 'load_more_posts'
                      },
                      beforeSend: function () {   
                      jQuery('.loadmore').hide();                 
                        jQuery('.loadmore').before('<div class="showloading" style="text-align:center">Loading....</div>');
                      },
                      success: function (response) {
                        jQuery('.loadmore').show();
                        console.log(response);

                        $('#load_more_posts').attr('data-offset', parseInt(response.data.offset));
                        if (userRowLength >= response.data.count) {
                          $('#load_more_posts').hide();
                        } else {
                          if (response.data.post !== '') {
                            $('.form-row-wrapper').append(response.data.post);
                          } else {
                            $('#load_more_posts').hide();
                          }
                          if (response.data.offset == null && response.data.post !== '') {
                            $('#load_more_posts').hide();
                          }
                        }

                      },
                      complete: function () {
                        jQuery('.showloading').hide();

                        jQuery('.preloader').fadeOut("slow");
                        if ($('#manageuser div.manageuser-row').length >= $total) {
                          jQuery('#load_more_posts').hide();
                        }
                        jQuery('select.join_our_mailing_list').each(function () {
                          jQuery('option').each(function () {
                            if (!this.selected) {
                              jQuery(this).attr('disabled', true);
                            }
                          });
                        });
                        jQuery('.join_our_mailing_list').multiselect({
                          nonSelectedText: "Stay Informed", includeSelectAllOption: true,
                        });

                        jQuery('ul.multiselect-container.dropdown-menu li label.checkbox').each(function (index) {
                          spclength1 = jQuery(this).find('span.checkmark').length;
                          if (spclength1 == 0) {
                            jQuery(this).append('<span class="checkmark"></span>');
                          }

                        });
                      }
                    });
                  });

                  $('#member-search').keyup(function() {
                     if(jQuery(this).val().length > 2) {
                    var $this = jQuery(this);
                    var searchkeyword = $this.val();
                    var offset = jQuery('#load_more_search').attr('data-offset');
                    var $total = jQuery('#load_more_search').attr('data-total');
                    var userRowLength = $('#manageuser div.manageuser-row').length;
                    if (searchkeyword.replace(/^\s+|\s+$/g, "").length != 0) {
                      $.ajax({
                        method: 'POST',
                        url: nstxl_ajaxurl,
                        type: 'JSON',
                        data: {
                          searchkeyword: searchkeyword,
                          offset: offset,
                          limit: limit,
                          action: 'nstxl_search_member'
                        },
                        beforeSend: function () {
                          jQuery('.preloader').show();
                        },
                        success: function (response) {
                          //console.log(response.data.post);
                          $('#load_more_search').attr('data-offset', parseInt(response.data.offset));
                          $('#load_more_search').attr('data-total', parseInt(response.data.count));
                          if (response.data.post !== '') {
                            $('.form-row-wrapper').html(response.data.post);
                            if (response.data.count == '1') {
                              $('#load_more_search').hide();
                            } else {
                              $('#load_more_search').show();
                            }
                            $('#load_more_posts').hide();
                          } else {
                            $('#load_more_search').hide();
                            $('.form-row-wrapper').html('No matching records found');
                          }
                          if (response.data.offset == null && response.data.post !== '') {
                            $('#load_more_search').hide();
                            $('.form-row-wrapper').html('No matching records found');
                          }
                        },
                        complete: function () {
                          jQuery('.preloader').fadeOut("slow");
                          jQuery('select.join_our_mailing_list').each(function () {
                            jQuery('option').each(function () {
                              if (!this.selected) {
                                jQuery(this).attr('disabled', true);
                              }
                            });
                          });
                          jQuery('.join_our_mailing_list').multiselect({
                            nonSelectedText: "Stay Informed", includeSelectAllOption: true, selectAllValue: ''
                          });

                          jQuery('ul.multiselect-container.dropdown-menu li label.checkbox').each(function (index) {
                            spclength1 = jQuery(this).find('span.checkmark').length;
                            if (spclength1 == 0) {
                              jQuery(this).append('<span class="checkmark"></span>');
                            }

                          });

                          jQuery('ul.multiselect-container.dropdown-menu li.multiselect-item.multiselect-all a.multiselect-all label.checkbox input').prop('disabled', true);
                          jQuery('ul.multiselect-container.dropdown-menu li.multiselect-item.multiselect-all a.multiselect-all label.checkbox input').prop('checked', false);

                        }
                      });

                    } else {
                      alert('Please enter the string for search');
                      window.location.href = siteurl + '/manage-your-users';
                    }
                  }
                  else if(jQuery(this).val().length == 0)
                  {
                    alert('Please enter the string for search');
                      window.location.href = siteurl + '/manage-your-users';
                  }
                  });


                  $('#load_more_search').on('click', function (e) {
                    e.preventDefault();
                    var $offset = $(this).attr('data-offset');
                    if ($offset == 0) {
                      var $offset = $(this).attr('data-offset') + limit;
                    }
                    var $total = $(this).attr('data-total');
                    var userRowLength = $('#manageuser div.manageuser-row').length;
                    // console.log('var'+$offset);
                    $.ajax({
                      method: 'POST',
                      url: nstxl_ajaxurl,
                      type: 'JSON',
                      data: {
                        load_more: 1,
                        offset: $offset,
                        limit: limit,
                        action: 'nstxl_search_member'
                      },
                      beforeSend: function () {
                        jQuery('.preloader').show();
                      },
                      success: function (response) {
                        //console.log(response.data.post);
                        if (isNaN(response.data.offset)) {
                          response.data.offset = 0;
                        }
                        $('#load_more_search').attr('data-offset', parseInt(response.data.offset));
                        $('#load_more_search').attr('data-total', parseInt(response.data.count));
                        if (userRowLength >= response.data.count) {
                          $('#load_more_search').hide();
                        } else {
                          if (response.data.post !== '') {
                            $('.form-row-wrapper').append(response.data.post);
                            $('#load_more_search').show();
                            $('#load_more_posts').hide();
                          } else {
                            $('#load_more_search').hide();
                          }
                          if (response.data.offset == response.data.count) {
                            $('#load_more_search').hide();
                          }
                          if (response.data.offset == null && response.data.post !== '') {
                            $('#load_more_search').hide();
                          }
                        }

                      },
                      complete: function () {
                        jQuery('.preloader').fadeOut("slow");
                        jQuery('select.join_our_mailing_list').each(function () {
                          jQuery('option').each(function () {
                            if (!this.selected) {
                              jQuery(this).attr('disabled', true);
                            }
                          });
                        });
                        jQuery('.join_our_mailing_list').multiselect({
                          nonSelectedText: "Stay Informed", includeSelectAllOption: true, selectAllValue: ''
                        });

                        jQuery('ul.multiselect-container.dropdown-menu li label.checkbox').each(function (index) {
                          spclength1 = jQuery(this).find('span.checkmark').length;
                          if (spclength1 == 0) {
                            jQuery(this).append('<span class="checkmark"></span>');
                          }

                        });

                        jQuery('ul.multiselect-container.dropdown-menu li.multiselect-item.multiselect-all a.multiselect-all label.checkbox input').prop('disabled', true);
                        jQuery('ul.multiselect-container.dropdown-menu li.multiselect-item.multiselect-all a.multiselect-all label.checkbox input').prop('checked', false);

                      }
                    });
                  });

                  jQuery('select.join_our_mailing_list').each(function () {
                    jQuery('option').each(function () {
                      if (!this.selected) {
                        jQuery(this).attr('disabled', true);
                      }
                    });
                  });
                  jQuery('ul.multiselect-container.dropdown-menu li.multiselect-item.multiselect-all a.multiselect-all label.checkbox input').prop('disabled', true);

                  jQuery('ul.multiselect-container.dropdown-menu li.multiselect-item.multiselect-all a.multiselect-all label.checkbox input').prop('checked', false);
                  jQuery('.join_our_mailing_list').multiselect({
                    nonSelectedText: "Stay Informed",
                    includeSelectAllOption: false,
                    selectAllValue: ''
                  });

                });


              </script> 

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->
  </div><!--#content-inside -->
</div><!-- #content -->

<?php
get_footer('admin');
