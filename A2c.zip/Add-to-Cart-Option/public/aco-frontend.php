<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/* Hide add to cart for customer and visitor only */
add_filter('woocommerce_is_purchasable', 'aco_hide_addtocart_customers_visitors', 10, 2);
if ( ! function_exists( 'aco_hide_addtocart_customers_visitors' ) ) {
    function aco_hide_addtocart_customers_visitors($is_purchasable, $product ) {
        
        $arrycalback = aco_get_product_ids();   
            
        /* Hide for customer */
        if(!empty($arrycalback[0]) && is_user_logged_in()){
            $user = new WP_User(get_current_user_id());            
            if(!empty($user->roles) && in_array( 'customer', $user->roles)){
                if( in_array( $product->get_id(), $arrycalback[0])) {
                    return false;
                }               
            }
        }
        /* Hide for visitors */
        if(!empty($arrycalback[1])){
            if(!is_user_logged_in()){
                if( in_array( $product->get_id(), $arrycalback[1])) {
                    return false;
                }
            }
        }        
        return $is_purchasable;		
    }
}


/* REPLACE ADD TO CART BUTTON LABEL FOR CUSTOMER AND VISITORS */

/* To change add to cart text on single product page for customer and visitors */
add_filter('woocommerce_product_single_add_to_cart_text','aco_add_to_cart_button_label_change');

/* To change add to cart text on product archives(Collection) page */
add_filter( 'woocommerce_product_add_to_cart_text', 'aco_add_to_cart_button_label_change' );
if ( ! function_exists( 'aco_add_to_cart_button_label_change' ) ) {
    function aco_add_to_cart_button_label_change($def){
        global $product;
        global $wpdb;	
        $product = wc_get_product(); 
        //$current_user = wp_get_current_user();
        /* Replace add to cart label for customer only  */      
        $arrycalback = aco_get_product_ids();
        
        if(!empty($arrycalback[0]) && is_user_logged_in()){
            $user = new WP_User(get_current_user_id());        
            if(!empty($user->roles) && in_array( 'customer', $user->roles)){
                if( in_array( $product->get_id(), $arrycalback[0])) {
                    if(!empty(trim(get_post_meta( $product->get_id(), 'label_replace_addtocart', true )))){
                        return __(get_post_meta( $product->get_id(), 'label_replace_addtocart', true ), 'add-to-cart-option');	
                    }
                }               
            }            
        }	

        /* Replace add to cart label for visitors */        
        if(!empty($arrycalback[1]) && !is_user_logged_in()){
            if( in_array( $product->get_id(), $arrycalback[1])) {
                if(!empty(trim(get_post_meta( $product->get_id(), 'label_replace_addtocart', true )))){
                    return __(get_post_meta( $product->get_id(), 'label_replace_addtocart', true ), 'add-to-cart-option');	
                }
            } 				
        }
        return $def;	
    }
}

/* Add custom link to add to cart button */
add_filter('woocommerce_product_single_add_to_cart_link','aco_add_to_cart_custome_link');
add_filter('woocommerce_loop_add_to_cart_link','aco_add_to_cart_custome_link');
if ( ! function_exists( 'aco_add_to_cart_custome_link' ) ) {
    function aco_add_to_cart_custome_link($link) {
        global $product;
        global $wpdb;

        $product = wc_get_product();
        $current_user = wp_get_current_user();
        $arrycalback = aco_get_product_ids();        
        
        /* Add custom link to "add to cart" button for customer */
        if(!empty($arrycalback[0]) && is_user_logged_in()){
            $user = new WP_User(get_current_user_id());
            if(!empty($user->roles) && in_array( 'customer', $user->roles)){
                if( in_array( $product->get_id(), $arrycalback[0])) {			
                    $product_id = $product->get_id();
                    $product_sku = $product->get_sku();
                    if(!empty(get_post_meta( $product->get_id(), 'dis_customer_product', true )) && !empty(get_post_meta( $product->get_id(), 'label_replace_addtocart', true ))){
                        if(!empty(get_post_meta( $product->get_id(), 'url_redirect_prod', true ))){
                            $link = '<a href="'.esc_url(get_post_meta( $product->get_id(), 'url_redirect_prod', true )).'" class="button aco-shop-product-custom-label" target="_blank">'.__(get_post_meta( $product->get_id(), 'label_replace_addtocart', true ), 'add-to-cart-option').'</a>';
                        }                    
                    }            
                }               
            }
        }
        /* Add custom link to "add to cart" button for visitors */
        if(!empty($arrycalback[1])){
            if(!is_user_logged_in() && !empty(get_post_meta( $product->get_id(), 'label_replace_addtocart', true ))){
                if( in_array( $product->get_id(), $arrycalback[1])) {			
                    $product_id = $product->get_id();
                    $product_sku = $product->get_sku();
                    if(!empty(get_post_meta( get_the_ID(), 'url_redirect_prod', true ))){
                        $link = '<a href="'.esc_url(get_post_meta( get_the_ID(), 'url_redirect_prod', true )).'" class="button aco-shop-product-custom-label" target="_blank">'.__(get_post_meta( $product->get_id(), 'label_replace_addtocart', true ), 'add-to-cart-option').'</a>';
                    }             
                }			
            }
        }
    return $link;
    }
}

/* Get ids of disabled product for customer and visitors */
if ( ! function_exists( 'aco_get_product_ids' ) ) {
    function aco_get_product_ids(){
        global $wpdb;
        /* Get disable product ids for customer */ 
        $post_ids = $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key='dis_customer_product' AND meta_value='yes'"); //Get product ids for customer disable
        
        $ids_arr = array();
        foreach ($post_ids as $key => $ids_value) {
            $ids_arr[] = $ids_value->post_id;
        }
        
        /* Get disable product ids for visitor */
        $post_ids_visitors = $wpdb->get_results("SELECT * FROM $wpdb->postmeta WHERE meta_key='dis_visitors_product' AND meta_value='yes'"); // Get product ids for visitors

        $ids_arr_visitors = array();
        foreach ($post_ids_visitors as $key => $vis_ids_value) {
            $ids_arr_visitors[] = $vis_ids_value->post_id;
        }
        return array( $ids_arr, $ids_arr_visitors);
    }
}
add_action('init', 'aco_get_product_ids');

/* Custom button on single product page */
function aco_shop_single_custom_button($product) {
    global $product;
    if ( ! $product->is_purchasable() ) {
        $arrycalback = aco_get_product_ids();
        echo '<p class="add-tocart-customlabel">'.aco_add_to_cart_custome_link($link).'</p>';        
    }    
}
add_action( 'woocommerce_product_meta_start', 'aco_shop_single_custom_button' );