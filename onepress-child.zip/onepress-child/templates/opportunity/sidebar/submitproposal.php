<?php
// Returns Array of Term ID's for "my_taxonomy".
$term_list = wp_get_post_terms(get_the_ID(), 'opportunity-type', array('fields' => 'ids'));
  $modal_id = '';
  $modal_body_container_class  = '';
  $content_html = '';
if (in_array('40', $term_list)) {
  if (is_user_logged_in()) {
    $url = get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID();
    $spdatelined = get_field('nstxl_proposal_deadline', get_the_ID(), false, false);

    $cdate = date("Y-m-d H:i:s", current_time("timestamp"));
    $after15minut = strtotime("-15 minutes", current_time('timestamp'));
    $cdate = date("Y-m-d H:i:s", $after15minut);
    if (!empty($spdatelined)) {
      if ($cdate > $spdatelined) {
        //echo '<h3>Your proposal submission date has passed.</h3>';
        $modal_id = 'modal-proposal-submission-passed-'.get_the_ID();
        $modal_body_container_class  = 'modal-proposal-submission-passed-container';
        $content_html = '<h4>The proposal submission period has ended</h4><p class="text-center">Thank you for your interest. Please check our opportunities page for other opportunities you may be interested in.</p>';
        echo '<button type="button" class="submitpropalbtn btn-txt" data-toggle="modal" data-target="#'.$modal_id.'">Submit a Solution</button>';        
      } else {
        echo '<a href="' . $url . '"><button class="submitpropalbtn btn-txt">Submit a Solution</button></a>';
      }
    } else {
      echo '<a href="' . $url . '"><button class="submitpropalbtn btn-txt">Submit a Solution</button></a>';
    }
  } else {
    ?>
    <a href="<?php echo get_bloginfo('url'); ?>/login?redirect_to=<?php echo urlencode(get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID()); ?>"><button class="polar_button submitpropalbtn btn-txt">Submit a Solution</button></a> 
    <?php
  }
} else {
  //echo '<h3>We are not accepting proposals at this time.</h3>';
//  $modal_id = 'modal-proposal-not-allow-'.get_the_ID();
//  $modal_body_container_class  = 'modal-proposal-not-allow-container';
//  $content_html = '<h4>We are not accepting proposals at this time.</h4>';
//  echo '<button type="button" class="submitpropalbtn btn-txt" data-toggle="modal" data-target="#'.$modal_id.'">Submit a Solution</button>';
    //echo '<h3>We are not accepting proposals at this time.</h3>';
  $modal_id = '';
  $modal_body_container_class  = '';
  $content_html = '';
  }
nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class);
