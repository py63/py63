<?php
/**
 * Tsemplate Name: Edit Member
 */
global $wpdb, $current_user;
$first_name = $last_name = $email = '';
if (isset($_POST['memberid']) && !empty($_POST['memberid'])) {
  $cur_id = $_POST['memberid'];
}
if (!empty($cur_id)) {
  $single_user_data = get_userdata($cur_id);
  $uploaded_comp_url = nstxl_get_company_logo($cur_id);
  if ($cur_id == nstxl_is_poc($cur_id)) {
    $userdata = nstxl_company_additional_userdata($cur_id);
  }
  $company_name = get_user_meta($cur_id, "company_name", true);
  $first_name = $single_user_data->first_name;
  $last_name = $single_user_data->last_name;
  $email = $single_user_data->user_email;
}
?>
<div class="editsponsor-container">
  <div class="wrap-apple-icon">
    <?php
    if (!empty($company_name)) {
      echo '<h3 class="rgs_title">' . $company_name . '</h3>';
    }
    if (!empty($uploaded_comp_url)) {
      echo '<div class="company-img-wrapper"><img src="' . esc_url($uploaded_comp_url) . '" alt="" class="apple-icon"></div>';
    }
    ?> 
  </div>
  <div class="clearfix page-header-wrapper">
    <h3 class="rgs_title clearfix"><?php _e(the_title(), 'paid-memberships-pro'); ?></h3>
  </div> 
  <div class="editsponsor-form-container">
    <form method="post" class="editsponsor-form" enctype="multipart/form-data" name="editsponsor" id="editsponsor">
      <div class="row">
        <div class="form-group col-lg-12 col-md-12 col-xs-12"> 
          <label for="first_name"><?php _e('First Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="first_name" required value="<?php echo esc_attr(stripslashes_deep($first_name)); ?>" type="text">            
        </div>
        <div class="form-group col-lg-12 col-md-12 col-xs-12"> 
          <label for="last_name"><?php _e('Last Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="last_name" required value="<?php echo esc_attr(stripslashes_deep($last_name)); ?>" type="text">              
        </div>
      </div>
      <div class="row">
        <div class="form-group col-lg-12 col-md-12 col-xs-12">
          <label for="email"><?php _e('Email', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input name="email" required value="<?php echo esc_attr(stripslashes_deep($email)); ?>" type="email">            
        </div>          
      </div>
      <input name="cusrid" id="cusrid" value="<?php  if (!empty($cur_id)) {  echo $cur_id; } ?>" type="hidden">
      <div class="btn-group">
        <button type="button" id="editsponsor-update" class="btn btn-txt" name="editsponsor-update"><?php _e('Update', 'paid-memberships-pro'); ?></button>
      </div>
    </form>
  </div>
</div>
<script type="text/javascript">
  var curuid = '<?php
             if (!empty($cur_id)) {
               echo $cur_id;
             }
      ?>';
  jQuery(document).ready(function ($) {
    jQuery('.pmpro_asterisk').remove();
    jQuery('ul.multiselect-container.dropdown-menu li label.checkbox').each(function (index) {
      spclength1 = jQuery(this).find('span.checkmark').length;
      if (spclength1 == 0) {
        jQuery(this).append('<span class="checkmark"></span>');
      }
    });
    $("#editsponsor").validate({
      rules: {
        first_name: {
          required: true,
        },
        action: "required",
        last_name: {
          required: true,
        },
        email: {
          required: true,
          //validemail: true,
          remote: {
            url: nstxl_ajaxurl,
            type: 'post',
            data: {
              action: 'nstxl_check_userbemail',
              curuid: curuid,
              email: function () {
                return $(".editsponsor-form-container input[name='email']").val();
              }
            },
          }
        },
      },
      messages: {
        email: {
          required: "Please enter email",
          //validemail: "Please enter valid email address",
          remote: 'Email is already taken.'
        }
      },
      errorClass: "form-invalid",
      errorElement: 'div',
      highlight: function (element, errorClass, validClass) {
        $(element).closest("div.field").addClass("error").removeClass("success");
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).closest(".error").removeClass("error").addClass("success");
      },
      errorPlacement: function (error, element) {

        if (element.parent().find("div.help-block.with-errors").length === 0) {
          if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
            element.parent().append(error);
          } else {
            error.addClass("help-block with-errors").appendTo(element.closest('div.form-group'));
          }
        } else {
          if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
            element.parent().append(error);
          } else {
            error.appendTo(element.parent().find("div.help-block.with-errors"));
          }
        }
      },

    });
    jQuery('#editsponsor-update').on('click', function (e) {
      e.preventDefault();
      if (jQuery('#editsponsor').valid()) {
        var form = jQuery('form#editsponsor')[0];
        var formData = new FormData(form);
        formData.append("action", "nstxl_update_single_member");
        $.ajax({
          url: nstxl_ajaxurl,
          type: "POST",
          data: formData,
          beforeSend: function () {
            jQuery('.preloader').fadeIn();
          },
          success: function (response, textStatus, jqXHR) {
            jQuery('.preloader').fadeOut();
            jQuery('#edit-scompany-modal-success').modal('hide');
            if (response.data.response == "success") {
              jQuery('#edit-sponsor-modal-success').modal('show');
              jQuery('#edit-sponsor-modal-success  .edit-sponsor-modal-success-container').html('<h4>Sponsored company information has edited successfully</h4>');
            }

          },
          error: function (jqXHR, textStatus, errorThrown) {
            jQuery('#edit-sponsor-modal-success').modal('show');
            jQuery('#edit-sponsor-modal-success  .edit-sponsor-modal-success-container').html('<h4 style="color:red">' + errorThrown + '</h4>');
          },
          complete: function () {
          },
          cache: false,
          contentType: false,
          processData: false
        });

      }
    });
    jQuery('.close').on('click', function (e) {
      jQuery('#edit-sponsor-modal-success').modal('hide');
    });
    jQuery('#edit-sponsor-modal-success').on('hidden.bs.modal', function () {
      window.location.href = siteurl + '/your-sponsored-companies';
    })
  });
</script> 
  <?php
