<?php


global $pmpro_reports;

$pmpro_reports['membersby_company_type'] = __('Members by Company Type', 'paid-memberships-pro' );

//widget
function pmpro_report_membersby_company_type_widget() {
	global $wpdb;

	$companytype1 = nstxl_members_count_by_company_type('Corporate:_Less_than_$10M_Annual_Revenue');
	$companytype2 = nstxl_members_count_by_company_type('Corporate:_$10M-$50M_Annual_Revenue');
	$companytype3 = nstxl_members_count_by_company_type('Corporate:_$50M-$100M_Annual_Revenue');
	$companytype4 = nstxl_members_count_by_company_type('Corporate:_More_than_$100M_Annual_Revenue');
	$companytype5 = nstxl_members_count_by_company_type('Non-Corporate:_College_or_University'); 
	$totalcompany = nstxl_members_count_by_company_type_total();
	?>

	<span id="pmpro_report_membersby_company_type_memberships" class="pmpro_report-holder">
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php _e('Company Type', 'paid-memberships-pro' ); ?></th>
					<th scope="col"><?php _e('All Members', 'paid-memberships-pro' ); ?></th>
				</tr>
				<tr>
					<th scope="col"><strong><?php _e('Total Members', 'paid-memberships-pro' ); ?></strong></th>
					<th scope="col"><strong><?php echo $totalcompany;?></strong></th>
				</tr>
			</thead>

			<tbody>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: Less than $10M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype1; ?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: $10M-$50M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype2;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: $50M-$100M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype3;?></td>

				</tr>


				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: More than $100M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype4;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Non-Corporate: College or University', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype5;?></td>

				</tr>


			</tbody>

		</table>
		<?php if ( function_exists( 'pmpro_report_membersby_company_type_page' ) ) { ?>
			<p class="pmpro_report-button">
				<a class="button button-primary" href="<?php echo admin_url( 'admin.php?page=pmpro-reports&report=membersby_company_type' ); ?>"><?php _e('Details', 'paid-memberships-pro' );?></a>
			</p>
		<?php } ?>
	</span>

	<?php
}

function pmpro_report_membersby_company_type_page()
{
	global $wpdb, $pmpro_currency_symbol;

	$companytype1 = nstxl_members_count_by_company_type('Corporate:_Less_than_$10M_Annual_Revenue');
	$companytype2 = nstxl_members_count_by_company_type('Corporate:_$10M-$50M_Annual_Revenue');
	$companytype3 = nstxl_members_count_by_company_type('Corporate:_$50M-$100M_Annual_Revenue');
	$companytype4 = nstxl_members_count_by_company_type('Corporate:_More_than_$100M_Annual_Revenue');
	$companytype5 = nstxl_members_count_by_company_type('Non-Corporate:_College_or_University'); 
	$companytype6 = nstxl_members_count_by_company_type('Non-Corporate:_Laboratory');
	$companytype7 = nstxl_members_count_by_company_type('Non-Corporate:_Technology_Incubator_or_Accelerator');
	$companytype8 = nstxl_members_count_by_company_type('Non-Corporate:_Investor');
	$companytype9 = nstxl_members_count_by_company_type('Non-Profit:_Less_than_$50M_Annual_ Revenue');
	$companytype10 = nstxl_members_count_by_company_type('Non-Profit:_$50M-$100M_Annual_Revenue');
	$totalcompany = nstxl_members_count_by_company_type_total(); 
	?>

	<div style="clear: both;"></div>

	<?php if($totalcompany == '0') { echo "<h3>No members found.</h3>"; } ?>	

	<div id="piechart"></div>

	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

	<script type="text/javascript">
		google.charts.load('current', {'packages':['corechart']});
		google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
	var data = google.visualization.arrayToDataTable([
		['Members', ''],
		['Corporate: Less than $10M Annual Revenue', <?php echo $companytype1;?>],
		['Corporate: $10M-$50M Annual Revenue', <?php echo $companytype2;?>],
		['Corporate: $50M-$100M Annual Revenue',<?php echo $companytype3;?>],
		['Corporate: More than $100M Annual Revenue', <?php echo $companytype4;?>],
		['Non-Corporate: College or University', <?php echo $companytype5;?>],
		['Non-Corporate: Laboratory', <?php echo $companytype6;?>],
		['Non-Corporate: Technology Incubator or Accelerator',<?php echo $companytype7;?>],
		['Non-Corporate: Investor', <?php echo $companytype8;?>],
		['Non-Profit: Less than $50M Annual Revenue', <?php echo $companytype9;?>],
		['Non-Profit:$50M-$100M Annual Revenue', <?php echo $companytype10;?>]
		]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'Members by Company Type', 'width':1000, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>


<?php
}





