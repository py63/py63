<?php
// Returns Array of Term ID's for "my_taxonomy".
$term_list = wp_get_post_terms( get_the_ID(), 'opportunity-type', array( 'fields' => 'ids' ) );
if(in_array('40',$term_list)){
if (is_user_logged_in()) {
  $url = get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID();
  //$url = add_query_arg( '_wpnonce', wp_create_nonce( 'submitproposallink' ), $url );
  //$cdate = date("m-d-Y", current_time("timestamp"));  
  //$cdate = date("Y-m-d H:i:s", current_time("timestamp"));
  $spdatelined = get_field('nstxl_proposal_deadline', get_the_ID(), false, false);

  $cdate = date("Y-m-d H:i:s", current_time("timestamp"));
  $after15minut = strtotime("-15 minutes", current_time('timestamp'));
  $cdate = date("Y-m-d H:i:s", $after15minut);
//echo'<br>'. $spdatelined = get_field( 'nstxl_proposal_deadline', $opid );
  if (!empty($spdatelined)) {
    if ($cdate > $spdatelined) {
      echo '<h3>Your proposal submission date has passed.</h3>';
    } else {
      echo '<a href="' . $url . '"><button class="polar_button submitpropalbtn polar-shape-square polar-size-custom polar-style-flat polar-icon-left">SUBMIT A PROPOSAL</button></a>';
    }
  } else {
    echo '<a href="' . $url . '"><button class="polar_button submitpropalbtn polar-shape-square polar-size-custom polar-style-flat polar-icon-left">SUBMIT A PROPOSAL</button></a>';
  }
} else {
  ?>
  <a href="<?php echo get_bloginfo('url'); ?>/login?redirect_to=<?php echo urlencode(get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID()); ?>"><button class="polar_button submitpropalbtn polar-shape-square polar-size-custom polar-style-flat polar-icon-left">SUBMIT A PROPOSAL</button></a> 
<?php
}
} else {
    echo '<h3>We are not accepting proposals at this time.</h3>';  
}

