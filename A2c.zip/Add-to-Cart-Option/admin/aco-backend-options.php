<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/* Tab setting */
add_filter('woocommerce_product_data_tabs', 'aco_product_settings_tabs' );
if ( ! function_exists( 'aco_product_settings_tabs' ) ) {
    function aco_product_settings_tabs( $tabs ){ 
        $tabs['cart_custom_opt'] = array(
            'label'    => __( 'Add to Cart Option', 'add-to-cart-option' ),
            'target'   => 'cart_product_data_opt',
            'priority' => 399,
        );
        return $tabs; 
    }
}

/* Tab content */
add_action( 'woocommerce_product_data_panels', 'aco_product_panels' );
if ( ! function_exists( 'aco_product_panels' ) ) {
    function aco_product_panels(){ 
        echo '<div id="cart_product_data_opt" class="cart_opt_panel panel woocommerce_options_panel hidden">';	
       
        /* Checkbox for customer role only */
        $args_customers = array(
            'label' => __( 'Disable Product', 'add-to-cart-option' ), // Text in the editor label
            'class' => 'dis_customer_product',
            'style' => 'dis_customer_product_wrapper',
            'wrapper_class' => 'dis_customer_product_wrapper', 
            'value' => get_post_meta( get_the_ID(), 'dis_customer_product', true ),
            'id' => 'dis_customer_product', // required, it's the meta_key for storing the value (is checked or not)
            'name' => 'dis_customer_product', 
            'cbvalue' => 'yes', // "value" attribute for the checkbox
            'desc_tip' => false, // true or false, show description directly or as tooltip
            'description' => __( 'Disable this product being added to the cart from users having customer role', 'add-to-cart-option' ) // description
        );
        woocommerce_wp_checkbox( $args_customers );
    
        /* Checkbox for visitors only */
        $args_visitors = array(
            'label' => __( 'Disable Product', 'add-to-cart-option' ), // Text in the editor label
            'class' => 'dis_visitors_product',
            'style' => '',
            'wrapper_class' => 'customclss',
            'value' => get_post_meta( get_the_ID(), 'dis_visitors_product', true ),
            'id' => 'dis_visitors_product', // required, it's the meta_key for storing the value (is checked or not)
            'name' => 'dis_visitors_product', 
            'cbvalue' => 'yes', // "value" attribute for the checkbox
            'desc_tip' => false, // true or false, show description directly or as tooltip
            'description' => __( 'Disable this product being added to the cart for visitors', 'add-to-cart-option' ) // description
        );
        woocommerce_wp_checkbox( $args_visitors );

        /* Label field that replace to "add to cart" label */
        $args_label_cart = array(
            'label' => __( 'Label', 'add-to-cart-option' ), // Text in the label in the editor
            'class' => 'label_replace_addtocart',
            'type'  => 'text',
            'wrapper_class' => 'label_replace_addtocart_wrapper',
            'value' => get_post_meta( get_the_ID(), 'label_replace_addtocart', true ),
            'id' => 'label_replace_addtocart', // required, will be used as meta_key
            'name' => 'label_replace_addtocart',
            'desc_tip' => true, // true or false, show description directly or as tooltip
            'description' => __( 'Label that replaces "Add to Cart"', 'add-to-cart-option' ) // description
        );
        woocommerce_wp_text_input( $args_label_cart );

        /* URL Redirect */
        $args_url_redirect_prod = array(
            'label' => __( 'URL Redirect', 'add-to-cart-option' ), // Text in the label in the editor
            'class' => 'url_redirect_prod',
            'wrapper_class' => 'url_redirect_prod_wrapper',
            'value' => get_post_meta( get_the_ID(), 'url_redirect_prod', true ),
            'id' => 'url_redirect_prod', // required, will be used as meta_key
            'name' => 'url_redirect_prod', // name will be set automatically from id if empty
            'desc_tip' => true, // true or false, show description directly or as tooltip
            'type' => 'url',
            'description' => __( 'Full Website URL where it will redirect the user on click', 'add-to-cart-option' ) // description
        );
        woocommerce_wp_text_input( $args_url_redirect_prod );	
    
        echo '<p>'. __( '<strong>Note:</strong> The label and URL redirect only works when the option for "disable product" is enabled for customers or visitors.', 'add-to-cart-option' ).'</p></div>'; 
    }
}

/* Save */
add_action('woocommerce_process_product_meta', 'aco_save_custom_tabs');
if ( ! function_exists( 'aco_save_custom_tabs' ) ) {
    function aco_save_custom_tabs( $post_id ) {

        /* Grab the disable product for customer only */
        $dis_customer_only = isset( $_POST[ 'dis_customer_product' ] ) ? sanitize_text_field( $_POST[ 'dis_customer_product' ] ) : '';

        /* Grab the disable product for visitor */
        $dis_visitors = isset( $_POST[ 'dis_visitors_product' ] ) ? sanitize_text_field( $_POST[ 'dis_visitors_product' ] ) : '';

        /* Grab the custom label for "Add to cart" */
        $custom_label = isset( $_POST[ 'label_replace_addtocart' ] ) ? sanitize_text_field( $_POST[ 'label_replace_addtocart' ] ) : '';

        /* Grab the redirection URL */
        if(isset( $_POST[ 'url_redirect_prod' ] )){
            $flter_url = filter_var($_POST[ 'url_redirect_prod' ], FILTER_SANITIZE_URL);
            
            if (filter_var($flter_url, FILTER_VALIDATE_URL)) {
                $redirect_url_cart = $flter_url;
            } else {
                echo _e($flter_url.' is not a valid URL', 'add-to-cart-option' );
            }
        }
        else{
            $redirect_url_cart = '';
        }
        
        /* Grab the product */
        $product = wc_get_product( $post_id );

        /* Save the custom label using WooCommerce built-in functions */	
        $product->update_meta_data( 'dis_customer_product', $dis_customer_only );
        $product->update_meta_data( 'dis_visitors_product', $dis_visitors );
        $product->update_meta_data( 'label_replace_addtocart', $custom_label );
        $product->update_meta_data( 'url_redirect_prod', $redirect_url_cart );
        $product->save();
    }
}