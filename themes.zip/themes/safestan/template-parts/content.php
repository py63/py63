<?php
/**
 * The template part for displaying content
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="card-box">
        <div class="col-md-4 col-sm-4">
            <div class="row text-center">
            <?php if (has_post_thumbnail( $post->ID ) )
				{ 
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); 
					 ?>
			  			<img src="<?php echo $image[0];?>" class="img-responsive">
					<?php 
				}
				else
				{
					?>
						<img  src="<?php bloginfo('template_directory');?>/images/logo-blog.png" class="img-responsive" />
					<?php 
				}
			?>
				
            </div>
        </div>
      	<div class="col-md-8 col-sm-8 mt-2 paddingx30">
			<?php the_title( sprintf( '<h4><a class="blog-hadding mt-2" href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' ); ?>
			<p class="blog-timing">
				<span><img src="<?php bloginfo('stylesheet_directory'); ?>/images/date.png" alt="date"></span> <?php the_time('M j, Y');?>
				<span class="ml-12">
					<img src="<?php bloginfo('stylesheet_directory'); ?>/images/admin.png" alt="user"> <?php echo get_the_author();?>
				</span>
				<span class="ml-12"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/list.png" alt="listimg">
					<?php 
					$post_categories = get_the_category( get_the_ID() );
					$i = 1;
					foreach ($post_categories as $post_category) {					
						if($i!= 1) { echo $separator_cat = ', ';}
						echo '<a href="'.get_term_link( $post_category ).'">'.$post_category->name.'</a>';
						$i++;
					}
					?>
				</span>
			</p>
			<?php 
				if(!empty(get_the_excerpt()))
				{
					echo the_excerpt();
				}
				else
				{
					echo "<p>Pellentesque diam metus, dapibus id vulputate in, ultrices a dui. Proin scelerisque, nisl a vulputate sollicitudin, nibh velit venenatis enim, sit amet tempus ipsum arcu sit amet justo. Nam sed ante sed leo porttitor dictum euismod a nulla. Nullam mollis, diam vitae cursus malesuada.</p>";
				}
			 ?><a href="<?php the_permalink();?>" class="btn btn-primary mt-1">read more</a>
		</div>
	</div> 
	<div class="entry-content">
		<?php
			/* translators: %s: Name of current post */
			/*the_content( sprintf(
				__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'twentysixteen' ),
				get_the_title()
			) );*/

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
		?>
	</div>
</article><!-- #post-## -->
