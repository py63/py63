<?php
include "wp-load.php";
global $wpdb;

$mycustomposts = get_posts( array( 'post_type' => 'property', 'numberposts' => 100));
    echo '<pre>';
    print_r($mycustomposts);
    echo '</pre>';
   foreach( $mycustomposts as $mypost ) {     
    wp_delete_post( $mypost->ID, true);   
   }
   echo '<h1 style=:"color:red;"> DELETED! DELETED! DELETED! DELETED! </h1>';

?>