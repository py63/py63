<div id="secondary" class="widget-area sidebar" role="complementary">
  <?php include(locate_template('templates/opportunity/sidebar/trackopportunity.php')); ?>
  <?php include(locate_template('templates/opportunity/sidebar/documents.php')); ?>
  <?php include(locate_template('templates/opportunity/sidebar/timeline-dates.php')); ?>
  <?php include(locate_template('templates/opportunity/sidebar/submitquestion.php')); ?>    
  <?php
  $opr_sites = get_post_meta(get_the_ID(), 'remote_opportunity_visibility', true);
  $ota_logo = '';
  if (is_array($opr_sites) && !empty($opr_sites)) {
    foreach ($opr_sites as $opr_site) {
      if (strpos($opr_site, 's2marts') !== false) {
        $smartlogo = get_theme_mod('smart_logo');
        $pagelink = 'https://s2marts.org/';
        //$ota_logo .= '<a href="' . $pagelink . '"  class="ota-logo-list" ><img src="' . $smartlogo . '" alt="s2mart"></a>';
        $attachId = attachment_url_to_postid($smartlogo);
        echo '<p>This opportunity is a S2marts OTA</p>';
        echo '<a href="' . $pagelink . '" target="_blank"  class="ota-logo-link" >' . wp_get_attachment_image($attachId, 'thumbnail', false, array("class" => "img-responsive")) . '</a>';
      } elseif (strpos($opr_site, 'trainingaccelerator') !== false) {
        $trexlogo = get_theme_mod('trex_logo');
        $pagelink = 'https://trainingaccelerator.org/';
        echo '<p>This opportunity is a TReX OTA</p>';
        //$ota_logo .= '<a href="' . $pagelink . '"  class="ota-logo-list"><img src="' . $trexlogo . '" alt="trex"></a>';
        $attachId = attachment_url_to_postid($trexlogo);
        echo '<a href="' . $pagelink . '" target="_blank" class="ota-logo-link" >' . wp_get_attachment_image($attachId, 'thumbnail', false, array("class" => "img-responsive")) . '</a>';
      } else {
        $nstxllogo = get_stylesheet_directory_uri() . '/assets/images/blank-PNG.png';
        $pagelink = get_bloginfo('url') . '/otas/';
        $ota_logo .= '<a href="' . $pagelink . '"  class="ota-logo-list"><img src="' . $nstxllogo . '" alt="s2mart"></a>';
      }
    }
  } else {
    $nstxllogo = get_stylesheet_directory_uri() . '/assets/images/blank-PNG.png';
    $pagelink = get_bloginfo('url') . '/otas/';
    $ota_logo .= '<a href="' . $pagelink . '"  class="ota-logo-link"><img src="' . $nstxllogo . '" alt="s2mart"></a>';
  }
  ?>
</div><!-- #secondary -->