<?php 
	require('../../../wp-load.php');
global $wpdb;

  if(isset($_POST['imgId']) && !empty($_POST['imgId'])){

    	$imageId = $_POST['imgId'];
      $postId  = $_POST['postId'];

      if($_POST['imgStatus']==1)
      {
        $imageRowsCount = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE ".$wpdb->prefix."post_slider_image.post_id =".$postId." AND status = 1 AND image_id = ".$imageId."");
        if($imageRowsCount[0]->image_featured_status == 1)
        {
          $wpdb->query("UPDATE wpsft_post_slider_image SET image_featured_status = 0 WHERE wpsft_post_slider_image.image_id = $imageId");
        }
          
          //echo $imageRowsCount[0]->image_featured_status;die;
      }

      $imageRowsCount = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE ".$wpdb->prefix."post_slider_image.post_id =".$postId." AND status = 1");
      /*echo $_POST['imgStatus'];die;
      echo count($imageRowsCount);die;*/
      
      if($_POST['imgStatus']==0)
      {
    	  if(count($imageRowsCount) <= 9)
        {  
            //echo 'Less then 10 image Approved';
            $row = $wpdb->query("UPDATE wpsft_post_slider_image SET status = 1 WHERE wpsft_post_slider_image.image_id = $imageId");
      	   
            $res = 1;
        }
        else
        {
            $res = 'Maximun 10 image Approved';
           //echo 'More then 10 image Approved';
        }

      }
      else
      {
  	     $row = $wpdb->query("UPDATE wpsft_post_slider_image SET status = 0 WHERE wpsft_post_slider_image.image_id = $imageId");
  	     $res = 0;
      }
        //$res = 'Maximun 10 image Approved';
  	
  	 echo $res; die;
  }

  if(isset($_POST['imgDelete']) && !empty($_POST['imgDelete'])){
      $imgDelete      = $_POST['imgDelete'];
      $imgDeleteName  = $_POST['imgDeleteName'];
      
      //$arr = explode('/', $imgDeleteName);
      
      //$imgpath = site_url().'/wp-content/uploads/front-slider-image/'.$imgDeleteName;
      
      $upload_dir = wp_upload_dir();
      $up_Path =  $upload_dir['basedir'].'/front-slider-image/';

      $imgpathDelete = $up_Path.$imgDeleteName;
      
      $row = $wpdb->query("DELETE FROM wpsft_post_slider_image WHERE wpsft_post_slider_image.image_id =  $imgDelete");
      unlink($imgpathDelete);
      echo $res = '1';die;
  }

  if(isset($_POST['imgFetauredId']) && !empty($_POST['imgFetauredId'])){
      $imgFetauredId      = $_POST['imgFetauredId'];
      $imgFeaturedStatus  = $_POST['imgFeaturedStatus'];
      $postId  = $_POST['postId'];
      
      $imfeatureds = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE image_featured_status = 1 AND post_id = ".$postId."");
      
      if($imgFeaturedStatus != 1)
      {
        
        $imgFetauredId1 = $imfeatureds[0]->image_id;
        $postId1 = $imfeatureds[0]->post_id;

        $wpdb->query("UPDATE wpsft_post_slider_image SET image_featured_status = 0 WHERE wpsft_post_slider_image.image_id = ".$imgFetauredId1." AND wpsft_post_slider_image.post_id = ".$postId1."");
      }

      if($imgFeaturedStatus == 0)
      {
          $row = $wpdb->query("UPDATE wpsft_post_slider_image SET image_featured_status = 1 WHERE wpsft_post_slider_image.image_id = ".$imgFetauredId." AND wpsft_post_slider_image.post_id = ".$postId."");
          echo $res = 1;die;    
      }
  }
  if(isset($_POST['imgDeleteFront']) && !empty($_POST['imgDeleteFront'])){
      $imgDeleteFront      = $_POST['imgDeleteFront'];
      $imgDeleteNameFront  = $_POST['imgDeleteNameFront'];
      
      //$arr = explode('/', $imgDeleteName);
      
      //$imgpath = site_url().'/wp-content/uploads/front-slider-image/'.$imgDeleteName;
      
      $upload_dir = wp_upload_dir();
      $up_Path =  $upload_dir['basedir'].'/front-slider-image/';

      $imgpathDelete = $up_Path.$imgDeleteNameFront;
      
      $row = $wpdb->query("DELETE FROM wpsft_post_slider_image WHERE wpsft_post_slider_image.image_id =  $imgDeleteFront");
      unlink($imgpathDelete);
      echo $res = '1';die;
  }

//Delete review from property.

if(isset($_POST['proerptyReviewDelete']) && !empty($_POST['proerptyReviewDelete'])){
  $proerptyReviewDelete = $_POST['proerptyReviewDelete'];   
  
  $row = $wpdb->query("DELETE FROM wpsft_richreviews WHERE id =  $proerptyReviewDelete");
 
  echo $res = '1';die;
}

if(isset($_POST['reviewID']) && !empty($_POST['reviewID'])){
      
      $reviewID = $_POST['reviewID'];
      $reviewStatus = $_POST['reviewStatus'];
      $reviewpostId  = $_POST['reviewpostId'];
      //res = array();

      if($_POST['reviewStatus']==1)
      {
        $reviewRowsCount = $wpdb->get_results( "SELECT * FROM wpsft_richreviews WHERE post_id = $reviewpostId AND review_status = 1 AND id = $reviewID");        
        $reviewRowsCount[0]->review_status;
        if($reviewRowsCount[0]->review_status == 1)
        {
          $wpdb->query("UPDATE wpsft_richreviews SET review_status = 0 WHERE id = $reviewID");
          //$res = array(a=>0,b=>$reviewID);
          $res = 0;
        }
      }
      else
      {
        if($_POST['reviewStatus']==0)
        {
          $row = $wpdb->query("UPDATE wpsft_richreviews SET review_status = 1 WHERE id = $reviewID");       
          //$res = array(a=>1,b=>$reviewID);
          $res = 1;
        }
      }
      echo $res;  die; 
}