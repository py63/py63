<style type="text/css">
  .invoice_preview_section tr.hide-section td {
    border: 0 !important;
}
	@media print {
		#Header,
		#Footer {
			visibility: hidden;
			display: none;
		}
		tr.hide-section{
			display: block;
		}
		body header,
		body .step-anchor .nav-item,
		body .qualification-member,
		body .commonly_requested_corporate_info,
		body .printpdf,
		body #pmpro_payment_information_fields,
		body #accept_policy_div,
		body .pmpro_submit,
		body .sw-toolbar,
		body footer,
		.rgs_title,
		.sw-btn-prev,
		.sw-main section,
		.title-area-content-wrapper,
		.page-title {
			/*visibility: hidden;*/
			display: none;
		}
		a[href]:after {
			content: none !important;
		}
		@page {
			margin-top: 0;
			margin-bottom: 0;
		}
		body {
			padding-top: 2px;
			padding-bottom: 72px;
		}
		#invoice-preview-table,
		#invoice-preview-table .inner-table,
		#invoice-preview-table tr,
		#invoice-preview-table td table {
			display: table !important;
			width: 100%
		}
		#invoice-preview-table .inner-table,
		#invoice-preview-table .inner-table .biling-table {
			border-collapse: collapse !important;
			display: table;
			width: 100%;
		}
		#invoice-preview-table .inner-table .biling-table {
			border-collapse: collapse !important;
		}
		#invoice-preview-table .inner-table .biling-table th,
		#invoice-preview-table .inner-table .biling-table td {
			border: 1px solid #ddd !important;
			width: 30%;
			word-wrap: break-word;
		}
		.title-table {
			color: #f01c35 !important;
		}
		/*	#invoice-preview-table .inner-table .biling-table th:nth-child(2), #invoice-preview-table .inner-table .biling-table td:nth-child(2){
				border-right: 1px solid #ddd !important;
			}*/
                  .invoice_preview_section tr.hide-section td {
    border: 0 !important;
}
		}
	</style>
	<div class="invoice_preview_section clearfix">
		<style>
			table {
				border-collapse: none !important;
			}

			tr {
				border: 0 !important;
			}
		</style>
		<table border="0" id="invoice-preview-table" class="main-table-wrapper invoice-preview-table" cellpadding="0" cellspacing="0" style=" width: 100%; max-width: 600px; margin: 20px auto; background-color: #fff;font-family: sans-serif; padding: 10px 30px 30px; overflow-x:hidden; border:0px;">
			<tr class="hide-section">
				<td><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.png" style="margin: auto; display: block; width: 220px" alt="logo">
				</td>
			</tr>
			<?php /*?>
			<tr class="td-center hide-section" align="center">
				<td style="padding: 0; text-align: center;">
					<div class="wrap-logos clearfix">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo-circle.png" style="width: 50px;">
						<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo-trex.png" style="width: 150px; ">
					</div>
				</td>
			</tr>
	<?php */?>
                        <tr align="center" style="border: 0px none !important"  class="hide-section">
                          <td align="center" style="border: 0px none !important">
					<table align="center" cellpadding="0" cellspacing="0" border="0">
						<tr style="border:0px none;">
							<td class="title-table" align="center" style="font-size: 24px;
							font-family: sans-serif;
							color: #f01c35;
							text-align: center; border-bottom: none !important;
							"><?php _e('Membership Invoice','polar'); ?></td>
						</tr>


					</table>


				</td>
			</tr>
			<tr>
                          <td style="border-bottom: none !important;">
					<table class="inner-table" cellpadding="0" cellspacing="0" style="text-align: center;" width="100%">
					<tr class="hide-section" style="border: 0px none !important">
                                          <td style="border: none !important;">
							<table style="text-align: right; font-size: 12px; padding-bottom: 30px; width: 100%; border: 0px none !important" width="100%">
								<tr style="border: none !important;">
									<td style="width: 50%; border-bottom: none !important;"></td>
									<td style="border-bottom: none !important;">National Security Technology Accelerator</td>
								</tr>
								<tr style="border: none !important;">
									<td style="width: 50%; border-bottom: none !important;"></td>
									<td style="border-bottom: none !important;">NSTXL</td>
								</tr>
								<tr style="border: none !important;">
									<td style="width: 50%; border-bottom: none !important;"></td>
                                                                        <td style="border-bottom: none !important;">220 NW 8<span>th</span> Street</td>
								</tr>
								<tr style="border: none !important;">
									<td style="width: 50%; border-bottom: none !important;"> </td>
                                                                        <td style="border-bottom: none !important;">Portland, OR 97210<br />USA</td>
								</tr>
							</table>
						</td>
					</tr>

					<tr style="text-align: left; border: none !important;" class="hide-section">

						<td style="font-size: 14px; border-bottom: none !important;">
							<?php
							$company_userdata = nstxl_company_additional_userdata($current_user->ID);						
							if ( isset( $company_userdata['company_name'] ) && !empty( $company_userdata['company_name'] ) ) {
								$companyname = $company_userdata['company_name'];
								echo $companyname;
							}							
							if ( isset( $company_userdata['poc_userid'] ) && !empty( $company_userdata['poc_userid'] ) ) {
								$poc = $company_userdata['poc_userid'];
								$user_info = get_userdata( $poc );							
							}							
							?>
						</td>
					</tr>
					<tr style="text-align: left;" class="hide-section">
						<?php if (isset($user_info) && !empty($user_info)) { ?>
							<td style="font-size: 14px; border-bottom: none !important;">
								<span class="invc-prev-name"><?php echo ucwords($user_info->display_name); ?></span><br>
								<div style="font-weight: 600">Via email <span class="invc-prev-email"><?php echo $user_info->user_email; ?></span></div>
							</td>
							<?php } ?>
						</tr>
                                                <tr style="text-align: left; border-bottom: none !important;"><td style="border-bottom: none !important;"><h4>Order Details</h4></td></tr>

						<tr>
							<td style="text-align: left">
								<table class="biling-table" style="border: 1px solid #ddd; border-collapse: collapse; margin: 20px 0; font-size: 14px; width: 100%" width="100%" cellpadding="0" cellspacing="0">
									<tr>
										<th style="border: 1px solid #ddd; padding: 5px ;color:#d2232a;"><?php _e('Purchase','polar'); ?></th>
										<?php /*?><th style="border: 1px solid #ddd;  padding: 5px ; color:#d2232a;"><?php _e('Organization Type','polar'); ?></th><?php */?>
										<th style="border: 1px solid #ddd;  padding: 5px; color:#d2232a;"><?php _e('Amount Due','polar'); ?></th>
									</tr>

									<tr>
										<td style="border: 1px solid #ddd;  padding: 5px"><?php _e('12-month NSTXL Membership','polar'); ?></td>
									<?php /*?><td style="border: 1px solid #ddd;  padding: 5px">
										<?php
										if ( isset( $companyname ) && !empty( $companyname ) ) {
											echo $companyname;
										}
										?>
									</td><?php */?>
									<td style="border: 1px solid #ddd;  padding: 5px">
										<?php echo pmpro_formatPrice($pmpro_level->initial_payment);?> </td>
									</tr>
									<tr>
										<td style="border: 1px solid #ddd;  padding:5px"><span class="font-weight-b"><?php _e('Total Due Upon Invoice','polar'); ?></span> </td>
										<?php /*?><td style="border: 1px solid #ddd;  padding: 5px"> </td><?php */?>
										<td style="border: 1px solid #ddd;  padding: 5px">
											<span class="font-weight-b">
												<?php echo pmpro_formatPrice($pmpro_level->initial_payment);?>
											</span>
										</td>
									</tr>
								</table>
							</td>
						</tr>

					<?php /* ?><tr style="text-align: left;" class="hide-section">
						<td style="font-size: 14px;"> Thank you! We look forward to welcoming you as a member.</td>
					</tr><?php */ ?>
				</table>
			</td>
		</tr>
	</table>
	<div class="printpdf clearfix">
		<a id="cmd" class="btn pull-left" href="#"><?php _e('Save Invoice', 'paid-memberships-pro' ); ?></a>
		<a class="pmpro_a-print pull-right" href="#" onclick="window.print();"><?php _e('Print Invoice', 'paid-memberships-pro' ); ?></a>
	</div>
</div>