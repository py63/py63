<?php 
/* Plugin Name: Add to cart option
* Description: This plugin helps to add more options to the woocommerce add to cart. It allows hiding add to cart button for customers and visitors once they selected options. It also provides features to rename the "add to cart" button and redirects to another page/website.
* Plugin URI: #
* Author: TFL
* Author URI: http://galaxyweblinks.com
* Version: 1.0
* Text Domain: add-to-cart-option
* License:GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly 
}

/* Define file path */
if(!defined('ACO_PLUGINPATH')){
	define('ACO_PLUGINPATH', plugin_dir_path(__FILE__));
}

/* Include files */
require_once(ACO_PLUGINPATH.'admin/aco-backend-options.php');
require_once(ACO_PLUGINPATH.'admin/aco-custom-style.php');
require_once(ACO_PLUGINPATH.'public/aco-frontend.php');

/* Check if WooCommerce is active */
function aco_addon_activate() {  
    if( !class_exists( 'WooCommerce' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( __( 'Please install and Activate WooCommerce.', 'add-to-cart-option' ), 'Plugin dependency check', array( 'back_link' => true ) );
    }
}

/* Sets up activation hook */
register_activation_hook(__FILE__, 'aco_addon_activate');

/* Add custom script */
function aco_admin_inq($hook) {
    $screen = get_current_screen();
    if ( 'post' === $screen->base && 'product' === $screen->post_type) {
        wp_enqueue_script('aco_adm_custom_script', plugin_dir_url(__FILE__) . 'admin/js/aco-custom-admin-script.js');
    }
}
add_action('admin_enqueue_scripts', 'aco_admin_inq');

