<?php
/**
*Template Name: Dashboard Submit Question Form
*/

global $wpdb, $current_user;
if (!is_user_logged_in() ) { 
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit; }  
if(empty($_GET['oppid'])){
   wp_redirect(get_bloginfo('url') . '/dashboard-submit-question/', 301);
   exit;
}
get_header('admin');


 $join_lists = "";
 do_action('onepress_page_before_content');
  ?>
  <div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">
        <div class="edituser-container adduser-container dashboard-inner-wrapper dashboard-bg-white personal-profile-dashboard personal-info-container">
          <a class="arrow-back" href="<?php echo site_url(); ?>/dashboard-submit-question/"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/arrow-back.png"></a>
          <div class="wrap-apple-icon person-name">
              <h2 class="rgs_title">
                <?php 
                $oppid = $_GET['oppid'];
                  echo get_the_title($oppid); 
                ?>  
                </h2> 
          </div>
          <?php include(locate_template('templates/opportunity/sidebar/submitquestion.php')); ?>
        </div>


     </main>
  </div>
  </div>
  </div>

<?php

get_footer('admin');