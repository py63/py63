<?php
/**
 * Template Name: Opportunity with tab
 *
 * @package OnePress
 */
get_header();

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
global $current_user;
$cusr_id = $current_user->ID;
?>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  ?>
  <div id="content-inside" class="container no-sidebar">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' ); ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>
              <div id="opportunity-outer-tab" class="tab-opportunity-container container"> 
                <div class="opr-tab-header">
                  <ul class="nav nav-pills">
                    <li>
                      <a href="#tab1a" class="active" data-toggle="tab"><?php _e('Coming Soon', 'polar'); ?></a>
                    </li>
                    <li>
                      <a href="#tab2a" data-toggle="tab"><?php _e('Current', 'polar'); ?></a>
                    </li>
                    <li>
                      <a href="#tab3a" data-toggle="tab"><?php _e('Under Evaluation', 'polar'); ?></a>
                    </li>
                    <li>
                      <a href="#tab4a" data-toggle="tab"><?php _e('Awarded', 'polar'); ?></a>
                    </li>
                  </ul>
                  <div class="form-01">
                    <?php $unique_id = esc_attr(uniqid('search-form-')); ?>
                    <form role="search" method="get" class="search-form opportunity-search" action="<?php echo esc_url(home_url('/')); ?>search-opportunity">
                      <input type="search" id="<?php echo $unique_id; ?>" class="search-field" placeholder="<?php echo esc_attr_x('Search', 'placeholder', 'polar'); ?>" value="<?php echo get_search_query(); ?>" name="sa" />
                      <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text"><?php echo _x('Search', 'submit button', 'polar'); ?></span></button>
                    </form>
                  </div>
                </div>
                <div class="tab-content clearfix">
                  <div class="tab-pane active" id="tab1a" data-id="1">
                    <?php
                    $termID = 43;
                    $tab_num = 1;
                    include(locate_template('templates/opportunity/main-tabs/opportunity-category-tab.php'));
                    ?>  
                  </div>
                  <div class="tab-pane" id="tab2a" data-id="2">
                    <?php
                    $termID = 40;
                    $tab_num = 2;
                    include(locate_template('templates/opportunity/main-tabs/opportunity-category-tab.php'));
                    ?>
                  </div>
                  <div class="tab-pane" id="tab3a" data-id="3">
                    <?php
                    $termID = 44;
                    $tab_num = 3;
                    include(locate_template('templates/opportunity/main-tabs/opportunity-category-tab.php'));
                    ?>
                  </div>
                  <div class="tab-pane" id="tab4a" data-id="4">
                    <?php
                    $termID = 41;
                    $tab_num = 4;
                    include(locate_template('templates/opportunity/main-tabs/opportunity-category-tab.php'));
                    ?>
                  </div>
                </div>
              </div>          
            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->
  </div><!--#content-inside -->
</div><!-- #content -->
<?php
$modal_id = 'track-opportunity-modal-' . get_the_ID();
$modal_body_container_class = 'track-opportunity-modal-container';
$content_html = '';
nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class);
?>  
<!-- /.modal --> 
<script type="text/javascript">
  jQuery(document).ready(function ($) {
    trackOpportunity();
    untrackOpportunity();
    $('body').on('click', '.loadmore a', function (e) {
      e.preventDefault();
      this_save_to_remove = $(this);
      var temphref = $(this).attr('href');
      $(this).hide();
      $(this).parent(".loadmore").append("<div class='loadmore wow animated fadeInUp loadmoreloading'>Loading...</div>");
      var activepan = $(".tab-pane.active").data('id');
      $.post(temphref, function (response) {
        this_save_to_remove.parent(".loadmore").remove();
        var tempdata = $(response).find('.opportunity-posts').each(function () {
          var temptab = $(this).data("tab");
          var temptab_html = $(this).html();
          if (activepan == temptab)
          {
            $(".opportunity-posts" + temptab).append(temptab_html);
          }
        });
        trackOpportunity();
        untrackOpportunity();
      });
    });

//    jQuery('.close').on('click', function (e) {
//      jQuery('#update-personalinfo-modal-success').modal('hide');
//    });
//    jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
//      location.reload(true);
//    })
  });
</script>
<?php
get_footer();
