<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>	
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php endif; ?>
	<link href="<?php bloginfo('template_directory');?>/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php bloginfo('template_directory');?>/css/main.css" rel="stylesheet">
	<link href="<?php bloginfo('template_directory');?>/css/slider.css" rel="stylesheet">
	<link href="<?php bloginfo('template_directory');?>/css/font-awesome.min.css" rel="stylesheet">

	<?php wp_head(); ?>
	<script type="text/javascript">
   		var homeurl = "<?php echo home_url();?>";
   	</script>
</head>

<body <?php body_class(); ?>>
<!-- <div class="loader" style="display:none;"></div> -->
<section id="wrapper" class="new_wrapper">
	<header class="main-header box-shadow">
		<div class="container-fluid custom_container">
		  <nav class="navbar navbar-default new_nav"> 
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		       <span class="sr-only">Toggle navigation</span>
		       <img src="<?php bloginfo('template_directory');?>/images/icon-bar.png" width="18" height="14" alt=""/></button>
		      <?php twentysixteen_the_custom_logo(); ?>
		     </div>
		    
		    <!-- Collect the nav links, forms, and other content for toggling -->
		    
		    <div class="collapse navbar-collapse text-right" id="bs-example-navbar-collapse-1">
	            <?php if ( has_nav_menu( 'primary' ) ) : ?>
								<?php
									wp_nav_menu( array(
										'theme_location' => 'primary',
										'container' => false, 
										'menu_class'     => 'nav navbar-nav nav-center float-none',
									 ) );
								?>
				<?php endif; ?>
	            <ul class="nav navbar-nav navbar-right login">
		            <?php 
		            $home_url = home_url();
		            $wp_logout_url = $home_url.'/login';
		            
		            if(!(is_user_logged_in()))
		            {	?>
			            <li>
			              	<a href="<?php bloginfo('url')?>/login/">
			              		<!--<span class="fa fa-lock"></span>-->
			              		<span <?php if(is_page('login')) {?> class="login selected"<?php } else { ?>class="signup" <?php } ?>>Login</span>
			              	</a>
			            </li>
		              	<li>
		              		<a href="<?php bloginfo('url')?>/register/">
		              			<!--<span class="fa fa-user"></span>-->
		              			<span <?php if(is_page('register')) {?> class="signup selected"<?php } else { ?>class="signup" <?php } ?>>Sign Up</span>
		              		</a>
		              	</li>
		              		<?php 
	              	}
	              	else
	              	{	?>
		              	<li> 
			              	<a href="<?php echo wp_logout_url( $wp_logout_url );?>">
			              		<!--<span class="fa fa-lock"></span>-->
			              		<span class="login">Logout</span>
			              	</a>
			            </li>
		              	<li>
		              		<a href="<?php bloginfo('url')?>/your-profile/">
		              			<!--<span class="fa fa-user"></span>-->
		              			<span <?php if(is_page('your-profile')) {?> class="selected"<?php } else { ?>class="signup" <?php } ?>>Profile</span>
		              		</a>
		              	</li>
		            	<?php 
		            } 	?>  	
	            </ul>
		    </div>
		    <!-- /.navbar-collapse --> 
		  </nav>
		</div>
	</header>
		