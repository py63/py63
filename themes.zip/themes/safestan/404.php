<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
	<!-- Start Head Section -->
	<div class="top-banner">
	    <div class="container">
	      	<div class="row">
				<div class="col-md-12 col-sm-12">
	        		<h1 class="banner-hadding"><?php _e( 'Oops! That page can&rsquo;t be found.', 'twentysixteen' ); ?></h1>
				</div>
	      	</div>
	    </div>
	</div>	
	<!-- End Head Section -->
	<div class="account-main main-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12"><h2>
            <?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'twentysixteen' ); ?></h2>          
          </div>
        </div>
      </div>
    </div>

	
<?php get_footer(); ?>
