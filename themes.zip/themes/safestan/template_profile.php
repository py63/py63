<?php
/**
 * Template Name: Profile
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();?>
	<!-- Start Head Section -->
	<div class="top-banner">
	    <div class="container">
	      <div class="row">
	        <div class="col-md-12 col-sm-12">
	          <h1 class="banner-hadding"><?php the_title();?></h1>
	        </div>
	      </div>
	    </div>
	</div>	
	<!-- End Head Section -->
	<div class="profile">
	    <div class="container">
		    <div class="row">
		        <div class="col-md-12 col-sm-12">
		          	<div class="user-box">
		            	<div class="row">
		            	<?php the_content();?>
		            	</div>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
	<?php // End of the loop.
	endwhile;
	?>
<script type="text/javascript">
jQuery(document).ready(function(){
    //alert("hello");
    //var getval = jQuery('#wpua-remove-button-existing').css('class');
    var getval = jQuery( "#wpua-remove-button-existing" ).hasClass( "wpua-hide" );
    //console.log(getval);
    //alert(getval);
    if(getval == false){
    	jQuery( "#wpua-upload-button-existing" ).addClass( "wpua-hide" );
    	jQuery( "#wpua-add-button-existing" ).addClass( "wpua-hide" );
    }else{
    	jQuery( "#wpua-upload-button-existing" ).removeClass( "wpua-hide" );
    	jQuery( "#wpua-add-button-existing" ).removeClass( "wpua-hide" );
    }
    jQuery("#wpua-remove-existing").click(function(){
    	jQuery( "#wpua-upload-button-existing" ).removeClass( "wpua-hide" );
    	jQuery( "#wpua-add-button-existing" ).removeClass( "wpua-hide" );
    });
});
</script>
<?php get_footer(); ?>
