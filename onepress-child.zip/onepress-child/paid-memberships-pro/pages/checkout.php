<style>
  /* step page */
#smartwizard.sw-theme-dots .sw-container {
  min-height: 300px !important;
}
  #smartwizard .nav.nav-tabs.step-anchor {
    justify-content: space-around;
    max-width: 935px;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor:before {
    background-color: transparent;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li {
    border: none;
    width: auto;
    text-align: center;
    position:relative;
    max-width: 198px;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li:before {
    content: '';
    background: #bf3737;
    height: 1px;
    width: 100%;
    position: absolute;
    top: 50px;
    right: 50%;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li:after {
    content: '';
    background: #bf3737;
    height: 1px;
    width: 100%;
    position: absolute;
    top: 50px;
    left: 50%;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li:first-child:before {
    width: 0;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li:last-child:after {
    width: 0;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li > a:before {
    content: ' ';
    position: absolute;
    bottom: 6px;
    left: 45%;
    margin-top: 0px;
    display: block;
    border-radius: 50%;
    color: transparent;
    background: #fff;
    border: 1px solid #bf3737;
    width: 16px;
    height: 16px;
    text-decoration: none;
    z-index: 98;
    top: auto;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li > a:after {
    content: ' ';
    position: relative;
    left: 43%;
    bottom: -3px;
    margin-top: 5px;
    display: block;
    width: 16px;
    height: 16px;
    background: transparent;
    border-radius: 50%;
    z-index: 99;
    top: auto;
  }

  #smartwizard.sw-theme-dots > ul.step-anchor > li:last-child > a:before {
    left:46%;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li > a:after {
    left: 44%;
    bottom: -2px;
  }

  #smartwizard.sw-theme-dots > ul.step-anchor > li.active > a:after {
    background: #bf3737;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li small {
    font-size: 14px;
    font-weight: normal;
    line-height: 20px;
    letter-spacing: normal;
    text-align: center;
    color: #000;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li.done > a {
    color: #000;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li.done > a:after {
    left: 44%;
    bottom: -1px;
    content: '\2713';
    color: #fff;
    font-size: 11px;
  }
  #smartwizard.sw-theme-dots > ul.step-anchor > li.done > a:before {
    background:#bf3737;
  }
  .sw-theme-dots > ul.step-anchor:before {
    top: 75px;
  }
  .sw-theme-dots > ul.step-anchor > li > a {     
    color: #000;  
    font-family: AvenirNext-Bold,sans-serif;
    font-size: 16px;
    font-weight: normal;
    text-align: center;
    text-transform:uppercase;
  }
  .sw-theme-dots > ul.step-anchor > li.active > a:hover {
    color: #bf3737;
  }
  .sw-theme-dots > ul.step-anchor > li > a br{
    display:none;
  }
  .sw-theme-dots > ul.step-anchor > li.active > a {
    color: #bf3737;
    font-family: AvenirNext-Bold,sans-serif;
    font-size: 16px;
    font-weight: normal;
    text-align: center;
    text-transform:uppercase;
  }
  .sw-theme-dots > ul.step-anchor:before {
    top:90px;
  }
  .sw-theme-dots > ul.step-anchor > li > a:after {   
    left: 45%;
    bottom: -1px;
  }
  .sw-theme-dots > ul.step-anchor > li.active > a:after {
    background: #bf3737;
  }
  #smartwizard #user_pic_div {display:none;}
  #smartwizard #user_pic { display: none;}
  #smartwizard h3.rgs_title {
    font-size: 40px;
    font-weight: normal;
    text-align: center;
    color: #bf3737;
    margin: 40px 0 20px 0;
  }
  #smartwizard .circle { 
    position: relative; 
    width: 110px; 
    margin: 0 auto 40px auto;
  }
  #smartwizard #user_pic_div label {text-align: center;}

  #smartwizard .pmpro_checkout {
    width: 100%;
    margin-top: 0;
  }
  #smartwizard.sw-theme-dots .step-content{
    max-width: 780px;
    margin: 0 auto;
  }
  #smartwizard .pmpro_checkout-fields {
    position: relative;
  }
  #smartwizard .pmpro_checkout-fields h3 {
    font-family: AvenirNext-Bold,sans-serif;
    font-size: 18px;
    font-weight: normal;
    letter-spacing: 1px;
    color: #000;
    margin-bottom: 20px;
    text-transform: uppercase;
  }
  #smartwizard .pmpro_checkout-fields div.row {
    margin:0 -15px 0 -15px;
  }
  #smartwizard .pmpro_checkout-fields div{margin-bottom:0;}
  #smartwizard .pmpro_checkout-fields div.form-group{margin-bottom:1em;}
  #smartwizard hr {
    margin-top: 20px;
  }
  #smartwizard .pmpro_form .user_pics.circle {
    text-align: center;
    width: 200px;
    margin: 0 auto 50px !important;
    position: relative;
  }
  #smartwizard .profile-pic {
    position: relative;
    width: 114px;
    height: 114px;  
    overflow: hidden;
    margin:0;	
  }

  #smartwizard .profile-pic-img {
    width: 100%;
    height: 100%;
    vertical-align: middle;
    object-fit: cover;
    max-height:94px;
    max-width:94px;
    border-radius:50%;
    cursor:pointer;
  }
  .pmpro_form #smartwizard  .user_pics.circle .fa.fa-camera.upload-button {
    position: absolute; 
    border-radius: 50%;  
    color: #ffffff;
    background: #d2232a;
    bottom: 20px;
    right: 10px;
    width: 40px;
    height: 40px;
    line-height: 40px;
    font-size: 20px;
    padding: 0;
    cursor:pointer;
  }
  .pmpro_form  #smartwizard .user_pics.circle .fa-camera:before {
    left: 10px;
    position: relative;
  }
  form.pmpro_form #smartwizard label {
    display: block;
    margin: 0 0 5px 0;
    text-align: left;
    font-size: 18px;
    font-weight: normal;
    line-height: 1.56;
    letter-spacing: -0.5px;
    color: #000;
  }
  form.pmpro_form #smartwizard .input {
    border: 1px solid #000;
    background-color: #fff;
    box-shadow: none;
    font-size: 18px;
    font-weight: normal;
    line-height: 1.56;
    letter-spacing: -0.5px;
    color: #000;
    padding: 5px 10px;
  }
  .btn.btn-danger.btn-sm.btn-remove, .btn.btn-info.btn-md.btn-add.pull-right{
    background-color: transparent;
    border-color: transparent;
    box-shadow: none;
  }

  #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom{
    max-width:660px;
    margin:60px auto 0 auto;
  }
  #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom .sw-btn-group{
    margin:0 auto !important;
  }
  #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom .sw-btn-group .sw-btn-prev{
    font-family: AvenirNext-Bold,sans-serif;
    font-weight: 400;
    line-height: 1.43;
    letter-spacing: 1px;
    padding: 8px 42px;
    border: 1px solid #bf3737;
    font-size: 14px;
    text-align: center;
    color: #000;
    background-color: transparent;
    border-radius: 0;
    margin:0 5px;
    min-width: 188px;
  }
  #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom .sw-btn-group .sw-btn-next{
    font-family: AvenirNext-Bold,sans-serif;
    font-weight: 400;
    line-height: 1.43;
    letter-spacing: 1px;
    padding: 8px 42px;
    border: 2px solid #bf3737;
    font-size: 14px;
    text-align: center;
    color: #fff;
    background-color: #bf3737;
    border-radius: 0;
    margin:0 5px;
    min-width: 188px;
  }
  #traditional_or_nontraditional_organization_div{
    padding:0 15px;
  }
  #traditional_or_nontraditional_organization_div .help-block.with-errors{
    display:none;
  }
  form.pmpro_form #smartwizard #traditional_or_nontraditional_organization_div label{
    display:inline-block;
  }
  #smartwizard .pmpro_checkout-field-is-have-your-company-logo{margin-top:20px;}
  #smartwizard .pmpro_checkout-field-is-have-your-company-logo .upload_comp_btn{
    font-family: AvenirNext-Bold,sans-serif;
    font-size: 14px;
    font-weight: normal;
    line-height: 20px;
    letter-spacing: 1px;
    text-align: center;
    color: #000;
    text-transform: uppercase;
    border: 1px solid #bf3737;
    padding: 10px 15px;
    margin: 0 10px;
    background:transparent;
  }
  #smartwizard .pmpro_checkout-field-is-have-your-company-logo .upload_comp_btn:hover{
    background: #bf3737;
    color:#fff;
    text-decoration:none;
    border:1px solid !important;
  }
  #smartwizard #ibenic_comp_file_upload_preview.file-upload.file-preview{
    display: inline-block;
    position: relative;
    max-width: 250px;
    margin-right: 20px;
  }
  #smartwizard #ibenic_comp_file_upload_preview.file-upload.file-preview .ibenic_file_delete_comp{
    color: #fff;
    background-color: #bf3737;
    border-color: #bf3737;
    border-radius: 20px!important;
    width: 34px;
    position: absolute;
    top: -10px;
    right: -10px;
  }
  #smartwizard #primary_domain_interest_div label{
    min-height:56px;
  }
  #smartwizard .row.cmp_users_data{margin:0;}
  #smartwizard .cmp_users_data .row.item{
    margin: 10px 0;
    padding: 20px;
    background: #fff;
    box-shadow: 0 2px 15px 0 rgba(0, 0, 0, 0.14);
  }
  #smartwizard .cmp_users_data .row.item:first-child .btn-remove{display:none;}
  #smartwizard .cmp_users_data .row.item .btn-remove{padding-top:43px; cursor:pointer;}
  #smartwizard .repeater-default .btn-add{    
    width: 100%;
    margin: 20px 0;
    background: transparent;
    border-color: #bf3737;
    border-radius: 0;
    padding: 15px;
    color: #000;
    font-size: 18px;
    font-weight: normal;
    line-height: 28px;
    letter-spacing: -0.5px;
    text-align: center;
    cursor: pointer;
  }

  #smartwizard .billing-info-container h3, #smartwizard .billing-info-container h4{
    font-family: AvenirNext-Bold,sans-serif;
    font-size: 18px;
    font-weight: normal;
    letter-spacing: 1px;
    color: #000; 
    text-transform:uppercase;
  }
  #smartwizard .billing-info-container h3 a{
    font-family: AvenirNext-Regular,sans-serif;
    font-size: 14px;
    font-weight: normal;
    line-height: 1.43;
    color: #bf3737;
    text-transform:none;
  }
  #smartwizard .billing-info-container p{
    font-family:  AvenirNext-Regular,sans-serif;
    font-size: 18px;
    font-weight: normal;
    line-height: 1.56;
    letter-spacing: -0.5px;
    color: #000;
    margin-bottom: 0;
  }
  #smartwizard .billing-info-container p b{
    font-family:  AvenirNext-Bold,sans-serif;
    font-size: 14px;
    font-weight: normal;
    line-height: 1.43;
    letter-spacing: normal;
    color: #000;
  }
  #smartwizard .billing-info-container .row div:first-child{
    margin-bottom:20px;
  }
  #smartwizard .left-checkout-section{
    border-top: 1px solid #bf3737;
    padding: 30px 0 0 0;
    margin: 30px 15px -20px 15px;
  }
  #smartwizard .left-checkout-section table, #smartwizard .left-checkout-section table>tbody>tr>td, #smartwizard .left-checkout-section table>tbody>tr>th, #smartwizard .left-checkout-section table>thead>tr>td, #smartwizard .left-checkout-section table>thead>tr>th{
    padding:0;
    border:0 none;
  }
  #smartwizard .left-checkout-section table tr th{
    font-family: AvenirNext-Bold,sans-serif;
    font-size: 18px;
    font-weight: normal;
    letter-spacing: 1px;
    color: #000; 
    text-transform:uppercase;
  }
  #smartwizard .left-checkout-section table>thead>tr>td {
    padding-bottom: 30px;
  }
  #smartwizard .left-checkout-section table>thead>tr>th {
    padding-bottom: 10px;
  }
  #smartwizard .pmpro_checkout-field, #smartwizard .pmpro_checkout-fields div.pmpro_checkout-field{
    margin-bottom:20px;
  }
  #smartwizard #pmpro_payment_information_fields{
    max-width:480px;
  }
  #smartwizard .pmpro_checkout-field.pmpro_payment-expiration select{
    max-width: 46% !important;
  }
  #smartwizard .pmpro_checkout-field select#ExpirationMonth{margin-right:2%;}
  #smartwizard .pmpro_checkout-field select#ExpirationYear{margin-left:2%;}
  #smartwizard #pmpro_processing_nextstep {
    display: none;
  }
  #smartwizard a.download-form-link, #smartwizard a#cmd {
    background: #f3f3f3;
    padding: 10px;
    min-width: 288px;
    width: auto;
    display: inline-block;
    margin-bottom: 20px;
    font-size: 14px;
    line-height: 1.43;
    letter-spacing: normal;
    color: #bf3737 !important;
    position: relative;
    font-family: AvenirNext-Regular,sans-serif;
    text-align: left;
    border: 0 none;
    box-shadow: none;
    text-transform: none;
    font-weight: normal;
    border-radius:0;
  }
  #smartwizard a.download-form-link:after, #smartwizard a#cmd:after {
    content: '';
    background-image: url(/wp-content/themes/onepress-child/images/download-red.png);
    background-repeat: no-repeat;
    width: 23px;
    height: 21px;
    position: absolute;
    right: 15px;
    bottom: 10px;
  }
  #smartwizard a.download-form-link:hover, #smartwizard a.upload_doc_btn:hover{
    text-decoration:none;
  }
  #smartwizard #ibenic_file_upload_preview.file-upload.file-preview {
    background: #f3f3f3;
    max-width: 288px;
    padding: 5px 10px;
    position:relative;
    margin-top: 10px;
  }
 
  #smartwizard #ibenic_file_upload_preview.file-upload.file-preview .ibenic_file_preview {
    display: inline-block;
    width: 240px;
    position: relative;
    padding-left: 25px;
      top: 8px;
    overflow: hidden;
  }
  #smartwizard #ibenic_file_upload_preview.file-upload.file-preview .ibenic_file_preview:before {
    content: '';
    position: absolute;
    background: transparent url(/wp-content/themes/onepress-child/images/attach.svg) no-repeat;
    width: 19px;
    height: 18px;
    background-size: 100%;
    left: 0px;
    top: 5px;
  }
  .alert-success {
  margin-top: 10px;
  }
  #smartwizard #ibenic_file_upload_preview.file-upload.file-preview button.ibenic_file_delete {
    background: transparent;
    border: 0 none;
    box-shadow: none;
    color: #000;
    font-size: 22px;
    padding:0;
    position:relative;
  }
  #smartwizard #ibenic_file_upload_preview.file-upload.file-preview button.ibenic_file_delete .fa-trash:before {
    content: "";
    background: transparent url(/wp-content/themes/onepress-child/images/trash-dark.svg) no-repeat;
    width: 20px;
    height: 20px;
    position: absolute;
    top: 5px;
  }
  #smartwizard table.invoice-preview-table tbody tr td, #smartwizard table.invoice-preview-table tbody tr td table {
    border: 0 none;
  }
  #smartwizard table.invoice-preview-table tbody tr td table td{
    font-size: 18px;
    font-weight: normal;
    line-height: 1.56;
    letter-spacing: -0.5px;
    color: #000;
  }
  #smartwizard table.invoice-preview-table tbody tr td table.inner-table h4{
    border-top: 1px solid #bf3737;
    font-weight: normal;
    color: #000;
    padding-top: 20px;
  }
  #smartwizard table.invoice-preview-table tbody tr td table td{ width: 100%;}
  .commonly_requested_corporate_info h4 {
font-family: AvenirNext-Bold,sans-serif;
font-size: 18px;
font-weight: normal;
letter-spacing: 1px;
color: 
#000;
text-transform: uppercase;
}
.pay-heading {
font-family: AvenirNext-Bold,sans-serif;
font-size: 18px;
font-weight: normal;
letter-spacing: 1px;
color: 
#000;
text-transform: uppercase;
}
.inner-table tbody{
width: 100% !important;
display: inline-table !important; 
}

.btn-add .add-user-text img{
 margin-top: -4px;}
  #smartwizard table.invoice-preview-table tbody tr td table.inner-table .font-weight-b{
    font-family: AvenirNext-Bold,sans-serif;
    font-size: 18px;
    font-weight: normal;
    letter-spacing: 1px;
    color: #000;
  }
  #smartwizard .pmprorh_checkbox_label{
    position:relative;
  }
  #smartwizard .pmprorh_checkbox_label .help-block.with-errors{
    position:absolute;
    top:30px;  
  }
  #smartwizard .pmprorh_checkbox_label .help-block.with-errors li{
    margin:0;
  }
  #smartwizard .pmpro_checkout-field .text-center p {
    text-align:left;
    font-size: 18px;
    line-height: 1.56;
    letter-spacing: -0.5px;
    color: #000;
  }
  #smartwizard .pmpro_submit{
    position:relative;
  }
  #smartwizard .pmpro_submit .pmpro_btn-submit-checkout{
    position: absolute;
    bottom: -51px;
    color: #fff !important;
    background-color: #bf3737 !important;
    left: 385px;
  }
  #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom.step-4 {
    margin: 0 auto 0 auto;
  }
  #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom.step-4 .sw-btn-group{left:-130px}
  #smartwizard .btn.btn-secondary.sw-btn-next.disabled {
    display: none;
  }

.left-checkout-section div.AuthorizeNetSeal {
margin: 0 0 20px 0;
}
.incubator-code-section {
margin-bottom: 20px;
}
.incubator-code-section #other_discount_code_p {
padding-top: 20px;
}
#other_discount_code_tr input#other_discount_code {
max-width: 630px !important;
}
#smartwizard .download-link-section p {
font-family: AvenirNext-Regular,sans-serif;
font-size: 18px;
font-weight: normal;
line-height: 1.56;
letter-spacing: -0.5px;
color: #000;
margin-bottom:20px;
}
#smartwizard .download-link-section a.upload_doc_btn {
font-family: AvenirNext-Bold,sans-serif;
font-size: 14px;
font-weight: 400;
font-stretch: normal;
font-style: normal;
line-height: 1.43;
letter-spacing: 1px;
padding: 10px 14px;
border: 1px solid #bf3737;
box-shadow: none;
background-color: #fff!important;
color: #000;
text-transform: uppercase;
}
#smartwizard #ibenic_file_upload_preview.file-upload.file-preview button.ibenic_file_send {
position: absolute;
top: -2px;
left: 300px;
width: 200px;
}
.biling-table tr:last-child {
border-top: 1px solid rgba(134, 134, 134, 0.1) !important;
}
  @media screen and (max-width: 767px){
    #smartwizard.sw-theme-dots > ul.step-anchor:before {
      background-color: #bf3737;
      top: 30px;
      height: 200px;
      left: 42px;
      width: 1px;
    }
    #smartwizard.sw-theme-dots > ul.step-anchor > li{
      width:100%;
      max-width: 100%;
      text-align:left;
    }
    .sw-theme-dots > ul.step-anchor > li > a, .sw-theme-dots > ul.step-anchor > li.active > a {
      text-align: left;
      padding-left: 50px;
      max-height: 40px;
    }
    #smartwizard.sw-theme-dots > ul.step-anchor > li small{
      padding-left:50px;
    }
    #smartwizard.sw-theme-dots > ul.step-anchor > li > a:before, #smartwizard.sw-theme-dots > ul.step-anchor > li:last-child > a:before {
      bottom: 10px;
      left: 14px;
    }
    #smartwizard.sw-theme-dots > ul.step-anchor > li > a:after {
      left: -36px;
      bottom: 25px;
    }

    #smartwizard.sw-theme-dots > ul.step-anchor > li.done > a:after {
      left: -33px;
      bottom: 26px;
    }
    #smartwizard.sw-theme-dots > ul.step-anchor > li:before, #smartwizard.sw-theme-dots > ul.step-anchor > li:after{
      height:0;
    }
    #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom .sw-btn-group .sw-btn-prev, #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom .sw-btn-group .sw-btn-next{
      min-width:120px;
    }
    #smartwizard .pmpro_submit {
      width: 100%;
    }
    #smartwizard .pmpro_submit .pmpro_btn-submit-checkout {
      left: 0;
      right: 0;
      width: auto;
      margin: 0 auto;
      bottom: 10px;
    }
    #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom.step-4 .sw-btn-group {
      left: auto;
    }
    #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom .sw-btn-group .sw-btn-prev, #smartwizard .btn-toolbar.sw-toolbar.sw-toolbar-bottom .sw-btn-group .sw-btn-next {
      padding: 8px 32px;
    }
    form.pmpro_form #smartwizard #step-4 #pmpro_processing_message {
      left:0;
    }
    #smartwizard #ibenic_file_upload_preview.file-upload.file-preview button.ibenic_file_send {
      position: relative;
      top: 0;
      left: 0;
    }
  }</style>
<?php if(is_user_logged_in()) { ?> 
  <?php
  global $gateway, $pmpro_review, $skip_account_fields, $pmpro_paypal_token, $wpdb, $current_user, $pmpro_msg, $pmpro_msgt, $pmpro_requirebilling, $pmpro_level, $pmpro_levels, $tospage, $pmpro_show_discount_code, $pmpro_error_fields;
  global $discount_code, $username, $password, $password2, $bfirstname, $blastname, $baddress1, $baddress2, $bcity, $bstate, $bzipcode, $bcountry, $bphone, $bemail, $bconfirmemail, $CardType, $AccountNumber, $ExpirationMonth,$ExpirationYear;
  global $current_user; // = wp_get_current_user();
  if(!empty($current_user)){
    $cur_id = $current_user->ID;
    $name_on_card = get_user_meta($cur_id,'name_on_card',true);
    if(empty($bfirstname)) {
      $bfirstname = $current_user->user_firstname;
    }
    if(empty($blastname)){
      $blastname = $current_user->user_lastname;
    }

  //if( !empty($blastname)){
    $user_login = $current_user->user_login;
  //}

  if(empty($bemail)){
    $bemail = $current_user->user_email;
  }

  if(empty($bconfirmemail)){
    $bconfirmemail = $current_user->user_email;
  }
  if(empty($username)){
    $username = $current_user->user_login;
  }
  if( !empty($cur_id) ) {
    $subtitle = get_user_meta($cur_id,'subtitle',true);
    $datitle = get_user_meta($cur_id,'datitle',true);
    $business_duns = get_user_meta($cur_id,'business_duns',true);
    $corganization_type = get_user_meta($cur_id,'corganization_type',true);
    $cage_code = get_user_meta($cur_id,'cage_code',true);
    $cnumberofemployees = get_user_meta($cur_id,'cnumberofemployees',true);
    $annual_revenues = get_user_meta($cur_id,'annual_revenues',true);
    $publicly_traded = get_user_meta($cur_id,'publicly_traded',true);
    $ticker_symbol = get_user_meta($cur_id,'ticker_symbol',true);
    $current_technology_expertise = get_user_meta($cur_id,'current_technology_expertise',true);
    $technology_expertise_in_development = get_user_meta($cur_id,'technology_expertise_in_development',true);
    $technology_solutions_services = get_user_meta($cur_id,'technology_solutions_services',true);  
    $products_services_offered = get_user_meta($cur_id,'products_services_offered',true);
    $are_you_start_up = get_user_meta($cur_id,'are_you_start_up',true);
    $is_your_website_live = get_user_meta($cur_id,'is_your_website_live',true);
    $have_you_incorporated = get_user_meta($cur_id,'have_you_incorporated',true);
    $how_are_you_financed = get_user_meta($cur_id,'how_are_you_financed',true);
    $traditional_or_non_traditional_govt_contractor = get_user_meta($cur_id,'traditional_or_non_traditional_govt_contractor',true);
    $call_apply = get_user_meta($cur_id,'call_apply',true);    
    $uploaded_doc_url = get_user_meta($cur_id,'uploaded_doc',true);
    $uploaded_doc_urdl = get_user_meta($cur_id,'uploaded_doc1',true);
    $incorporated_state = get_user_meta($cur_id,'incorporated_state',true);
    $website_live_url = get_user_meta($cur_id,'website_live_url',true);
    $designation = get_user_meta($cur_id,'designation',true);
    $other_designation = get_user_meta($cur_id,'other_designation',true);
    $uploaded_doc_path = get_user_meta($cur_id, "uploaded_doc_path",true);
    $uploaded_doc_url = get_user_meta($cur_id, "uploaded_doc",true);

    $uploaded_comp_url  = get_user_meta($cur_id, "uploaded_comp",true);
    $uploaded_comp_path = get_user_meta($cur_id, "uploaded_comp_path",true); 
    $have_your_company_logo = get_user_meta($cur_id, "have_your_company_logo",true);
    $linkedin_id = get_user_meta($cur_id, "linkedin_id",true);   
  }
}
/**
* Filter to set if PMPro uses email or text as the type for email field inputs.
*
* @since 1.8.4.5
*
* @param bool $use_email_type, true to use email type, false to use text type
*/
$pmpro_email_field_type = apply_filters('pmpro_email_field_type', true);
?>
<script>
  var AjaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
  var DiscountTimeout = '<?php echo apply_filters("pmpro_ajax_timeout", 5000, "applydiscountcode");?>';
</script>
<div id="pmpro_level-<?php echo $pmpro_level->id; ?>">
  <?php if ($discount_code && $pmpro_review) { ?>
    <input class="input <?php echo pmpro_getClassForField("discount_code");?>" id="discount_code" name="discount_code" type="hidden" size="20" value="<?php echo esc_attr($discount_code) ?>" />
    <?php } ?>
    <?php if($pmpro_msg) { ?>
      <div id="pmpro_message" class="pmpro_message <?php echo $pmpro_msgt?>"><?php echo $pmpro_msg?></div>
      <?php } else { ?>
        <div id="pmpro_message" class="pmpro_message" style="display: none;"></div>
        <?php } ?>
        <?php if($pmpro_review) { ?>
          <p><?php _e('Almost done. Review the membership information and pricing below then <strong>click the "Complete Payment" button</strong> to finish your order.', 'paid-memberships-pro' );?></p>
          <?php } ?>

          <form id="pmpro_form" class="pmpro_form" action="<?php if(!empty($_REQUEST['review'])) echo pmpro_url("checkout", "?level=" . $pmpro_level->id); ?>" method="post" data-toggle="validator">

            <input type="hidden" id="level" name="level" value="<?php echo esc_attr($pmpro_level->id) ?>" />
            <input type="hidden" id="checkjavascript" name="checkjavascript" value="1" />

            <div id="pmpro_pricing_fields" class="pmpro_checkout">							
              <div class="pmpro_checkout-fields">
              <?php
                /**
                * All devs to filter the level description at checkout.
                * We also have a function in includes/filters.php that applies the the_content filters to this description.
                * @param string $description The level description.
                * @param object $pmpro_level The PMPro Level object.
                */
                $level_description = apply_filters('pmpro_level_description', $pmpro_level->description, $pmpro_level);
                if(!empty($level_description))
                //echo $level_description;
              ?>

<div id="pmpro_level_cost">
  <?php if($discount_code && pmpro_checkDiscountCode($discount_code)) { ?>
    <?php //printf(__('<p class="pmpro_level_discount_applied">The <strong>%s</strong> code has been applied to your order.</p>', 'paid-memberships-pro' ), $discount_code);?>
    <?php } ?>
    <?php //echo wpautop(pmpro_getLevelCost($pmpro_level)); ?>
    <?php //echo wpautop(pmpro_getLevelExpiration($pmpro_level)); ?>
  </div>

  <?php do_action("pmpro_checkout_after_level_cost"); ?>
</div> <!-- end pmpro_checkout-fields -->
</div> <!-- end pmpro_pricing_fields -->



<?php
do_action('pmpro_checkout_after_pricing_fields');
?>
<?php /* if (is_user_logged_in()) { ?>				
<h3 class="rgs_title"><?php _e('Register Now', 'paid-memberships-pro' );?></h3>
<?php } */ ?>
<div id="smartwizard" class="sw-main sw-theme-dots">
  <ul>
    <li><a href="#step-1">Billing Info<br />&nbsp;</a><small>Your profile and who to bill</small></li>
    <li><a href="#step-2">Company Profile<br />&nbsp;</a><small>About your company</small></li>			
    <li><a href="#step-3">Add Users<br />&nbsp;</a><small>Add your colleagues</small></li>  
    <li><a href="#step-4">Pay<br />&nbsp;</a><small>Last step!</small></li>
  </ul>
      <div>
        <?php include( get_stylesheet_directory().'/paid-memberships-pro/pages/checkout-steps/step-1.php'); ?>
        <?php include( get_stylesheet_directory().'/paid-memberships-pro/pages/checkout-steps/step-2.php'); ?>
        <?php
        do_action('pmpro_checkout_after_user_fields');
        ?>                <div id="step-4">
          <div id="form-step-3" role="form">
            <h3 class="rgs_title">Pay</h3>

          <!--IF having any issue in discount code please copy the checkout box action code from index.php to here-->

<div class="row" id="step4-section-container">
                     <div class="billing-info-container container print-hide">
                        <div><h3>Billing Info <a class="backtostep1" href="#"><img src="/wp-content/themes/onepress-child/images/edit-name-red.svg"> change</a> </h3></div>
                        <div class="row">
                          <div class="col-sm-12 col-md-12 col-lg-12">
                              <p><b>Name</b></p>
                              <?php //echo $bfirstname.' '.$blastname; ?>
                              <p><span class="nbfname"><?php //echo $bfirstname; ?></span>&nbsp;<span class="nblname"><?php //echo $blastname; ?></span></p>
                          </div>
                          <div class="col-sm-12 col-md-12 col-lg-4">
                              <p><b>Phone</b></p>
                              <p><span class="nbphone"><?php //echo $bphone; ?></span></p>
                          </div>
                          <div class="col-sm-12 col-md-12 col-lg-4">
                              <p><b>Email</b></p>
                              <p><span class="nbemail"><?php //echo $bemail; ?></span></p>
                          </div>
                          <div class="col-sm-12 col-md-12 col-lg-4">
                              <p><b>Address</b></p>
                              <p><span class="nbaddress1"><?php //echo $baddress1; ?></span></p>
                              <p><span class="nbaddress2"><?php //echo $baddress2; ?></span></p>
                              <p><span class="nbcity"><?php //echo $bcity; ?></span>, <span class="nbstate"><?php //echo $bstate; ?></span> <span class="nbzipcode"><?php //echo $bzipcode; ?></span></p>    
                              <p><span class="nbcountry"><?php //echo $bcountry; ?></span></p>
                          </div>
                        </div>
                        <div class="billing-change-request-container container text-center print-hide">                                  
                            <?php /* ?><p>Want to change Billing Information <a class="backtostep1" href="#">Click Here</a></p><?php */ ?>
                            <script>jQuery(document).ready( function($){

                              var bfirstname = jQuery('#bfirstname').val();
                              jQuery('.nbfname').html(bfirstname);
                              var blastname = jQuery('#blastname').val();
                              jQuery('.nblname').html(blastname);
                              var bemail = jQuery('#bemail').val();
                              jQuery('.nbemail').html(bemail);
                              var bphone = jQuery('#bphone').val();
                              jQuery('.nbphone').html(bphone);

                              var baddress1 = jQuery('#baddress1').val();
                              jQuery('.nbaddress1').html(baddress1);

                              var baddress2 = jQuery('#baddress2').val();
                              jQuery('.nbaddress2').html(baddress2);

                              var nbcity = jQuery('#bcity').val();
                              jQuery('.nbcity').html(nbcity);

                              var nbstate = jQuery('#bstate').val();
                              jQuery('.nbstate').html(nbstate);

                              var nbzipcode = jQuery('#bzipcode').val();
                              jQuery('.nbzipcode').html(nbzipcode);

                              var nbcountry = jQuery('#bcountry').val();
                              jQuery('.nbcountry').html(nbcountry);

                              jQuery(document).on('click','.backtostep1', function(e){
                                 e.preventDefault();
                                jQuery('#smartwizard ul.nav-tabs li:first-child a').trigger('click');  
                              });                                      
                            });</script>
                        </div>
                      </div>
                          <div class="left-checkout-section col-md-12">
                          <?php
                          do_action('pmpro_checkout_boxes');
                          ?>

                          <?php if(pmpro_getGateway() == "paypal" && empty($pmpro_review) && true == apply_filters('pmpro_include_payment_option_for_paypal', true ) ) { ?>
                            <div id="pmpro_payment_method" class="pmpro_checkout" <?php if(!$pmpro_requirebilling) { ?>style="display: none;"<?php } ?>>

                              <h3>
                                <span class="pmpro_checkout-h3-name"><?php _e('Payment Method', 'paid-memberships-pro' ); ?></span>
                              </h3>
                              <div class="pmpro_checkout-fields">
                                <span class="gateway_paypal">
                                  <input type="radio" name="gateway" value="paypal" <?php if(!$gateway || $gateway == "paypal") { ?>checked="checked"<?php } ?> />
                                  <a href="javascript:void(0);" class="pmpro_radio"><?php  _e('Check Out with a Credit Card Here', 'paid-memberships-pro' );//_e('Check Out with a Credit Card Here', 'paid-memberships-pro' );?></a>
                                  <span class="checkmark"></span>
                                </span>
                                <span class="gateway_paypalexpress">
                                  <input type="radio" name="gateway" value="paypalexpress" <?php if($gateway == "paypalexpress") { ?>checked="checked"<?php } ?> />
                                  <a href="javascript:void(0);" class="pmpro_radio"><?php _e('Check Out with PayPal', 'paid-memberships-pro' );?></a>
                                  <span class="checkmark"></span>
                                </span>
                              </div> <!-- end pmpro_checkout-fields -->
                            </div> <!-- end pmpro_payment_method -->
                            <?php } ?>



                            <?php
                            $pmpro_accepted_credit_cards = pmpro_getOption("accepted_credit_cards");
                            $pmpro_accepted_credit_cards = explode(",", $pmpro_accepted_credit_cards);
                            $pmpro_accepted_credit_cards_string = pmpro_implodeToEnglish($pmpro_accepted_credit_cards);
                            ?>

                            <?php
                            $pmpro_include_payment_information_fields = apply_filters("pmpro_include_payment_information_fields", true);
                            if($pmpro_include_payment_information_fields) { ?>    
                              <h5 class="pay-heading">
                                <span class="pmpro_checkout-h3-name"><?php _e('Payment Information', 'paid-memberships-pro' );?></span>
                                <span class="pmpro_checkout-h3-msg"><?php printf(__('We Accept %s', 'paid-memberships-pro' ), $pmpro_accepted_credit_cards_string);?></span>
                              </h5>
                             
                             <div class="row">
                               <div class="col-sm-12 col-md-2"> 
                                 <div class="AuthorizeNetSeal"> <script type="text/javascript" language="javascript">var ANS_customer_id="6c42e36e-aab6-4999-bca2-a5fb779f1f7a";</script> <script type="text/javascript" language="javascript" src="//verify.authorize.net:443/anetseal/seal.js" ></script>
                                 </div>
                               </div>
                           
                               <div id="pmpro_payment_information_fields" class="pmpro_checkout col-sm-12 col-md-10" <?php if(!$pmpro_requirebilling || apply_filters("pmpro_hide_payment_information_fields", false) ) { ?>style="display: none;"<?php } ?>>

                                <?php $sslseal = pmpro_getOption("sslseal"); ?>
                                <?php if(!empty($sslseal)) { ?>
                                  <div class="pmpro_checkout-fields-display-seal">
                                    <?php } ?>
                                    <div class="pmpro_checkout-field pmpro_payment-name-on-the-card clearfix">
                                       <label for="name_on_card"><?php _e('Name on the Card', 'paid-memberships-pro' );?></label>      
                                      <input id="name_on_card" name="name_on_card" class="input <?php echo pmpro_getClassForField("name_on_card");?>" type="text" size="30" value="<?php //echo esc_attr($AccountNumber); ?>" autocomplete="off" />    
                                     </div>
                                    <div class="pmpro_checkout-fields">
                                      <?php
                                      $pmpro_include_cardtype_field = apply_filters('pmpro_include_cardtype_field', false);
                                      if($pmpro_include_cardtype_field) { ?>
                                        <div class="pmpro_checkout-field pmpro_payment-card-type">
                                          <label for="CardType"><?php _e('Card Type', 'paid-memberships-pro' );?></label>
                                          <select id="CardType" name="CardType" class=" <?php echo pmpro_getClassForField("CardType");?>">
                                            <?php foreach($pmpro_accepted_credit_cards as $cc) { ?>
                                              <option value="<?php echo $cc; ?>" <?php if($CardType == $cc) { ?>selected="selected"<?php } ?>><?php echo $cc; ?></option>
                                              <?php } ?>
                                            </select>                                            
                                          </div>
                                          <?php } else { ?>
                                            <input type="hidden" id="CardType" name="CardType" value="<?php echo esc_attr($CardType);?>" />
                                            <script>
                                              <!--
                                              jQuery(document).ready(function() {
                                                jQuery('#AccountNumber').validateCreditCard(function(result) {
                                                  var cardtypenames = {
                                                    "amex"                      : "American Express",
                                                    "diners_club_carte_blanche" : "Diners Club Carte Blanche",
                                                    "diners_club_international" : "Diners Club International",
                                                    "discover"                  : "Discover",
                                                    "jcb"                       : "JCB",
                                                    "laser"                     : "Laser",
                                                    "maestro"                   : "Maestro",
                                                    "mastercard"                : "Mastercard",
                                                    "visa"                      : "Visa",
                                                    "visa_electron"             : "Visa Electron"
                                                  };

                                                  if(result.card_type)
                                                    jQuery('#CardType').val(cardtypenames[result.card_type.name]);
                                                  else
                                                    jQuery('#CardType').val('Unknown Card Type');
                                                });
                                              });
                                            -->
                                          </script>
                                          <?php } ?>    
                                          <div class="row">
                                          <div class="pmpro_checkout-field pmpro_payment-account-number col-sm-12">
                                             <label for="AccountNumber"><?php _e('Card Number', 'paid-memberships-pro' );?></label>
                                            <input id="AccountNumber" name="AccountNumber" class="input <?php echo pmpro_getClassForField("AccountNumber");?>" type="text" size="30" value="<?php echo esc_attr($AccountNumber); ?>" data-encrypted-name="number" autocomplete="off" />
                                          </div>
                                          <div class="pmpro_checkout-field pmpro_payment-expiration col-sm-12 col-md-6">
                                            <label for="ExpirationMonth"><?php _e('Expiration Date', 'paid-memberships-pro' );?></label>
                                            <select id="ExpirationMonth" name="ExpirationMonth" class=" <?php echo pmpro_getClassForField("ExpirationMonth");?>">
                                              <option value="01" <?php if($ExpirationMonth == "01") { ?>selected="selected"<?php } ?>>01</option>
                                              <option value="02" <?php if($ExpirationMonth == "02") { ?>selected="selected"<?php } ?>>02</option>
                                              <option value="03" <?php if($ExpirationMonth == "03") { ?>selected="selected"<?php } ?>>03</option>
                                              <option value="04" <?php if($ExpirationMonth == "04") { ?>selected="selected"<?php } ?>>04</option>
                                              <option value="05" <?php if($ExpirationMonth == "05") { ?>selected="selected"<?php } ?>>05</option>
                                              <option value="06" <?php if($ExpirationMonth == "06") { ?>selected="selected"<?php } ?>>06</option>
                                              <option value="07" <?php if($ExpirationMonth == "07") { ?>selected="selected"<?php } ?>>07</option>
                                              <option value="08" <?php if($ExpirationMonth == "08") { ?>selected="selected"<?php } ?>>08</option>
                                              <option value="09" <?php if($ExpirationMonth == "09") { ?>selected="selected"<?php } ?>>09</option>
                                              <option value="10" <?php if($ExpirationMonth == "10") { ?>selected="selected"<?php } ?>>10</option>
                                              <option value="11" <?php if($ExpirationMonth == "11") { ?>selected="selected"<?php } ?>>11</option>
                                              <option value="12" <?php if($ExpirationMonth == "12") { ?>selected="selected"<?php } ?>>12</option>
                                            </select>/<select id="ExpirationYear" name="ExpirationYear" class=" <?php echo pmpro_getClassForField("ExpirationYear");?>">
                                            <?php
                                            for($i = date_i18n("Y"); $i < intval( date_i18n("Y") ) + 10; $i++)
                                            {
                                              ?>
                                              <option value="<?php echo $i?>" <?php if($ExpirationYear == $i) { ?>selected="selected"<?php } ?>><?php echo $i?></option>
                                              <?php
                                            }
                                            ?>
                                          </select>                                          
                                        </div>
                                        <?php
                                        $pmpro_show_cvv = apply_filters("pmpro_show_cvv", true);
                                        if($pmpro_show_cvv) { ?>
                                          <div class="pmpro_checkout-field pmpro_payment-cvv col-sm-12 col-md-6">
                                            <label for="CVV"><?php _e('Security Code (CVC)', 'paid-memberships-pro' );?></label> 
                                            <input id="CVV" name="CVV" type="password" size="4" value="<?php if(!empty($_REQUEST['CVV'])) { echo esc_attr($_REQUEST['CVV']); }?>" class="input <?php echo pmpro_getClassForField("CVV");?>" />
                                           <small>(<a href="javascript:void(0);" onclick="javascript:window.open('<?php echo pmpro_https_filter(PMPRO_URL); ?>/pages/popup-cvv.html','cvv','toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=600, height=475');"><?php _e("what's this?", 'paid-memberships-pro' );?></a>)</small>
                                          </div>
                                          <?php } ?>
                                    </div>     
                                          <?php $off = 0; if($pmpro_show_discount_code && $_REQUEST['level'] == 1 && $off == 1 ) { ?>
                                            <div class="pmpro_checkout-field pmpro_payment-discount-code">
                                            <label for="discount_code"><?php _e('Incubator Code', 'paid-memberships-pro' );?></label>
                                            <input class="input <?php echo pmpro_getClassForField("discount_code");?>" id="discount_code" name="discount_code" type="text" size="10" value="<?php echo esc_attr($discount_code); ?>" />
                                            <input type="button" id="discount_code_button" name="discount_code_button" value="<?php _e('Apply', 'paid-memberships-pro' );?>" />
                                              <p id="discount_code_message" class="pmpro_message" style="display: none;"></p>
                                            </div>
                                            <?php } ?>
                                          </div> <!-- end pmpro_checkout-fields -->
                                          <?php if(!empty($sslseal)) { ?>
                                            <div class="pmpro_checkout-fields-rightcol pmpro_sslseal"><?php echo stripslashes($sslseal); ?></div>
                                          </div> <!-- end pmpro_checkout-fields-display-seal -->
                                          <?php } ?>                               
                                        </div> <!-- end pmpro_payment_information_fields -->
                         
                                        
                                        
                                        <?php } ?>
                                        <script>
                                          <!--
                                          //checking a discount code
                                          jQuery('#discount_code_button').click(function() {
                                            var code = jQuery('#discount_code').val();
                                            var level_id = jQuery('#level').val();

                                            if(code)
                                            {
                                              //hide any previous message
                                              jQuery('.pmpro_discount_code_msg').hide();

                                              //disable the apply button
                                              jQuery('#discount_code_button').attr('disabled', 'disabled');

                                              jQuery.ajax({
                                                url: AjaxUrl,type:'GET',timeout: DiscountTimeout,
                                                dataType: 'html',
                                                data: "action=applydiscountcode&code=" + code + "&level=" + level_id + "&msgfield=discount_code_message",
                                                error: function(xml){
                                                  alert('Error applying discount code [1]');

                                                  //enable apply button
                                                  jQuery('#discount_code_button').removeAttr('disabled');
                                                },
                                                success: function(responseHTML){
                                                  if (responseHTML == 'error')
                                                  {
                                                    alert('Error applying Incubator code [2]');
                                                  }
                                                  else
                                                  {
                                                    jQuery('#discount_code_message').html(responseHTML);
                                                  }

                                                  //enable invite button
                                                  jQuery('#discount_code_button').removeAttr('disabled');
                                                }
                                              });
                                            }
                                          });
                                        </script>

                                        <?php do_action('pmpro_checkout_after_payment_information_fields'); ?>
</div>
                                        <?php if($tospage && !$pmpro_review) { ?>
                                          <div id="pmpro_tos_fields" class="pmpro_checkout">

                                            <h3>
                                              <span class="pmpro_checkout-h3-name"><?php echo $tospage->post_title?></span>
                                            </h3>
                                            <div class="pmpro_checkout-fields">
                                              <div id="pmpro_license" class="pmpro_checkout-field">
                                                <?php echo wpautop(do_shortcode($tospage->post_content));?>
                                              </div> <!-- end pmpro_license -->
                                              <input type="checkbox" name="tos" value="1" id="tos" /> <label class="pmpro_label-inline pmpro_clickable" for="tos"><?php printf(__('I agree to the %s', 'paid-memberships-pro' ), $tospage->post_title);?></label>
                                            </div> <!-- end pmpro_checkout-fields -->
                                          </div> <!-- end pmpro_tos_fields -->
                                          <?php
                                        }
                                        ?>
                                        </div>                               
                       <div class="right-checkout-section col-md-12">
                       <div class="commonly_requested_corporate_info clearfix"> 
                          <hr>
                        <h4 <?php /* ?>class="crci"<?php */ ?>>Commonly Requested Corporate Information <?php /* ?> <img src="/wp-content/themes/polar/assets/images/infobutton.png" width="25px" height="25px"> <?php */ ?></h4> 
                        <div class="row download-link-section">
                          <div class="col-sm-12 col-md-6"> 
                            <a class="download-form-link" href="<?php echo content_url(); ?>/uploads/2018/08/nstxl-w9.pdf" target="_blank"><?php /* ?><i class="fa fa-file-pdf-o" aria-hidden="true"></i><?php */ ?>W9 form</a>
                          </div>
                          <div class="col-sm-12 col-md-6"> 
                            <a class="download-form-link" href="<?php echo content_url(); ?>/uploads/2019/01/corporate-information.pdf" target="_blank"><?php /* ?><i class="fa fa-file-pdf-o" aria-hidden="true"></i><?php */ ?>Corporate information</a>
                          </div>    
                          <div class="col-sm-12"> 
                            <p>Submit a form for us to fill out</p>
                            <a class="upload_doc_btn" href="#"<?php if(!empty($uploaded_doc_url)){ echo "style='display:none'";  } ?> ><img src="/wp-content/themes/onepress-child/images/attach.svg">&nbsp;Attach</a>
                              <?php /* ?><div class="polar_column_text polar-content-element upload_doc_section hidden"><input id="upload_doc_file" name="upload_doc_file" type="file"></div><?php */ ?>
                              <div class="ibenic_upload_message"></div>
                              <div id="ibenic_file_upload" class="file-upload"  style="display:none;">
                                <?php /* ?><input type="file" id="ibenic_file_input" style="opacity:0;" /> <?php */ ?>
                                <input id="upload_doc_file" <?php if(!empty($uploaded_doc_url)){ echo "disabled";  } ?> name="upload_doc_file" type="file" style="opacity:0;" style="display:none;">
                                <p class="ibenic_file_upload_text"><?php //_e( 'Upload your file', 'paid-memberships-pro' ); ?></p>
                              </div>

                              <div id="ibenic_file_upload_preview" class="file-upload file-preview" <?php if(empty($uploaded_doc_url)){ echo 'style="display:none"'; } ?> >
                                <div class="ibenic_file_preview"><?php if(!empty($uploaded_doc_url)){ echo basename($uploaded_doc_url); } ?></div>
                                <button data-fileurl="<?php if(!empty($uploaded_doc_url)){ echo $uploaded_doc_url; } ?>" class="ibenic_file_delete btn btn-secondary">
                                  <i class="fa fa-trash"></i><?php //_e( 'Delete', 'paid-memberships-pro' ); ?>
                                </button> 
                                <?php $is_send_to_nstxl = get_user_meta($current_user->ID,'send-to-nstxl',true);              
                                if($is_send_to_nstxl !='1') { ?>
                                  <button data-fileurl="<?php if(!empty($uploaded_doc_url)){ echo $uploaded_doc_url; } ?>" class="ibenic_file_send btn btn-txt mt-1 mb-1">
                                    <?php _e( 'Send to NSTXL', 'paid-memberships-pro' ); ?>
                                  </button>
                                  <?php } ?>            
                                </div>
                              </div>
                            </div>
                        <?php /* ?>
                            <!-- Modal -->
                            <div class="modal fade" id="send-to-nstxl-modal" tabindex="-1" role="dialog" aria-labelledby="send-to-nstxlLabel" aria-hidden="true">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-body">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>           
                                    <div class="org-inner-content">
                                      <p>Your document has been sent. We’ll fill it out within the next 2 days. Once it is completed, you’ll receive an email to continue with the registration process and can download the document from this site.</p>
                                    </div>
                                  </div>
                                </div>
                                <!-- /.modal-content -->
                              </div>
                              <!-- /.modal-dialog -->
                            </div>
                            <!-- /.modal -->
                        <?php */ ?>  
                          <?php
                          //Modal box for send to nstxl
                          $send_to_nstxl_modal_id = 'send-to-nstxl-modal';
                          $send_to_nstxl_modal_body_container_class = 'send-to-nstxl-modal-container org-inner-content';
                          $send_to_nstxl_content_html = '<h4>Your document has been sent. We’ll fill it out within the next 2 days. Once it is completed, you’ll receive an email to continue with the registration process and can download the document from this site.</h4>';
                          nstxl_modal_popup($send_to_nstxl_content_html, $send_to_nstxl_modal_id, $send_to_nstxl_modal_body_container_class);
                          ?>
                          </div>                                             
                          <?php //include_once('invoicepreviewtable.php'); 
                          //include_once('invoicepreviewtable-withoutlogo.php'); 
                          include_once('invoicepreviewtable-withoutlogo-withoutprint.php');
                          ?>
                         </div>
                         <div class="clear"></div>
                                        <?php do_action("pmpro_checkout_after_tos_fields"); ?>

                                        <?php do_action("pmpro_checkout_before_submit_button"); ?>
                                          <div id="accept_policy_div" class="pmpro_checkout-field col-md-12  form-group required">
                                            <hr>
                                            <div class="leftmar">
                                              <label class="pmprorh_checkbox_label" for="accept_policy"><input name="accept_policy" value="1" id="accept_policy" checked="checked" required="" type="checkbox">Accept our Principles of Engagement&nbsp; <a href="<?php echo site_url(); ?>/wp-content/uploads/2019/01/NSTXL-Principles-of-Engagement-Sept-2018.pdf" target="_blank">(Click to Read)</a></label> &nbsp; 
                                            </div>
                                          <div class="text-center print-hide"><p>* No refunds or cancellations will be granted for any reason.</p></div>
                                          </div>  
                         <input name="accept_policy_checkbox" value="1" required="" type="hidden">
                                        <div class="pmpro_submit">

                                          <?php if($pmpro_review) { ?>

                                            <span id="pmpro_submit_span">
                                              <input type="hidden" name="confirm" value="1" />
                                              <input type="hidden" name="token" value="<?php echo esc_attr($pmpro_paypal_token); ?>" />
                                              <input type="hidden" name="gateway" value="<?php echo esc_attr($gateway); ?>" />
                                              <input type="submit" class="pmpro_btn pmpro_btn-submit-checkout" value="<?php _e('Complete Payment', 'paid-memberships-pro' );?> &raquo;" />
                                            </span>

                                            <?php } else { ?>

                                              <?php
                                              $pmpro_checkout_default_submit_button = apply_filters('pmpro_checkout_default_submit_button', true);
                                              if($pmpro_checkout_default_submit_button)
                                              {
                                                ?>
                                                <span id="pmpro_submit_span">
                                                  <input type="hidden" name="submit-checkout" value="1" />
                                                  <input type="submit" class="pmpro_btn pmpro_btn-submit-checkout" value="<?php if($pmpro_requirebilling) { _e('Submit Application', 'paid-memberships-pro' ); } else { _e('Submit and Confirm', 'paid-memberships-pro' );}?>" />
                                                </span>
                                                <?php
                                              }
                                              ?>

                                              <?php } ?>

                                              <span id="pmpro_processing_message" style="visibility: hidden;">
                                                <?php
                                                $processing_message = apply_filters("pmpro_processing_message", __("Processing", 'paid-memberships-pro' ));
                                                echo '<img src="'.nstxl_extention_url.'/images/submit.gif">&nbsp;'.$processing_message;
                                                ?>
                                              </span>
                                            </div>
                                          </div>
                                        </div>             
                                          </div>
                                        </div>             
                                      </div><!-- End of smart widgetdiv-->            
                                    </form>
                                    <div class="next-step-loader"><img src="<?php echo nstxl_extention_url; ?>/images/form-step.gif"></div>
                                    <?php do_action('pmpro_checkout_after_form'); ?>

                                  </div> <!-- end pmpro_level-ID -->

                                  <script>
                                    jQuery('form').submit(function(){
                                      //On submit disable its submit button
                                      jQuery('input[type=submit]', this).attr('disabled', 'disabled');
                                      jQuery('input[type=image]', this).attr('disabled', 'disabled');
                                      //jQuery('#pmpro_processing_message').css('visibility', 'visible');
                                      jQuery('.nstxl-loader').show();
                                      jQuery('.loader-overlay').show();
                                    });
                                                                          <!--
                                      // Find ALL <form> tags on your page
                                      //jQuery('form').submit(function(){
                                      // On submit disable its submit button
                                      //jQuery('input[type=submit]', this).attr('disabled', 'disabled');
                                      //jQuery('input[type=image]', this).attr('disabled', 'disabled');
                                      //jQuery('#pmpro_processing_message').css('visibility', 'visible');
                                      //});

                                      //iOS Safari fix (see: http://stackoverflow.com/questions/20210093/stop-safari-on-ios7-prompting-to-save-card-data)
                                    var userAgent = window.navigator.userAgent;
                                    if(userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)) {
                                      jQuery('input[type=submit]').click(function() {
                                        try{
                                          jQuery("input[type=password]").attr("type", "hidden");
                                        } catch(ex){
                                          try {
                                            jQuery("input[type=password]").prop("type", "hidden");
                                          } catch(ex) {}
                                        }
                                      });
                                    }

                                    //add required to required fields
                                    jQuery('.pmpro_required').after('<span class="pmpro_asterisk"> <abbr title="Required Field">*</abbr></span>');

                                    //unhighlight error fields when the user edits them
                                    jQuery('.pmpro_error').bind("change keyup input", function() {
                                      jQuery(this).removeClass('pmpro_error');
                                    });

                                    //click apply button on enter in discount code box
                                    jQuery('#discount_code').keydown(function (e){
                                      if(e.keyCode == 13){
                                        e.preventDefault();
                                        jQuery('#discount_code_button').click();
                                      }
                                    });
                                  </script>
                                  <?php if(!empty($_REQUEST['discount_code'])) { ?>
                                    <script>
                                     //hide apply button if a discount code was passed in                        
                                      jQuery('#discount_code_button').hide();
                                      jQuery('#discount_code').bind('change keyup', function() {
                                        jQuery('#discount_code_button').show();
                                      });                          
                                    </script>
                                    <?php } ?>
                                    <script>
                                      //click apply button on enter in *other* discount code box
                                      jQuery('#other_discount_code').keydown(function (e){
                                        if(e.keyCode == 13){
                                          e.preventDefault();
                                          jQuery('#other_discount_code_button').click();
                                        }
                                      });
                                    </script>
                                    <script>
                                      <!--
                                      //add javascriptok hidden field to checkout
                                      jQuery("input[name=submit-checkout]").after('<input type="hidden" name="javascriptok" value="1" />');
                                    -->
                                  </script>

                                  <?php  if(is_page(1989)){ ?>
                                    <script>
                                      var pmpro_level_id = '<?php echo $pmpro_level->id; ?>';
                                    </script>
                                    <script>
                                      jQuery(document).on("DOMNodeInserted",function(e) { 
                                        jQuery('.poc').on('change', function() {
                                          jQuery('.poc').not(this).prop('checked', false);
                                        });
                                      }); 

                                      jQuery('.poc').on('change', function() {
                                        jQuery('.poc').not(this).prop('checked', false);
                                        var checked_closest_elm = jQuery(this).closest("div.item");
                                        var lfirstname_checked  = checked_closest_elm.find("input.lfirstname").val();
                                        var llastname_checked  = checked_closest_elm.find("input.llastname").val();
                                        var lemail_checked  = checked_closest_elm.find("input.lemail").val();
                                        var llinkedin_id_checked  = checked_closest_elm.find("input.llinkedin_id").val();    
                                        jQuery('.invc-prev-name').text(lfirstname_checked+' '+llastname_checked);
                                        jQuery('.invc-prev-email').text(lemail_checked);
                                      });
                                      jQuery(document).one("DOMNodeInserted",function(e) {    
                                        if(jQuery('#call_apply').find(':selected').val() == null || jQuery('#call_apply').val() == null){
                                          jQuery('#call_apply').trigger('change');
                                        }

                                        if(jQuery('#primary_application').find(':selected').val() == null || jQuery('#primary_application').val() == null){
                                          jQuery('#primary_application').trigger('change');
                                        }

                                        if(jQuery('#primary_domain_interest').find(':selected').val() == null || jQuery('#primary_domain_interest').val() == null){
                                          jQuery('#primary_domain_interest').trigger('change');
                                        }
                                        // if(jQuery('#corganization_type').data('levelID') == 'pmpro_level_id') {
                                        //   jQuery('#corganization_type').prop('selected',true);
                                        // }
                                        // if(jQuery('#primary_application').val() == null){
                                        //    jQuery('#primary_application').val('');
                                        //    return false;
                                        //    //jQuery('#primary_application').trigger('change');
                                        //  }
                                        //  if(jQuery('#primary_domain_interest').val() == null){
                                        //    jQuery('#primary_domain_interest').val('');
                                        //    return false;
                                        //    //jQuery('#primary_domain_interest').trigger('change');
                                        //  }

                                        jQuery("#corganization_type option[data-levelid='" + pmpro_level_id + "']").prop("selected", true);

                                        var str = jQuery('#corganization_type').find(":selected").val().toLowerCase();
                                        var res = str.match(/non-corporate:/g);
                                        if (!res) {
                                          var res1 = str.match(/non-profit:/g);
                                          if (!res1) {
                                            jQuery('.organization_type_toggle').show();   
                                            jQuery('#call_apply').prop('required',true);         
                                            jQuery('#call_apply').attr('required','required');
                                            if(jQuery('#call_apply').val() == null){
                                              jQuery('#call_apply').trigger('change');
                                            }
                                          } else {
                                            jQuery('.organization_type_toggle').hide();
                                            jQuery('#call_apply').prop('required',false);
                                          }
                                        } else {
                                          jQuery('.organization_type_toggle').hide();
                                          jQuery('#call_apply').prop('required',false);
                                          if(jQuery('#call_apply').val() == null){
                                            jQuery('#call_apply').trigger('change');
                                          }
                                        }
                                        if(jQuery('.organization_type_toggle').css('display') == 'none') {
                                          jQuery('#call_apply').prop('required',false);
                                        } else {
                                          jQuery('#call_apply').prop('required',true);        
                                          if(jQuery('#call_apply').val() == null){
                                            jQuery('#call_apply').trigger('change');
                                          }
                                        }
                                        // jQuery('.poc').on('change', function() { jQuery('.poc').not(this).prop('checked', false);
                                        // });
                                      });
</script>
<?php }  ?>
<script type="text/javascript">
  jQuery(document).ready(function($){ 
    $('.pmpro_asterisk').remove();
    $("div.profile-pic").click(function () {
      $("#user_pic").click();
    });

    jQuery('#smartwizard .form-group.required').each( function(){
      
      jQuery(this).find('input').prop('required',true);
      jQuery(this).find('select').prop('required',true);
      if(jQuery(this).find('input').next('.help-block').length == 0) {
        jQuery(this).find('input').after('<div class="help-block with-errors"></div>');
      }
      if(jQuery(this).find('select').next('.help-block').length == 0) {
        jQuery(this).find('select').after('<div class="help-block with-errors"></div>');
      }
      
    }); 
    $.validator.addMethod("needsSelection", function (value, element) {
      var count = $(element).find('option:selected').length;
      return count > 0;
    });

    if(jQuery('.repeater-first-section .lfirstname').val() == ''){
      jQuery('.repeater-first-section .lfirstname').val(jQuery('#bfirstname').val());
    }
    if(jQuery('.repeater-first-section .llastname').val() == ''){
      jQuery('.repeater-first-section .llastname').val(jQuery('#blastname').val());
    }
    if(jQuery('.repeater-first-section .lemail').val() == ''){
      jQuery('.repeater-first-section .lemail').val(jQuery('#bemail').val());
    }
    if(jQuery('.repeater-first-section .llinkedin_id').val() == ''){
      jQuery('.repeater-first-section .llinkedin_id').val(jQuery('#linkedin_id').val());
    }
  });
</script>
<style>
@media print{
  .paying-by-ach table thead td{
    border: none !important;
  }
}
  a#cmd{
    padding: 16px 23px;
    font-size: 18px;
    font-family: 'robotomedium';
    margin-right: 30px;
    text-transform: uppercase;
    background-color: #dc323e;
    color: #fff;
    font-size: 14px;
    transition: all 0.2s;
    border-color: #e35e67;
    border-radius: 5px !important;
  }
  .printpdf {
    margin: 0 auto;
  }
</style>
<script type="text/javascript"> 
  function printDiv(divName){      
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
  }


  jQuery('#cmd').click(function (e) {
    e.preventDefault(); 
    var element = document.getElementById('invoice-preview-table');
    var opt = { margin: 0, filename: 'invoice-preview.pdf', image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2 },
    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' } };
    html2pdf().from(element).set(opt).save();    
  });

    jQuery('.print-ach-invoice').click(function (e) {
    e.preventDefault(); 
    var element = document.getElementById('ach-invoice-table');
    var opt = { margin: 0.5, filename: 'ach-invoice-preview.pdf', image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2 },
    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' } };
    html2pdf().from(element).set(opt).save();    
  });
</script> 
<?php }
