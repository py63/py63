<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>	<!-- wrapper end -->
	<section id="footer" class="footer sticky-footers">
	    <div class="container-fluid custom_container">
	      <div class="row">
	        <div  class="col-sm-6 col-xs-12 align-middle">
	          <p class="para">Copyright ©<?php echo date('Y'); ?> safestan.com  All rights reserved.</p>
	        </div>
	        <div  class="col-sm-6 text-adjust col-xs-12 align-middle"> <span class="para">Website developed by</span>&nbsp;&nbsp;&nbsp;<a href="http://galaxyweblinks.com" target="_blank"> <img src="<?php bloginfo('template_directory');?>/images/footer-logo.png" class="" alt=""/></a> </div>
	      </div>
	    </div>
	  </section>	
	</section>


<?php wp_footer(); ?>
<script src="<?php bloginfo('template_directory')?>/js/bootstrap.min.js"></script>
<!-- <script src="https://www.google.com/recaptcha/api.js" async defer></script> -->
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('.custom-logo-link').addClass('navbar-brand');
		jQuery('.custom-logo-link img').addClass('img-responsive logo');
		jQuery('.current-menu-item a').addClass('selected');
		jQuery('.form1 textarea').attr('rows', 6);		
		
	});
	// for google captcha on review form
		/*jQuery('#submitReview').live('click',function(e){
			var response = grecaptcha.getResponse();
			var errorcls = jQuery( ".form-err" ).hasClass( "shown" );
			//alert(response);
			if(response.length == 0){
				jQuery('.cptcha-saftn').css('display','block');
				e.preventDefault();}			
			else if(response.length == 0 && errorcls == true ){				
				e.preventDefault();
			}
			else{
				return;
			}			
		});*/
</script>
</body>
</html>