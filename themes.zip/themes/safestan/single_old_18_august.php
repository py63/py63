<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); 

?>
<?php
$post_ID = get_the_ID();
// Start the loop.
while ( have_posts() ) : the_post();?>
<section class="property-review">
	<div class="container">
	    <div class="search">
            <div class="row">
                <div class="col-sm-5  col-md-4 align-center">
                    <?php 
                        $imageSliders = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id= ".$post_ID." AND status = 1 GROUP by image_id DESC LIMIT 0,10");
                        //echo '<pre>';print_r($imageSliders);die;
                    ?>
            	    <div class="search-result pos-rel">
                        <div class="reviewgallery">
                            <?php
                            //Property Gallery 
                            //echo $post_id = get_the_ID();
                            //$fields = CFS()->get( '_propery_gallery' );                            
                            //$fields = CFS()->get('_propery_gallery');
                            //echo '<pre>';print_r($fields);
                            if($imageSliders > 0 && !empty($imageSliders))
                            {
                                foreach ( $imageSliders as $imageSlider )
                                {
                                    //$thumb_path = $field['_upload_gallery_image'];
                                    ?>
                                    <div class="reviewgallery_inner">
                                        <img src="<?php echo $imageSlider->image_path;?>" class="img-responsive" alt=""/>
                                        <div class="img-overlay">&nbsp;</div>
                                        <div class="search-icon">
                                        	<a href="<?php echo $imageSlider->image_path;?>">
                                                <img src="<?php bloginfo('template_directory');?>/images/search-icon.png" width="20" height="20" alt=""/>
                                            </a>
                                        </div>
                                    </div>
                                    <?php
                                }
                            }
                            else
                            {
                                
                                /*echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found.jpg" class="img-responsive feature-img" alt=""/>';*/

                                if(CFS()->get('_property_address',$myrow->ID))
                                  {
                                      $property_address = CFS()->get('_property_address', $myrow->ID);
                                  }
                                  if(CFS()->get('_property_city', $myrow->ID))
                                  {
                                      $property_city = CFS()->get('_property_city', $myrow->ID);
                                  }
                                  if(CFS()->get('_property_state', $myrow->ID))
                                  {
                                      $property_state = CFS()->get('_property_state', $myrow->ID);
                                  }
                                  if(CFS()->get('_property_zip_code', $myrow->ID))
                                  {
                                      $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
                                  }
                                
              $property_fulladdr = array('property_address' => urlencode($property_address),
                                'property_city' => urlencode($property_city),
                                'property_state' => urlencode($property_state),
                                '_property_zip_code' => urlencode($property_zip_code)
                                );
                                //print_r($property_fulladdr);
                               $op = '<div class="google-map-embed">';
                               $op .= '<iframe width="470" height="275" frameborder="0" style="border:0" allowfullscreen ';
                               $op .= 'src="https://www.google.com/maps/embed/v1/place?q=';
                               $op .= implode(',', $property_fulladdr);
                               $op .= '&key=AIzaSyCUpXt8H-Wd6-_SHbSmnYwdBPXLDQD-gc0';  
                               $op .= '&zoom=11"></iframe></div>';

                               print $op;
                            }
                            ?>
                        </div>

                        <div class="clearfix"></div>
                        <script src="<?php bloginfo('template_directory');?>/script-upload.js"></script>
                        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory');?>/style-upload.css">
                    </div>
                </div>
                <div class="col-sm-7  col-md-8 align-center">
               	    <div class="details">
                        <div class="property-heading">
                            <h3  class="heading3"><?php the_title();?></h3> 
                            <div class="review">
                                <?php 
                                    //echo do_shortcode('[RICH_REVIEWS_SNIPPET stars_only="true"]');
                                    echo do_shortcode('[RICH_REVIEWS_SNIPPET category="post" id="'.$post_ID.'" stars_only="true"]');
                                ?>

                                <!-- <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/> 
                                <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png"   alt=""/>
                                <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png"  alt=""/>
                                <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png"  alt=""/>
                                <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/> -->
                            </div>  
                        </div>
                        <div class="media">
                            <div class="media-left">
                                <img src="<?php bloginfo('template_directory');?>/images/map-icon.png" width="15" height="24" alt="" class="media-object"/>
                            </div>
                            <div class="media-body">
                                    <div class="media-heading">
                                        <?php
                                            if(CFS()->get('_property_address'))
                                            {
                                                $property_address = CFS()->get('_property_address');
                                            }
                                            if(CFS()->get('_property_city'))
                                            {
                                                $property_city = CFS()->get('_property_city');
                                            }
                                            if(CFS()->get('_property_state'))
                                            {
                                                $property_state = CFS()->get('_property_state');
                                            }
                                            if(CFS()->get('_property_zip_code'))
                                            {
                                                $property_zip_code = CFS()->get('_property_zip_code');

                                                $numlength = strlen((string)$property_zip_code);
                                                if($numlength == 1)
                                                {
                                                    $property_zip_code = '0000'.$property_zip_code;         
                                                }
                                                elseif ($numlength == 2) {
                                                    $property_zip_code = '000'.$property_zip_code;
                                                }
                                                elseif ($numlength == 3) {
                                                    $property_zip_code = '00'.$property_zip_code;
                                                }
                                                elseif ($numlength == 4) {
                                                    $property_zip_code = '0'.$property_zip_code;
                                                }
                                                else {
                                                    $property_zip_code = $property_zip_code;
                                                }
                                            }
                                        ?>
                                        <p class="para2"> 
                                            <?php 
                                            echo $property_address.', '.$property_city.', '.$property_state.' '.$property_zip_code;
                                            ?>
                                        </p>
                                    </div>
                            </div>
                        </div>
                        <div class="more-images">
                            <div id="reivew_gallery_thumb">
                                <?php
                                //$fields_thumbs = CFS()->get('_propery_gallery');                            
                                if($imageSliders > 0)
                                {   $count = 0;
                                    foreach ( $imageSliders as $imageSlider ) {
                                        //$thumb_path = $fields_thumb['_upload_gallery_image'];
                                        echo '<a data-slide-index="'.$count.'" href="">';
                                        echo '<img src="'.$imageSlider->image_path.'" class="img-responsive" alt=""/>';
                                        echo '</a>';
                                        $count++;
                                    }
                                }
                                else
                                {
                                    echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found2.jpg" class="img-responsive feature-img" alt=""/>';
                                }   ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="about-review">
            <div class="row">
                <div class="col-sm-9">
                    <?php
                    if(is_user_logged_in())
                    {
                        global $current_user, $wpdb;
                        get_currentuserinfo();
                        //echo '<pre>'; print_r($current_user);die;
                        $user_name = $current_user->display_name;
                        $user_roles = $current_user->roles;
                        $user_role = array_shift($user_roles);
                        if($user_role == 'subscriber' || $user_role == 'administrator')
                        {   ?>
                            <h3 class="heading3">Add Photo - A picture tells a thousand words</h3>
                            <p class="para1">
                                Only JPEG, PNG, JPG Type Image Uploaded. Image Size Should Be Less Than 20MB.  
                            </p>
                            <?php 
                        }
                    }   ?>
                </div>
                <div class="col-sm-3">
                    <?php dynamic_sidebar('find-a-layer');?>
                </div>
            </div>
            <?php 
            /*-------Image Upload Section----------*/
            if(is_user_logged_in())
            {
                global $current_user, $wpdb;
                get_currentuserinfo();
                //echo '<pre>'; print_r($current_user);die;
                $user_name = $current_user->display_name;
                $user_roles = $current_user->roles;
                $user_role = array_shift($user_roles);
                
                if($user_role == 'subscriber' || $user_role == 'administrator')
                {   
                    $upload_dir = wp_upload_dir();
                    $up_Path =  $upload_dir['basedir'].'/front-slider-image/';
                    ?>                   

                    <div class="form-image-upload">
                        <form enctype="multipart/form-data" action="" method="post" role="form" class="form-uploadfile"> 
                            <div class="row">
                                <div class="col-sm-5 col-md-3 col-lg-3 col-xs-12 ">
                                    <div id="filediv" class="multifile">
                                        <input name="file[]" type="file" id="file" imgid="previewimg1" multiple="multiple"/>
                                    </div>
                                </div>
                                 <div class="col-sm-7 col-md-6 col-lg-6 col-xs-12 ">         
                                   <!--  <input type="button" id="add_more"  id="" value="+ Add More Files" class="common-btn"> -->
                                    <input type="submit"  name="submit" id="upload"  value="Upload Files" class="common-btn">
                                </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="upload-images"></div>
                                </div>
                            </div>
                            </div>
                        </form>
                    </div>
                    <!--Including PHP Script here-->
                    <?php
                    //echo 20*pow(1024,2);
                    $post_id = $post_ID;
                    $user_id = $current_user->ID;
                    //$image_path = $new_imgpath;
                    $status = 0;
                    $image_featured_status = 0;
                    $date = date('Y-m-d H:i:s');

                    if (isset($_POST['submit']) && !empty($_POST['submit'])) 
                    {

                        $j = 0; //Variable for indexing uploaded image 

                        /*echo "count file: ".count($_FILES['file']['name']);
                        die("test");*/
                        for ($i = 0; $i < count($_FILES['file']['name']); $i++) 
                        {   //loop to get individual element from the array

                            $validextensions = array("jpeg", "jpg", "png");  //Extensions which are allowed
                            $ext = explode('.', basename($_FILES['file']['name'][$i]));//explode file name from dot(.) 
                            //$target_path ='';

                            $file_extension = end($ext); //store extensions in the variable

                            $imgpath = site_url().'/wp-content/uploads/front-slider-image/';
                            
                            $target_path = $up_Path . $ext[0].rand() . "." . $ext[count($ext) - 1];//set the target path with a new name of image
                            //echo $target_path;
                            $j = $j + 1;//increment the number of uploaded images according to the files in array       
                          
                            if (($_FILES["file"]["size"][$i] < 20971520) //Approx. 20Mb files can be uploaded.
                                    && in_array($file_extension, $validextensions)) 
                            {
                                if (move_uploaded_file($_FILES['file']['tmp_name'][$i], $target_path)) 
                                {   //if file moved to uploads folder

                                    chmod($target_path, 0777);
                                    $imgpath_orig = end(explode('/', $target_path));

                                    //$imgName     =  explode('.',$imgpath_orig,-1);
                                    $imgName     = $imgpath_orig;
                                    $new_imgpath =  $imgpath.$imgpath_orig;

                                    $image_path = $new_imgpath;  

                                    $tableName = $wpdb->prefix.'post_slider_image';

                                    $insert = $wpdb->query("
                                        INSERT INTO $tableName (post_id, user_id, user_name, image_path, image_name, date, status, image_featured_status) VALUES ('$post_id','$user_id', '$user_name', '$image_path','$imgName' ,'$date','$status',$image_featured_status)
                                        ");


                                    /*echo $wpdb->last_query;
                                    die;*/
                                    /*echo '<span id="noerror">Image uploaded successfully!.</span><br/>';*/
                                    //echo '<img src="'.$new_imgpath.'" alt="" /><br>';
                                    
                                } 
                                else 
                                {   //if file was not moved.
                                    echo '<span id="error">please try again!.</span><br/><br/>';
                                }
                                $target_path ='';

                            } 
                            else
                            {   //if file size and file type was incorrect.
                                if($file_extension != null){
                                    echo '<span id="error">***Invalid file Size or Type***</span><br/>';
                                }
                            }
                            $ico = $i+1;
                            if($ico == count($_FILES['file']['name'])){
                                if( count($_FILES['file']['name']) == 1 ){
                                    echo '<span id="noerror"><h4>Thanks, your image has been uploaded successfully and waiting for review.</h4></span>';
                                }
                                else{
                                    echo '<span id="noerror"><h4>Thanks, your image have been uploaded successfully and waiting for review. </h4></span>';
                                }
                                
                            }
                        }

                    }


                    $imageRows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id='$post_id' AND user_id = '$user_id' GROUP by image_id DESC");

                    $mycount = 1;

                    if(!empty($imageRows) && $imageRows >0)
                    {
                       echo '
                       <div class="clearfix"></div>
                        <div class="data-tablegrid">    
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                                                <thead>
                                                    <tr>
                                                        <th>Serial Number</th>
                                                        <th>Image Name</th>
                                                        <th>Thumbnail</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead> 
                                                <tbody>';
                                                foreach($imageRows as $imageRow)
                                                {               
                                                    echo '<tr>
                                                        <td>'.$mycount.'</td><td>'.$imageRow->image_name.'</td><td><img src="'.$imageRow->image_path.'" width="100px;height="100px;"></td>';
                                                            if($imageRow->status == 0)
                                                            {
                                                                echo '<td>Unapproved<br>';
                                                                echo '</td>';
                                                            }
                                                            else
                                                            {
                                                                echo "<td>Approved<br>";
                                                                echo '</td>';
                                                            }
                                                    echo '</tr>';
                                                    $mycount++;
                                                }
                                                echo '</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    }
                    else
                    {
                        echo '<h3 class="heading3">No records available</h3>';
                    }
                    ?>
                    <?php 
                }
            }
            /*-------Image Upload Section----------*/
            ?>    
        </div>
        <div class="clearfix"></div>
        <!--<div class="about-review">
        	<h3 class="heading3">About</h3>            
            	<?php //the_content();?>
        </div>-->
        <div class="customer-property-review">
            <div class="row">
                    <input type="hidden" value="<?php echo $post_ID?>" name="post_id" id="post_id" />
                    <?php
                    global $wpdb;
                    $myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id DESC limit 0,10");
                    //echo '<pre>';print_r($myrows);die;
                    //$shortcode = do_shortcode('[RICH_REVIEWS_SHOW category="page" id="'.$post_ID.'"]');
                    ?>
            		<div class="col-sm-9" id="reviewEnable">
                        <?php $myrows1 = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id DESC");
                        $count_reviews = count($myrows1);
                        if($count_reviews > 0)
                        {   ?>
                            <div class="review-header">
                                <h3 class="heading3">
                                    <?php
                                        if($count_reviews == 1)
                                        {
                                            echo 'Customer Review: +1';
                                        }
                                        if($count_reviews == 0)
                                        {
                                            echo 'No Customer Reviews';
                                        }
                                        else
                                        {
                                            if($count_reviews != 1)
                                            {
                                                echo 'Customer Reviews: +'.$count_reviews;
                                            }
                                        }
                                    ?>
                                </h3>
                                <div id="sortingId" class="sorting">
                                    <span class="sort-by">Sory by: </span>
                                    <span class="sort-review sort-reviewNew">
                                        <a href="javascript:void(0);" class="sortby-active" id="newest_link_id" onclick="newvalue();">Newest</a> 
                                        <input type="hidden" id="orderByDesc" value="">
                                        <img src="<?php bloginfo('template_directory');?>/images/newest-sort.png" width="25" height="23" alt=""/>
                                    </span>
                                    <span class="border"></span> 
                                    <span class="sort-review sort-reviewOld">
                                        <a href="javascript:void(0);" id="oldest_link_id" onclick="oldvalue();"> Oldest</a> 
                                        <input type="hidden" id="orderByAsc" value="">
                                        <img src="<?php bloginfo('template_directory');?>/images/oldest-sort.png" width="25" height="22" alt=""/>
                                    </span>
                                </div>
                            </div>
                            <?php 
                        }   ?>
                        <div id="reviesDiv">
                            <?php
                            //print_r($myrows);
                            
                            if($myrows > 0)
                            {
                                foreach ($myrows as $myrow) 
                                {
                                    ?>
                        		    <div class="media">
                                    	<div class="media-left">
                                            <?php 
                                                $userimg = get_wp_user_avatar_src($myrow->reviewer_id, 'large'); 
                                                if($userimg)
                                                {
                                                    echo '<img src="'.$userimg.'" class="img-circle" alt=""/>';
                                                }
                                                /*else
                                                {
                                                    echo '<img src="'.get_bloginfo("template_directory").'/images/user_default.png">';
                                                }*/
                                             ?>
                                        </div>
                                        <div class="media-body">
                                        		<div class="media-heading">
                                                	<h4 class="heading4"><?php echo $myrow->reviewer_name;?></h4>
                                                    <span class="date">
                                                    <?php 
                                                    $originalDate = $myrow->date_time;
                                                    echo $newDate = date("F d, Y", strtotime($originalDate));
                                                    ?>
                                                    </span>
            										<div class="review">
                                                        <?php //$myrow->review_rating=0;?>
                                                        <?php if($myrow->review_rating==0)
                                                        {   ?>
                                                            <?php for($k=1; $k<=5; $k++)
                                                            {   ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                                <?php
                                                            }
                                                        }   
                                                        if($myrow->review_rating==1)
                                                        {   ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                            <?php for($k=1; $k<=4; $k++)
                                                            {   ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                                <?php
                                                            }
                                                        } 
                                                        if($myrow->review_rating==2)
                                                        { 
                                                            for($j=1; $j<=2; $j++)
                                                            { 
                                                                ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                                <?php
                                                            }   
                                                            for($k=1; $k<=3; $k++)
                                                            {   ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                                <?php
                                                            }
                                                        }   
                                                        if($myrow->review_rating==3)
                                                        {   
                                                            for($j=1; $j<=3; $j++)
                                                            {   ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                                <?php 
                                                            }   
                                                            for($k=1; $k<=2; $k++)
                                                            {   ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                                <?php
                                                            }
                                                        }  
                                                        if($myrow->review_rating==4)
                                                        {   
                                                            for($j=1; $j<=4; $j++)
                                                            { ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                                <?php
                                                            } 
                                                            for($k=1; $k<=1; $k++)
                                                            { ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                                <?php
                                                            } 
                                                        }   
                                                        if($myrow->review_rating==5)
                                                        {   
                                                            for($j=1; $j<=5; $j++)
                                                            {   ?>
                                                                <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                                <?php
                                                            }  
                                                        }   ?>
                                                         <!-- <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/> 
                                                         
                                                         <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/> -->
                                 				 	</div>  				
                                                    <p class="para1">
                                                        <?php echo $myrow->review_text;?>
                                                    </p>
                                                </div>
                                        </div>
                                    </div>
                                    <?php 
                                }
                            }       
                            ?>
                        </div>
                        <div class="text-center">
                            <!-- <img class="load_more" data-nonce="<?php echo wp_create_nonce('load_posts') ?>" src="<?php //bloginfo('template_directory');?>/images/loader.svg" width="32" height="30" alt=""/> -->
                            <?php 
                            if($count_reviews > 10)
                            {   ?>
                                <a href="javascript:void(0);" class="load_more" data-nonce="<?php echo wp_create_nonce('load_posts') ?>">
                                      <img src="<?php bloginfo('template_directory');?>/images/loader.svg" alt="" width="32" height="30">
                                </a>
                                <?php 
                            }
                            ?>
                        </div>

                        <h3 class="heading3 mb-10">
                            <a id="reviewID" class="close-section" href="javascript:">Write a review</a>
                        </h3>
                        <a name="writereview"></a>
                        <div class="writea-review login-mini-view" style="display:none;">
                            <div class="close-review">
                                <a href="javascript:"> 
                                    <img src="<?php bloginfo('template_directory');?>/images/close-icon.png" alt="" class="close-section" width="22" height="22">
                                </a>
                            </div>
                            <?php //echo do_shortcode('[RICH_REVIEWS_FORM]'); ?>
                            <?php 
                            $cuid = get_the_id();
                            //echo "current post id: ".$cuid;

                            if ( is_user_logged_in() ) {
                                $current_usr = wp_get_current_user();
                                //print_r($curent_usr);
                                $user_email = $current_usr->user_email;
                                //echo 'user email: '.$user_email;
                                //print_r($myrows);
                                
                                    /*foreach ($myrows as $myreview) {
                                        //print_r($myreview);
                                        $post_id = $myreview->post_id;
                                        $reviewer_email = $myreview->reviewer_email;
                                        $reviewer_name = $myreview->reviewer_name;
                                        }
                                        if($post_id == $cuid && $reviewer_email == $user_email){
                                            echo "you can't review more on this post";
                                        }
                                        else{ echo do_shortcode('[RICH_REVIEWS_FORM]'); }*/
                                

                                global $wpdb;

                                $wpsft_richreviews = $wpdb->wpsft_richreviews;
                                $rslt = $wpdb->get_results(' SELECT * FROM `wpsft_richreviews` WHERE `reviewer_email` = "'.$user_email.'" AND `post_id` = "'.$cuid.'" ORDER BY `reviewer_email` ASC ');
                                if(empty($rslt)){
                                    echo do_shortcode('[RICH_REVIEWS_FORM]');
                                    
                                }
                                else{ ?>

                                    <div class="morthn rr_successful1">
                                    <span class="rr_star glyphicon glyphicon-star left" style="font-size: 34px;"></span>
                                    <span class="rr_star glyphicon glyphicon-star big-star right" style="font-size: 34px;"></span>
                                    <center>
                                    <strong> You can't review more then 1 for same property your review may either pending or approved. Thanks! </strong>
                                    </center>
                                    <div class="clear"></div>
                                    </div>

                                  <?php  echo '<div class="dspoff">'.do_shortcode('[RICH_REVIEWS_FORM]').'</div>';
                                }
                                
                                 ?>

                                
                                <script type="text/javascript">
                                    jQuery(document).ready(function($){
                                        jQuery(".rr_review_form").live("submit", function(event) {
                                            var cpid = <?php echo $cuid; ?>;
                                            //alert(cpid);
                                            $.ajax({
                                                url:'<?php echo admin_url('admin-ajax.php'); ?>',
                                                data : {action: "delpost_review", cpid : cpid },
                                                success:function(response){
                                                    //alert(response);
                                                    }
                                                });
                                        });
                                    });

                                </script>

                               <?php $getreview = htmlentities(get_post_meta($cuid, '_userreview', true));
                                $getreview = urlencode($getreview);
                                
                                if( !empty($getreview) ) { ?>

                                <script type="text/javascript">
                                <?php //echo $getreview; ?>
                                    jQuery(document).ready(function($){
                                            
                                    $("#rRating").after('<input id="reviewusr" type="hidden" value="<?php echo $getreview; ?>" name="usrrev">');
                                            var getvlu = $('#reviewusr').val();
                                            var decodval = decodeURIComponent(getvlu);
                                            var decodval = decodval.replace(/\+/g,' ')
                                            $('#rTextarea').val(decodval);
                                        });
                                </script>

                           <?php } 
                                

                            } else {
                                     ?>
                                    <?php echo do_shortcode('[RICH_REVIEWS_FORM]'); ?>

                                    <script type="text/javascript">
                                        jQuery(document).ready(function($){
                                            jQuery('#rTextarea').prop('required',true);
                                            $(".rr_review_form").append('<input id="crrpid" type="hidden" value="<?php echo $cuid; ?>" name="crrpid">');

                                            jQuery(".rr_review_form").live("submit", function(event) {
                                            var txtval = jQuery('#rTextarea').val();
                                            var crrpid = jQuery('#crrpid').val();

                                                if(txtval == ''){
                                                    //alert('please add comment');
                                                    
                                                    event.preventDefault();
                                                }
                                                else{

                                                    jQuery( ".ulogn" ).css('display', 'block');
                                                    jQuery(this).hide("slow");
                                                    event.preventDefault();
                                                    $.ajax({
                                                        url:'<?php echo admin_url('admin-ajax.php'); ?>',
                                                        data : {action: "user_review", crrpid : crrpid, txtval: txtval},
                                                        success:function(response){
                                                            //$('#rTextarea').html(response);

                                                          //alert(response);
                                                        }
                                                    });
                                                }
                                            
                                            
                                            });


                                            
                                        });

                                        

                                    </script>

                                    <div class="ulogn" style="display: none;">
                                    <?php echo do_shortcode('[theme-my-login show_title=0]'); ?>
                                    </div>

                           <?php 
                                    $url = get_permalink();
                                    //echo "url: ".$url;
                                    session_unset();
                                    session_destroy();
                                    //echo "<pre>";print_r($_SESSION);echo"</pre>";
                                    if ((strpos($url,'property') !== false)) {
                                        if(session_id() == '')
                                        session_start(); 
                                        if(!isset($_SESSION['link']))
                                        $_SESSION['link'] = $url;
                                    } 
                                    //print_r($_SESSION);
                                }

                           
                            ?>
                            <script type="text/javascript">
                                jQuery(document).ready(function($){
                                    $("#submitReview").attr("name","postnow");
                                    $( ".writea-review" ).css('display', 'block');
                                });
                            </script>

                        </div>
                    </div>
                    <div class="col-sm-3">
                    	<div class="write-review">
                        	<a href="#reviewID" class="btn1 veiew_custom_btn1">Write a review</a>
                        </div>
                        <div class="findlayerWp">
                            <?php dynamic_sidebar('review-etiquete');?>
                        </div>
                        <!-- <h5 class="heading5">Revere Local Information</h5> -->
                        <!-- <div class="reverse-bg">
                            <?php 
                                $args = array( 
                                      'post_type'    => 'revere_local_informa',
                                      'posts_per_page' => -1,
                                      'post_status'    => 'publish',
                                      'order'          => 'DESC'
                                );
                            ?>
                            <ul class="reverse-bg">
                            	<?php /*query_posts( $args );
                                    while ( have_posts() ) : the_post();
                                        echo '<li><a href="javascript:">'.get_the_title().'</a></li>';
                                    endwhile;      
                                    // Reset Query 
                                    wp_reset_query();*/ 
                                ?>
                            </ul>
                        </div> -->
                    </div>
            </div>
        </div>
    </div>
</section>
<?php // End of the loop.
endwhile;
?>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/jquery.bxslider.min.js">
</script>
<style type="text/css">    
    .writea-review .rr_review_form tbody .rr_form_row:first-child{display: none;}
    .writea-review .rr_review_form tbody .rr_form_row:nth-child(2){display: none;}
    .writea-review .rr_review_form tbody .rr_form_row:nth-child(3){display: none;}
    .ulogn .wp-social-login-provider.wp-social-login-provider-facebook > img {
    padding: 8px 0;
}
.dspoff .rr_review_form {
    display: none;
}
</style>

<?php

?>

<script type="text/javascript">
    jQuery(document).ready(function($){
        if($('#rTextarea').val() || $('.form-err').hasClass('shown')  ) {
            $(".writea-review").show();
            console.log('value');
            //alert($('#rTextarea').val());
        }
        if($('.writea-review').find('.rr_successful')[0] !== undefined) {
            //console.log($('.writea-review div')[0])
            //alert('test');
            $(".writea-review").show();
            $('.rr_review_form').hide();
            $('.morthn').hide();
        }
        //console.log($('.writea-review').find('.rr_successful'));
        //alert($('.form-err').hasClass('shown'));
        
        /*$('.reviewgallery').bxSlider({
            pagerCustom: '#reivew_gallery_thumb',
            'controls':false
        });*/

        slider = $('.reviewgallery').bxSlider({
            pagerCustom: '#reivew_gallery_thumb',
            'controls':false
        });

        $(window).resize(function(){
           slider.reloadSlider();
        });
        
        $('.about-review p').addClass('para1');
        $('.writea-review input[name="rTitle"]').val('User Rating');

       /* $('.close-section').click(function(){
            $('.writea-review').slideToggle();
        });
        $('.write-review .btn1').click(function(){
            $('.writea-review').slideToggle();
        });
        $('.writea-review input[name="rTitle"]').val('User Rating');*/
        $('.close-section').click(function(){
            $('.writea-review').slideToggle();
        });
        //$('#reviewID').click();
        $('.write-review .btn1').click(function(){
            $('.writea-review').slideToggle();
        });
        $(".rr_review_form").live("submit", function(event) {
            //console.log($('submit'));
            //alert("you must logedin");
            //event.preventDefault();
            //$( ".ulogn" ).css('display', 'block');
            /*var pageUrl = $(window.location);
            var pageUrlNew = window.location+'#reviewID';
            //alert(pageUrlNew);
            window.location.replace(pageUrlNew);
            $("#reviewID").click();
            $(".writea-review").show();*/

            
                //alert('dfdfds');
                $(".writea-review").show();
            
        });
        if(window.location.href.indexOf("#reviewID") > -1) {
           $('.veiew_custom_btn1').click();
        }
    });
</script>
<!-- data table js and css-->
<script type="text/javascript" src="<?php bloginfo('template_directory')?>/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory')?>/js/dataTables.bootstrap.min.js"></script>
<link href="<?php bloginfo('template_directory')?>/css/dataTables.bootstrap.min.css" rel="stylesheet">
<script type="text/javascript">
    jQuery(document).ready(function($) {
    $('#example').DataTable();
} );
</script>





<?php get_footer(); ?>

