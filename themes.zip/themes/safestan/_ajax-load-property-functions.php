<?php
// enqueue_scripts: make sure to include ajaxurl, so we know where to send the post request
function dt_add_main_property_js(){
  
  wp_register_script( 'propertymain-js', get_template_directory_uri() . '/js/script-property.js', array( 'jquery' ), '1.0', true );
  wp_enqueue_script( 'propertymain-js' );
  wp_localize_script( 'propertymain-js', 'headJS', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ), 'templateurl' => get_template_directory_uri(), 'posts_per_page' => 3 ) );
  
}
add_action( 'wp_enqueue_scripts', 'dt_add_main_property_js', 90);

add_action( "wp_ajax_load_more_property_func", "load_more_property_func" ); // when logged in
add_action( "wp_ajax_nopriv_load_more_property_func", "load_more_property_func" );//when logged out 

function load_more_property_func() {
  //verifying nonce here      
  global $wpdb;
  $offset = isset($_REQUEST['offset'])?intval($_REQUEST['offset']):0;
  $posts_per_page = isset($_REQUEST['posts_per_page'])?intval($_REQUEST['posts_per_page']):3;
  
  $args = array( 
                    'post_type'    => 'property',
                    'post_status'    => 'publish',
                    'order'          => 'DESC',
                    'number'      => 6,
                    'offset'      => $offset
              );
  $myrows = query_posts( $args );
  ob_start(); // buffer output instead of echoing it

  if(count($myrows) > 0)
  {
    $result['have_posts'] = true; //set result array item "have_posts" to true
    while ( have_posts() ) : the_post(); ?>
      <div class="search">
          <div class="row">
              <div class="col-sm-5 align-center">
                <div class="search-result pos-rel">
                  <?php if (has_post_thumbnail( $post->ID ) ): ?>
                    <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
                    <img src="<?php echo $image[0]; ?>" class="img-responsive" alt=""/>
                  <?php endif; ?>
                  <div class="img-overlay">&nbsp;</div>
                  <div class="content"> 
                    <div class="top-content">
                      <div class="num-photo">1 Photo</div>
                        <div class="like-dislike"><a href="javascript:" class="favorite-property">&nbsp;</a></div>
                    </div>
                    <div class="bottom-content">
                        <span class="common-align-center">
                           <img src="<?php bloginfo('template_directory');?>/images/ready-icon.png"  alt=""/>
                         </span>
                         <span class="common-align-center">
                          <span class="property-move">READY TO MOVE ( New Property) </span>
                          <div class="property-price">$710,000</div>
                         </span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-sm-7 align-center">
                  <div class="details">
                  <h3  class="heading3"><?php the_title();?></h3> <div class="num-feet">1500 sqft</div>
                    <div class="property-address">
                      <?php
                        if(CFS()->get('_property_address'))
                        {
                            $property_address = CFS()->get('_property_address');
                        }
                        if(CFS()->get('_property_city'))
                        {
                            $property_city = CFS()->get('_property_city');
                        }
                        if(CFS()->get('_property_state'))
                        {
                            $property_state = CFS()->get('_property_state');
                        }
                        if(CFS()->get('_property_zip_code'))
                        {
                            $property_zip_code = CFS()->get('_property_zip_code');
                        }                                       
                        echo $property_address.', '.$property_city.', '.$property_state.' '.$property_zip_code;
                        ?>                                        
                    </div>
                    <p class="para2">
                      <?php
                              $content = get_the_content();
                              echo $contentnew = substr($content, 0, 200);
                            ?>
                    </p>
                      <div  class="footer-details">
                        <a href="<?php the_permalink();?>" class="btn1">View Detail</a>
                        <span class="count-review">
                          <img src="<?php bloginfo('template_directory');?>/images/review-icon.png" class="mr-5"  alt=""/> <a href="<?php the_permalink();?>">25+ Reviews</a></span>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <?php 
      $count++; 
    endwhile;      
    // Reset Query
    wp_reset_query();
    $result['html'] = ob_get_clean(); // put alloutput data into "html" item
  }
  else {
    //no posts found
    $result['have_posts'] = false; // return that there is no posts found
  }    

  if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result); // encode result array into json feed
      echo $result; // by echo we return JSON feed on POST request sent via AJAX
  }
  else { 
      header("Location: ".$_SERVER["HTTP_REFERER"]);
  }
  die();
}
?>
