<?php
/**
 * The header for the OnePress theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OnePress
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="profile" href="http://gmpg.org/xfn/11">

<?php   if (!is_user_logged_in()) {
    wp_redirect(site_url() . '/login/');
    exit;
  }
   
  global $current_user, $wpdb;
  if (nstxl_is_poc($current_user->ID)) {
    $membership_level = pmpro_getMembershipLevelForUser($current_user->ID);
    if (empty($membership_level)) {
       wp_redirect(get_bloginfo('url'), 301); 
      exit;
    }
  }
    // Redirect subscriber(non-member) user to membership level page.
  $cuid = $current_user->ID;
  $cmp_name = get_user_meta($cuid, 'company_name', true);
  $query = "SELECT user_id FROM " . $wpdb->prefix . "usermeta WHERE `meta_key` = 'company_name' AND `meta_value` = '{$cmp_name}' ";
  $result = $wpdb->get_results($query);
  $uids = array();
  if (!empty($result)) {
    foreach ($result as $key => $value) {
      $uids[] = $value->user_id;
    }
  }
  if (!empty($uids)) {
    $uidStr = implode(',', $uids);
    $query_mbr = "SELECT * FROM " . $wpdb->prefix . "pmpro_memberships_users WHERE `user_id` IN  ($uidStr)";
  }
  $result_mbr = $wpdb->get_results($query_mbr);
  if (empty($result_mbr) && !in_array('administrator', $current_user->roles)) {
    wp_redirect(get_bloginfo('url') . '/membership-account/membership-levels/', 301);
    exit();
  }     
  // Redirect subscriber(non-member) user to membership level page.
/*  $cuid = $current_user->ID;
  $cmp_name = get_user_meta($cuid, 'company_name', true);
  $query = "SELECT user_id FROM " . $wpdb->prefix . "usermeta WHERE `meta_key` = 'company_name' AND `meta_value` = '{$cmp_name}' ";
  $result = $wpdb->get_results($query);
  $uids = array();
  if (!empty($result)) {
    foreach ($result as $key => $value) {
      $uids[] = $value->user_id;
    }
  }
  if (!empty($uids)) {
    $uidStr = implode(',', $uids);
    $query_mbr = "SELECT * FROM " . $wpdb->prefix . "pmpro_memberships_users WHERE `user_id` IN  ($uidStr)";
  }
  $result_mbr = $wpdb->get_results($query_mbr);
  if (empty($result_mbr) && !in_array('administrator', $current_user->roles)) {
    wp_redirect(get_bloginfo('url'), 301);
    exit();
  } 
 */ 
?>  

     <?php wp_head(); ?>
       <style>#secondary.dashboard-sidebar {padding-bottom: 40px;padding-top: 0;}.logged-in .site-content {background-color: #f3f3f3;}
      #secondary.dashboard-sidebar .elementor-nav-menu--dropdown.elementor-nav-menu__container {overflow: visible;padding: 20px 25px;margin-top: 0;}
      .logged-in .left-sidebar #secondary.dashboard-sidebar.sidebar {padding-right: 5px;border-right: 0;}#primary {padding-top: 0;}
      .left-sidebar .content-area {border-left: 0 none;}.logged-in .elementor-column-gap-default>.elementor-row>.elementor-column>.elementor-element-populated {
        padding: 0 10px 10px 10px;}#secondary.dashboard-sidebar .elementor-nav-menu--dropdown.elementor-nav-menu__container{overflow:visible;padding: 20px 25px;}
      #secondary.dashboard-sidebar .elementor-nav-menu--dropdown a{font-family: AvenirNext-Bold,sans-serif;font-size: 16px;font-weight: normal;color: #000;padding: 8px 10px 8px 0px;text-transform:uppercase;}
      #secondary.dashboard-sidebar .elementor-nav-menu a, #secondary.dashboard-sidebar .elementor-nav-menu a:focus, #secondary.dashboard-sidebar .elementor-nav-menu a:hover{padding: 8px 10px 8px 0px; background: transparent;}
      #secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-item.elementor-item-active, #secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-item.highlighted, #secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-item:focus, .dashboard-sidebar .elementor-nav-menu--dropdown .elementor-item:hover, .dashboard-sidebar .elementor-sub-item.elementor-item-active, .dashboard-sidebar .elementor-sub-item.highlighted, .elementor-sub-item:focus, #secondary.dashboard-sidebar .elementor-sub-item:hover{background:transparent;background-color:transparent;}
      #secondary.dashboard-sidebar .elementor-nav-menu--dropdown.elementor-nav-menu__container .elementor-sub-item{font-family: AvenirNext-Regular,sans-serif;font-size: 14px;font-weight: normal;line-height: 20px;color: #000;text-transform:none;padding-bottom: 0; padding-left: 22px;}
       #secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-nav-menu li:not(:last-child){border-color:rgba(191,55,55,0.5) !important;}
       #secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-nav-menu .sub-menu li:not(:last-child){border-bottom: 0 none !important;}.elementor-nav-menu li ul.sub-menu {
padding-bottom: 20px;}#secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-nav-menu li.current-menu-item {color: #bf3737 !important;}
#secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-nav-menu li.current-menu-item a.elementor-item-active {color: #bf3737 !important;}
#secondary.dashboard-sidebar .elementor-nav-menu--dropdown .elementor-nav-menu li.current-menu-item a.highlighted {color: #bf3737 !important;}</style>
  </head>
 <body <?php body_class('frontend-dashboard'); ?>>
   <div class="preloader" style="display: none"><div class="nst-ripple"><div class="nst-pos"></div></div></div>
  <?php do_action('onepress_before_site_start'); ?>
  <div id="page" class="hfeed site">
    <a class="skip-link screen-reader-text" href="#content"><?php esc_html_e('Skip to content', 'onepress'); ?></a>
    <?php
    /**
     * @since 2.0.0
     */
    onepress_header();
    ?>
