=== Wp Clone any Post type ===
Tags: wp clone any post type, gwl clone any post type, clone posts, clone pages, clone post, clone page, clone, duplicate post, duplicate page, duplicate custom post, clone this page, clone this post, clone bulk post, duplicate bulk page and posts, page cloning, post cloning, posts cloning, pages cloning, page copy, page copy paste, replica posts, replica pages, replica posts and pages, post copy, posts copy paste, copy pages, copy posts
Requires at least: 4.0
Tested up to 5.2.2
Stable tag: 1.0
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cloning posts, pages and custom post types in WordPress.

== Description ==

This plugin allows users to clone posts of any type, or copy them to new drafts for further editing. Also, it creates to make an exact number of copy of the selected post, page and custom post types.

= How it works =
* In the 'Clone Settings' page select the elements where you want to clone. 

* In Edit Posts, Edit Pages and Edit Post for custom post type you can click on 'Clone' link below the title, this will immediately create a clone and return to the list.

* In Edit Posts, Edit Pages and Edit Post for the custom post type, you can select one or more items, then choose 'Clone' in the 'Bulk Actions' dropdown to clone them all at once.

= Features =

* Creates exact copy of single post, page and custom post type post.
* Creates number of exact copy of single items.
* Cloning multiple bulk posts, pages and custom post type posts at a single click.

== Installation ==

1. Download the wp-clone-any-post-type.zip file and unzip it.
2. Upload the wp-clone-any-post-type folder to the wp-content/plugins/ directory.
3. Activate the 'wp clone any post type' from plugin page on WordPress admin area.

ALTERNATIVELY, YOU CAN INSTALL THE PLUGIN AUTOMATICALLY THROUGH THE WORDPRESS ADMIN PANEL
1. Open your WordPress website admin panel and go to the Plugins > Add New page.
2. Search by 'galaxy weblinks' for 'wp clone any post type'.
3. Click on the Install Now button and then click on the Activate Plugin link.


== Changelog ==

= Version 1.0 =
* initial version

== Screenshots ==

1. Guide for clone settings page and review.
2. Clone Settings page.
3. Clone single post or page.
4. Clone single post for the custom post type.
5. Creates number of copy of selected item.
6. Clone multiple posts, pages and custom post types posts.
