<?php
/**
 * Template Name: Reset Password
 *
 */
get_header();

?>
	<div id="content" class="site-content form-page">
       <div id="content-inside" class="container no-sidebar">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'template-parts/content', 'page' ); ?>

						<?php
							// If comments are open or we have at least one comment, load up the comment template.
							if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;
						?>

					<?php endwhile; // End of the loop. ?>

				</main><!-- #main -->
			</div><!-- #primary -->

		</div><!--#content-inside -->
	</div><!-- #content -->

        <script>
		jQuery(document).ready(function ($) {
    "use strict";
// Validation
    jQuery('.tml-button').click(function(e){

    var tempthis=$(this);
    $('form[name="resetpass"]').validate({
      rules: {
        pass1: {
          required: true,
          minlength: 5,
        },
        pass2: {
          required: true,
          minlength: 5,
          equalTo: "[name=pass1]",
        },
 
      }, messages: { 
            pass2: {
              equalTo: "Password do not match.",                
            },
        },
      errorClass: "form-invalid",
      errorPlacement: function (label, element) {
        if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
          element.parent().append(label); // this would append the label after all your checkboxes/labels (so the error-label will be the last element in <div class="controls"> )
        } else {
          //label.insertAfter(element); // standard behaviour
             element.parent().append(label);
        }
      },
    });  
  });
    });
</script>
<style type="text/css">
	.tml-pass1-wrap label#pass1-error {
    padding-top: 20px !important;
    color: #bf3737;
}
	.tml-pass2-wrap label#pass2-error {
    padding-top: 20px !important;
    color: #bf3737;
}
</style>

<?php get_footer(); ?>