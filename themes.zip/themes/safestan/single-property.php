<?php

get_header(); 

?>

<?php
$post_ID = get_the_ID();
// Start the loop.
while ( have_posts() ) : the_post();?>
<div class="top-banner">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12">
          <h1 class="banner-hadding"> <?php the_title();?></h1>
        </div>
      </div>
    </div>
</div>
<div class="card-review review-detail property-review">
    <div class="container">
        <div class="customer-property-review">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="card-box">
                        <?php 
                            $imageSliders = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id= ".$post_ID." AND status = 1 GROUP by image_id DESC LIMIT 0,10");
                            //echo '<pre>';print_r($imageSliders);die;
                        ?>
                        <div class="col-md-5 col-sm-5">
                            
                                <?php
                                //Property Gallery 
                                //echo $post_id = get_the_ID();
                                //$fields = CFS()->get( '_propery_gallery' );                            
                                //$fields = CFS()->get('_propery_gallery');
                                //echo '<pre>';print_r($fields);
                                if($imageSliders > 0 && !empty($imageSliders))
                                {   
                                    echo '<div class="set-map12 reviewgallery">';
                                    foreach ( $imageSliders as $imageSlider )
                                    {
                                        //$thumb_path = $field['_upload_gallery_image'];
                                        ?>
                                        <div class="reviewgallery_inner">
                                            <img src="<?php echo $imageSlider->image_path;?>" class="img-responsive" alt=""/>
                                            <div class="img-overlay">&nbsp;</div>
                                            <div class="search-icon">
                                                <a class="fancybox" rel="fancybox" href="<?php echo $imageSlider->image_path;?>">
                                                    <img src="<?php bloginfo('template_directory');?>/images/search-icon.png" width="20" height="20" alt=""/>
                                                </a>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    echo '</div>';
                                }
                                else
                                {
                                    
                                    /*echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found.jpg" class="img-responsive feature-img" alt=""/>';*/

                                    if(CFS()->get('_property_address',$myrow->ID))
                                      {
                                          $property_address = CFS()->get('_property_address', $myrow->ID);
                                      }
                                      if(CFS()->get('_property_city', $myrow->ID))
                                      {
                                          $property_city = CFS()->get('_property_city', $myrow->ID);
                                      }
                                      if(CFS()->get('_property_state', $myrow->ID))
                                      {
                                          $property_state = CFS()->get('_property_state', $myrow->ID);
                                      }
                                      if(CFS()->get('_property_zip_code', $myrow->ID))
                                      {
                                          $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
                                      }
                                
                                    $property_fulladdr = array('property_address' => urlencode($property_address),
                                    'property_city' => urlencode($property_city),
                                    'property_state' => urlencode($property_state),
                                    '_property_zip_code' => urlencode($property_zip_code)
                                    );
                                    /*echo "<pre>";
                                    print_r($property_fulladdr);
                                    echo "</pre>";*/
                                   $op = '<div class="effect google-map-embed">';
                                   $op .= '<iframe width="470" height="275" frameborder="0" style="border:0" allowfullscreen ';
                                   $op .= 'src="https://www.google.com/maps/embed/v1/place?q=';
                                   $op .= implode(',', $property_fulladdr);
                                   $op .= '&key=AIzaSyCUpXt8H-Wd6-_SHbSmnYwdBPXLDQD-gc0';  
                                   $op .= '&zoom=11"></iframe></div>';

                                   print $op;
                                }
                                ?>
                            
                        </div>
                      
                        <!-- <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory');?>/style-upload.css"> -->  
                        <div class="col-md-7 col-sm-7 mb-3 mt-2">
                            <h4 class="card-hadding mt-2 px-0">
                                    <?php
                                            if(CFS()->get('_property_address'))
                                            {
                                                $property_address = CFS()->get('_property_address');
                                            }
                                            if(CFS()->get('_property_city'))
                                            {
                                                $property_city = CFS()->get('_property_city');
                                            }
                                            if(CFS()->get('_property_state'))
                                            {
                                                $property_state = CFS()->get('_property_state');
                                            }
                                            if(CFS()->get('_property_zip_code'))
                                            {
                                                $property_zip_code = CFS()->get('_property_zip_code');

                                                $numlength = strlen((string)$property_zip_code);
                                                if($numlength == 1)
                                                {
                                                    $property_zip_code = '0000'.$property_zip_code;         
                                                }
                                                elseif ($numlength == 2) {
                                                    $property_zip_code = '000'.$property_zip_code;
                                                }
                                                elseif ($numlength == 3) {
                                                    $property_zip_code = '00'.$property_zip_code;
                                                }
                                                elseif ($numlength == 4) {
                                                    $property_zip_code = '0'.$property_zip_code;
                                                }
                                                else {
                                                    $property_zip_code = $property_zip_code;
                                                }
                                            }
                                        ?>
                                            <?php 
                                            //echo "address: ".CFS()->get('_property_address');
                                            $pro_fulladr = array($property_address,$property_city,$property_state,$property_zip_code);
                                            $pro_fulladr = array_filter($pro_fulladr);
                                            /*echo "<pre>";
                                            print_r($pro_fulladr); 
                                            echo "</pre>";*/
                                            echo implode(', ', $pro_fulladr);                                         
                                           /*if($property_address != ' '){
                                            //echo "not empty";
                                             echo $property_address.', '.$property_city.', '.$property_state.' '.$property_zip_code;
                                            }
                                            else{
                                               //echo "empty";
                                                echo $property_city.', '.$property_state.' '.$property_zip_code;
                                            }*/                                            
                                            ?>
                            </h4> 
                            <p class="m-0 ratting">Rating</p>
                            <div class="mb-2">
                                <?php 
                                    //echo do_shortcode('[RICH_REVIEWS_SNIPPET stars_only="true"]');
                                    echo do_shortcode('[RICH_REVIEWS_SNIPPET category="post" id="'.$post_ID.'" stars_only="true"]');
                                ?>

                                <!-- <img src="<?php //bloginfo('template_directory');?>/images/star-yellow.png" alt=""/> 
                                <img src="<?php //bloginfo('template_directory');?>/images/star-yellow.png"   alt=""/>
                                <img src="<?php //bloginfo('template_directory');?>/images/star-yellow.png"  alt=""/>
                                <img src="<?php //bloginfo('template_directory');?>/images/star-yellow.png"  alt=""/>
                                <img src="<?php //bloginfo('template_directory');?>/images/star-grey.png" alt=""/> -->
                            </div>                             
                            <div class="pull-right"><?php dynamic_sidebar('find-a-layer');?></div>
                            <div class="social w-auto p-0 mb-3 socialnw123"><?php echo do_shortcode('[Sassy_Social_Share]') ?></div>
                            
                            <div class="more-images">
                                <div id="reivew_gallery_thumb">
                                <?php
                                //$fields_thumbs = CFS()->get('_propery_gallery');                            
                                    if($imageSliders > 0)
                                    {   $count = 0;
                                        foreach ( $imageSliders as $imageSlider ) {
                                            //$thumb_path = $fields_thumb['_upload_gallery_image'];
                                            echo '<a data-slide-index="'.$count.'" href="">';
                                            echo '<img src="'.$imageSlider->image_path.'" class="img-responsive" alt=""/>';
                                            echo '</a>';
                                            $count++;
                                        }
                                    }
                                    else
                                    {
                                        echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found2.jpg" class="img-responsive feature-img" alt=""/>';
                                    }   
                                ?>
                                </div>                            
                            </div>                        
                        </div>
                    </div>
                </div>
            </div>    
            <div class="col-md-12 col-sm-12 text-center border-bottom pb-3">
                <div class="customer-property-review">
                    <div class="row">
                        <a href="javascript:void(0)" class="btn btn-primary w-auto" id="review-form" style="display: none;">Write a Review</a>
                        <div class="coment-form mt-3 writea-review login-mini-view" style="display: inline-block;">
                            <?php echo do_shortcode('[RICH_REVIEWS_FORM]'); ?>
                            <a href="javascript:void(0)" class="close-form" id="close-review"><img src="<?php bloginfo('template_directory');?>/images/cross-2.png" alt="..."></a>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 border-bottom pb-3">
              <?php dynamic_sidebar('review-etiquete');?>
            </div>
            <div class="col-md-12 col-sm-12">
                <div class="coment-section border-top-0">             
                    <input type="hidden" value="<?php echo $post_ID?>" name="post_id" id="post_id" />
                    <?php
                    global $wpdb;
                    $myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id DESC limit 0,10");
                    //echo '<pre>';print_r($myrows);die;
                    //$shortcode = do_shortcode('[RICH_REVIEWS_SHOW category="page" id="'.$post_ID.'"]');
                    ?>
                    <?php $myrows1 = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id DESC");
                    /*echo "<pre>";
                    print_r($myrows1);
                    echo "</pre>";
                    echo "title: ". get_the_title($post_ID);*/
                        $count_reviews = count($myrows1);
                        if($count_reviews > 0)
                        {   ?>
                             <h4 class="sub-hadding pt-3"><?php echo $count_reviews; ?> thoughts on “<?php the_title(); ?>" It’s Time to Meet Safestan</h4>                          
                            <?php 
                        }   ?>
                            <?php
                            //print_r($myrows);
                            
                            if($myrows > 0)
                            {
                                foreach ($myrows as $myrow) 
                                {
                                    ?>
                                       <div class="media mt-2">
                                            <div class="media-left">
                                                <?php 
                                                    $userimg = get_wp_user_avatar_src($myrow->reviewer_id, 'large'); 
                                                    if($userimg)
                                                    {
                                                        echo '<img src="'.$userimg.'" class="media-object" alt=""/>';
                                                    }
                                                    /*else
                                                    {
                                                        echo '<img src="'.get_bloginfo("template_directory").'/images/user_default.png">';
                                                    }*/
                                                 ?>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="hadd-coment m-0"><?php echo $myrow->reviewer_name;?>
                                                    <span>
                                                    <?php 
                                                    $originalDate = $myrow->date_time;
                                                    echo $newDate = date("F d, Y", strtotime($originalDate));
                                                    ?>
                                                    </span>
                                                </h4>
                                                <p class="m-0">
                                                    <?php //$myrow->review_rating=0;
                                                    /*echo do_shortcode('[RICH_REVIEWS_SNIPPET stars_only="true" id="'.$myrow->id.'"]');
*/

                                                    ?>
                                                    <?php if($myrow->review_rating==0)
                                                    {   ?>
                                                        <?php for($k=1; $k<=5; $k++)
                                                        {   ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                            <?php
                                                        }
                                                    }   
                                                    if($myrow->review_rating==1)
                                                    {   ?>
                                                        <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                        <?php for($k=1; $k<=4; $k++)
                                                        {   ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                            <?php
                                                        }
                                                    } 
                                                    if($myrow->review_rating==2)
                                                    { 
                                                        for($j=1; $j<=2; $j++)
                                                        { 
                                                            ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                            <?php
                                                        }   
                                                        for($k=1; $k<=3; $k++)
                                                        {   ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                            <?php
                                                        }
                                                    }   
                                                    if($myrow->review_rating==3)
                                                    {   
                                                        for($j=1; $j<=3; $j++)
                                                        {   ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                            <?php 
                                                        }   
                                                        for($k=1; $k<=2; $k++)
                                                        {   ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                            <?php
                                                        }
                                                    }  
                                                    if($myrow->review_rating==4)
                                                    {   
                                                        for($j=1; $j<=4; $j++)
                                                        { ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                            <?php
                                                        } 
                                                        for($k=1; $k<=1; $k++)
                                                        { ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                                                            <?php
                                                        } 
                                                    }   
                                                    if($myrow->review_rating==5)
                                                    {   
                                                        for($j=1; $j<=5; $j++)
                                                        {   ?>
                                                            <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                                                            <?php
                                                        }  
                                                    }   ?>
                                                    <?php /* <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/> */ ?>
                                                     
                                                     <!--<img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>-->
                                                    <p> <?php echo $myrow->review_text;?></p>
                                                </p>
                                            </div>                  
                                        </div>
                                    
                                    <?php 
                                }
                                ?>
                                <?php 
                            }       
                            ?>
                        </div>
                        </div>
                        <div class="text-center">
                            <!-- <img class="load_more" data-nonce="<?php echo wp_create_nonce('load_posts') ?>" src="<?php //bloginfo('template_directory');?>/images/loader.svg" width="32" height="30" alt=""/> -->
                            <?php 
                            if($count_reviews > 10)
                            {   ?>
                                <a href="javascript:void(0);" class="load_more" data-nonce="<?php echo wp_create_nonce('load_posts') ?>">
                                      <img src="<?php bloginfo('template_directory');?>/images/loader.svg" alt="" width="32" height="30">
                                </a>
                                <?php 
                            }
                            ?>
                </div>
            </div>
        <div class="about-review">
            <div class="row">
                <div class="col-sm-9">
                    <?php
                    if(is_user_logged_in())
                    {
                        global $current_user, $wpdb;
                        get_currentuserinfo();
                        //echo '<pre>'; print_r($current_user);die;
                        $user_name = $current_user->display_name;
                        $user_roles = $current_user->roles;
                        $user_role = array_shift($user_roles);
                        if($user_role == 'subscriber' || $user_role == 'administrator')
                        {   ?>
                            <h4 class="containt-hadding">Add Photo - A picture tells a thousand words</h4>
                            <p class="para1">
                                Only JPEG, PNG, JPG Type Image Uploaded. Image Size Should Be Less Than 20MB.  
                            </p>
                            <?php 
                        }
                    }   ?>
                </div>
            </div>
            <?php 
            /*-------Image Upload Section----------*/
            if(is_user_logged_in())
            {
                global $current_user, $wpdb;
                get_currentuserinfo();
                //echo '<pre>'; print_r($current_user);die;
                $user_name = $current_user->display_name;
                $user_roles = $current_user->roles;
                $user_role = array_shift($user_roles);
                
                if($user_role == 'subscriber' || $user_role == 'administrator')
                {   
                    $upload_dir = wp_upload_dir();
                    $up_Path =  $upload_dir['basedir'].'/front-slider-image/';
                    ?>                   

                    <div class="form-image-upload">
                        <form enctype="multipart/form-data" action="" method="post" role="form" class="form-uploadfile"> 
                            <div class="row">
                                <div class="col-sm-5 col-md-3 col-lg-3 col-xs-12 ">
                                    <div id="filediv" class="multifile">
                                        <input name="file[]" type="file" id="file" imgid="previewimg1" multiple="multiple"/>
                                    </div>
                                </div>
                                 <div class="col-sm-7 col-md-6 col-lg-6 col-xs-12 ">         
                                   <!--  <input type="button" id="add_more"  id="" value="+ Add More Files" class="common-btn"> -->
                                    <input type="submit"  name="submit" id="upload"  value="Upload Files" class="common-btn">
                                </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="upload-images"></div>
                                </div>
                            </div>
                            </div>
                        </form>
                    </div>
                    <!--Including PHP Script here-->
                    <?php
                    //echo 20*pow(1024,2);
                    $post_id = $post_ID;
                    $user_id = $current_user->ID;
                    //$image_path = $new_imgpath;
                    $status = 0;
                    $image_featured_status = 0;
                    $date = date('Y-m-d H:i:s');

                    if (isset($_POST['submit']) && !empty($_POST['submit'])) 
                    {

                        $j = 0; //Variable for indexing uploaded image 

                        /*echo "count file: ".count($_FILES['file']['name']);
                        die("test");*/
                        for ($i = 0; $i < count($_FILES['file']['name']); $i++) 
                        {   //loop to get individual element from the array

                            $validextensions = array("jpeg", "jpg", "png");  //Extensions which are allowed
                            $ext = explode('.', basename($_FILES['file']['name'][$i]));//explode file name from dot(.) 
                            //$target_path ='';

                            $file_extension = end($ext); //store extensions in the variable

                            $imgpath = site_url().'/wp-content/uploads/front-slider-image/';
                            
                            $target_path = $up_Path . $ext[0].rand() . "." . $ext[count($ext) - 1];//set the target path with a new name of image
                            //echo $target_path;
                            $j = $j + 1;//increment the number of uploaded images according to the files in array       
                          
                            if (($_FILES["file"]["size"][$i] < 20971520) //Approx. 20Mb files can be uploaded.
                                    && in_array($file_extension, $validextensions)) 
                            {
                                if (move_uploaded_file($_FILES['file']['tmp_name'][$i], $target_path)) 
                                {   //if file moved to uploads folder

                                    chmod($target_path, 0777);
                                    $imgpath_orig = end(explode('/', $target_path));

                                    //$imgName     =  explode('.',$imgpath_orig,-1);
                                    $imgName     = $imgpath_orig;
                                    $new_imgpath =  $imgpath.$imgpath_orig;

                                    $image_path = $new_imgpath;  

                                    $tableName = $wpdb->prefix.'post_slider_image';

                                    $insert = $wpdb->query("
                                        INSERT INTO $tableName (post_id, user_id, user_name, image_path, image_name, date, status, image_featured_status) VALUES ('$post_id','$user_id', '$user_name', '$image_path','$imgName' ,'$date','$status',$image_featured_status)
                                        ");


                                    /*echo $wpdb->last_query;
                                    die;*/
                                    /*echo '<span id="noerror">Image uploaded successfully!.</span><br/>';*/
                                    //echo '<img src="'.$new_imgpath.'" alt="" /><br>';
                                    
                                } 
                                else 
                                {   //if file was not moved.
                                    echo '<span id="error">please try again!.</span><br/><br/>';
                                }
                                $target_path ='';

                            } 
                            else
                            {   //if file size and file type was incorrect.
                                if($file_extension != null){
                                    echo '<span id="error">***Invalid file Size or Type***</span><br/>';
                                }
                            }
                            $ico = $i+1;
                            if($ico == count($_FILES['file']['name'])){
                                if( count($_FILES['file']['name']) == 1 ){
                                    echo '<span id="noerror"><h4>Thanks, your image has been uploaded successfully and waiting for review.</h4></span>';
                                }
                                else{
                                    echo '<span id="noerror"><h4>Thanks, your image have been uploaded successfully and waiting for review. </h4></span>';
                                }
                                
                            }
                        }

                    }


                    $imageRows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id='$post_id' AND user_id = '$user_id' GROUP by image_id DESC");

                    $mycount = 1;

                    if(!empty($imageRows) && $imageRows >0)
                    {
                       echo '
                       <div class="clearfix"></div>
                        <div class="data-tablegrid">    
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                                                <thead>
                                                    <tr>
                                                        <th>Serial Number</th>
                                                        <th>Image Name</th>
                                                        <th>Thumbnail</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead> 
                                                <tbody>';
                                                foreach($imageRows as $imageRow)
                                                {               
                                                    echo '<tr>
                                                        <td>'.$mycount.'</td><td>'.$imageRow->image_name.'</td><td><img src="'.$imageRow->image_path.'" width="100px;height="100px;"></td>';
                                                            if($imageRow->status == 0)
                                                            {
                                                                echo '<td>Unapproved<br>';
                                                                echo '</td>';
                                                            }
                                                            else
                                                            {
                                                                echo "<td>Approved<br>";
                                                                echo '</td>';
                                                            }
                                                    echo '</tr>';
                                                    $mycount++;
                                                }
                                                echo '</tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    }
                    else
                    {
                        echo '<h4 class="containt-hadding">No records available</h4>';
                    }
                    ?>
                    <?php 
                }
            }
            /*-------Image Upload Section----------*/
            ?>    
        </div>
        <!--<div class="about-review">
            <h3 class="heading3">About</h3>            
                <?php //the_content();?>
        </div>-->
       
    </div>
</div>
<?php // End of the loop.
endwhile;
?>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/script-upload.js"></script>
<style type="text/css">    
/*    .writea-review .rr_review_form tbody .rr_form_row:first-child{display: none;}
    .writea-review .rr_review_form tbody .rr_form_row:nth-child(2){display: none;}
    .writea-review .rr_review_form tbody .rr_form_row:nth-child(3){display: none;}
    .ulogn .wp-social-login-provider.wp-social-login-provider-facebook > img {
    padding: 8px 0;
}
.dspoff .rr_review_form {
    display: none;
}*/
.login-mini-view .close-review {
    position: relative;
    right: -38px;
    top: -12px;
}

/* social share on single property */
.socialnw {
    display: inline-block;
    float: right;
}
.socialnw .heateor_sss_facebook_like {
    display: none;
}
</style>

<?php

?>

<script type="text/javascript">
    //bx thumb image slider
    /*slider = jQuery('.reviewgallery').bxSlider({
            pagerCustom: '#reivew_gallery_thumb',
            'controls':false
    });*/

    jQuery(window).resize(function(){
       slider.reloadSlider();
    });

    jQuery(document).ready(function($){
        if($('#rTextarea').val() || $('.form-err').hasClass('shown')  ) {
            $(".writea-review").show();
            console.log('value');
            //alert($('#rTextarea').val());
        }
        if($('.writea-review').find('.rr_successful')[0] !== undefined) {
            //console.log($('.writea-review div')[0])
            //alert('test');
            $(".writea-review").show();
            $('.rr_review_form').hide();
            $('.morthn').hide();
        }
        //console.log($('.writea-review').find('.rr_successful'));
        //alert($('.form-err').hasClass('shown'));
        
        /*$('.reviewgallery').bxSlider({
            pagerCustom: '#reivew_gallery_thumb',
            'controls':false
        });*/

        
        
        $('.about-review p').addClass('para1');
        $('.writea-review input[name="rTitle"]').val('User Rating');

       /* $('.close-section').click(function(){
            $('.writea-review').slideToggle();
        });
        $('.write-review .btn1').click(function(){
            $('.writea-review').slideToggle();
        });
        $('.writea-review input[name="rTitle"]').val('User Rating');*/
        /*$('.close-section').click(function(){
            $('.writea-review').slideToggle();
        });*/
        /*$('#reviewID').click();
        $('.write-review .btn1').click(function(){
            $('.writea-review').slideToggle();
        });*/
        $(".rr_review_form").live("submit", function(event) {
            //console.log($('submit'));
            //alert("you must logedin");
            //event.preventDefault();
            //$( ".ulogn" ).css('display', 'block');
            /*var pageUrl = $(window.location);
            var pageUrlNew = window.location+'#reviewID';
            //alert(pageUrlNew);
            window.location.replace(pageUrlNew);
            $("#reviewID").click();
            $(".writea-review").show();*/

            
                //alert('dfdfds');
                $(".writea-review").show();
            
        });
        if(window.location.href.indexOf("#reviewID") > -1) {
           $('.veiew_custom_btn1').click();
        }

    });

</script>                         
<script src="<?php bloginfo('template_directory')?>/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/jquery.bxslider.min.js"></script>
<!-- data table js and css-->
<script type="text/javascript" src="<?php bloginfo('template_directory')?>/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory')?>/js/dataTables.bootstrap.min.js"></script>
<link href="<?php bloginfo('template_directory')?>/css/dataTables.bootstrap.min.css" rel="stylesheet">
<script type="text/javascript">
    jQuery(document).ready(function($) {
    $('#example').DataTable();
} );

      $(document).ready(function () {
               $("#review-form").click(function(){
                                $(".coment-form").show();
                                $("#review-form").hide();
                        });
             $("#close-review").click(function(){
                                $(".coment-form").hide();
                                $("#review-form").show();
                        });
        });
</script>
<style type="text/css">
  .media-object{
    width: 65px;
    height: 65px;
  }  

</style>

<script type="text/javascript">
    
        slider = jQuery('.reviewgallery').bxSlider({
            pagerCustom: '#reivew_gallery_thumb',
            randomStart: false,
            controls: false,
            auto: false,
            infiniteLoop: false,
            mode: 'horizontal',
            startSlide: 0,
            touchEnabled: true,
            hideControlOnEnd: true
        });
    
</script>

<!-- Add jQuery library for fancybox -->
<script type="text/javascript" src="<?php bloginfo('template_directory')?>/fancybox/source/jquery-latest.min.js"></script>

<!-- Add fancyBox -->
<!-- <link rel="stylesheet" href="<?php bloginfo('template_directory')?>/fancybox/source/jquery.fancybox.css?v=2.1.7" type="text/css" media="screen" />
<script type="text/javascript" src="<?php bloginfo('template_directory')?>/fancybox/source/jquery.fancybox.pack.js?v=2.1.7"></script> -->

<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script type="text/javascript">
     // for google captcha on review form
     
     jQuery(document).ready(function(){
        jQuery('#submitReview').on('click',function(e){
            //alert("hello");
            var response = grecaptcha.getResponse();
            var errorcls = jQuery( ".form-err" ).hasClass( "shown" );
            //alert(response);
            if(response.length == 0){
                jQuery('.cptcha-saftn').css('display','block');
                e.preventDefault();}            
            else if(response.length == 0 && errorcls == true ){             
                e.preventDefault();
            }
            else{
                return;
            }           
        });

        jQuery('form.form-uploadfile').submit(function(e) {
        //e.preventDefault(e);
        //alert("hello");
        var name = jQuery(":file").val();
        console.log(name);
        //alert(name);
            if (!name)
            {
                if( jQuery(":file").length > 0 && jQuery(".abcd.img-inline").length > 0){
                    return;
                
                }
                else{
                        alert( "First image must be selected" );
                        e.preventDefault();
                }

                
            }
            
        });
    });
</script>


<?php get_footer(); ?>