<div id="step-2">
  <div id="form-step-1" role="form">
    <h3 class="rgs_title">Membership Application</h3>
    <div class="after_billing_fields row">
      <?php
      do_action("pmpro_checkout_after_billing_fields");
      ?>
    </div>
    <!-- Start step2 content -->
    <div class="cprofile-container">
      <div class="checkbox_container" style="display:none">
        <?php /*  ?><h3>Company Profile</h3> <?php */ ?>
        <p><b>Main point of Contact</b></p>
        <label class="checkbox-inline">
          <input type="checkbox" name="company_profile" value="yes" class="cprofile"/>
          <span>if diffrent from the account owner</span>
          <span class="checkmark"></span>
        </label>
      </div>
      <div class="mainpoint">   
        <div class="row">
          <div id="business_duns_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
            <div class="form-group">
              <label for="business_duns"><?php _e('Business DUNS', 'paid-memberships-pro'); ?><span class='required' aria-required='true'> *</span></label>
              <input id="business_duns" required="" name="business_duns" type="text" value="<?php echo $business_duns; ?>">           
              <div class="help-block with-errors"></div>
            </div>
          </div>
          <div id="cage_code_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
            <div class="form-group">
              <label for="cage_code"><?php _e('CAGE Code', 'paid-memberships-pro'); ?></label>
              <input id="cage_code" name="cage_code" type="text" value="<?php echo $cage_code; ?>">            
              <div class="help-block with-errors"></div>
            </div>
          </div>  
        </div>
        <div class="row">
          <div id="organization_type_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
            <div class="form-group">            
              <label for="organization_type"><?php _e('Organization Type', 'paid-memberships-pro'); ?><span class='required' aria-required='true'> *</span></label>
              <select id="corganization_type" name="corganization_type" required="" class="input ">
                <?php
                $incubatorId = get_user_meta($current_user->ID, 'incubator_id', true);
                if (empty($incubatorId)) {
                  ?><option value="">Organization Type</option><?php } ?>
                <option  data-levelid="1" value="Corporate:_Less_than_$10M_Annual_Revenue" <?php
                if (!empty($corganization_type)) {
                  selected($corganization_type, 'Corporate:_Less_than_$10M_Annual_Revenue');
                }
                ?>>Corporate: Less than $10M Annual Revenue</option>

                <?php if (empty($incubatorId)) { ?>
                  <option data-levelid="2" value="Corporate:_$10M-$50M_Annual_Revenue" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Corporate:_$10M-$50M_Annual_Revenue');
                  }
                  ?>>Corporate: $10M-$50M Annual Revenue</option>
                  <option data-levelid="3" value="Corporate:_$50M-$100M_Annual_Revenue" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Corporate:_$50M-$100M_Annual_Revenue');
                  }
                  ?> >Corporate: $50M-$100M Annual Revenue</option>
                  <option data-levelid="4" value="Corporate:_More_than_$100M_Annual_Revenue" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Corporate:_More_than_$100M_Annual_Revenue');
                  }
                  ?>>Corporate: More than $100M Annual Revenue</option>
                  <option data-levelid="7" value="Non-Corporate:_College_or_University"  <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Non-Corporate:_College_or_University');
                  }
                  ?>>Non-Corporate: College or University</option>
                  <option data-levelid="8" value="Non-Corporate:_Laboratory" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Non-Corporate:_Laboratory');
                  }
                  ?>>Non-Corporate: Laboratory</option>
                  <option data-levelid="6" value="Non-Corporate:_Technology_Incubator_or_Accelerator" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Non-Corporate:_Technology_Incubator_or_Accelerator');
                  }
                  ?>>Non-Corporate: Technology Incubator or Accelerator</option>
                  <option data-levelid="9" value="Non-Corporate:_Investor" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Non-Corporate:_Investor');
                  }
                  ?>>Non-Corporate: Investor</option>
                  <option data-levelid="5" value="Non-Profit:_Less_than_$50M_Annual_ Revenue" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Non-Profit:_Less_than_$50M_Annual_ Revenue');
                  }
                  ?>>Non-Profit: Less than $50M Annual Revenue</option>
                  <option data-levelid="10" value="Non-Profit:_$50M-$100M_Annual_Revenue" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Non-Profit:_$50M-$100M_Annual_Revenue');
                  }
                  ?>>Non-Profit:$50M-$100M Annual Revenue</option>

                  <option data-levelid="11" value="Non-Profit:_More_than_$100M_Annual_Revenue" <?php
                  if (!empty($corganization_type)) {
                    selected($corganization_type, 'Non-Profit:_More_than_$100M_Annual_Revenue');
                  }
                  ?>>Non-Profit:More than $100M Annual Revenue</option>
                        <?php } ?>

              </select>
              <div class="help-block with-errors"></div>
            </div>          
            <div class="organization_type_toggle" style="display:none">
              <div id="selectall_div" class="pmpro_checkout-field form-group">
                <div class="form-group">
                  <label for="call_apply"><?php _e('Additional Details', 'paid-memberships-pro'); ?></label>
                  <select id="call_apply" name="call_apply[]" required multiple="multiple" class="input ">
                    <option value="small_business" <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, 'small_business');
                    }
                    ?>>Small Business</option>
                    <option value="HUBZone"  <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, 'HUBZone');
                    }
                    ?>>HUBZone</option>
                    <option value="Women-owned"  <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, 'Women-owned');
                    }
                    ?>>Women-owned</option>
                    <option value="SDVOSB" <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, 'SDVOSB');
                    }
                    ?>>SDVOSB</option>
                    <option value="Minority-owned" <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, 'Minority-owned');
                    }
                    ?>>Minority-owned</option>
                    <option value="<$50M_of_work_with_DoD_last_year" <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, '<$50M_of_work_with_DoD_last_year');
                    }
                    ?>><$50M of work with DoD last year</option>
                    <option value="Synthetic_Terrain" <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, 'Synthetic_Terrain');
                    }
                    ?>>Synthetic Terrain</option>
                    <option value="Other" <?php
                    if (!empty($call_apply)) {
                      echo nstxl_multiselect_selected($call_apply, 'Other');
                    }
                    ?>>Other</option>
                  </select>                
                  <div class="help-block with-errors"></div>
                </div>
              </div> 
            </div>

          </div>
          <div id="numberofemployees_div" class="pmpro_checkout-field col-sm-12 col-lg-6">
            <div class="form-group">
              <label for="cnumberofemployees"><?php _e('Number Of Employees', 'paid-memberships-pro'); ?><span class='required' aria-required='true'> *</span></label>
              <select id="cnumberofemployees" name="cnumberofemployees" required="" class="input ">
                <option value="">Number Of Employees</option>
                <option value="1-19_Employees" <?php
                if (!empty($cnumberofemployees)) {
                  selected($cnumberofemployees, '1-19_Employees');
                }
                ?>>1-19 Employees</option>
                <option value="20-99_Employees" <?php
                if (!empty($cnumberofemployees)) {
                  selected($cnumberofemployees, '20-99_Employees');
                }
                ?>>20-99 Employees</option>
                <option value="100-499_Employees"  <?php
                if (!empty($cnumberofemployees)) {
                  selected($cnumberofemployees, '100-499_Employees');
                }
                ?>>100-499 Employees</option>
                <option value="500-2,499_Employees" <?php
                if (!empty($cnumberofemployees)) {
                  selected($cnumberofemployees, '500-2,499_Employees');
                }
                ?>>500-2,499 Employees</option>
                <option value="5,000+_Employees" <?php
                if (!empty($cnumberofemployees)) {
                  selected($cnumberofemployees, '5,000+_Employees');
                }
                ?>>5,000+ Employees</option>
              </select>            
              <div class="help-block with-errors"></div>
            </div>
          </div>
        </div>  
        <div id="publicly_traded_div" class="pmpro_checkout-field clearfix">
          <p><strong><?php _e('Is your firm publicly traded?', 'paid-memberships-pro'); ?></strong></p>
          <label class="pmprorh_checkbox_label checkbox" for="publicly_traded">      
            <input name="publicly_traded" value="yes" class="publicly_traded" type="radio" <?php
            if (!empty($publicly_traded)) {
              checked($publicly_traded, 'yes');
            }
            ?>>&nbsp;<?php _e('Yes', 'paid-memberships-pro'); ?></input>
            &nbsp;&nbsp;<input name="publicly_traded" value="no" class="publicly_traded" type="radio" <?php
            if (!empty($publicly_traded)) {
              checked($publicly_traded, 'no');
            }
            ?>>&nbsp;<?php _e('No', 'paid-memberships-pro'); ?></input>
          </label>
          <div class="publicly_traded_toggle clearfix" <?php
          if ($publicly_traded == 'yes') {
            echo 'style="display:block"';
          } else {
            echo 'style="display:none"';
          }
          ?>>            
            <div class="pmpro_checkout-field pmpro_checkout-field-tricker-symbol">
              <p><strong><?php _e('Ticker Symbol?', 'paid-memberships-pro'); ?></strong></p>
              <div class="form-group">
                <label class="pmprorh_checkbox_label checkbox" for="ticker_symbol"><?php _e('Please enter your Stock Symbol', 'paid-memberships-pro'); ?></label>
                <input id="ticker_symbol" pattern="^[_A-z0-9]{1,}$" name="ticker_symbol" type="text" class="input" size="30" value="<?php echo $ticker_symbol; ?>">
                <div class="help-block with-errors"></div>
              </div>
            </div>
          </div>
          <div>
            <div id="are_you_start_up_div" class="pmpro_checkout-field clearfix">
              <p><strong><?php _e('Is your firm a start-up?', 'paid-memberships-pro'); ?></strong></p>
              <label class="pmprorh_checkbox_label checkbox" for="are_you_start_up">
                <input name="are_you_start_up" <?php checked($are_you_start_up, 'yes'); ?> value="yes" class="are_you_start_up" type="radio">&nbsp;<?php _e('Yes', 'paid-memberships-pro'); ?></input>
                &nbsp;&nbsp;<input name="are_you_start_up" <?php checked($are_you_start_up, 'no'); ?> value="no" class="are_you_start_up" type="radio">&nbsp;<?php _e('No', 'paid-memberships-pro'); ?></input>
              </label>
            </div>
            <div id="are_you_start_up_toggle_div" class="pmpro_checkout-field" <?php
            if ($are_you_start_up == 'yes') {
              echo 'style="display:block"';
            } else {
              echo 'style="display:none"';
            }
            ?>>
              <p>We love working with start-ups!  But to verify that your firm meets the criteria for membership, we need a bit more information.</p>
              <div id="have_you_incorporated_div" class="pmpro_checkout-field clearfix">
                <div class="form-group">
                <label class="pmprorh_checkbox_label checkbox" for="have_you_incorporated"><input name="have_you_incorporated" value="yes" id="have_you_incorporated" type="checkbox" <?php checked($have_you_incorporated, 'yes'); ?>><span>Have you incorporated?  If so, in what state and under what name?</span><span class="checkmark"></span></label>
                </div>
                <div class="have_you_incorporated_div_toggle" style="display:none">
                  <div class="pmpro_checkout-field pmpro_checkout-field-have-you-incorporated">
                    <div class="form-group">
                      <label for="incorporated_state">State of Incorporation</label>
                      <select id="incorporated_state" name="incorporated_state">
                        <option value=""><?php _e('State of Incorporation', 'paid-memberships-pro'); ?></option>
                        <option value="AL" <?php selected($incorporated_state, 'AL'); ?> >Alabama</option>
                        <option value="AK" <?php selected($incorporated_state, 'AK'); ?>>Alaska</option>
                        <option value="AZ" <?php selected($incorporated_state, 'AZ'); ?>>Arizona</option>
                        <option value="AR" <?php selected($incorporated_state, 'AR'); ?>>Arkansas</option>
                        <option value="CA" <?php selected($incorporated_state, 'CA'); ?>>California</option>
                        <option value="CO" <?php selected($incorporated_state, 'CO'); ?>>Colorado</option>
                        <option value="CT" <?php selected($incorporated_state, 'CT'); ?>>Connecticut</option>
                        <option value="DE" <?php selected($incorporated_state, 'DE'); ?>>Delaware</option>
                        <option value="DC" <?php selected($incorporated_state, 'DC'); ?>>District Of Columbia</option>
                        <option value="FL" <?php selected($incorporated_state, 'FL'); ?>>Florida</option>
                        <option value="GA" <?php selected($incorporated_state, 'GA'); ?>>Georgia</option>
                        <option value="HI" <?php selected($incorporated_state, 'HI'); ?>>Hawaii</option>
                        <option value="ID" <?php selected($incorporated_state, 'ID'); ?>>Idaho</option>
                        <option value="IL" <?php selected($incorporated_state, 'IL'); ?>>Illinois</option>
                        <option value="IN" <?php selected($incorporated_state, 'IN'); ?>>Indiana</option>
                        <option value="IA" <?php selected($incorporated_state, 'IA'); ?>>Iowa</option>
                        <option value="KS" <?php selected($incorporated_state, 'KS'); ?>>Kansas</option>
                        <option value="KY" <?php selected($incorporated_state, 'KY'); ?>>Kentucky</option>
                        <option value="LA" <?php selected($incorporated_state, 'LA'); ?>>Louisiana</option>
                        <option value="ME" <?php selected($incorporated_state, 'ME'); ?>>Maine</option>
                        <option value="MD" <?php selected($incorporated_state, 'MD'); ?>>Maryland</option>
                        <option value="MA" <?php selected($incorporated_state, 'MA'); ?>>Massachusetts</option>
                        <option value="MI" <?php selected($incorporated_state, 'MI'); ?>>Michigan</option>
                        <option value="MN" <?php selected($incorporated_state, 'MN'); ?>>Minnesota</option>
                        <option value="MS" <?php selected($incorporated_state, 'MS'); ?>>Mississippi</option>
                        <option value="MO" <?php selected($incorporated_state, 'MO'); ?>>Missouri</option>
                        <option value="MT" <?php selected($incorporated_state, 'MT'); ?>>Montana</option>
                        <option value="NE" <?php selected($incorporated_state, 'NE'); ?>>Nebraska</option>
                        <option value="NV" <?php selected($incorporated_state, 'NV'); ?>>Nevada</option>
                        <option value="NH" <?php selected($incorporated_state, 'NH'); ?>>New Hampshire</option>
                        <option value="NJ" <?php selected($incorporated_state, 'NJ'); ?>>New Jersey</option>
                        <option value="NM" <?php selected($incorporated_state, 'NM'); ?>>New Mexico</option>
                        <option value="NY" <?php selected($incorporated_state, 'NY'); ?>>New York</option>
                        <option value="NC" <?php selected($incorporated_state, 'NC'); ?>>North Carolina</option>
                        <option value="ND" <?php selected($incorporated_state, 'ND'); ?>>North Dakota</option>
                        <option value="OH" <?php selected($incorporated_state, 'OH'); ?>>Ohio</option>
                        <option value="OK" <?php selected($incorporated_state, 'OK'); ?>>Oklahoma</option>
                        <option value="OR" <?php selected($incorporated_state, 'OR'); ?>>Oregon</option>
                        <option value="PA" <?php selected($incorporated_state, 'PA'); ?>>Pennsylvania</option>
                        <option value="RI" <?php selected($incorporated_state, 'RI'); ?>>Rhode Island</option>
                        <option value="SC" <?php selected($incorporated_state, 'SC'); ?>>South Carolina</option>
                        <option value="SD" <?php selected($incorporated_state, 'SD'); ?>>South Dakota</option>
                        <option value="TN" <?php selected($incorporated_state, 'TN'); ?>>Tennessee</option>
                        <option value="TX" <?php selected($incorporated_state, 'TX'); ?>>Texas</option>
                        <option value="UT" <?php selected($incorporated_state, 'UT'); ?>>Utah</option>
                        <option value="VT" <?php selected($incorporated_state, 'VT'); ?>>Vermont</option>
                        <option value="VA" <?php selected($incorporated_state, 'VA'); ?>>Virginia</option>
                        <option value="WA" <?php selected($incorporated_state, 'WA'); ?>>Washington</option>
                        <option value="WV" <?php selected($incorporated_state, 'WV'); ?>>West Virginia</option>
                        <option value="WI" <?php selected($incorporated_state, 'WI'); ?>>Wisconsin</option>
                        <option value="WY" <?php selected($incorporated_state, 'WY'); ?>>Wyoming</option>
                        <option value="outside_us" <?php selected($incorporated_state, 'outside_us'); ?>>Outside the United States</option>
                      </select>                     
                    </div>
                  </div>
                </div>
              </div>

              <div id="how_are_you_financed_div" class="pmpro_checkout-field clearfix">
                <div class="form-group">
                <label for="how_are_you_financed">How are you financed?</label>
                <select id="how_are_you_financed" multiple="" name="how_are_you_financed[]" class="input">                  
                  <option value="Self-financed" <?php
                  if (!empty($how_are_you_financed)) {
                    nstxl_multiselect_selected($how_are_you_financed, 'Self-financed');
                  }
                  ?> >Self-financed</option>>Self-financed</option>
                  <option value="Venture capital" <?php
                  if (!empty($how_are_you_financed)) {
                    nstxl_multiselect_selected($how_are_you_financed, 'Venture capital');
                  }
                  ?>>Venture capital</option>
                  <option value="Angel financing" <?php
                  if (!empty($how_are_you_financed)) {
                    nstxl_multiselect_selected($how_are_you_financed, 'Angel financing');
                  }
                  ?>>Angel financing</option>
                  <option value="Loans" <?php
                  if (!empty($how_are_you_financed)) {
                    nstxl_multiselect_selected($how_are_you_financed, 'Loans');
                  }
                  ?>>Loans</option>
                  <option value="Friends and family" <?php
                  if (!empty($how_are_you_financed)) {
                    nstxl_multiselect_selected($how_are_you_financed, 'Friends and family');
                  }
                  ?>>Friends and family</option>                
                </select>
                </div>                
              </div>
            </div>
          </div>
        </div>

        <div id="technology_solutions_or_services_div" class="pmpro_checkout-field">
          <div class="form-group"><?php $technology_solutions_services = get_user_meta(get_current_user_id(), 'technology_solutions_services', true); ?>
            <label for="technology_solutions_services"><?php _e('Tell us more about your firm', 'paid-memberships-pro'); ?></label>        
            <textarea id="technology_solutions_or_services" name="technology_solutions_services" rows="2" cols="60" class="input text" ><?php
              if (!empty($technology_solutions_services)) {
                echo $technology_solutions_services;
              }
              ?></textarea>
          </div>
          <div class="help-block with-errors"></div>
        </div>  

        <!-- Start of Have your company logo section-->
        <div id="have_your_company_logo_div" class="pmpro_checkout-field clearfix">
          <label class="pmprorh_checkbox_label checkbox" for="have_your_company_logo"><input name="have_your_company_logo" value="yes" id="have_your_company_logo" type="checkbox" <?php
            if (!empty($have_your_company_logo)) {
              checked($have_your_company_logo, 'yes');
            }
            ?>><span class="checkmark_text"><?php _e('Check here to have your company name and/or logo appear on our Membership page', 'paid-memberships-pro'); ?></span><span class="checkmark"></span></label>
          <div class="have_your_company_logo_div_toggle1">
            <div class="pmpro_checkout-field pmpro_checkout-field-is-have-your-company-logo">    
              <a class="upload_comp_btn btn-txt" href="#"><?php _e('Upload Your Company Logo', 'paid-memberships-pro'); ?></a>
              <div id="ibenic_file_upload" class="file-upload" style="display:none;">
                <input id="upload_comp_file" name="upload_comp_file" type="file" style="opacity:0;" style="display:none;">
                <p class="ibenic_file_upload_text"></p>
              </div> <!-- End ibenic_file_upload div-->

              <div id="ibenic_comp_file_upload_preview" class="file-upload file-preview" <?php
              if (empty($uploaded_comp_url)) {
                echo 'style="display:none"';
              }
              ?> >
                <div class="ibenic_comp_file_preview"><?php
                  if (!empty($uploaded_comp_url)) {
                    echo '<img src="' . $uploaded_comp_url . '" alt="Company Logo" title="Company Logo">';
                  }
                  ?> 
                </div><!-- End ibenic_comp_file_preview div-->
                <button data-fileurl="<?php
                if (!empty($uploaded_comp_url)) {
                  echo $uploaded_comp_url;
                }
                ?>" class="ibenic_file_delete_comp btn btn-secondary">
                  <i class="fa fa-close"></i><?php //_e( 'Delete', 'paid-memberships-pro' );     ?>
                </button> 
                <input type="hidden" name="chk_comp_doc" id="chk_comp_doc">
              </div><!-- End ibenic_file_upload_preview div-->     
              <div class="tooltip1"><img src="<?php echo nstxl_tooltip_icon; ?>" width="17px" height="17px"> <span class="tooltiptext1"> The logo will solely be used for display on the website and by uploading the logo the registrant is authorized to provide permission on behalf of their organization.</span></div>
               <div class="ibenic_upload_message"></div>
            </div><!-- End pmpro_checkout-field-is-have-your-company-logo div-->
          </div><!-- End have_your_company_logo_div_toggle div-->
        </div><!-- End of Have your company logo div-->
        <!-- End of Have your company logo section-->

      </div>
    </div><!--End step2 content-->
  </div>
</div>
<?php /* ?>
  <style>#primary_domain_interest_div ul.multiselect-container.dropdown-menu li a label .help-block.with-errors{display: none}</style>
  <?php */ ?>