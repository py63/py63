<?php

global $post;
if(!empty($oppid))
{
	$repeater_eventdates = get_field('opportunity_dates', $oppid);
}
else{
	$repeater_eventdates = get_field('opportunity_dates');
}


// echo '<pre>';
// print_r($repeater_eventdates);
// echo '<pre>';

if(isset($repeater_eventdates) && !empty($repeater_eventdates)){
?>

<aside class="aside-opportunity-content widget">
 <div class="widget-content">
 <div class="table table-responsive">
 <form method="post" name="eventdates-<?php if(!empty($oppid)){ echo $oppid; } else{ echo get_the_ID(); } ?>" id="eventdates-<?php if(!empty($oppid)){ echo $oppid; } else{ echo get_the_ID(); } ?>" novalidate="novalidate">
 <input type="hidden" name="action" value="nstxl_eventdates_download">
 <table class="table table-striped table-bordered table-hover">
 <thead>
 <tr> 
 <th><h2 class="widget-title">PROJECT TIMELINE</h2></th>
 <th><div class="hidden-check"><input type="checkbox" id="select_all_eventdates-<?php if(!empty($oppid)){ echo $oppid; } else{ echo get_the_ID(); } ?>" value=""><label class="select_all_eventdates" for="select_all_eventdates-<?php if(!empty($oppid)){ echo $oppid; } else{ echo get_the_ID(); } ?>">Select All</label></div></th>
 </tr>
 </thead>
 <tbody> 
 <?php
	 foreach( $repeater_eventdates as $key => $row )
 	{ 
  	 $column_id[ $key ] = $row['opportunity_all_dates'];
  	} 
    array_multisort( $column_id, SORT_ASC, $repeater_eventdates );
    foreach( $repeater_eventdates as $key => $row ) :
      {
   	?>
 <tr>
 <td>
 	<?php  
 		$date = $row['opportunity_all_dates']; 
 		echo  $row['opportunity_date_text'] .' - '. date("M d, Y g:i A", strtotime($date));
	?>	
</td>
 <td class="td-right"><div class="custom-control custom-checkbox mb-3">
 <input type="checkbox" name="eventdates[]" class="custom-control-input eventdatescheck" id="eventdates<?php echo $key; ?>" data-id="<?php echo $key; ?>" value="<?php echo date("M d, Y g:i A", strtotime($date)); ?>">
 <label class="custom-control-label" for="eventdates<?php echo $key; ?>">&nbsp;</label>
 </div>
 </td>
 </tr>
 <tr>
<?php
}
endforeach;
?>

 <td colspan="3" class="text-right"><!-- Button code -->
<div title="Add to Calendar" class="addeventatc">
    Add to Calendar

    <?php
//    foreach( $repeater_eventdates as $key => $row )
//   { 
//      $column_id[ $key ] = $row['opportunity_all_dates'];
//     } 
//     array_multisort( $column_id, SORT_ASC, $repeater_eventdates );
//     foreach( $repeater_eventdates as $key => $row ) :
//       {
//     $date = $row['opportunity_all_dates']; 
//     echo '<span class="start">'. date("M d, Y g:i A", strtotime($date)).'</span>';
// }
// endforeach;
?>
<?php
      foreach( $repeater_eventdates as $row )
      {
        $date = $row['opportunity_all_dates'];
        ?>
    <span class="start"><?php echo date("m/d/Y", strtotime($date)); ?></span>

    <span class="title">
      <?php
        if(!empty($oppid))
      {
        echo get_the_title($oppid) .' - '. date("M d, Y g:i A", strtotime($date));
      }
      else{
        echo get_the_title(get_the_ID()) .' - '. date("M d, Y g:i A", strtotime($date));
      }
      ?>
    </span>
    
    <span class="description">
      <?php
   if(!empty($oppid))
      {
        echo get_the_content($oppid);
      }
      else{
        echo get_the_content(get_the_ID());
      }
      ?>
    </span>
    <?php
    }
      ?>
    
</div></td>
 </tr>
 </tbody>
 </table>
 </form>
 </div>
 </div>
 </aside>

   <script type="text/javascript">
    jQuery(document).ready(function ($) {
      var opriD = '<?php echo get_the_ID();?>';
      if ($('.eventdatescheck:checked').length != 0) {
        $('.addeventatc').prop('disabled', false);
      } else {
        $('.addeventatc').css("pointer-events", "none");
      }
      $('#select_all_eventdates-'+opriD).on('click', function () {
        if (this.checked) {
          $('.eventdatescheck').each(function () {
            this.checked = true;
           $('.addeventatc').css("pointer-events", "auto");
          });
        } else {
          $('.eventdatescheck').each(function () {
            this.checked = false;
           $('.addeventatc').css("pointer-events", "none");
          });
        }
      });

      $('.eventdatescheck').on('click', function () {
        if ($('.eventdatescheck:checked').length == $('.eventdatescheck').length) {
          $('#select_all_eventdates-'+opriD).prop('checked', true);
        } else {
          $('#select_all_eventdates-'+opriD).prop('checked', false);
        }

        if ($('.eventdatescheck:checked').length != 0) {
        $('.addeventatc').css("pointer-events", "auto");
        } else {
          $('.addeventatc').css("pointer-events", "none");
        }
      });
    });
  </script>
 <?php
}
else{
	echo "<h4>Proposal date not found.</h4>";
}
 