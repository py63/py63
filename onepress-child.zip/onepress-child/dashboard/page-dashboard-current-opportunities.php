<?php
/*
 * Template Name: Dashboard Current Opportunities
 *
 * @package OnePress
 */
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
get_header('admin');
$term = get_term_by('slug', 'current-opportunities', 'opportunity-type');
if (!empty($term)) {
  $termID = $term->term_id;
} else {
  $termID = "";
}
global $current_user;
$cusr_id = $current_user->ID;
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  // [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' );  ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>
              <!--Star of container -->
              <div class="current-opportunities-container opportunity-dashbaord-grid dashboard-inner-wrapper">
                <div class="row">
                  <?php /* ?>
                  <div class="clearfix col-sm-12">
                    <h3 class="rgs_title clearfix"><?php _e(the_title(), 'paid-memberships-pro'); ?></h3>
                  </div>
                <?php */ ?>
                  <div class="search-wrapper clearfix col-sm-12">   
                    <?php  ?>         
                      <div class="member-search-container pull-right form-01">
                      <?php $unique_id = esc_attr( uniqid( 'search-form-' ) ); ?>
                      <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>/dashboard-search">
                      <input type="search" id="<?php echo $unique_id; ?>" class="search-field" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'polar' ); ?>" value="<?php echo get_search_query(); ?>" name="sa" />
                      <input type="hidden" name="term_id" value="<?php echo $termID; ?>"/>
                      <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text"><?php echo _x( 'Search', 'submit button', 'polar' ); ?></span></button>
                      </form>
                      </div>
                      <?php ?>           
                    <?php /* ?><div class="btn-group pull-right"><button class="btn btn-magenta" type="button"><?php _e('Tracked Opportunities','paid-memberships-pro'); ?></button>
                      </div>
                      <?php */ ?>
                  </div>
                </div>  
                <div class="opportunity-tracker-inner opportunity-content">         
                  <!-- Blog Query  -->
                  <div class="opportunity-posts">

                    <?php
                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    // $args = array('post_type' => 'post','category__not_in' => 34, 'posts_per_page' => 6, 'paged' => $paged );

                    $args = array('post_type' => 'opportunity', 'posts_per_page' => 6, 'tax_query' => array(
                            'relation' => 'or',
                            array(
                                'taxonomy' => 'opportunity-type',
                                'field' => 'slug',
                                'terms' => 'current-opportunities',
                            ),
                            array(
                                'taxonomy' => 'opportunity-type',
                                'field' => 'term_id',
                                'terms' => $termID,
                            )
                        ), 'paged' => $paged);

                    //query_posts($args); 
                    $Newquery = new WP_Query($args);
                    ?>
                    <!-- the loop -->
                    <div class="card-deck">
                      <?php
                      if ($Newquery->have_posts()) : while ($Newquery->have_posts()) : $Newquery->the_post();
                          include(locate_template('templates/opportunity/main-tabs/content-opportunities.php'));
                          endwhile;
                        ?>
                      <?php else : ?>
                        <!-- No posts found -->
                        <div class="text-center"><h3>No Current opportunities found</h3></div>
                      <?php endif; ?>
                    </div>   

                    <div class="loadmore wow animated fadeInUp" id="loadmores"><?php echo get_next_posts_link('Load more', $Newquery->max_num_pages); ?></div>
                    <!-- End of Blog Query -->
                  </div>
                  <?php wp_reset_query(); ?>
                </div>
              </div> 

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->



  </div><!--#content-inside -->
</div><!-- #content -->

<script>
  jQuery(document).ready(function ($) {
    trackOpportunity();
    untrackOpportunity();
    $('body').on('click', '.loadmore a', function (e) {
      e.preventDefault();
      var temphref = $(this).attr('href');
      $("#loadmores").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> Loading...</div>");

      $.post(temphref, function (response) {
        $("#loadmores").remove();
        var tempdata = $(response).find('.polar-posts').html();
        $(".polar-posts").append(tempdata);
        trackOpportunity();
        untrackOpportunity();
      });
    });

    jQuery('.close').on('click', function (e) {
      jQuery('#update-personalinfo-modal-success').modal('hide');
    });
    jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
      location.reload(true);
    })
  });
</script>
<?php get_footer('admin'); ?>
