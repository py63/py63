jQuery(document).ready(function($) {
	$('#myslidgallery_table').DataTable();
    $('#myslidgallery_table_detail').DataTable();
    alert(1254);
} );

