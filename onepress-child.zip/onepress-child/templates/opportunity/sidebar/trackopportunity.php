<?php $cusr_id = get_current_user_id();
 if (is_user_logged_in())  {  
    $trckid = get_the_ID();    
    $mytrackIDs = get_user_meta($cusr_id,'myopportunitiesposts',true);
    if(!empty($mytrackIDs)){
       if (in_array($trckid, $mytrackIDs)) {   ?>
         <a class="trkoppo untrackopportunity" data-id="<?php echo get_the_ID(); ?>" href="#"><button class=""><?php _e('Untrack Opportunity','onpress'); ?></button></a>
    <?php  } else { ?>
        <a href="#" class="trkoppo trackopportunity" data-id="<?php echo get_the_ID(); ?>"><button class=""><?php _e('Track Opportunity','onpress'); ?></button></a>
     <?php }        
    } else { ?>      
        <a href="#" class="trkoppo trackopportunity" data-id="<?php echo get_the_ID(); ?>"><button class=""><?php _e('Track Opportunity','onpress'); ?></button>
        </a>   
   <?php  }
} else { ?>    
        <a  href="<?php echo esc_url(get_bloginfo('url')); ?>/login?redirect_to=<?php echo urlencode(get_bloginfo( 'url' ).'/tracked-opportunities'); ?>" class="trkoppo"><button class=""><?php _e('Track Opportunity','onpress'); ?></button></a>
<?php } ?> 
<?php 
$modal_id = 'track-opportunity-modal-'.get_the_ID();
$modal_body_container_class  = 'track-opportunity-modal-container';
$content_html = '';
nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class);
?>  
<script type="text/javascript">
jQuery(document).ready(function($) {
    trackOpportunity();
    untrackOpportunity();
    $('body').on('click', '.loadmore a', function(e){
        e.preventDefault();
        var temphref=$(this).attr('href');
        $("#loadmores").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> <img src='"+loademoreimg+"' /> Loading...</div>");

        $.post(temphref,function(response) {
            $("#loadmores").remove();
            var tempdata=$(response).find('.opportunity-posts').html();
            $(".opportunity-posts").append(tempdata);
            trackOpportunity();
            untrackOpportunity();
        });
    });

    jQuery('#<?php echo $modal_id; ?> .close').on('click', function(e){
        jQuery('#<?php echo $modal_id; ?>').modal('hide');      
    }); 
        jQuery('#<?php echo $modal_id; ?>').on('hidden.bs.modal', function () {    
      location.reload(true);
    })  
});
</script>