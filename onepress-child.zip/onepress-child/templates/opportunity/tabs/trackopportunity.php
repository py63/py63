<?php $cusr_id = get_current_user_id();
 if (is_user_logged_in())  {  
    $trckid = get_the_ID();    
    $mytrackIDs = get_user_meta($cusr_id,'myopportunitiesposts',true);
    if(!empty($mytrackIDs)){
       if (in_array($trckid, $mytrackIDs)) {   ?>
         <a class="untrackopportunity" data-id="<?php echo get_the_ID(); ?>" href="#"><button class="polar_button  polar-shape-square polar-size-custom polar-style-flat polar-icon-left"><?php _e('Untrack Opportunity','polar'); ?></button></a>
    <?php  } else { ?>
        <a href="#" class="trackopportunity" data-id="<?php echo get_the_ID(); ?>"><button class="polar_button  polar-shape-square polar-size-custom polar-style-flat polar-icon-left"><?php _e('Track Opportunity','polar'); ?></button></a>
     <?php }        
    } else { ?>      
        <a href="#" class="trackopportunity" data-id="<?php echo get_the_ID(); ?>"><button class="polar_button  polar-shape-square polar-size-custom polar-style-flat polar-icon-left"><?php _e('Track Opportunity','polar'); ?></button>
        </a>   
   <?php  }
} else { ?>    
    <a href="<?php echo esc_url(get_bloginfo('url')); ?>/login?redirect_to=<?php echo urlencode(get_bloginfo( 'url' ).'/opportunity-tracker'); ?>"><button class="polar_button  polar-shape-square polar-size-custom polar-style-flat polar-icon-left"><?php _e('Track Opportunity','polar'); ?></button></a>
<?php } ?> 
  <!-- Modal -->
  <div class="modal fade" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" aria-hidden="true">&times;</button> 
          <div class="update-personalinfo-box-success-container">
            <p></p> 
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
  </div> 
  <!-- /.modal --> 
<script type="text/javascript">
jQuery(document).ready(function($) {
    trackOpportunity();
    untrackOpportunity();
    $('body').on('click', '.loadmore a', function(e){
        e.preventDefault();
        var temphref=$(this).attr('href');
        $("#loadmores").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> <img src='"+loademoreimg+"' /> Loading...</div>");

        $.post(temphref,function(response) {
            $("#loadmores").remove();
            var tempdata=$(response).find('.polar-posts').html();
            $(".polar-posts").append(tempdata);
            trackOpportunity();
            untrackOpportunity();
        });
    });

    jQuery('.close').on('click', function(e){
        jQuery('#update-personalinfo-modal-success').modal('hide');      
    }); 
        jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {    
      location.reload(true);
    })  
});
</script>