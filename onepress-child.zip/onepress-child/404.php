<?php
/**
 * Template Name: 404
 *
 * @package OnePress
 */
get_header();

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
//do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">
<?php
onepress_breadcrumb();
?>
  <div id="elementor-section">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">
      	<?php //while (have_posts()) : the_post(); ?>

          <?php //get_template_part('template-parts/content', 'page'); ?>

        <?php //endwhile; // End of the loop. ?>

     <article >

	<div class="list-article-content">
		<div class="list-article-meta">
			<?php //the_category( ' / ' ); ?>
		</div>
		<header class="entry-header">
			<?php //the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
		</header><!-- .entry-header -->
		<div class="entry-content">
			<?php echo do_shortcode('[elementor-template id="6485"]'); ?>
		</div><!-- .entry-content -->
	</div>

</article>


      </main><!-- #main -->
    </div><!-- #primary -->
  </div><!--#content-inside -->
</div><!-- #content -->

<?php get_footer(); ?>
