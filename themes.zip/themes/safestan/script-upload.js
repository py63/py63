var abc = 0; //Declaring and defining global increement variable
var xyz = 1; //Declaring and defining global increement variable

jQuery(document).ready(function($) {

//To add new input file field dynamically, on click of "Add More Files" button below function will be executed
    /*$('#add_more').click(function() {
        xyz += 1; //increementing global variable by 1
        
        var z = xyz - 1;
        var customId = 'previewimg' + xyz;
        $('#filediv:first-child').before($("<div/>", {id: 'filediv'}).fadeIn('slow').append(
                $("<input/>", {name: 'file[]', type: 'file', id: 'file', imgid: customId })       
                
                ));
    });*/

//following function will executes on change event of file input to select different file	
/*$('body').on('change', '#file', function(){
            if (this.files && this.files[0]) {
                 abc += 1; //increementing global variable by 1
				
				var z = abc - 1;
                var x = $(this).parent().find('#previewimg' + z).remove();
                $('.col-sm-12 .upload-images').append("<div id='abcd"+ abc +"' class='abcd img-inline'><img id='previewimg" + abc + "' src='' class='img-thumb-user'/></div>");
                
                var fileimgName = $(this.files[0]);
                //console.log(fileimgName.name);

			    var reader = new FileReader();
                reader.onload = imageIsLoaded;
                reader.readAsDataURL(this.files[0]);

			    $(this).hide();
                $("#abcd"+ abc).append($("<img/>", {id: 'img', src: homeurl+'/wp-content/themes/safestan/x.png',class:'cross-top', alt: 'delete'}).click(function() {
                $(this).parent().remove();


                var removeImgID = $(this).prev().get(0).id;
                if(removeImgID == 'previewimg1'){
                    $( "input[imgid='"+removeImgID+"']" ).removeAttr('value');
                }else{
                    $( "input[imgid='"+removeImgID+"']" ).parent('div').remove(); 
                    $( "input[imgid='"+removeImgID+"']" ).remove();
                }
                }));
            }
        });*/

//To preview image     
    function imageIsLoaded(e) {
        $('#previewimg' + abc).attr('src', e.target.result);
    };

    $('#upload').click(function(e) {
        var name = $(":file").val();
        //console.log(name);
        //alert(name);
        if (!name)
        {
            if( $(":file").length > 0 && $(".abcd.img-inline").length > 0){
                return;
            
            }
            else{
                    alert( "First image must be selected" );
                    e.preventDefault();
            }

            
        }
        
    });
});
