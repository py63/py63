<?php


global $pmpro_reports;

$pmpro_reports['membersby_company_type_past_thirty_days'] = __('New Member Companies over the past 30 days', 'paid-memberships-pro' );

//widget
function pmpro_report_membersby_company_type_past_thirty_days_widget() {
	global $wpdb;

	$companytype1 = nstxl_members_count_by_company_type_past_thirty_days('Corporate:_Less_than_$10M_Annual_Revenue');
	$companytype2 = nstxl_members_count_by_company_type_past_thirty_days('Corporate:_$10M-$50M_Annual_Revenue');
	$companytype3 = nstxl_members_count_by_company_type_past_thirty_days('Corporate:_$50M-$100M_Annual_Revenue');
	$companytype4 = nstxl_members_count_by_company_type_past_thirty_days('Corporate:_More_than_$100M_Annual_Revenue');
	$companytype5 = nstxl_members_count_by_company_type_past_thirty_days('Non-Corporate:_College_or_University'); 
	$totalcompany = nstxl_members_count_by_company_type_past_thirty_days_total();
	?>

	<span id="pmpro_report_membersby_company_type_past_thirty_days_memberships" class="pmpro_report-holder">
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php _e('Company Type', 'paid-memberships-pro' ); ?></th>
					<th scope="col"><?php _e('All Members', 'paid-memberships-pro' ); ?></th>
				</tr>
				<tr>
					<th scope="col"><strong><?php _e('Total Members', 'paid-memberships-pro' ); ?></strong></th>
					<th scope="col"><strong><?php echo $totalcompany;?></strong></th>
				</tr>
			</thead>

			<tbody>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: Less than $10M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype1; ?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: $10M-$50M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype2;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: $50M-$100M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype3;?></td>

				</tr>

				
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Corporate: More than $100M Annual Revenue', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype4;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Non-Corporate: College or University', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $companytype5;?></td>

				</tr>

				
			</tbody>
			
		</table>
		<?php if ( function_exists( 'pmpro_report_membersby_company_type_past_thirty_days_page' ) ) { ?>
			<p class="pmpro_report-button">
				<a class="button button-primary" href="<?php echo admin_url( 'admin.php?page=pmpro-reports&report=membersby_company_type_past_thirty_days' ); ?>"><?php _e('Details', 'paid-memberships-pro' );?></a>
			</p>
		<?php } ?>
	</span>
	
	<?php
}

function pmpro_report_membersby_company_type_past_thirty_days_page()
{

	global $wpdb;
	
	//vars
	if(!empty($_REQUEST['s']))
		$s = sanitize_text_field( $_REQUEST['s'] );
	else
		$s = "";
	
	if(!empty($_REQUEST['l'])) {
		if($_REQUEST['l'] == 'all')
			$l = 'all';
		else
			$l = intval($_REQUEST['l']);
	} else {
		$l = "";
	}
	?>
	<h1><?php _e('New Member Companies over the past 30 days', 'paid-memberships-pro' ); ?></h1>	
	
<?php /**	
	<form id="posts-filter" method="get" action="">	
		
		<ul class="subsubsub">
			<li>			
				<?php _e( 'Show', 'Dropdown label, e.g. Show All Users', 'paid-memberships-pro' )?> <select name="l" onchange="jQuery('#posts-filter').submit();">
					<option value="" <?php if(!$l) { ?>selected="selected"<?php } ?>><?php _e('All Users', 'paid-memberships-pro')?></option>
					<option value="all" <?php if($l == "all") { ?>selected="selected"<?php } ?>><?php _e('All Levels', 'paid-memberships-pro')?></option>
					<?php
					$levels = $wpdb->get_results("SELECT id, name FROM $wpdb->pmpro_membership_levels ORDER BY name");
					foreach($levels as $level)
					{
						?>
						<option value="<?php echo $level->id?>" <?php if($l == $level->id) { ?>selected="selected"<?php } ?>><?php echo $level->name?></option>
						<?php
					}
					?>
				</select>			
			</li>
		</ul>
		<p class="search-box">
			<label class="hidden" for="post-search-input"><?php _e( 'Search', 'Search form label', 'paid-memberships-pro')?> <?php if(empty($l)) echo "Users"; else echo "Members";?>:</label>
			<input type="hidden" name="page" value="pmpro-reports" />		
			<input type="hidden" name="report" value="membersby_company_type_past_thirty_days" />		
			<input id="post-search-input" type="text" value="<?php echo esc_attr($s)?>" name="s"/>
			<input class="button" type="submit" value="Search Members"/>
		</p>

		**/?>

		<?php 
		//some vars for the search					
		if(isset($_REQUEST['pn']))
			$pn = intval($_REQUEST['pn']);
		else
			$pn = 1;
		
		if(isset($_REQUEST['limit']))
			$limit = intval($_REQUEST['limit']);
		else
			$limit = 15;
		
		$end = $pn * $limit;
		$start = $end - $limit;	
		
		$exclude_users =  nstxl_suspended_users(); 			

		if(!empty($exclude_users))
		{
			$exclude_users = "u.ID NOT IN (".$exclude_users.")";
		}
		else
		{
			$exclude_users = "1=1";    
		}			
		
		if($l)
		{
			$condition = "AND um.meta_key ='corganization_type' AND um.meta_value LIKE '%{$l}%'";

			$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email,mu.status,UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership FROM $wpdb->users u LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->usermeta um1 ON u.ID = um1.user_id LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id";

			$sqlQuery .= " WHERE {$exclude_users} {$condition} AND mu.status = 'active' AND DATE(mu.startdate) BETWEEN NOW() - INTERVAL 30 DAY AND NOW()";

			$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";
			
			$sqlQuery .= "GROUP BY u.ID ORDER BY user_registered DESC LIMIT $start, $limit";
		}
		else
		{

			$condition = "AND um.meta_key ='corganization_type'";

			$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email,mu.status,UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership FROM $wpdb->users u LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->usermeta um1 ON u.ID = um1.user_id LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id";
			
			$sqlQuery .= " WHERE {$exclude_users} {$condition} AND mu.status = 'active' AND DATE(mu.startdate) BETWEEN NOW() - INTERVAL 30 DAY AND NOW()";

			$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

			$sqlQuery .= "GROUP BY u.ID ORDER BY user_registered DESC LIMIT $start, $limit";
		}

		$sqlQuery = apply_filters("pmpro_members_list_sql", $sqlQuery);
		
		$theusers = $wpdb->get_results($sqlQuery);
		$totalrows = $wpdb->get_var("SELECT FOUND_ROWS() as found_rows");
		
		if($theusers)
		{
			?>
			<p class="clear"><h3><?php echo strval($totalrows)?> members found.</h3>		
				<?php		
			}		
			?>
			<table class="widefat">
				<thead>
					<tr class="thead">
						<th><?php _e('First Name', 'paid-memberships-pro')?></th>
						<th><?php _e('Last Name', 'paid-memberships-pro')?></th>	
						<th><?php _e('Email', 'paid-memberships-pro')?></th>
						<th><?php _e('Company Name', 'paid-memberships-pro')?></th>
						<th><?php _e('Membership', 'paid-memberships-pro')?></th>
						<th><?php _e('Joined', 'paid-memberships-pro')?></th>
						<th><?php _e('Expires', 'paid-memberships-pro')?></th>
						<th><?php _e('Membership Status', 'paid-memberships-pro')?></th>

					</tr>
				</thead>
				<tbody id="users" class="list:user user-list">	
					<?php	
					$count = 0;							
					foreach($theusers as $auser)
					{
					//get meta																					
						$theuser = get_userdata($auser->ID);			

						?>
						<tr <?php if($count++ % 2 == 0) { ?>class="alternate"<?php } ?>>
							<td><?php echo $theuser->first_name?></td>
							<td><?php echo $theuser->last_name?></td>										
							<td>
								<?php echo $theuser->user_email;?>
							</td>
							<td><?php echo get_user_meta($auser->ID,'company_name', true); ?></td> 
							<td><?php echo $auser->membership?></td>												
							<td>
								<?php
								$level = pmpro_getMembershipLevelForUser( $theuser->ID );
								if ( ! empty( $level ) && ! empty( $level->startdate ) ) {
									echo date( "M d, Y g:i A", $level->startdate );
								} else {
									echo "N/A";
								}
								?>
							</td>
							<td>
								<?php
								if($auser->enddate)
									echo apply_filters("pmpro_memberslist_expires_column", date_i18n("M d, Y g:i A", $auser->enddate), $auser);
								else
									echo __(apply_filters("pmpro_memberslist_expires_column", "Never", $auser), "pmpro");
								?>
							</td>
							<td><?php echo ucfirst($auser->status);?></td>
						</tr>
						<?php
					}
					
					if(!$theusers)
					{
						?>
						<tr>
							<td colspan="9"><p><?php _e('No members found.', 'paid-memberships-pro')?> <?php if($l) { ?><a href="?page=pmpro-reports&report=membersby_company_type_past_thirty_days&s=<?php echo esc_attr($s)?>"><?php _e('Search all levels', 'paid-memberships-pro')?></a>.<?php } ?></p></td>
						</tr>
						<?php
					}
					?>		
				</tbody>
			</table>
			<!--	</form> -->

			<?php
			echo pmpro_getPaginationString($pn, $totalrows, $limit, 1, get_admin_url(NULL, "/admin.php?page=pmpro-reports&report=membersby_company_type_past_thirty_days&s=" . urlencode($s)), "&l=$l&limit=$limit&pn=");
			?>
			<?php
		}




