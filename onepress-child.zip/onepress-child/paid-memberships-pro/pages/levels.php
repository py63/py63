<?php
global $wpdb, $pmpro_msg, $pmpro_msgt, $current_user;
//echo $current_user->roles;

/** Redirect additional user to membership account page. * */
$puid = nstxl_get_parent_userid($current_user->ID);
if (!empty($puid)) {
  if ($puid != $current_user->ID) {
    wp_redirect(get_bloginfo('url') . '/membership-account/', 301);
    exit;
  }
}
/** Redirect additional user to membership account page. * */
$incubatorId = nstxl_getIncubatorId($current_user->ID);
if (!empty($incubatorId) && in_array('subscriber', (array) $current_user->roles)) {
  $sponsored_data = get_user_meta($incubatorId, 'sponsored_users', true);
  if (!empty($sponsored_data)) {
    $key = array_search($current_user->ID, $sponsored_data);
    if ($key !== false) {
      wp_redirect(get_bloginfo('url') . '/membership-account/membership-checkout/?level=1', 301);
      exit;
    }
  }
}

$pmpro_levels = pmpro_getAllLevels(false, true);
$pmpro_level_order = pmpro_getOption('level_order');

$expiredStatus = '';
$expiredMembId = '';
if (is_user_logged_in()) {
  $user = wp_get_current_user();
  $role = (array) $user->roles;
  $expiredMemberIds = nstxl_get_membership_status_expired_user($user->ID);
  //print_r($expiredMemberIds);
  if (!empty($expiredMemberIds)) {
    foreach ($expiredMemberIds as $expiredMemberId) {
      $expiredStatus = $expiredMemberId->status;
      $expiredMembId = $expiredMemberId->membership_id;
    }
    //if( ($role[0] == 'subscriber') && ($expiredMemberIds[0]->status != 'expired')) {  
    if (!empty($expiredMemberIds[0]->membership_id) && ($expiredMemberIds[0]->status == 'expired')) {
      ?>
      <script>
        jQuery(document).ready(function () {
          jQuery('.renewmembershipdas.expired').modal('show');
        });
      </script>
      <?php
    } else { /* ?>

      <script>
      jQuery(document).ready(function () {
      jQuery('.renewmembershipdas.subscriber').modal('show');
      });
      </script>

      <?php
     */
    }
  } else {
    ?>
    <script>
      jQuery(document).ready(function () {
        jQuery('.renewmembershipdas.subscriber').modal('show');
      });
    </script>
    <?php
  }
}
?>

<?php /**
<!-- Modal -->
<div class="modal fade custom-popup renewmembershipdas expired-membership expired" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="redirect-modalLabel" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/assets/images/close-icon.svg"></span>
        </button>
        <div class="redirect-box-success-container text-center">
          <b class="renew-title">Your NSTXL membership has expired.</b>
          <p class="renew-des">Renew your membership here. If you have any questions contact</p> 
          <div class="renew-button">
            <a class="red-text" href="mailto:membership@nstxl.org">membership@nstxl.org</a>
          </div>
        </div>
      </div> 

      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div> 
</div> 
<!-- /.modal -->
**/?>

<?php
if (!empty($pmpro_level_order)) {
  $order = explode(',', $pmpro_level_order);

  //reorder array
  $reordered_levels = array();
  foreach ($order as $level_id) {
    foreach ($pmpro_levels as $key => $level) {
      if ($level_id == $level->id)
        $reordered_levels[] = $pmpro_levels[$key];
    }
  }

  $pmpro_levels = $reordered_levels;
}

$pmpro_levels = apply_filters("pmpro_levels_array", $pmpro_levels);

if ($pmpro_msg) {
  ?>
  <div class="pmpro_message <?php echo $pmpro_msgt ?>"><?php echo $pmpro_msg ?></div>
  <?php
}
?>
<?php if (isset($_GET['expr']) && $_GET['expr'] == '1') { //echo $_GET['expr'];   ?> 
<script>
  jQuery(document).ready(function () {
    jQuery('.renewmembershipdas.expired').modal('show');
  });
</script>
<?php } ?>

<?php /*
<!-- Modal -->
<div class="modal fade custom-popup renewmembershipdas expired-membership subscriber" id="redirect-modal-success" tabindex="-1" role="dialog" aria-labelledby="redirect-modalLabel" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/assets/images/close-icon.svg"></span>
        </button>
        <div class="redirect-box-success-container text-center">
          <!--<b class="renew-title">Your NSTXL membership has expired.</b>  -->
          <p class="renew-des">Hmmm.... We can't find your firm in our membership database. But we'd love to welcome you as members. Please fill out a membership application to begin enjoying member benefits. If you believe this is in error, please contact <a class="red-text" href="mailto:membership@nstxl.org">membership@nstxl.org</a> so we can sort things out asap.</p> 
        </div>
      </div> 

      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div> 
</div> 
<!-- /.modal -->
*/?>


<div class="member_plan radio">
  <h3 class="rgs_title">Membership  Levels</h3>

<?php /**
  <div class="card-deck">
    <div class="columns card">

      <ul class="price">
        <li class="plan-heading">Corporate</li>
        <li class="text-content">Based on Parent Company Annual Revenues <div class="tooltip1"><img src="/wp-content/themes/polar/assets/images/infobutton.png" width="18px" height="18px">
            <span class="tooltiptext1">Corporate membership fees are based the size of the corporate parent.  For more information, consult our FAQ, &nbsp;<a href="<?php echo site_url(); ?>/faq/" target="_blank">How do I determine my company’s membership dues?</a></span>
          </div></li>
        <?php
        foreach ($pmpro_levels as $level) {
          $tab = get_option('pmpro_tab_' . $level->id);
          if (!empty($tab) && ( $tab == 'corporate' )) {
            if (isset($current_user->membership_level->ID))
              $current_level = ($current_user->membership_level->ID == $level->id);
            else
              $current_level = false;
            ?>
            <li> <label class="lbl">
                <?php if (empty($current_user->membership_level->ID) && ( $expiredStatus != 'expired' )) { ?>

                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif (!empty($expiredStatus) && !empty($expiredMembId) && ( $expiredStatus == 'expired' )) {
                  ?>
                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" <?php
                  if ($expiredMembId == $level->id) {
                    echo 'checked';
                  }
                  ?>>
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif (!$current_level) { ?>

                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif ($current_level) { ?>      

                  <?php
                  //if it's a one-time-payment level, offer a link to renew       
                  if (pmpro_isLevelExpiringSoon($current_user->membership_level) && $current_user->membership_level->allow_signups) {
                    ?>
                    <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" checked="checked">
                    <span class="nstxlbtn-txt"><?php _e('Renew', 'paid-memberships-pro'); ?></span>
                    <?php
                  } else {
                    ?>

                    <input type="radio" class="nstxlradio-btn" name="optradio" value="#" checked="checked">
                    <span class="nstxlbtn-txt"><?php _e('Your Level', 'paid-memberships-pro'); ?></span>
                    <?php
                  }
                  ?>

                <?php } ?>
                <span class="checkmark"></span><?php echo $current_level ? "<strong>{$level->name}</strong>" : $level->name; ?><span class="values"><?php
                  if (pmpro_isLevelFree($level))
                    $cost_text = "<strong>" . __("Free", 'paid-memberships-pro') . "</strong>";
                  else
                    $cost_text = pmpro_getLevelCostPolar($level, true, true);
                  $expiration_text = pmpro_getLevelExpirationnstxl($level);
                  if (!empty($cost_text) && !empty($expiration_text))
                    echo $cost_text . "<br />" . $expiration_text;
                  elseif (!empty($cost_text))
                    echo $cost_text;
                  elseif (!empty($expiration_text))
                    echo $expiration_text;
                  ?></span></label></li>
            <?php
          }
        }
        ?>    
      </ul>
    </div>

    <div class="columns card">

      <ul class="price">
        <li class="plan-heading">Non-Profit</li>
        <li class="text-content">Based on Annual Revenues</li>
        <?php
        foreach ($pmpro_levels as $level) {
          $tab = get_option('pmpro_tab_' . $level->id);
          if (!empty($tab) && ( $tab == 'non-profit' )) {
            if (isset($current_user->membership_level->ID))
              $current_level = ($current_user->membership_level->ID == $level->id);
            else
              $current_level = false;
            ?>
            <li> <label class="lbl">
                <?php if (empty($current_user->membership_level->ID) && ( $expiredStatus != 'expired' )) { ?>

                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif (!empty($expiredStatus) && !empty($expiredMembId) && ( $expiredStatus == 'expired' )) {
                  ?>
                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" <?php
                  if ($expiredMembId == $level->id) {
                    echo 'checked';
                  }
                  ?>>
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif (!$current_level) { ?>

                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif ($current_level) { ?>      

                  <?php
                  //if it's a one-time-payment level, offer a link to renew       
                  if (pmpro_isLevelExpiringSoon($current_user->membership_level) && $current_user->membership_level->allow_signups) {
                    ?>
                    <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" checked="checked">
                    <span class="nstxlbtn-txt"><?php _e('Renew', 'paid-memberships-pro'); ?></span>
                    <?php
                  } else {
                    ?>

                    <input type="radio" class="nstxlradio-btn" name="optradio" value="#" checked="checked">
                    <span class="nstxlbtn-txt"><?php _e('Your Level', 'paid-memberships-pro'); ?></span>
                    <?php
                  }
                  ?>

                <?php } ?>
                <span class="checkmark"></span><?php echo $current_level ? "<strong>{$level->name}</strong>" : $level->name; ?><span class="values"><?php
                  if (pmpro_isLevelFree($level))
                    $cost_text = "<strong>" . __("Free", 'paid-memberships-pro') . "</strong>";
                  else
                    $cost_text = pmpro_getLevelCostPolar($level, true, true);
                  $expiration_text = pmpro_getLevelExpirationnstxl($level);
                  if (!empty($cost_text) && !empty($expiration_text))
                    echo $cost_text . "<br />" . $expiration_text;
                  elseif (!empty($cost_text))
                    echo $cost_text;
                  elseif (!empty($expiration_text))
                    echo $expiration_text;
                  ?></span></label></li>
            <?php
          }
        }
        ?> 

      </ul>
    </div>

    <div class="columns card">

      <ul class="price">
        <li class="plan-heading">Non Corporate</li>
        <li class="text-content">Based on Annual Revenues</li>
        <?php
        foreach ($pmpro_levels as $level) {
          $tab = get_option('pmpro_tab_' . $level->id);
          if (!empty($tab) && ( $tab == 'non-corporate' )) {
            if (isset($current_user->membership_level->ID))
              $current_level = ($current_user->membership_level->ID == $level->id);
            else
              $current_level = false;
            ?>
            <li> <label class="lbl">
                <?php if (empty($current_user->membership_level->ID) && ( $expiredStatus != 'expired' )) { ?>

                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif (!empty($expiredStatus) && !empty($expiredMembId) && ( $expiredStatus == 'expired' )) {
                  ?>
                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" <?php
                  if ($expiredMembId == $level->id) {
                    echo 'checked';
                  }
                  ?>>
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif (!$current_level) { ?>

                  <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">
                  <span class="nstxlbtn-txt"><?php _e('CONTINUE', 'paid-memberships-pro'); ?></span>
                <?php } elseif ($current_level) { ?>      

                  <?php
                  //if it's a one-time-payment level, offer a link to renew       
                  if (pmpro_isLevelExpiringSoon($current_user->membership_level) && $current_user->membership_level->allow_signups) {
                    ?>
                    <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" checked="checked">
                    <span class="nstxlbtn-txt"><?php _e('Renew', 'paid-memberships-pro'); ?></span>
                    <?php
                  } else {
                    ?>

                    <input type="radio" class="nstxlradio-btn" name="optradio" value="#" checked="checked">
                    <span class="nstxlbtn-txt"><?php _e('Your Level', 'paid-memberships-pro'); ?></span>
                    <?php
                  }
                  ?>

                <?php } ?>
                <span class="checkmark"></span>
                <?php
                if ($current_level) {
                  echo "<strong>{$level->name}</strong>";
                } else {
                  echo $level->name;
                } if (($level->id == 6)) {
                  echo "&nbsp;&nbsp;<a data-toggle='tooltip' data-placement='right' title='' data-original-title='Each incubator gets to add 5 of their incubated companies as a member each year for no additional charge.'><img src='/wp-content/themes/polar-child/assets/images/infobutton.png' width='18px' height='18px'></a>";
                } if ($level->id == 7) {
                  echo "&nbsp;&nbsp;<a data-toggle='tooltip' data-placement='right' title='' data-original-title='the university membership that states that it applies to the whole university'><img src='/wp-content/themes/polar-child/assets/images/infobutton.png' width='18px' height='18px'></a>";
                }
                ?>
                <span class="values">
                  <?php
                  if (pmpro_isLevelFree($level))
                    $cost_text = "<strong>" . __("Free", 'paid-memberships-pro') . "</strong>";
                  else
                    $cost_text = pmpro_getLevelCostPolar($level, true, true);
                  $expiration_text = pmpro_getLevelExpirationnstxl($level);
                  if (!empty($cost_text) && !empty($expiration_text))
                    echo $cost_text . "<br />" . $expiration_text;
                  elseif (!empty($cost_text))
                    echo $cost_text;
                  elseif (!empty($expiration_text))
                    echo $expiration_text;
                  ?></span></label></li>
            <?php
          }
        }
        ?> 

      </ul>
    </div> 
  </div>

 **/ ?>

 <!------ My tabel ---------->
 <div class="clearfix"> </div>
 <div class="card-deck">
  <div class="columns card_main">

    <div class="columns card">
      <div class="annual-duas-card" style="background-color: #f1f1f1;">
        <h2 style="text-align: left; font-family: Roboto; font-weight: 500; font-style: normal;">Corporate</h2>
        <div class="price">
          <table class="corporat_table ">
            <tbody>
              <tr>
                <th>Annual Revenues</th>
                <th>Annual Dues</th>
              </tr>

              <?php
              foreach ($pmpro_levels as $level) {
                $tab = get_option('pmpro_tab_' . $level->id);
                if (!empty($tab) && ( $tab == 'corporate' )) {
                  if (isset($current_user->membership_level->ID))
                    $current_level = ($current_user->membership_level->ID == $level->id);
                  else
                    $current_level = false;
                  ?>
                  <tr  class="<?php  if ($current_level) {echo "active"; } ?>">
                    <td>   
                      <label class="lbl">
                        <?php if (empty($current_user->membership_level->ID) && ( $expiredStatus != 'expired' )) { ?>

                          <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">

                        <?php } elseif (!empty($expiredStatus) && !empty($expiredMembId) && ( $expiredStatus == 'expired' )) {
                          ?>
                          <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" <?php
                          if ($expiredMembId == $level->id) {
                            echo 'checked';
                          }
                          ?>>

                        <?php } elseif (!$current_level) { ?>

                          <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">

                        <?php } elseif ($current_level) { ?>      

                          <?php
                            //if it's a one-time-payment level, offer a link to renew       
                          if (pmpro_isLevelExpiringSoon($current_user->membership_level) && $current_user->membership_level->allow_signups) {
                            ?>
                            <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" checked="checked">

                            <?php
                          } else {
                            ?>

                            <input type="radio" class="nstxlradio-btn" name="optradio" value="#" checked="checked">

                            <?php
                          }
                          ?>

                        <?php } ?>
                        <span class="checkmark"></span><?php echo $current_level ? "<strong>{$level->name}</strong>" : $level->name; ?>
                      </td>
                      <td>
                        <span class="values"><?php
                        if (pmpro_isLevelFree($level))
                          $cost_text = "<strong>" . __("Free", 'paid-memberships-pro') . "</strong>";
                        else
                          $cost_text = pmpro_getLevelCostPolar($level, true, true);
                        $expiration_text = pmpro_getLevelExpirationnstxl($level);
                        if (!empty($cost_text) && !empty($expiration_text))
                          echo $cost_text . "<br />" . $expiration_text;
                        elseif (!empty($cost_text))
                          echo $cost_text;
                        elseif (!empty($expiration_text))
                          echo $expiration_text;
                        ?></span></label>
                        <?php  if ($current_level) { ?>
                         <span class="nstxlbtn-txt current_level"><?php _e('Current Level', 'paid-memberships-pro'); ?></span> 
                       <?php  } ?> 
                     </td> 


                   </tr> 

                   <?php
                 }
               }
               ?> 
             </tbody>
           </table>
         </div>
       </div>
     </div>
     <div class="level-info-section"><div class="levelmtext">Based on Parent Company Annual Revenues 
      <div class="tooltip1"><img src="<?php echo nstxl_tooltip_icon; ?>" width="17px" height="17px">
        <span class="tooltiptext1">Corporate membership fees are based the size of the corporate parent.  For more information, consult our FAQ, &nbsp;<a href="<?php echo site_url(); ?>/faq/" target="_blank">How do I determine my company’s membership dues?</a></span>
      </div></div>
    </div>
  </div>



  <!----------------------------------------------------------------------------------------------------->
  <div class="columns card_main">
    <div class="columns card">
      <div class="annual-duas-card" style="background-color: #f1f1f1;">
        <h2 style="text-align: left; font-family: Roboto; font-weight: 500; font-style: normal;">Non-Profit</h2>
        <div class="price">
          <table class="corporat_table">
            <tbody>
              <tr>
                <th>Annual Revenues</th>
                <th>Annual Dues</th>
              </tr>
              <?php
              foreach ($pmpro_levels as $level) {
                $tab = get_option('pmpro_tab_' . $level->id);
                if (!empty($tab) && ( $tab == 'non-profit' )) {
                  if (isset($current_user->membership_level->ID))
                    $current_level = ($current_user->membership_level->ID == $level->id);
                  else
                    $current_level = false;
                  ?>
                  <tr  class="<?php  if ($current_level) {echo "active"; } ?>">
                    <td> 
                      <label class="lbl">
                        <?php if (empty($current_user->membership_level->ID) && ( $expiredStatus != 'expired' )) { ?>

                          <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">

                        <?php } elseif (!empty($expiredStatus) && !empty($expiredMembId) && ( $expiredStatus == 'expired' )) {
                          ?>
                          <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" <?php
                          if ($expiredMembId == $level->id) {
                            echo 'checked';
                          }
                          ?>>

                        <?php } elseif (!$current_level) { ?>

                          <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">

                        <?php } elseif ($current_level) { ?>      

                          <?php
                            //if it's a one-time-payment level, offer a link to renew       
                          if (pmpro_isLevelExpiringSoon($current_user->membership_level) && $current_user->membership_level->allow_signups) {
                            ?>
                            <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" checked="checked">

                            <?php
                          } else {
                            ?>

                            <input type="radio" class="nstxlradio-btn" name="optradio" value="#" checked="checked">

                            <?php
                          }
                          ?>

                        <?php } ?>
                        <span class="checkmark"></span><?php echo $current_level ? "<strong>{$level->name}</strong>" : $level->name; ?>
                      </td>
                      <td>  
                        <span class="values"><?php
                        if (pmpro_isLevelFree($level))
                          $cost_text = "<strong>" . __("Free", 'paid-memberships-pro') . "</strong>";
                        else
                          $cost_text = pmpro_getLevelCostPolar($level, true, true);
                        $expiration_text = pmpro_getLevelExpirationnstxl($level);
                        if (!empty($cost_text) && !empty($expiration_text))
                          echo $cost_text . "<br />" . $expiration_text;
                        elseif (!empty($cost_text))
                          echo $cost_text;
                        elseif (!empty($expiration_text))
                          echo $expiration_text;
                        ?></span>
                      </label>
                      <?php  if ($current_level) { ?>
                       <span class="nstxlbtn-txt current_level"><?php _e('Current Level', 'paid-memberships-pro'); ?></span> 
                     <?php  } ?>
                   </td>
                 </tr>
                 <?php
               }
             }
             ?> 
           </tbody>
         </table>
       </div>
     </div>
   </div>
   <div class="level-info-section"><p class="levelmtext">Based on Annual Revenues</p></div>
 </div> 

 <!--------------------------------------------------------------------------------->
 <div class="columns card_main"> 
  <div class="columns card">
    <div class="annual-duas-card" style="background-color: #f1f1f1;">
      <h2 style="text-align: left; font-family: Roboto; font-weight: 500; font-style: normal;">Academic &amp; Other</h2>
      <div class="price">
        <table class="corporat_table">
          <tbody>
            <tr>
              <th>Annual Revenues</th>
              <th>Annual Dues</th>
            </tr>
            <?php
            foreach ($pmpro_levels as $level) {
              $tab = get_option('pmpro_tab_' . $level->id);
              if (!empty($tab) && ( $tab == 'non-corporate' )) {
                if (isset($current_user->membership_level->ID))
                  $current_level = ($current_user->membership_level->ID == $level->id);
                else
                  $current_level = false;
                ?>
                <tr  class="<?php  if ($current_level) {echo "active"; } ?>">
                  <td>
                    <label class="lbl">
                      <?php if (empty($current_user->membership_level->ID) && ( $expiredStatus != 'expired' )) { ?>

                        <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">

                      <?php } elseif (!empty($expiredStatus) && !empty($expiredMembId) && ( $expiredStatus == 'expired' )) {
                        ?>
                        <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" <?php
                        if ($expiredMembId == $level->id) {
                          echo 'checked';
                        }
                        ?>>

                      <?php } elseif (!$current_level) { ?>

                        <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">

                      <?php } elseif ($current_level) { ?>      

                        <?php
                            //if it's a one-time-payment level, offer a link to renew       
                        if (pmpro_isLevelExpiringSoon($current_user->membership_level) && $current_user->membership_level->allow_signups) {
                          ?>
                          <input type="radio" class="nstxlradio-btn" name="optradio" value="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>" checked="checked"> 

                          <?php
                        } else {
                          ?>

                          <input type="radio" class="nstxlradio-btn" name="optradio" value="#" checked="checked">

                          <?php
                        }
                        ?>

                      <?php } ?>
                      <span class="checkmark"></span>
                      <?php
                      if ($current_level) {
                        echo $level->name; 
                      } else {
                        echo $level->name;
                      } if (($level->id == 6)) {
                        echo ' <div class="tooltip1"><img src="' . nstxl_tooltip_icon . '" width="17px" height="17px">
                        <span class="tooltiptext1">Each incubator gets to add 5 of their incubated companies as a member each year for no additional charge.</span>
                        </div>';
                      } if ($level->id == 7) {
                        echo ' <div class="tooltip1"><img src="' . nstxl_tooltip_icon . '" width="17px" height="17px">
                        <span class="tooltiptext1">The university membership that states that it applies to the whole university.</span>
                        </div>';
                      }
                      ?>
                    </td>
                    <td>
                      <span class="values">
                        <?php
                        if (pmpro_isLevelFree($level))
                          $cost_text = "<strong>" . __("Free", 'paid-memberships-pro') . "</strong>";
                        else
                          $cost_text = pmpro_getLevelCostPolar($level, true, true);
                        $expiration_text = pmpro_getLevelExpirationnstxl($level);
                        if (!empty($cost_text) && !empty($expiration_text))
                          echo $cost_text . "<br />" . $expiration_text;
                        elseif (!empty($cost_text))
                          echo $cost_text;
                        elseif (!empty($expiration_text))
                          echo $expiration_text;
                        ?></span></label> 
                        <?php  if ($current_level) { ?>
                         <span class="nstxlbtn-txt current_level"><?php _e('Current Level', 'paid-memberships-pro'); ?></span> 
                       <?php  } ?>
                     </td>
                   </tr>
                   <?php
                 }
               }
               ?> 
             </tbody>
           </table>
         </div>
       </div>
     </div>
     <div class="level-info-section"><p class="levelmtext">Based on Annual Revenues</p></div>
   </div>

 </div>



 <!-------- ends here ------->




</div>


<div class="clearfix"> </div>
<div class="plan-ftr">
  <nav id="nav-below" class="navigation" role="navigation">
    <div class="nav-previous alignleft">
      <?php if (!empty($current_user->membership_level->ID)) { ?>
        <a href="<?php echo pmpro_url("account") ?>" id="pmpro_levels-return-account"><?php _e('&larr; Return to Your Account', 'paid-memberships-pro'); ?></a>
      <?php } else { ?>
        <a href="<?php echo home_url() ?>" id="pmpro_levels-return-home"><?php _e('&larr; Return to Home', 'paid-memberships-pro'); ?></a>
      <?php } ?>
    </div>
  </nav>

  <a id="checkoutbtn-nstxl" class="pmpro_btn pmpro_btn-select pmpro_btn_new" href="<?php echo pmpro_url("checkout", "?level=" . $level->id, "https") ?>">Change Level</a>  
</div>

<script type="text/javascript">
  var wid = jQuery(window).width();
  jQuery.fn.equalHeights = function () {
    var max_height = 0;
    jQuery(this).each(function () {
      max_height = Math.max(jQuery(this).height(), max_height);
    });
    jQuery(this).each(function () {
      jQuery(this).height(max_height);
    });
  };

  /******************* custom js *************************/

  jQuery(document).ready(function () {
    if (wid >= 768)
    {
      jQuery('.card_main .card').equalHeights();
    }

    jQuery(".price tr").click(function () {
      jQuery('.price').css("border-color", "#eeeeee");
      jQuery(this).parent('.price').css("border-color", "#dc323e");
      jQuery(this).parent('.plan-heading').css("border-color", "#dc323e");

      jQuery(".price tr").removeClass('active'); 
      jQuery('.price tr', this).addBack(this).addClass("active");
      var nstxlradioBtn = jQuery(this).find('.nstxlradio-btn').val();
      var nstxlradioTxt = jQuery(this).find('.nstxlbtn-txt').html();
      if (nstxlradioBtn == '#')
      {
        jQuery('#checkoutbtn-nstxl').addClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      } else
      {
        jQuery('#checkoutbtn-nstxl').removeClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      }
    });

    if (jQuery(".price tr").hasClass("active")) {
      var nstxlradioBtn = jQuery(this).find('.nstxlradio-btn').val();
      var nstxlradioTxt = jQuery(this).find('.nstxlbtn-txt').html();
      if (nstxlradioBtn == '#')
      {
        jQuery('#checkoutbtn-nstxl').addClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      } else
      {
        jQuery('#checkoutbtn-nstxl').removeClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      }
    }

    if (jQuery(".nstxlradio-btn").is(":checked")) {
      var nstxlradioBtn = jQuery('input[name=optradio]:checked').val();
      ;
      var nstxlradioTxt = jQuery('input[name=optradio]:checked').next('.nstxlbtn-txt').html();
      jQuery('input[name=optradio]:checked').closest('li').addClass('active');
      jQuery('input[name=optradio]:checked').closest('ul').css("border-color", "#dc323e");
      jQuery('input[name=optradio]:checked').closest('.plan-heading').css("border-color", "#dc323e");
      if (nstxlradioBtn == '#')
      {
        jQuery('#checkoutbtn-nstxl').addClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      } else
      {
        jQuery('#checkoutbtn-nstxl').removeClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      }
    }
  });

  /**************************************ends here *********************************/
/**
  jQuery(document).ready(function () {
    if (wid >= 768)
    {
      jQuery('.price').equalHeights();
    }

    jQuery(".price li").click(function () {
      jQuery('.price').css("border-color", "#eeeeee");
      jQuery(this).parent('.price').css("border-color", "#dc323e");
      jQuery(this).parent('.plan-heading').css("border-color", "#dc323e");

      jQuery(".price li").removeClass('active');
      jQuery('.price li', this).addBack(this).addClass("active");
      var nstxlradioBtn = jQuery(this).find('.nstxlradio-btn').val();
      var nstxlradioTxt = jQuery(this).find('.nstxlbtn-txt').html();
      if (nstxlradioBtn == '#')
      {
        jQuery('#checkoutbtn-nstxl').addClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      } else
      {
        jQuery('#checkoutbtn-nstxl').removeClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      }
    });

    if (jQuery(".price li").hasClass("active")) {
      jQuery(this).parent("ul").css("border-color", "#dc323e");
      var nstxlradioBtn = jQuery(this).find('.nstxlradio-btn').val();
      var nstxlradioTxt = jQuery(this).find('.nstxlbtn-txt').html();
      if (nstxlradioBtn == '#')
      {
        jQuery('#checkoutbtn-nstxl').addClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      } else
      {
        jQuery('#checkoutbtn-nstxl').removeClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      }
    }

    if (jQuery(".nstxlradio-btn").is(":checked")) {
      var nstxlradioBtn = jQuery('input[name=optradio]:checked').val();
      ;
      var nstxlradioTxt = jQuery('input[name=optradio]:checked').next('.nstxlbtn-txt').html();
      jQuery('input[name=optradio]:checked').closest('li').addClass('active');
      jQuery('input[name=optradio]:checked').closest('ul').css("border-color", "#dc323e");
      jQuery('input[name=optradio]:checked').closest('.plan-heading').css("border-color", "#dc323e");
      if (nstxlradioBtn == '#')
      {
        jQuery('#checkoutbtn-nstxl').addClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      } else
      {
        jQuery('#checkoutbtn-nstxl').removeClass('disabled');
        jQuery('#checkoutbtn-nstxl').attr("href", nstxlradioBtn);
        jQuery('#checkoutbtn-nstxl').text(nstxlradioTxt);
      }
    }
  });

  **/


</script> 


<?php 
if (!empty($expiredMemberIds[0]->membership_id) && ($expiredMemberIds[0]->status == 'expired')) 
  {
   $modal_id = 'update-personalinfo-modal-success';
   $modal_body_container_class  = 'update-personalinfo-modal-success-container renewmembershipdas expired-membership expired';
   $content_html = ' <div class="redirect-box-success-container text-center">
   <b class="renew-title">Your NSTXL membership has expired.</b>
   <p class="renew-des">Renew your membership here. If you have any questions contact</p> 
   <div class="renew-button">
   <a class="red-text" href="mailto:membership@nstxl.org">membership@nstxl.org</a>
   </div>
   </div>';
   nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class);
 }
 ?>


 <?php 
 if (isset($_GET['expr']) && $_GET['expr'] == '1')
 { 
   $modal_id = 'redirect-modal-success';
   $modal_body_container_class  = 'renewmembershipdas expired-membership subscriber';
   $content_html = "<p class='renew-des'>Hmmm.... We can't find your firm in our membership database. But we'd love to welcome you as members. Please fill out a membership application to begin enjoying member benefits. If you believe this is in error, please contact <a class='red-text' href='mailto:membership@nstxl.org'>membership@nstxl.org</a> so we can sort things out asap.</p> ";
   nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class);
 }
 ?>     