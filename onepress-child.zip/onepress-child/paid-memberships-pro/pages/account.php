<?php
	echo pmpro_shortcode_account_nstxl('');
?>
