<?php
global $wpdb, $current_user;
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
if (is_user_logged_in() && empty(nstxl_is_poc($current_user->ID))) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
get_header('admin'); 
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
//do_action('onepress_page_before_content');
?>
<div class="page-header">
 <div class="container">
   <h1 class="entry-title">Faqs</h1> </div>
 </div> 
 <div id="content" class="site-content">
  <?php
 // onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
   <?php get_sidebar('dashboard'); ?>
   <div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

      <?php while (have_posts()) : the_post(); ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <header class="entry-header">
            <?php //the_title( '<h1 class="entry-title">', '</h1>' );   ?>
          </header><!-- .entry-header --> 

          <div class="entry-content">
           <div class="faqs-container">   
            <!--   <div class="row"> -->
             <div class="faqs-single faqs-dashboard dashboard-bg-white" >


               <div class="">  
                 <h4 class="faq-single-title"><?php echo get_the_title(); ?></h4>
                 <h6 class="faq-single-date">Created: <?php echo get_the_date(); ?></h6> 
                 <?php the_content(); ?> 	
                 <div class="article-likebox">
                   Was This Article Helpful?&nbsp;  <input type="button" value="Yes" id="like_<?php echo get_the_ID(); ?>" class="like"  />&nbsp;
                   <input type="button" value="No" id="unlike_<?php echo get_the_ID(); ?>" class="unlike" /> 
                   <span id="likemsgtext"></span>
                 </div> 

<script type="text/javascript"> 
jQuery(document).ready(function(){
jQuery(".like, .unlike").click(function(){
var id = this.id;   
var split_id = id.split("_");
var text = split_id[0];
  //  alert(text);
  var postid = split_id[1]; 
  var type = 0;
  if(text == "like"){
   type = 1;
   var textmsg = ' <i class="fa fa-thumbs-up" aria-hidden="true"></i>';
 }else{
   type = 0;
   var textmsg = ' <i class="fa fa-thumbs-down" aria-hidden="true"></i>'; 
 }
 jQuery.ajax({
   url: nstxl_ajaxurl,
   type: 'post',
   cache: false,
   data: {postid:postid,type:type,action:'nstxl_faq_article_like_dislike'},
   beforeSend: function () {  
    jQuery( '.nstxl-loader' ).show();
    jQuery( '.loader-overlay' ).show();
  },
  complete: function () {
    jQuery( '.nstxl-loader' ).hide();
    jQuery( '.loader-overlay' ).hide();
  },
  success: function(response){     
    jQuery('#likemsgtext').html(textmsg);       
  }
});

});
});
</script>  
               </div>

             </div>
           </div>
         </div><!-- .entry-content -->
       </article><!-- #post-## -->

     <?php endwhile; // End of the loop.  ?>   

   </main><!-- #main -->
 </div><!-- #primary -->



</div><!--#content-inside -->
</div><!-- #content -->  

<?php
get_footer('admin'); 

