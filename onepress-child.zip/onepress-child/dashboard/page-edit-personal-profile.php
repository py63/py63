<?php
/**
 * Template Name: Edit Personal Profile
 *
 * @package OnePress
 */
global $wpdb, $current_user;
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
if (is_user_logged_in() && empty(nstxl_is_poc($current_user->ID))) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
get_header('admin');
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
/**
 * Register our JS scripts
 */
wp_register_script('pmpro-countries', nstxl_extention_url . 'includes/essential-plugins/pmpro-state-dropdowns/js/crs.js', array('jquery'));
wp_register_script('pmpro-countries-main', nstxl_extention_url . 'includes/essential-plugins/pmpro-state-dropdowns/js/countries-main.js', array('jquery', 'pmpro-countries'));
global $current_user, $user_id, $order_id, $pmpro_default_country;
if (empty($pmpro_default_country)) {
  $pmpro_default_country = 'US';
}
$the_user_id = $user_id;

//fallback to current user on pages that don't support $user_id variable.
if (empty($the_user_id)) {
  $the_user_id = $current_user->ID;
}
$user_saved_countries = array();

//if the page is edit user or profile, change the ID to '#pmpro_bstate' otherwise default to '#bstate'.

$user_saved_countries['state_id'] = 'bstate';

//if $morder is not empty (i.e. on the orders page try to get details from REQUEST or USER META )

$user_saved_countries['bcountry'] = get_user_meta($the_user_id, 'pmpro_bcountry', true);



$user_saved_countries['bstate'] = get_user_meta($the_user_id, 'pmpro_bstate', true);




wp_localize_script('pmpro-countries-main', 'pmpro_state_dropdowns', $user_saved_countries);

wp_enqueue_script('pmpro-countries');
wp_enqueue_script('pmpro-countries-main');
global $gateway, $pmpro_review, $skip_account_fields, $pmpro_paypal_token, $wpdb, $current_user, $pmpro_msg, $pmpro_msgt, $pmpro_requirebilling, $pmpro_level, $pmpro_levels, $tospage, $pmpro_show_discount_code, $pmpro_error_fields;
global $username, $bfirstname, $blastname, $baddress1, $baddress2, $bcity, $bstate, $bzipcode, $bcountry, $bphone, $bemail;
if (!empty($current_user)) {
  $cur_id = $current_user->ID;
  $name_on_card = get_user_meta($cur_id, 'name_on_card', true);
  if (empty($bfirstname)) {
    $bfirstname = $current_user->user_firstname;
  }
  if (empty($blastname)) {
    $blastname = $current_user->user_lastname;
  }

//if( !empty($blastname)){
  $user_login = $current_user->user_login;
//}

  if (empty($bemail)) {
    $bemail = $current_user->user_email;
  }

  if (empty($bconfirmemail)) {
    $bconfirmemail = $current_user->user_email;
  }
  if (empty($username)) {
    $username = $current_user->user_login;
  }
  if (!empty($cur_id)) {
    $designation = get_user_meta($cur_id, 'designation', true);
    $other_designation = get_user_meta($cur_id, 'other_designation', true);
    $cell_phone = get_user_meta($cur_id, "cell_phone", true);
    $pmpro_bphone = get_user_meta($cur_id, "pmpro_bphone", true);
    $pmpro_baddress1 = get_user_meta($cur_id, "pmpro_baddress1", true);
    $pmpro_baddress2 = get_user_meta($cur_id, "pmpro_baddress2", true);
    $pmpro_bcity = get_user_meta($cur_id, "pmpro_bcity", true);
    $pmpro_bstate = get_user_meta($cur_id, "pmpro_bstate", true);
    $pmpro_bcountry = get_user_meta($cur_id, "pmpro_bcountry", true);
    $pmpro_bzipcode = get_user_meta($cur_id, "pmpro_bzipcode", true);
    $pmpro_bzipcode = get_user_meta($cur_id, "pmpro_bzipcode", true);
    $bemail = get_user_meta($cur_id, "pmpro_bemail", true);
  }
}
?>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
   <?php get_sidebar('dashboard'); ?>
   <div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

      <?php while (have_posts()) : the_post(); ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <header class="entry-header">
            <?php //the_title( '<h1 class="entry-title">', '</h1>' );   ?>
          </header><!-- .entry-header -->

          <div class="entry-content">
            <?php the_content(); ?>

            <!--   <div class="row"> -->
              <div class="personal-info-container personal-profile personal-profile-dashboard dashboard-bg-white" >
                <form method="post" class="pmpro_form" enctype="multipart/form-data" name="personal-info" id="personal-info">
                  <div class="">                
                    <div id="step-1">                                             
                      <div id="form-step-0" role="form">
<!--                           <h3 class="rgs_title"><?php _e(the_title(), 'paid-memberships-pro'); ?></h3>
-->                          <div id="pmpro_user_fields" class="pmpro_checkout">
  <div class="pmpro_checkout-fields">
    <?php
    $uploaded_doc_url = get_user_meta($cur_id, 'uploaded_doc', true);
    $defalut_pic_url = WP_PLUGIN_URL . '/nstxl-memberhip-extension/images/user.png';
    $user_pic = get_user_meta($cur_id, 'user_pic', true);
    if (!empty($user_pic)) {
      $user_pic_url = $user_pic['fullurl'];
      $avatar = '<div class="profile-pic"><img class="profile-pic-img" alt="user pic" src="' . $user_pic_url . '"><i class="fa fa-camera upload-button"></i></div>';
    } else {
      $avatar = '<div class="profile-pic"><img class="profile-pic-img" alt="user pic" src="' . $defalut_pic_url . '"><i class="fa fa-camera upload-button"></i></div>';
    }
    ?>
    <div class="user_pics circle"><?php echo $avatar; ?></div>
  <div class="person-name"><h2><?php if (!empty($bfirstname)) { echo esc_attr($bfirstname); } ?> <?php if (!empty($bfirstname)) {echo esc_attr($blastname); } ?></h2>  <h3><a href="<?php echo get_bloginfo('url');?>/change-password/">Change Password</a></h3>   </div>   


  <div class="clearfix"></div>

  <div class="row">
    <div class="col-sm-12">	<h3>Account Details</h3></div>
    <div class="pmpro_checkout-field pmpro_checkout-field-bfirstname col-sm-12 col-lg-6">

      <div class="form-group">
        <label for="bfirstname"><?php _e('First Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>                    
        <input id="bfirstname" required=""  name="bfirstname" required type="text" class="input <?php echo pmpro_getClassForField("bfirstname"); ?>" size="30" value="<?php echo esc_attr($bfirstname); ?>" />

        <div class="help-block with-errors"></div>
      </div>
    </div> <!-- end pmpro_checkout-field-bfirstname -->
    <div class="pmpro_checkout-field pmpro_checkout-field-blastname col-sm-12 col-lg-6">
      <div class="form-group">
        <label for="blastname"><?php _e('Last Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
        <input id="blastname" required="" name="blastname" required type="text" class="input <?php echo pmpro_getClassForField("blastname"); ?>" size="30" value="<?php echo esc_attr($blastname); ?>" />

        <div class="help-block with-errors"></div>
      </div>
    </div> <!-- end pmpro_checkout-field-blastname -->
<?php /*
    <div class="pmpro_checkout-field pmpro_checkout-field-username col-sm-12 col-lg-6">
      <div class="form-group">
        <label for="username"><?php _e('Username', 'paid-memberships-pro'); ?></label>
        <input id="username" readonly  required name="username" type="text" class="input <?php echo pmpro_getClassForField("username"); ?>" size="30" value="<?php echo esc_attr($username); ?>" />
        <div class="help-block with-errors"></div>
      </div>

    </div> <!-- end pmpro_checkout-field-username -->
 */ ?>
 <?php
 do_action('pmpro_checkout_after_username');
 ?>
 


 <div class="pmpro_checkout-field pmpro_checkout-field-bemail col-sm-12 col-lg-6">
  <div class="form-group">
    <label for="bemail"><?php _e('E-mail Address', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
    <input id="bemail" readonly name="bemail" required type="email" class="input pmpro_required" size="30" value="<?php echo esc_attr($bemail); ?>" />
    <div class="help-block with-errors"></div>
  </div>  
</div> <!-- end pmpro_checkout-field-bemail -->

<?php
$pmpro_checkout_confirm_email = apply_filters("pmpro_checkout_confirm_email", true);
$pmpro_checkout_confirm_email = false;
if ($pmpro_checkout_confirm_email) {
  ?>
  <div class="pmpro_checkout-field pmpro_checkout-field-bconfirmemail col-sm-12 col-lg-6">
    <div class="form-group">
      <label for="bconfirmemail"><?php _e('Confirm E-mail Address', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
      <input required id="bconfirmemail" data-match="#bemail" data-match-error="E-mail Doesn't Match"  name="bconfirmemail" type="email" class="input bconfirmemail" size="30" value="<?php echo esc_attr($bconfirmemail); ?>" />
      <div class="help-block with-errors"></div>
    </div>
  </div> <!-- end pmpro_checkout-field-bconfirmemail -->
<?php } else { ?>
  <input type="hidden" name="bconfirmemail_copy" value="1" />
<?php }
?>

<?php
do_action('pmpro_checkout_after_email');
?>
<div class="pmpro_checkout-field pmpro_checkout-field-designation col-sm-12 col-lg-6">
  <div class="form-group">
    <label for="designation"><?php _e('Title', 'paid-memberships-pro'); ?></label>
    <select name="designation" id="designation" class="custom-select">  
      <option value=""><?php _e('Title', 'paid-memberships-pro'); ?></option>
      <option value="CEO"  <?php selected($designation, 'CEO'); ?>>CEO</option>
      <option value="COO" <?php selected($designation, 'COO'); ?>>COO</option>
      <option value="CFO" <?php selected($designation, 'CFO'); ?>>CFO</option>
      <option value="VicePresident" <?php selected($designation, 'VicePresident'); ?>>Vice President</option>
      <option value="Manager" <?php selected($designation, 'Manager'); ?>>Manager</option>
      <option value="AccountManager" <?php selected($designation, 'AccountManager'); ?>>Account Manager</option>
      <option value="Director" <?php selected($designation, 'Director'); ?>>Director</option>
      <?php /* ?><option value="WY" <?php  selected($designation, 'WY'); ?>>Wyoming</option><?php */ ?>
      <option value="other" <?php selected($designation, 'other'); ?>>Other</option>
    </select>
    <div class="help-block with-errors"></div>
  </div>
  <div class="form-group other-designation" style="display:none">
    <label for="other_designation"><?php _e('Please Enter Title', 'paid-memberships-pro'); ?></label>  
    <input id="other_designation" name="other_designation" type="text" class=" " size="30" value="<?php echo esc_attr($other_designation); ?>" />
    <div class="help-block with-errors"></div>     
  </div>
</div>


<?php
$pmpro_include_billing_address_fields = apply_filters('pmpro_include_billing_address_fields', true);
if ($pmpro_include_billing_address_fields) {
  ?>
  <div id="pmpro_billing_address_fields" class="pmpro_checkout">
    <div class="col-sm-12">	<h3>Contact Info</h3></div>
    <div class="pmpro_checkout-fields row">
      <div class="pmpro_checkout-field pmpro_checkout-field-bphone col-sm-12 col-lg-6">
        <div class="form-group">
          <label for="bphone"><?php _e('Primary Phone', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input id="bphone" required="" name="bphone" type="text" class="input <?php echo pmpro_getClassForField("bphone"); ?>" size="30" value="<?php echo esc_attr(formatPhone($pmpro_bphone)); ?>" />
          <div class="help-block with-errors"></div>
        </div>
      </div> 

      <?php
      do_action('pmpro_checkout_after_password');
      ?>
      <!-- we have moved the bfname and last name on to the top of the username -->
      <div class="pmpro_checkout-field pmpro_checkout-field-baddress1 col-sm-12">
        <div class="form-group">
          <label for="baddress1"><?php _e('Address 1', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
          <input id="baddress1" required="" name="baddress1" type="text" class="input <?php echo pmpro_getClassForField("baddress1"); ?>" size="30" value="<?php echo esc_attr($pmpro_baddress1); ?>" />
          <div class="help-block with-errors"></div>                                                                                  
        </div>
      </div> <!-- end pmpro_checkout-field-baddress1 -->
      <div class="pmpro_checkout-field pmpro_checkout-field-baddress2 col-sm-12">
        <label for="baddress2"><?php _e('Address 2', 'paid-memberships-pro'); ?></label>
        <input id="baddress2" name="baddress2" type="text" class="input <?php echo pmpro_getClassForField("baddress2"); ?>" size="30" value="<?php echo esc_attr($pmpro_baddress2); ?>" />
      </div> <!-- end pmpro_checkout-field-baddress2 -->
      <?php
      global $pmpro_states;
      $longform_address = apply_filters("pmpro_longform_address", true);
      if ($longform_address) {
        if (empty($bstate)) {
          if (empty($pmpro_bstate)) {
            $bstate = '';
          } else {
            $bstate = $pmpro_bstate;
          }
        }
        ?>
        <div class="pmpro_checkout-field pmpro_checkout-field-bcity col-sm-12 col-lg-6">
          <div class="form-group">
            <label for="bcity"><?php _e('City', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input id="bcity"  required="" name="bcity" type="text" class="input <?php echo pmpro_getClassForField("bcity"); ?>" size="30" value="<?php echo esc_attr($pmpro_bcity); ?>" />
            <div class="help-block with-errors"></div>                                                                                          
          </div>
        </div> <!-- end pmpro_checkout-field-bcity -->
        <div class="pmpro_checkout-field pmpro_checkout-field-bstate col-sm-12 col-lg-6">
          <div class="form-group">  
            <label for="bstate"><?php _e('State', 'paid-memberships-pro'); ?></label>       
            <select name="bstate" id="bstate" class="<?php echo pmpro_getClassForField("bstate"); ?>">
              <option value="">--</option>
              <?php foreach ($pmpro_states as $ab => $st) { ?>
                <option value="<?php echo esc_attr($ab); ?>" <?php if ($ab == $pmpro_bstate) { ?>selected="selected"<?php } ?>><?php echo $st; ?></option>
              <?php } ?>
            </select>

            <div class="help-block with-errors"></div>                                                                                      
          </div>
        </div> <!-- end pmpro_checkout-field-bstate -->
        <div class="pmpro_checkout-field pmpro_checkout-field-bzipcode col-sm-12 col-lg-6">
          <label for="bzipcode"><?php _e('Zip Code', 'paid-memberships-pro'); ?></label>
          <input id="bzipcode" name="bzipcode" type="text" class="input <?php echo pmpro_getClassForField("bzipcode"); ?>" size="30" value="<?php echo esc_attr($pmpro_bzipcode); ?>" />

        </div> <!-- end pmpro_checkout-field-bzipcode -->
      <?php } else { ?>
        <div class="pmpro_checkout-field pmpro_checkout-field-bcity_state_zip col-sm-12 col-lg-6">
          <label for="bcity_state_zip"><?php _e('City, State Zip', 'paid-memberships-pro'); ?></label>
          <input id="bcity" name="bcity" type="text" class="input <?php echo pmpro_getClassForField("bcity"); ?>" size="14" value="<?php echo esc_attr($pmpro_bcity); ?>" />,
          <?php $state_dropdowns = apply_filters("pmpro_state_dropdowns", false); ?>

          <input id="bzipcode"  name="bzipcode" type="text" class="input <?php echo pmpro_getClassForField("bzipcode"); ?>" size="5" value="<?php echo esc_attr($pmpro_bzipcode); ?>" />
        </div> <!-- end pmpro_checkout-field-bcity_state_zip -->
      <?php } ?>

      <?php
      $show_country = apply_filters("pmpro_international_addresses", true);
      if ($show_country) {
        global $pmpro_countries, $pmpro_default_country;
        if (empty($bcountry)) {
          if (empty($pmpro_bcountry)) {
            $bcountry = $pmpro_default_country;
          } else {
            $bcountry = $pmpro_bcountry;
          }
        }
        ?>
        <div class="pmpro_checkout-field pmpro_checkout-field-bcountry col-sm-12 col-lg-6">
          <label for="bcountry"><?php _e('Country', 'paid-memberships-pro'); ?></label>
          <select name="bcountry" id="bcountry" class="<?php echo pmpro_getClassForField("bcountry"); ?>"  data-default-value="<?php $bcountry; ?>" >
            <?php
            foreach ($pmpro_countries as $abbr => $country) {
              ?>
              <option value="<?php echo $abbr ?>" 
                <?php if ($abbr == $bcountry) { ?>selected="selected"<?php } ?>>
                <?php echo $country ?>                                  
              </option>
            <?php } ?>
          </select>
        </div> <!-- end pmpro_checkout-field-bcountry -->
      <?php } else { ?>
        <input type="hidden" name="bcountry" value="US" />
      <?php } ?>

      <?php //if($skip_account_fields) {  ?>
        <?php
        if ($current_user->ID) {
          if (!$bemail && $current_user->user_email) {
            $bemail = $current_user->user_email;
          }
          if (!$bconfirmemail && $current_user->user_email) {
            $bconfirmemail = $current_user->user_email;
          }
        }
        ?>
        <?php
        $pmpro_checkout_confirm_email = apply_filters("pmpro_checkout_confirm_email", true);
        $pmpro_checkout_confirm_email = false;
        if ($pmpro_checkout_confirm_email) {
          ?>
          <div class="pmpro_checkout-field pmpro_checkout-field-bconfirmemail">
            <input id="bconfirmemail" required  name="bconfirmemail" type="<?php echo ($pmpro_email_field_type ? 'email' : 'text'); ?>" class="input <?php echo pmpro_getClassForField("bconfirmemail"); ?>" size="30" value="<?php echo esc_attr($bconfirmemail); ?>" />
            <label for="bconfirmemail"><?php _e('Confirm E-mail', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <div class="help-block with-errors"></div>
          </div> <!-- end pmpro_checkout-field-bconfirmemail -->
        <?php } else { ?>
          <input type="hidden" name="bconfirmemail_copy" value="1" />
        <?php } ?>
        <?php //}  ?>
      </div> <!-- end pmpro_checkout-fields -->
    </div> <!--end pmpro_billing_address_fields -->
  <?php } ?>

  <div class="pmpro_hidden">
    <input id="fullname" name="fullname" type="text" class="input <?php echo pmpro_getClassForField("fullname"); ?>" size="30" value="" />
    <label for="fullname"><?php _e('Full Name', 'paid-memberships-pro'); ?></label>
    <strong><?php _e('LEAVE THIS BLANK', 'paid-memberships-pro'); ?></strong>
  </div> <!-- end pmpro_hidden -->

  <div class="pmpro_checkout-field pmpro_captcha">
    <?php
    global $recaptcha, $recaptcha_publickey;
    if ($recaptcha == 2 || ($recaptcha == 1 && pmpro_isLevelFree($pmpro_level))) {
      echo pmpro_recaptcha_get_html($recaptcha_publickey, NULL, true);
    }
    ?>
  </div> <!-- end pmpro_captcha -->

  <?php
  do_action('pmpro_checkout_after_captcha');
  ?>
  <div class="col-sm-12 col-lg-12">  <div class="btn-group">
    <button class="btn btn-txt pp-update" type="submit"><?php _e('Update', 'paid-memberships-pro'); ?></button>
  </div> </div>
</div>
</div>  <!-- end pmpro_checkout-fields -->
</div> <!-- end pmpro_user_fields -->
</div>
</div>
</div>

</form>
</div>
<!--  </div> -->
<?php /* ?>
<!-- Modal -->
<div class="modal fade custom-popup" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/assets/images/close-icon.svg"></span>
        </button>
        <p>User profile has been updated.</p>
      </div> 

      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div> 
</div> 
<!-- /.modal -->
<?php */ ?>
</div><!-- .entry-content -->
</article><!-- #post-## -->

<?php endwhile; // End of the loop.    ?>

</main><!-- #main -->
</div><!-- #primary -->



</div><!--#content-inside -->
</div><!-- #content -->  

<script type="text/javascript">
  var cellphone = '<?php echo $cell_phone; ?>';
  jQuery("div.profile-pic").click(function () {
    jQuery("#user_pic").click();
  });
  jQuery('#cell_phone').val(cellphone);
  jQuery(window).load(function ($) {
    jQuery('#bcountry').attr('data-default-value', '<?php echo $bcountry; ?>');
    jQuery('#bcountry option[value="<?php echo $bcountry; ?>"]').prop('selected', true);
    jQuery('#bcountry').trigger('change');
    jQuery('#bstate').attr('data-default-value', '<?php echo $bstate; ?>');
    jQuery('#bstate option[value="<?php echo $bstate; ?>"]').prop('selected', true);
    jQuery('#bstate').trigger('change');
  });

</script> 

<script type="text/javascript">
  jQuery.noConflict();
  (function( $ ) {
    jQuery(function() {
      /*update edit profile*/
      $.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-zA-Z\s]+$/i.test(value);
      }, "Letters only please");
      $.validator.addMethod("validemail", function(value, element) {
        return this.optional(element) || /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/i.test(value);
      }, "Enter a valid email only please");   
      $("#personal-info").validate({
        rules: {
          bfirstname: {
            required: true,
          },
          action: "required",
          bemail: {
            required: true,    
            validemail: true,      
            remote: {
              url: nstxl_ajaxurl,
              type: 'post',        
              data: {
                action: 'nstxl_check_userbemail',
                bemail: function () {
                  return $("input[name='bemail']").val();
                }
              },
            }         
          },
          blastname: {
           required: true,
         }, 
         bphone: {
           required: true,
         },
         baddress1: {
           required: true,
         },
         bcity: {
           required: true,
         },              
         user_name: {
          required: true,
          minlength: 5,
        },
      },
      messages: {      
        bemail: {
         required: "Please enter email",
         validemail:"Please enter valid email address",
         remote: 'Email is already taken.'
       }      
     },
     errorClass: "form-invalid",
   // errorLabelContainer:'.help-block.with-errors',
   errorElement: 'div',
   highlight: function(element, errorClass, validClass) {
    $(element).closest("div.field").addClass("error").removeClass("success");
  },
  unhighlight: function(element, errorClass, validClass){
    $(element).closest(".error").removeClass("error").addClass("success");
  },
  errorPlacement: function (error, element) {

    if(element.parent().find("div.help-block.with-errors").length === 0) {
      if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {          
        element.parent().append(error); 
      } else {

        error.addClass("help-block with-errors").appendTo( element.closest('div.form-group'));          
      }
    } else {
      if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
          element.parent().append(error); // this would append the label after all your checkboxes/labels (so the error-label will be the last element in <div class="controls"> )
        } else {
          error.appendTo(element.parent().find("div.help-block.with-errors"));
        }

      }
    },   
    submitHandler: function(form) {       
      var form = jQuery('form#personal-info')[0]; 
      var formData = new FormData(form);
      formData.append("action", "nstxl_update_personal_profile");     
      $.ajax({
        url: nstxl_ajaxurl,
        type: "POST",
        data: formData,
        async: false,
        beforeSend: function() {
          console.log('253512');
        // jQuery('.next-step-loader').css('display', 'block');
        $(".preloader").show();
        jQuery('.preloader').css('display', 'block'); 
      },        
      success: function (response, textStatus, jqXHR)
      {               
       if (response.data.response == "success") {
        jQuery('#update-personalinfo-modal-success').modal('show');
      }

    },
    error: function(jqXHR, textStatus, errorThrown) { 
      add_message( textStatus, "danger" );
    },
    complete: function(){
      $(".preloader").hide();        
    },
    cache: false,
    contentType: false,
    processData: false
  });
    }    
  });


      jQuery('.form-group.required').each( function(){
        jQuery(this).find('input').prop('required',true);
        jQuery(this).find('select').prop('required',true);
        if(jQuery(this).find('.help-block').length == 0) {
      //jQuery(this).find('input').after('<div class="help-block with-errors"></div>');
      jQuery(this).append('<div class="help-block with-errors"></div>');
    }
  }); 
    });
})(jQuery); 
</script>   
<?php $modal_id = 'update-personalinfo-modal-success';
  $modal_body_container_class  = 'update-personalinfo-modal-success-container';
  $content_html = '<h4>User profile has been updated.</h4>';
   nstxl_modal_popup($content_html, $modal_id, $modal_body_container_class); ?>
<?php
get_footer('admin'); 

