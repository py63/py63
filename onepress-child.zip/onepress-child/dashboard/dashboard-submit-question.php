<?php
/**
*Template Name: Dashboard Submit Question
*/

global $wpdb, $current_user;
if (!is_user_logged_in() ) { 
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit; }  
get_header('admin');

 $join_lists = "";
 do_action('onepress_page_before_content');
  ?>
  <div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

         <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' );  ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <!--Star of container -->
              <div class="current-opportunities-container opportunity-dashbaord-grid dashboard-inner-wrapper">
          
                <div class="submit-question-inner opportunity-content">   
                <h4><?php _e('Please choose the project you’re submitting to :','paid-memberships-pro'); ?></h4>  

                  <!-- Blog Query  -->
                  <div class="opportunity-posts">
                    <!-- the loop -->
                    <?php
                        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                        $args = array(
                        'order' => 'DESC',
                        'posts_per_page' => 6,
                        'post_type' => 'opportunity',
                        'post_status' => 'publish',
                        'meta_query' => array(
                            'relation' => 'OR',
                            array(
                                'key'     => 'nstxl_question_deadline',
                                'value'   => date("Y-m-d H:i:s", current_time("timestamp")), 
                                'compare' => '>',
                                'type'        => 'date'
                            ),
                            array(
                                'key' => 'nstxl_question_deadline',
                                'value'   => '',
                                'compare' => NULL,
                            ),
                        ),
                         'tax_query' => array(
                        array(
                        'taxonomy' => 'opportunity-type',
                        'field' => 'term_id',
                        'terms' => array(40,43),
                        ), 
                       ),   
                        'paged' => $paged,
                        );

                        $opportunity_query = new WP_Query($args);

                    ?>
                    <div class="card-deck">
                   <?php
                    if ($opportunity_query->have_posts()) : while ($opportunity_query->have_posts()) : $opportunity_query->the_post();
                        include(locate_template('templates/opportunity/main-tabs/content-opportunities.php'));
                    endwhile;
                          ?>
                        <?php else : ?>
                        <!-- No posts found -->
                        <div class="text-center"><h3>No opportunities found</h3></div>
                      <?php endif; ?>

                    </div>   
                     <!-- End of Blog Query -->
                    <div class="loadmore wow animated fadeInUp" id="loadmores"><?php echo get_next_posts_link('Load more', $opportunity_query->max_num_pages); ?></div>
                  </div>
                 
                  </br>
                  <h4 class="text-center mt-2"><?php _e('Haven’t tracked the opportunity? Click ','paid-memberships-pro'); ?> <a style="color:#bf3737" href="<?php echo site_url(); ?>/tracked-opportunities/">Here</a> <?php _e('to find and track it.','paid-memberships-pro'); ?></h4> 
                  
                </div>
                <?php wp_reset_query(); ?>
    

            </div><!-- .entry-content -->
          </div>
          </article><!-- #post-## -->
</main>
</div>
</div>
</div>

<script>
  jQuery(document).ready(function ($) {
    trackOpportunity();
    untrackOpportunity();
    $('body').on('click', '.loadmore a', function (e) {
      e.preventDefault();
      var temphref = $(this).attr('href');
      $("#loadmores").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> Loading...</div>");

      $.post(temphref, function (response) {
        $("#loadmores").remove();
        var tempdata = $(response).find('.opportunity-posts').html();
        $(".opportunity-posts").append(tempdata);
        trackOpportunity();
        untrackOpportunity();
      });
    });
  });
</script>
<?php

get_footer('admin');