<?php
get_header();
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
global $current_user;
$cusr_id = $current_user->ID;
$layout = onepress_get_layout();
?>

<div id="content" class="site-content">
  <div id="content-inside" class="container <?php echo esc_attr($layout); ?>">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <header class="entry-header">
            <?php  the_title('<h1 class="entry-title">', '</h1>'); ?>
            <?php /* if (get_theme_mod('single_meta', 1)) { ?>
            <div class="entry-meta">
              <?php onepress_posted_on(); ?>
            </div><!-- .entry-meta -->
            <?php } */?>
          </header><!-- .entry-header -->

          <?php if (get_theme_mod('single_thumbnail', 0) && has_post_thumbnail()) { ?>
          <div class="entry-thumbnail">
            <?php
            $layout = onepress_get_layout();
            $size = 'large';
            the_post_thumbnail($size);
            ?>
          </div><!-- .entry-footer -->
          <?php } ?>            

          <div class="entry-content">
            <?php if(!empty(get_field( 'nstxl_overview', get_the_ID()))){ ?>
            <h5>Overview</h5>
            <?php echo wp_trim_words( the_field( 'nstxl_overview', get_the_ID()), 500, '...' ); ?>
            <hr>
            <?php } ?>
            <?php the_content(); ?>
            <?php
            //$opr_id = get_the_ID(); //get_template_part( 'templates/opportunity/tabs/opportunity-tabs' ); 
            // include(locate_template('templates/opportunity/tabs/opportunity-tabs.php'));
            ?>	
            <div class="information-bellow-tab">
              <hr>
              <?php echo the_field('information_bellow_tab', get_the_ID()); ?>									
            </div>
          </div><!-- .entry-content -->
           <?php include(locate_template('templates/opportunity/sidebar/submitproposal.php')); ?>	
          
          <?php if (get_theme_mod('single_meta', 1)) { ?>

          <?php onepress_entry_footer(); ?>

          <?php } ?>
        </article><!-- #post-## -->

        <?php endwhile; // End of the loop.   ?>

      </main><!-- #main -->
    </div><!-- #primary -->
    <?php
      $opr_id = get_the_ID(); //get_template_part( 'templates/opportunity/tabs/opportunity-tabs' ); 
      include(locate_template('templates/opportunity/sidebar/sidebar-opportunities.php'));
    ?>	

  </div><!--#content-inside -->
</div><!-- #content -->
<?php
get_footer();
