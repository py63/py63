<?php
include(locate_template('templates/opportunity/sidebar/keydocuments.php')); 
include(locate_template('templates/opportunity/sidebar/additionaldocuments.php')); 