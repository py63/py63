<?php
/**
 * Template Name: Login
 *
 */
get_header();

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
?>  
<div id="content" class="site-content form-page">
	<?php

	if(is_user_logged_in())
	{
		echo "<p style='text-align: center'><strong>You Are Already Logged In</strong></p>";
	}	
	else{
		
		while( have_posts() ) : the_post();

			the_content();

			if( $enable_page_comments && comments_open() ) {
				comments_template();
			}

		endwhile;

	}
	
	?>
	<?php 
	if(isset($_REQUEST['err']) && $_REQUEST['err'] == 'true')
	{
		$error_msg = 'Looks like you are already registered. Please Login';
		?>
		<script>
			jQuery(document).ready(function($){
				jQuery('#login-modal-error').modal('show');
			});
		</script>	



		<!-- Modal -->
		<div class="modal fade" id="login-modal-error" tabindex="-1" role="dialog" aria-labelledby="organization-modalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> 
						<div style="padding: 40px">
							<p style="color:red; text-align: center"><?php echo $error_msg; ?></p>
						</div>

					</div>
				</div>
				<!-- /.modal-content -->
			</div>
			<!-- /.modal-dialog -->
		</div>
	<?php } ?>
	<!-- /.modal -->

	<?php 
	if(isset($_GET['redirect_to']) && $_GET['redirect_to']) { ?>
		<script>
			jQuery(document).ready(function($){
		jQuery('form[name=login] input[name=redirect_to]').val('<?php echo $_REQUEST["redirect_to"]; ?>');
	});
</script>	
<?php } ?>


<?php 
if(isset($_REQUEST['err']) && $_REQUEST['err'] == 'blocked')
{
	$error_msg = 'You are membership has been rejected by NSTXL.';
	?>
	<script>
		jQuery(document).ready(function($){
			jQuery('#login-modal-error').modal('show');
		});
	</script>	
	<!-- Modal -->
	<div class="modal fade" id="login-modal-error" tabindex="-1" role="dialog" aria-labelledby="organization-modalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> 
					<div style="padding: 40px">
						<p style="color:red; text-align: center"><?php echo $error_msg; ?></p>
					</div>

				</div>
			</div>
			<!-- /.modal-content -->
		</div>
		<!-- /.modal-dialog -->
	</div>
<?php } ?>
<!-- /.modal -->
</div>
<?php

get_footer();
 