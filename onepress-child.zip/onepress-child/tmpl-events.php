<?php
/*
 * Template Name: Events Template
 */
get_header();
do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">  
  <div id="content-inside" class="container no-sidebar">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <div class="blog-section">
          <div class="form-01">
           <?php /*
           $terms = get_terms(array(
            'taxonomy' => 'category',
            'hide_empty' => false,
            'include' => array(54, 30)
          ));
           echo '<select class="categoryfilter custom-select" id="categoryfilter" name="categoryfilter"><option value="">Select Category</option>';
           foreach ($terms as $term) :
            echo '<option id="searchpost" value="' . $term->slug . '">' . $term->name . '</option>';
          endforeach;
          echo '</select>';
         */ ?>
          <?php $unique_id = esc_attr(uniqid('search-form-')); ?>
          <form role="search" method="get" class="search-form opportunity-search" action="<?php echo esc_url(home_url('/')); ?>/search-event">
            <input type="search" id="<?php echo $unique_id; ?>" class="search-field" placeholder="<?php echo esc_attr_x('Search', 'placeholder', 'polar'); ?>" value="<?php echo get_search_query(); ?>" name="sa" />
            <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text"><?php echo _x('Search', 'submit button', 'polar'); ?></span></button>
          </form>   
        </div>
        <div class="blog-posts">
          <div class="card-deck" id="posts">



            <?php
            $postperpage = (isset($_POST["postperpage"])) ? $_POST["postperpage"] : 6;
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

             $featured_events_select_postid = get_theme_mod('featured_events_select_postid'); 

            if( !empty ($featured_events_select_postid) ){
              $args = array('post_type' => 'post', 'posts_per_page' => $postperpage, 'post_status' => 'publish',  'paged' => $paged, 'category__in' => array(46),'post__not_in' => array($featured_events_select_postid));                                            
            }
            else
            {
              $args = array('post_type' => 'post', 'posts_per_page' => $postperpage, 'post_status' => 'publish',  'paged' => $paged, 'category__in' => array(46));  
            } 

            query_posts($args);
            ?>
            <?php
            if(have_posts()) : while (have_posts()) : the_post(); 
              $posttitle = get_the_title();
              $wordcount = str_word_count($posttitle);
              ?>

              <?php
                /*
                 * Include the Post-Format-specific template for the content.
                 * If you want to override this in a child theme, then include a file
                 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                 */
                get_template_part('template-parts/content', 'blog');
                ?>
              <?php endwhile; ?>
              <?php else : ?>
                <!-- No posts found -->
              <?php endif; ?>

              <?php
              global $wp_query;
          //echo $wp_query->max_num_pages;
              $max_page = $wp_query->max_num_pages;
              if ($max_page > $paged) {
                ?>
                 <div class="loadmore wow animated fadeInUp" id="loadmores"><?php echo get_next_posts_link('Load more', $wp_query->max_num_pages); ?></div>
              <?php } ?>
            </div>
          </div>
        </div><!--blog-section -->
      </main><!-- #main -->

    </div><!-- #primary -->
  </div><!--#content-inside -->
</div><!-- #content -->
<?php wp_reset_query(); ?>

<script>
  jQuery(document).ready(function ($) {
    $('body').on('click', '.loadmore a', function (e) {
      e.preventDefault();
      var temphref = $(this).attr('href');
      $("#loadmores").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> Loading...</div>");

      $.post(temphref, function (response) {
        $("#loadmores").remove();
        var tempdata = $(response).find('.blog-posts').html();
        $(".blog-posts").append(tempdata);
      });
    });
  });
</script>
<?php
get_footer();
