<?php
/**
 * Template Name: Membership-list
 *
 * @package OnePress
 */
get_header();
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">

  <?php
  onepress_breadcrumb();
  ?>
<div id="elementor-section">  
<div id="content-inside" class="container no-sidebar member-ship-list">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' );  ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>

       <div class="search-form-section member-list">
                        <form role="search" method="get" class="search" >
              <input type="search" id="membername" class="search-field" placeholder="Search"  name="s" onkeydown="return event.key != 'Enter';">
              <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text">Search</span></button>
            </form>
          </div>   

              <div class='membercontent container'>
                <div class="filter-container"> 
                  <ul id="alpha-filterlist">
                    <li>#</li>   
                    <?php
                    foreach (range('a', 'z') as $v) {
                      if ($v == 'a') {
                        echo '<li class="active">';
                      } else {
                        echo '<li>';
                      }
                      echo '<a href="javascript:void(0)" data-value="' . $v . '">' . $v . '</a></li>';
                    }
                    ?>
                  </ul>
                </div> 
                <div id="displaymember"></div>
              </div>

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->
  </div><!--#content-inside -->
 </div> 
</div><!-- #content -->
<script type="text/javascript">
  jQuery(document).ready(function ($) {
    jQuery('#alpha-filterlist li a[data-value=a]').trigger('click');
  });
  jQuery(document).on('click', '#alpha-filterlist li a', function (e) {
    jQuery("#membername").val(''); 
    e.preventDefault();
    jQuery('#alpha-filterlist li.active').removeClass('active');
    var $parent = jQuery(this).parent();
    $parent.addClass('active');
    var shortVal = jQuery(this).data('value');
    var data = {short_val: shortVal, action: 'nstxl_display_member_list'};
    jQuery.ajax({
      url: nstxl_ajaxurl,
      type: 'POST',
      data: data,
      cache: false,
      dataType: 'json',
      beforeSend: function () {
        jQuery('.nstxl-loader').show();
        jQuery('.loader-overlay').show();
      },
      complete: function () {
        jQuery('.nstxl-loader').hide();
        jQuery('.loader-overlay').hide();
      },
      success: function (data, textStatus, jqXHR) {
        //   console.log(data.data);
        if (data.data != "") {
          jQuery("#displaymember").html(data.data);
        } else {
          jQuery("#displaymember").html('<h3>No data found</h3>');
        }
      }
    });
  });
</script> 


<script type="text/javascript">
   jQuery(document).ready(function(){
        jQuery("#membername").keyup(function(){
      jQuery('#alpha-filterlist li.active').removeClass('active');       
   var shortVal  =  jQuery("#membername").val(); 
   if(shortVal == '') 
   {
   jQuery('#alpha-filterlist li a[data-value=a]').trigger('click'); 
   }
 //  alert(shortVal);
   if(jQuery(this).val().length > 2) {
   var data = { short_val: shortVal, action: 'nstxl_display_member_list_input' }; 
   jQuery.ajax( {
      url: nstxl_ajaxurl,
      type: 'POST',
      data: data,   
      cache: false,
      dataType: 'json',
      beforeSend: function () {  
        // jQuery( '.nstxl-loader' ).show();
        // jQuery( '.loader-overlay' ).show();
      },
      complete: function () {
        // jQuery( '.nstxl-loader' ).hide();
        // jQuery( '.loader-overlay' ).hide();
      },
      success: function ( data, textStatus, jqXHR ) {
    //   console.log(data.data);
       if ( data.data !="" ) {
        jQuery( "#displaymember" ).html(data.data);
      } else {
        jQuery( "#displaymember" ).html('<h3>No data found</h3>');
      }
    }
  });
}

 });
});   
</script> 




<?php get_footer(); ?>
