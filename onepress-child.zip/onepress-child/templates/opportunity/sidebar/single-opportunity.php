<?php
get_header();
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
global $current_user;
$cusr_id = $current_user->ID;
$layout = onepress_get_layout();
?>

<div id="content" class="site-content">

  <?php onepress_breadcrumb(); ?>

  <div id="content-inside" class="container <?php echo esc_attr($layout); ?>">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
              <?php if (get_theme_mod('single_meta', 1)) { ?>
                <div class="entry-meta">
                  <?php onepress_posted_on(); ?>
                </div><!-- .entry-meta -->
              <?php } ?>
            </header><!-- .entry-header -->

            <?php if (get_theme_mod('single_thumbnail', 0) && has_post_thumbnail()) { ?>
              <div class="entry-thumbnail">
                <?php
                $layout = onepress_get_layout();
                $size = 'large';
                the_post_thumbnail($size);
                ?>
              </div><!-- .entry-footer -->
            <?php } ?>            

            <div class="entry-content">
              <?php the_content(); ?>
              <?php
              $opr_id = get_the_ID(); //get_template_part( 'templates/opportunity/tabs/opportunity-tabs' ); 

              include(locate_template('templates/opportunity/tabs/opportunity-tabs.php'));
              ?>	
              <div class="information-bellow-tab">
                <hr>
                <?php echo the_field('information_bellow_tab', get_the_ID()); ?>									
              </div>
            </div><!-- .entry-content -->
            <?php if (get_theme_mod('single_meta', 1)) { ?>

              <?php onepress_entry_footer(); ?>

            <?php } ?>
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->

    <div id="secondary" class="widget-area sidebar" role="complementary">
      <?php
      $repeater_update = get_field('latest_updates_section');
      if (isset($repeater_update) && !empty($repeater_update)) {
        ?>
        <aside class="aside-opportunity-content widget">
          <h2 class="widget-title">
            <?php _e('Latest Update', 'onpress'); ?>
          </h2>
          <div class="widget-content">
            <?php
            echo '<ul>';
            foreach ($repeater_update as $row) {
              echo '<li><a href="' . $row['latest_update_doc']['url'] . '" download>' . $row['latest_update_doc']['filename'] . '</a></li>';
            }
            echo '</ul>';
            ?>
          </div>
        </aside>
      <?php } ?>
      <?php
      $add_repeater_update = get_field('additional_documents');
      if (isset($add_repeater_update) && !empty($add_repeater_update)) {
        ?>
        <aside class="aside-opportunity-content widget">
          <h2 class="widget-title">
            <?php _e('ADDITIONAL DOCUMENTS', 'onpress'); ?>
          </h2>
          <div class="widget-content">
            <?php
            echo '<ul>';
            foreach ($add_repeater_update as $row) {
              echo '<li><a href="' . $row['additional_documents_doc']['url'] . '" download>' . $row['additional_documents_doc']['filename'] . '</a></li>';
            }
            echo '</ul>';
            ?>
          </div> 
        </aside>
      <?php } ?>
      <?php
      $datePosted = get_field('nstxl_date_posted', get_the_ID());
      $qusdeadline = get_field('nstxl_question_deadline', get_the_ID());
      $industryday = get_field('nstxl_industry_day', get_the_ID());
      $expected_question_posting = get_field('nstxl_expected_question_posting', get_the_ID());
      $proposal_deadline = get_field('nstxl_proposal_deadline', get_the_ID());
      $expected_date_of_award = get_field('nstxl_expected_date_of_award', get_the_ID());
      if (!empty($datePosted) || !empty($qusdeadline) || !empty($industryday) || !empty($expected_question_posting) || !empty($proposal_deadline) || !empty($expected_date_of_award)) {
        ?>
        <aside class="aside-opportunity-content widget">
          <h2 class="widget-title"><?php _e('Important Dates', 'onpress'); ?></h2>
          <div class="widget-content">
            <ul>
              <?php if (!empty($datePosted)) { ?>
                <li><?php _e('Date Posted', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($datePosted))); ?></li>
              <?php } ?>
              <?php if (!empty($qusdeadline)) { ?>
                <li><?php _e('Question Deadline', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($qusdeadline))); ?></li>
              <?php } ?>
              <?php if (!empty($industryday)) { ?>
                <li><?php _e('Industry Day', 'onpress'); ?>: <?php echo $industryday; ?></li>
              <?php } ?>
              <?php if (!empty($expected_question_posting)) { ?>
                <li><?php _e('Expected Question Posting', 'onpress'); ?>: <?php echo $expected_question_posting; ?></li>
              <?php } ?>
              <?php if (!empty($proposal_deadline)) { ?>
                <li><?php _e('Proposal Submission Deadline', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($proposal_deadline))); ?></li>
              <?php } ?>
              <?php if (!empty($expected_date_of_award)) { ?>
                <li><?php _e('Expected Date Of Award', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($expected_date_of_award))); ?></li>
              <?php } ?>
            </ul>
          </div> 
        </aside>
      <?php } ?>
    </div><!-- #secondary -->
  </div><!--#content-inside -->
</div><!-- #content -->
<?php
get_footer();
