<?php

global $pmpro_reports;

$pmpro_reports['members_by_tech_area'] = __('Members by Tech Area', 'paid-memberships-pro' );


//widget
function pmpro_report_members_by_tech_area_widget() {
	global $wpdb;

	$techarea1 = nstxl_members_count_by_tech_area('Artificial_Intelligence');
	$techarea2 = nstxl_members_count_by_tech_area('machine-learning');
	$techarea3 = nstxl_members_count_by_tech_area('big-data-analytics');
	$techarea4 = nstxl_members_count_by_tech_area('Cloud_Computing');
	$techarea5 = nstxl_members_count_by_tech_area('advanced-computing'); 
	$total_techarea = nstxl_members_count_by_tech_area_total();   
	?>

	<span id="pmpro_report_members_by_tech_area_memberships" class="pmpro_report-holder">
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php _e('Tech Area', 'paid-memberships-pro' ); ?></th>
					<th scope="col"><?php _e('All Members', 'paid-memberships-pro' ); ?></th>
				</tr>
				<tr>
					<th scope="col"><strong><?php _e('Total Members', 'paid-memberships-pro' ); ?></strong></th>
					<th scope="col"><strong><?php echo $total_techarea;?></strong></th>
				</tr>
			</thead>

			<tbody>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Artificial Intelligence', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $techarea1; ?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Machine Learning', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $techarea2;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Big Data Analytics', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $techarea3;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Cloud Computing', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $techarea4;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('Advanced Computing', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $techarea5;?></td>

				</tr>

			</tbody>

		</table>
		<?php if ( function_exists( 'pmpro_report_members_by_tech_area_page' ) ) { ?>
			<p class="pmpro_report-button">
				<a class="button button-primary" href="<?php echo admin_url( 'admin.php?page=pmpro-reports&report=members_by_tech_area' ); ?>"><?php _e('Details', 'paid-memberships-pro' );?></a>
			</p>
		<?php } ?>
	</span>

	<?php
}

function pmpro_report_members_by_tech_area_page()
{

	global $wpdb;

	//vars
	if(!empty($_REQUEST['s']))
		$s = sanitize_text_field( $_REQUEST['s'] );
	else
		$s = "";

	if(!empty($_REQUEST['l'])) {
		if($_REQUEST['l'] == 'all')
			$l = '';
		else
			$l = $_REQUEST['l'];
	} else {
		$l = "";
	}
	?>
	<h1><?php _e('Members by Tech Area', 'paid-memberships-pro' ); ?></h1>		


	<form id="posts-filter" method="get" action="">	
		<ul class="subsubsub">
			<li>			
				<?php _e( 'Show', 'Dropdown label, e.g. Show All Members', 'paid-memberships-pro' )?>
				<select name="l" onchange="jQuery('#posts-filter').submit();">
					<option value="all" >All Tech Area</option>
					<option value="Artificial_Intelligence" <?php if($l == "Artificial_Intelligence") { ?>selected="selected"<?php } ?>>Artificial Intelligence</option>
					<option value="machine-learning" <?php if($l == "machine-learning") { ?>selected="selected"<?php } ?>>Machine Learning</option>
					<option value="big-data-analytics" <?php if($l == "big-data-analytics") { ?>selected="selected"<?php } ?>>Big Data Analytics</option>
					<option value="Cloud_Computing" <?php if($l == "Cloud_Computing") { ?>selected="selected"<?php } ?>>Cloud Computing</option>
					<option value="advanced-computing" <?php if($l == "advanced-computing") { ?>selected="selected"<?php } ?>>Advanced Computing</option>
					<option value="quantum-technologies" <?php if($l == "quantum-technologies") { ?>selected="selected"<?php } ?>>Quantum Technologies</option>
					<option value="Cyber_Operations_&_Training" <?php if($l == "Cyber_Operations_&_Training") { ?>selected="selected"<?php } ?>>Cyber Operations & Training</option>
					<option value="cybersecurity-general" <?php if($l == "cybersecurity-general") { ?>selected="selected"<?php } ?>>Cybersecurity (general)</option>
					<option value="Instrumentation,_Test_&_Training" <?php if($l == "Instrumentation,_Test_&_Training") { ?>selected="selected"<?php } ?>>Instrumentation, Test & Training</option>
					<option value="multispectral-sensing" <?php if($l == "multispectral-sensing") { ?>selected="selected"<?php } ?>>Multispectral Sensing</option>
					<option value="microelectronics-verification-and-validation" <?php if($l == "microelectronics-verification-and-validation") { ?>selected="selected"<?php } ?>>Microelectronics Verification and Validation</option>
					<option value="modeling-and-simulation" <?php if($l == "modeling-and-simulation") { ?>selected="selected"<?php } ?>>Modeling & Simulation</option>
					<option value="Medical_Modeling_&_Simulation" <?php if($l == "Medical_Modeling_&_Simulation") { ?>selected="selected"<?php } ?>>Medical Modeling & Simulation</option>
					<option value="lethality-modeling-and-testing" <?php if($l == "lethality-modeling-and-testing") { ?>selected="selected"<?php } ?>>Lethality Modeling and Testing</option>
					<option value="Immersion_(VR/AR)" <?php if($l == "Immersion_(VR/AR)") { ?>selected="selected"<?php } ?>>Immersion (VR/AR)</option>
					<option value="Gaming_Applications" <?php if($l == "Gaming_Applications") { ?>selected="selected"<?php } ?>>Gaming Applications</option>
					<option value="Synthetic_Terrain" <?php if($l == "Synthetic_Terrain") { ?>selected="selected"<?php } ?>>Synthetic Terrain</option>
					<option value="virtualization" <?php if($l == "virtualization") { ?>selected="selected"<?php } ?>>Virtualization</option>
					<option value="warfighter-training" <?php if($l == "warfighter-training") { ?>selected="selected"<?php } ?>>Warfighter Training</option>
					<option value="logistics-software" <?php if($l == "logistics-software") { ?>selected="selected"<?php } ?>>Logistics Software</option>
					<option value="advanced-materials" <?php if($l == "advanced-materials") { ?>selected="selected"<?php } ?>>Advanced Materials</option>
					<option value="workforce-development" <?php if($l == "workforce-development") { ?>selected="selected"<?php } ?>>Workforce Development</option>
					<option value="standard-setting" <?php if($l == "standard-setting") { ?>selected="selected"<?php } ?>>Standard Setting</option>
					<option value="design-assurance" <?php if($l == "design-assurance") { ?>selected="selected"<?php } ?>>Design Assurance</option>
					<option value="human-systems-integration" <?php if($l == "human-systems-integration") { ?>selected="selected"<?php } ?>>Human Systems Integration</option>
					<option value="hypersonics" <?php if($l == "hypersonics") { ?>selected="selected"<?php } ?>>Hypersonics</option>
					<option value="autonomous-and-unmanned-systems" <?php if($l == "autonomous-and-unmanned-systems") { ?>selected="selected"<?php } ?>>Autonomous and Unmanned Systems</option>
					<option value="high-energy-lasers" <?php if($l == "high-energy-lasers") { ?>selected="selected"<?php } ?>>High Energy Lasers</option>
					<option value="spectrum-warfare-technologies" <?php if($l == "spectrum-warfare-technologies") { ?>selected="selected"<?php } ?>>Spectrum Warfare Technologies</option>
					<option value="gun-and-projectile-systems" <?php if($l == "gun-and-projectile-systems") { ?>selected="selected"<?php } ?>>Gun & Projectile Systems</option>
					<option value="launcher-technology" <?php if($l == "launcher-technology") { ?>selected="selected"<?php } ?>>Launcher Technology</option>
					<option value="surface-offensive-defensive-engagements" <?php if($l == "surface-offensive-defensive-engagements") { ?>selected="selected"<?php } ?>>Surface Offensive & Defensive Engagements</option>
					<option value="asymmetric-warfare" <?php if($l == "asymmetric-warfare") { ?>selected="selected"<?php } ?>>Asymmetric Warfare</option>
					<option value="direct-energy-science-and-engineering" <?php if($l == "direct-energy-science-and-engineering") { ?>selected="selected"<?php } ?>>Direct Energy Science and Engineering</option>
					<option value="integrated-warfare-systems" <?php if($l == "integrated-warfare-systems") { ?>selected="selected"<?php } ?>>Integrated Warfare Systems</option>
					<option value="strategic-missions-hardware" <?php if($l == "strategic-missions-hardware") { ?>selected="selected"<?php } ?>>Strategic Missions Hardware</option>
					<option value="field-programmable-gate-arrays" <?php if($l == "field-programmable-gate-arrays") { ?>selected="selected"<?php } ?>>Field Programmable Gate Arrays</option>
					<option value="chip-fabrication-tech" <?php if($l == "chip-fabrication-tech") { ?>selected="selected"<?php } ?>>Chip Fabrication Tech</option>
					<option value="radiation-hardening" <?php if($l == "radiation-hardening") { ?>selected="selected"<?php } ?>>Radiation Hardening</option>
					<option value="magnetic-random-access-memory" <?php if($l == "magnetic-random-access-memory") { ?>selected="selected"<?php } ?>>Magnetic Random Access Memory</option>
					<option value="electronic-manufacturing-technology" <?php if($l == "electronic-manufacturing-technology") { ?>selected="selected"<?php } ?>>Electronic Manufacturing Technology</option>
					<option value="RF-and-OE-microelectronics" <?php if($l == "RF-and-OE-microelectronics") { ?>selected="selected"<?php } ?>>RF & OE Microelectronics</option>
					<option value="microelectronics-development-and-development" <?php if($l == "microelectronics-development-and-development") { ?>selected="selected"<?php } ?>>Microelectronics development and development</option>
					<option value="programmable-IC" <?php if($l == "programmable-IC") { ?>selected="selected"<?php } ?>>Programmable IC</option>
					<option value="sensor-systems" <?php if($l == "sensor-systems") { ?>selected="selected"<?php } ?>>Sensor Systems</option>
					<option value="electromagnetic-technologies" <?php if($l == "electromagnetic-technologies") { ?>selected="selected"<?php } ?>>Electromagnetic Technologies</option>
					<option value="threat-engineering" <?php if($l == "threat-engineering") { ?>selected="selected"<?php } ?>>Threat Engineering</option>
					<option value="mission-engineering-and-analysis" <?php if($l == "mission-engineering-and-analysis") { ?>selected="selected"<?php } ?>>Mission Engineering and Analysis</option>
					<option value="electronic-power-management" <?php if($l == "electronic-power-management") { ?>selected="selected"<?php } ?>>Electronic Power Management</option>
					<option value="Other" <?php if($l == "Other") { ?>selected="selected"<?php } ?>>Other</option>

				</select>			
			</li>
		</ul>


		<p class="search-box">
			<label class="hidden" for="post-search-input"><?php _e( 'Search', 'Search form label', 'paid-memberships-pro')?> <?php if(empty($l)) echo "Users"; else echo "Members";?>:</label>
			<input type="hidden" name="page" value="pmpro-reports" />		
			<input type="hidden" name="report" value="members_by_tech_area" />		
			<!-- <input id="post-search-input" type="text" value="<?php // echo esc_attr($s)?>" name="s"/>
				<input class="button" type="submit" value="Search Members"/> -->
			</p>

			<?php 
		//some vars for the search					
			if(isset($_REQUEST['pn']))
				$pn = intval($_REQUEST['pn']);
			else
				$pn = 1;

			if(isset($_REQUEST['limit']))
				$limit = intval($_REQUEST['limit']);
			else
				$limit = 15;

			$end = $pn * $limit;
			$start = $end - $limit;		

			$exclude_users =  nstxl_suspended_users(); 

			if(!empty($exclude_users))
			{
				$exclude_users = "u.ID NOT IN (".$exclude_users.")";
			}
			else
			{
				$exclude_users = "1=1";    
			}		

			if($l)
			{

				$condition = "AND um.meta_key ='primary_application' AND um.meta_value LIKE '%{$l}%'";

				$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email,mu.status,UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership FROM $wpdb->users u LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->usermeta um1 ON u.ID = um1.user_id LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id";

				$sqlQuery .= " WHERE {$exclude_users} {$condition}  AND mu.status = 'active'"; 

				$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')"; 

				$sqlQuery .= "GROUP BY u.ID ORDER BY user_registered DESC LIMIT $start, $limit";
			}
			else 
			{

				$condition = "AND um.meta_key ='primary_application'";

				$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email,mu.status,UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership FROM $wpdb->users u LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->usermeta um1 ON u.ID = um1.user_id LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id";

				$sqlQuery .= " WHERE {$exclude_users} {$condition}  AND mu.status = 'active'";  

				$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";  

				$sqlQuery .= "GROUP BY u.ID ORDER BY user_registered DESC LIMIT $start, $limit";
			}

			$sqlQuery = apply_filters("pmpro_members_list_sql", $sqlQuery);

			$theusers = $wpdb->get_results($sqlQuery);
			$totalrows = $wpdb->get_var("SELECT FOUND_ROWS() as found_rows");

			if($theusers)
			{
				?>
				<p class="clear"><h3><?php echo strval($totalrows)?> members found.</h3>
					<?php		
				}		
				?>
				<table class="widefat">
					<thead>
						<tr class="thead">
							<th><?php _e('First Name', 'paid-memberships-pro')?></th>
							<th><?php _e('Last Name', 'paid-memberships-pro')?></th>	
							<th><?php _e('Email', 'paid-memberships-pro')?></th>
							<th><?php _e('Company Name', 'paid-memberships-pro')?></th>
							<th><?php _e('Tech Area', 'paid-memberships-pro')?></th>
							<th><?php _e('Membership', 'paid-memberships-pro')?></th>
							<th><?php _e('Joined', 'paid-memberships-pro')?></th>
							<th><?php _e('Expires', 'paid-memberships-pro')?></th>
							<th><?php _e('Membership Status', 'paid-memberships-pro')?></th>

						</tr>
					</thead>
					<tbody id="users" class="list:user user-list">	
						<?php	
						$count = 0;							
						foreach($theusers as $auser)
						{
					//get meta																					
							$theuser = get_userdata($auser->ID);			
							$userdata = get_userdata( $auser->ID );
							?>
							<tr <?php if($count++ % 2 == 0) { ?>class="alternate"<?php } ?>>
								<td><?php echo $theuser->first_name?></td>
								<td><?php echo $theuser->last_name?></td>										
								<td>
									<?php echo $theuser->user_email;?>
								</td>
								<td><?php echo get_user_meta($auser->ID,'company_name', true); ?></td> 
								<td><?php if(!empty($userdata->primary_application)){
									$primary_application = implode( "<br> ", $userdata->primary_application );
									echo $techarea_data_filter = str_replace("_"," ",$primary_application);
								}?></td> 

								<td><?php echo $auser->membership?></td>												
								<td>
									<?php
									$level = pmpro_getMembershipLevelForUser( $theuser->ID );
									if ( ! empty( $level ) && ! empty( $level->startdate ) ) {
										echo date( "M d, Y g:i A", $level->startdate );
									} else {
										echo "N/A";
									}
									?>
								</td>
								<td>
									<?php
									if($auser->enddate)
										echo apply_filters("pmpro_memberslist_expires_column", date_i18n("M d, Y g:i A", $auser->enddate), $auser);
									else
										echo __(apply_filters("pmpro_memberslist_expires_column", "Never", $auser), "pmpro");
									?>
								</td>
								<td><?php echo ucfirst($auser->status);?></td>
							</tr>
							<?php
						}

						if(!$theusers)
						{
							?>
							<tr>
								<td colspan="9"><p><?php _e('No members found.', 'paid-memberships-pro')?> <?php if($l) { ?><a href="?page=pmpro-reports&report=members_by_tech_area&s=<?php echo esc_attr($s)?>"><?php _e('Search all levels', 'paid-memberships-pro')?></a>.<?php } ?></p></td>
							</tr>
							<?php
						}
						?>		
					</tbody>
				</table>
			</form>  

			<?php
			echo pmpro_getPaginationString($pn, $totalrows, $limit, 1, get_admin_url(NULL, "/admin.php?page=pmpro-reports&report=members_by_tech_area&s=" . urlencode($s)), "&l=$l&limit=$limit&pn=");
			?>
			<?php
		}



