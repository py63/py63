<?php
global $post;
$nstxl_statement_of_need = get_field('nstxl_statement_of_need', $post->ID);
$presentations = get_field('nstxl_presentations', $post->ID);
$qandansresponse = get_field('nstxl_q_&_a_responses', $post->ID);
$repeater_update = get_field('latest_updates_section');
if (isset($repeater_update) && !empty($repeater_update)) { ?>
  <aside class="aside-opportunity-content widget">
 <?php if (isset($_POST['downloadkeydoc'])) {
  $upload_dir = wp_upload_dir();
  $upload_dir_path = $upload_dir["basedir"];
  $date = current_time('timestamp');
  $downloaded_keydoc_path = $upload_dir_path . '/opportunity-documents/';
  if (!file_exists($downloaded_keydoc_path)) {
    mkdir($downloaded_keydoc_path, 0777, true);
  }
  $downloaded_keydoc_url = $upload_dir["baseurl"] . '/opportunity-documents/';


  $zip_destination = $downloaded_keydoc_path . '/keydocuments-' . $date . '.zip';
  $exported_keydoc_path_url = $downloaded_keydoc_url . basename($zip_destination);
  $zipname = basename($zip_destination);
  $za = new ZipArchive;

  if ($za->open($zip_destination, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    echo '<div class="notice notice-error"><p>' . (!empty($this->last_error) ? sprintf(__('Error: %s', 'download-plugins-dashboard'), $this->last_error) : __('Something went wrong...', 'download-plugins-dashboard') ) . '</p></div>';
    exit();
  }
  if (isset($_POST['keydoc']) && !empty($_POST['keydoc'])) {
    $download_keydocs = $_POST['keydoc'];

    foreach ($download_keydocs as $download_keydoc) {
      $document_parse_array = parse_url($download_keydoc);
      $document_half_path = $document_parse_array['path'];
      $document_full_path = get_home_path() . $document_half_path;
      //$fpath = '/opportunity-documents/' . get_the_title() . '-' . get_the_ID() . '/' . basename($document_half_path);
      $fpath = '/opportunity-documents/' . basename($document_half_path);
      $za->addFile($document_full_path, $fpath);
    }
  }
  $za->close();
  //if (file_exists($exported_keydoc_path_url)) {
  ?>
  <h4 class="doc-success-msg"><?php _e('Your key documents zip have generated successfully please click', 'nstxl'); ?> <a id='downloadproposal' href="<?php echo $exported_keydoc_path_url; ?>" download> here </a><?php _e('to download the documents.', 'nstxl'); ?> </h4>
  <?php
  // }
}
  ?>
    <div class="widget-content">
      <div class="table table-responsive">
        <form method="post" name="keydocumentform-<?php echo get_the_ID(); ?>" id="keydocumentform-<?php echo get_the_ID(); ?>" >
          <input type="hidden" name="action" value="nstxl_keydocuments_download" />
          <table class="table table-striped table-bordered table-hover">
            <thead>
              <tr>        
                <th><h2 class="widget-title"><?php _e('Key Documents', 'onepress'); ?></h2></th>
                <th><div class="hidden-check"><input type="checkbox" id="select_all_keydocuments-<?php echo get_the_ID(); ?>"  value=""/><label class="select_all_keydocuments" for="select_all_keydocuments-<?php echo get_the_ID(); ?>"><?php _e('Select All', 'onepress'); ?></label></div></th>
              </tr>
            </thead>
            <tbody>              
              <?php if (isset($nstxl_statement_of_need) && !empty($nstxl_statement_of_need)) { ?>
                <tr>
                  <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/pdf-dark.svg" class="oppt-doc-icons"><a href="<?php echo $nstxl_statement_of_need['url']; ?>" download><?php echo $nstxl_statement_of_need['title']; ?></a></td>
                  <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $nstxl_statement_of_need['ID']; ?>" data-id="<?php echo $nstxl_statement_of_need['ID']; ?>" value="<?php echo $nstxl_statement_of_need['url']; ?>">
                      <label class="custom-control-label" for="keydoc<?php echo $nstxl_statement_of_need['ID']; ?>">&nbsp;</label>
                    </div>
                  </td>
                </tr>
                <?php
              }
              if (isset($presentations) && !empty($presentations)) {
                ?>
                <tr>
                  <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ppt-dark.svg" class="oppt-doc-icons"><a href="<?php echo $presentations['url']; ?>" download><?php echo $presentations['title']; ?></a></td>
                  <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $presentations['ID']; ?>" data-id="<?php echo $presentations['ID']; ?>" value="<?php echo $presentations['url']; ?>">
                      <label class="custom-control-label" for="keydoc<?php echo $presentations['ID']; ?>">&nbsp;</label>
                    </div>
                  </td>
                </tr>
                <?php
              }
              if (isset($qandansresponse) && !empty($qandansresponse)) {
                ?>
                <tr>
                  <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/documents-dark.svg" class="oppt-doc-icons"><a href="<?php echo $qandansresponse['url']; ?>" download><?php echo $qandansresponse['title']; ?></a></td>
                  <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $qandansresponse['ID']; ?>" data-id="<?php echo $qandansresponse['ID']; ?>" value="<?php echo $qandansresponse['url']; ?>">
                      <label class="custom-control-label" for="keydoc<?php echo $qandansresponse['ID']; ?>">&nbsp;</label>
                    </div>
                  </td>
                </tr>
              <?php } ?>

              <?php
              if (!empty($repeater_update)) {
                foreach ($repeater_update as $row) {
                  ?>        
                  <tr>
                    <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/documents-dark.svg" class="oppt-doc-icons"><a href="<?php echo $row['latest_update_doc']['url']; ?>" download><?php echo $row['latest_update_doc']['title']; ?></a></td>
                    <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                        <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $row['latest_update_doc']['ID']; ?>" data-id="<?php echo $row['latest_update_doc']['ID']; ?>" value="<?php echo $row['latest_update_doc']['url']; ?>">
                        <label class="custom-control-label" for="keydoc<?php echo $row['latest_update_doc']['ID']; ?>">&nbsp;</label>
                      </div></td>
                  </tr>
                  <?php
                }
              }
              ?>
            <input type="hidden" name="oprid" id="oprid" value="<?php echo esc_attr(get_the_ID()); ?>">
            <tr>
              <td colspan="3" class="text-right"><button type="submit" name="downloadkeydoc" id="downloadkeydoc" value="downloadkeydoc" class="btn btn-txt no-btn" disabled><?php _e('Download', 'onepress'); ?></button></td>
            </tr>
            </tbody>
          </table>
        </form>
      </div>
    </div>
  </aside>
  <?php if(is_single()) {  ?>
  <script type="text/javascript">
    jQuery(document).ready(function ($) {
      var opriD = '<?php echo get_the_ID();?>';
      if ($('.keydocumentcheck:checked').length != 0) {
        $('#downloadkeydoc').prop('disabled', false);
      } else {
        $('#downloadkeydoc').prop('disabled', true);
      }
      $('#select_all_keydocuments-'+opriD).on('click', function () {
        if (this.checked) {
          $('.keydocumentcheck').each(function () {
            this.checked = true;
            $('#downloadkeydoc').prop('disabled', false);
          });
        } else {
          $('.keydocumentcheck').each(function () {
            this.checked = false;
            $('#downloadkeydoc').prop('disabled', true);
          });
        }
      });

      $('.keydocumentcheck').on('click', function () {
        if ($('.keydocumentcheck:checked').length == $('.keydocumentcheck').length) {
          $('#select_all_keydocuments-'+opriD).prop('checked', true);
        } else {
          $('#select_all_keydocuments-'+opriD).prop('checked', false);
        }

        if ($('.keydocumentcheck:checked').length != 0) {
          $('#downloadkeydoc').prop('disabled', false);
        } else {
          $('#downloadkeydoc').prop('disabled', true);
        }
      });
    });
  </script>
  <?php } ?>
  <?php
} else {
  if(!is_single()){ 
  echo '<h4>This opportunity has not found any key documents</h4>';
  }
}