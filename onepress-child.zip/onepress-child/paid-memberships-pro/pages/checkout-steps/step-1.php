<?php
$skip_account_fields = '';
if (!$skip_account_fields && !$pmpro_review) {
  ?>
  <div id="step-1">                                             
    <div id="form-step-0" role="form">
      <h3 class="rgs_title">Billing  Info</h3>
      <div id="pmpro_user_fields" class="pmpro_checkout">
        <?php
        $uploaded_doc_url = get_user_meta($cur_id, 'uploaded_doc', true);
        $defalut_pic_url = WP_PLUGIN_URL . '/nstxl-memberhip-extension/images/user.png';
        $user_pic = get_user_meta($cur_id, 'user_pic', true);
        if (!empty($user_pic)) {
          $user_pic_url = $user_pic['fullurl'];
          $avatar = '<div class="profile-pic"><img class="profile-pic-img" alt="user pic" src="' . $user_pic_url . '"><i class="fa fa-camera upload-button"></i></div>';
        } else {
          $avatar = '<div class="profile-pic"><img class="profile-pic-img" alt="user pic" src="' . $defalut_pic_url . '"><i class="fa fa-camera upload-button"></i></div>';
        }
        ?>
        <div class="user_pics circle"><?php echo $avatar; ?></div>
        <div class="pmpro_checkout-fields">
          <h3><?php _e('Account Details', 'paid-memberships-pro'); ?></h3>
          <div class="row">            
            <div class="pmpro_checkout-field pmpro_checkout-field-bfirstname col-sm-12 col-lg-6">
              <div class="form-group">
                <label for="bfirstname"><?php _e('First Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>                    
                <input id="bfirstname" required=""  name="bfirstname" required type="text" class="input <?php echo pmpro_getClassForField("bfirstname"); ?>" size="30" value="<?php echo esc_attr($bfirstname); ?>" />
                <span class="pmpro_asterisk"> <abbr title="Required Field">*</abbr></span>
                <div class="help-block with-errors"></div>
              </div>
            </div> <!-- end pmpro_checkout-field-bfirstname -->
            <div class="pmpro_checkout-field pmpro_checkout-field-blastname col-sm-12 col-lg-6">
              <div class="form-group">
                <label for="blastname"><?php _e('Last Name', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                <input id="blastname" required="" name="blastname" required type="text" class="input <?php echo pmpro_getClassForField("blastname"); ?>" size="30" value="<?php echo esc_attr($blastname); ?>" />
                <span class="pmpro_asterisk"> <abbr title="Required Field">*</abbr></span>
                <div class="help-block with-errors"></div>
              </div>
            </div> <!-- end pmpro_checkout-field-blastname -->
          </div>
          <div class="row">
            <div class="pmpro_checkout-field pmpro_checkout-field-designation col-md-12">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="designation"><?php _e('Title', 'paid-memberships-pro'); ?></label>
                  <select name="designation" id="designation">
                    <option value=""><?php _e('Title', 'paid-memberships-pro'); ?></option>
                    <option value="CEO"  <?php selected($designation, 'CEO'); ?>>CEO</option>
                    <option value="COO" <?php selected($designation, 'COO'); ?>>COO</option>
                    <option value="CFO" <?php selected($designation, 'CFO'); ?>>CFO</option>
                    <option value="VicePresident" <?php selected($designation, 'VicePresident'); ?>>Vice President</option>
                    <option value="Manager" <?php selected($designation, 'Manager'); ?>>Manager</option>
                    <option value="AccountManager" <?php selected($designation, 'AccountManager'); ?>>Account Manager</option>
                    <option value="Director" <?php selected($designation, 'Director'); ?>>Director</option>
                    <?php /* ?><option value="WY" <?php  selected($designation, 'WY'); ?>>Wyoming</option><?php */ ?>
                    <option value="other" <?php selected($designation, 'other'); ?>>Other</option>
                  </select>
                  <div class="help-block with-errors"></div>
                </div>
                <div class="col-md-6 form-group other-designation" style="display:none">
                  <label for="other_designation"><?php _e('Please Enter Title', 'paid-memberships-pro'); ?></label>  
                  <input id="other_designation" name="other_designation" type="text" class=" " size="30" value="<?php echo esc_attr($other_designation); ?>" />
                  <div class="help-block with-errors"></div>     
                </div>
            </div>
            </div>
          </div>
          <div class="row">
            <div class="pmpro_checkout-field pmpro_checkout-field-username col-sm-12 col-lg-6">
              <div class="form-group">
                <label for="username"><?php _e('Username', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                <input id="username" readonly required name="username" type="text" class="input <?php echo pmpro_getClassForField("username"); ?>" size="30" value="<?php echo esc_attr($username); ?>" />
                <div class="help-block with-errors"></div>
              </div>

            </div> <!-- end pmpro_checkout-field-username -->

            <?php
            do_action('pmpro_checkout_after_username');
            ?>

            <div class="pmpro_checkout-field pmpro_checkout-field-bemail col-sm-12 col-lg-6">
              <div class="form-group">
                <label for="bemail"><?php _e('E-mail Address', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                <input id="bemail" required="" name="bemail" required type="<?php echo ($pmpro_email_field_type ? 'email' : 'text'); ?>" class="input <?php echo pmpro_getClassForField("bemail"); ?>" size="30" value="<?php echo esc_attr($bemail); ?>" />
                <div class="help-block with-errors"></div>
              </div>	
            </div> <!-- end pmpro_checkout-field-bemail -->        
            <?php
            $pmpro_checkout_confirm_email = apply_filters("pmpro_checkout_confirm_email", true);
            $pmpro_checkout_confirm_email = false;
            if ($pmpro_checkout_confirm_email) {
              ?>
              <div class="pmpro_checkout-field pmpro_checkout-field-bconfirmemail col-sm-12 col-lg-6">
                <div class="form-group">
                  <label for="bconfirmemail"><?php _e('Confirm E-mail Address', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                  <input required id="bconfirmemail" readonly required  "data-match="#bemail" data-match-error="E-mail Doesn't Match"  name="bconfirmemail" type="<?php echo ($pmpro_email_field_type ? 'email' : 'text'); ?>" class="input <?php echo pmpro_getClassForField("bconfirmemail"); ?>" size="30" value="<?php echo esc_attr($bconfirmemail); ?>" />
                         <div class="help-block with-errors"></div>
                </div>
              </div> <!-- end pmpro_checkout-field-bconfirmemail -->
            <?php } else { ?>
              <input type="hidden" name="bconfirmemail_copy" value="1" />
            <?php }
            ?>

            <?php
            do_action('pmpro_checkout_after_email');
            ?>
          </div>
          <hr>
          <h3><?php _e('Contact Info', 'paid-memberships-pro'); ?></h3>
          <div class="row">
            <div class="pmpro_checkout-field pmpro_checkout-field-bphone col-sm-12 col-lg-6">
              <div class="form-group">
                <label for="bphone"><?php _e('Primary Phone Number', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                <input id="bphone" required="" name="bphone" type="text" class="input <?php echo pmpro_getClassForField("bphone"); ?>" size="30" value="<?php echo esc_attr(formatPhone($bphone)); ?>" />
                <div class="help-block with-errors"></div>
              </div>
            </div> 

            <?php
            do_action('pmpro_checkout_after_password');
            ?>
          </div>
          <?php
          $pmpro_include_billing_address_fields = apply_filters('pmpro_include_billing_address_fields', true);
          if ($pmpro_include_billing_address_fields) {
            ?>
            <div id="pmpro_billing_address_fields" class="pmpro_checkout" <?php if (!$pmpro_requirebilling || apply_filters("pmpro_hide_billing_address_fields", false)) { ?>style="display: none;"<?php } ?>>
              <?php /* 	<hr />		
                <h3>
                <span class="pmpro_checkout-h3-name"><?php _e('Billing Address', 'paid-memberships-pro' );?></span>
                </h3> */ ?>
              <div class="pmpro_checkout-fields">
                <div class="row">
                  <!-- we have moved the bfname and last name on to the top of the username -->
                  <div class="pmpro_checkout-field pmpro_checkout-field-baddress1 col-sm-12">
                    <div class="form-group">
                      <label for="baddress1"><?php _e('Address 1', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                      <input id="baddress1" required="" name="baddress1" type="text" class="input <?php echo pmpro_getClassForField("baddress1"); ?>" size="30" value="<?php echo esc_attr($baddress1); ?>" />
                      <div class="help-block with-errors"></div>                                                                                  
                    </div>
                  </div> <!-- end pmpro_checkout-field-baddress1 -->
                  <div class="pmpro_checkout-field pmpro_checkout-field-baddress2 col-sm-12">
                    <div class="form-group">
                      <label for="baddress2"><?php _e('Address 2', 'paid-memberships-pro'); ?></label>
                      <input id="baddress2" name="baddress2" type="text" class="input <?php echo pmpro_getClassForField("baddress2"); ?>" size="30" value="<?php echo esc_attr($baddress2); ?>" />
                    </div>
                  </div> <!-- end pmpro_checkout-field-baddress2 -->
                </div>
                <?php
                $longform_address = apply_filters("pmpro_longform_address", true);
                if ($longform_address) {
                  ?>
                  <div class="row">
                    <div class="pmpro_checkout-field pmpro_checkout-field-bcity col-sm-12 col-lg-6">
                      <div class="form-group">
                        <label for="bcity"><?php _e('City', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                        <input id="bcity"  required="" name="bcity" type="text" class="input <?php echo pmpro_getClassForField("bcity"); ?>" size="30" value="<?php echo esc_attr($bcity); ?>" />
                        <div class="help-block with-errors"></div>                                                                                          
                      </div>
                    </div> <!-- end pmpro_checkout-field-bcity -->
                    <div class="pmpro_checkout-field pmpro_checkout-field-bstate col-sm-12 col-lg-6">
                      <div class="form-group">
                        <label for="bstate"><?php _e('State', 'paid-memberships-pro'); ?></label>
                        <input id="bstate" name="bstate" type="text" class="input <?php echo pmpro_getClassForField("bstate"); ?>" size="30" value="<?php echo esc_attr($bstate); ?>" />
                        <div class="help-block with-errors"></div>                                                                                      
                      </div>
                    </div> <!-- end pmpro_checkout-field-bstate -->
                  </div>
                  <?php /* ?>
                    <div class="pmpro_checkout-field pmpro_checkout-field-bzipcode col-sm-12 col-lg-6 tt">
                    <label for="bzipcode"><?php _e('Zip Code', 'paid-memberships-pro'); ?></label>
                    <input id="bzipcode" name="bzipcode" type="text" class="input <?php echo pmpro_getClassForField("bzipcode"); ?>" size="30" value="<?php echo esc_attr($bzipcode); ?>" />
                    </div> <!-- end pmpro_checkout-field-bzipcode -->
                    <?php */ ?>  
                <?php } else { ?>
                  <div class="pmpro_checkout-field pmpro_checkout-field-bcity_state_zip col-sm-12 col-lg-6 tt2">
                    <label for="bcity_state_zip"><?php _e('City, State Zip', 'paid-memberships-pro'); ?></label>
                    <input id="bcity" name="bcity" type="text" class="input <?php echo pmpro_getClassForField("bcity"); ?>" size="14" value="<?php echo esc_attr($bcity); ?>" />,
                    <?php
                    $state_dropdowns = apply_filters("pmpro_state_dropdowns", false);
                    if ($state_dropdowns === true || $state_dropdowns == "names") {
                      global $pmpro_states;
                      ?>
                      <select name="bstate" class="<?php echo pmpro_getClassForField("bstate"); ?>">
                        <option value="">--</option>
                        <?php foreach ($pmpro_states as $ab => $st) { ?>
                          <option value="<?php echo esc_attr($ab); ?>" <?php if ($ab == $bstate) { ?>selected="selected"<?php } ?>><?php echo $st; ?></option>
                        <?php } ?>
                      </select>
                      <?php
                    } elseif ($state_dropdowns == "abbreviations") {
                      global $pmpro_states_abbreviations;
                      ?>
                      <select name="bstate" class="<?php echo pmpro_getClassForField("bstate"); ?>">
                        <option value="">--</option>
                        <?php
                        foreach ($pmpro_states_abbreviations as $ab) {
                          ?>
                          <option value="<?php echo esc_attr($ab); ?>" <?php if ($ab == $bstate) { ?>selected="selected"<?php } ?>><?php echo $ab; ?></option>
                        <?php } ?>
                      </select>
                    <?php } else { ?>
                      <input id="bstate" name="bstate" type="text" class="input <?php echo pmpro_getClassForField("bstate"); ?>" size="2" value="<?php echo esc_attr($bstate); ?>" />
                    <?php } ?>
                    <input id="bzipcode"  name="bzipcode" type="text" class="input <?php echo pmpro_getClassForField("bzipcode"); ?>" size="5" value="<?php echo esc_attr($bzipcode); ?>" />
                  </div> <!-- end pmpro_checkout-field-bcity_state_zip -->
                <?php } ?>

                <?php
                $show_country = apply_filters("pmpro_international_addresses", true);
                if ($show_country) {
                  ?>
                  <div class="row">
                    <div class="pmpro_checkout-field pmpro_checkout-field-bcountry col-sm-12 col-lg-6 clearfix" style="clear:both">
                      <label for="bcountry"><?php _e('Country', 'paid-memberships-pro'); ?></label>
                      <select name="bcountry" id="bcountry" class="<?php echo pmpro_getClassForField("bcountry"); ?>">
                        <?php
                        global $pmpro_countries, $pmpro_default_country;
                        if (!$bcountry) {
                          $bcountry = $pmpro_default_country;
                        }
                        foreach ($pmpro_countries as $abbr => $country) {
                          ?>
                          <option value="<?php echo $abbr ?>" <?php if ($abbr == $bcountry) { ?>selected="selected"<?php } ?>><?php echo $country ?></option>
                        <?php } ?>
                      </select>
                    </div> <!-- end pmpro_checkout-field-bcountry -->
                    <?php if ($longform_address) { ?>
                      <div class="pmpro_checkout-field pmpro_checkout-field-bzipcode col-sm-12 col-lg-6">
                        <label for="bzipcode"><?php _e('Zip Code', 'paid-memberships-pro'); ?></label>
                        <input id="bzipcode" name="bzipcode" type="text" class="input <?php echo pmpro_getClassForField("bzipcode"); ?>" size="30" value="<?php echo esc_attr($bzipcode); ?>" />
                      </div> <!-- end pmpro_checkout-field-bzipcode -->
                    <?php } ?>
                  </div>

                <?php } else { ?>
                  <input type="hidden" name="bcountry" value="US" />
                <?php } ?>
                <?php /*
                  <div class="pmpro_checkout-field pmpro_checkout-field-bphone">
                  <label for="bphone"><?php _e('Phone', 'paid-memberships-pro' );?></label>
                  <input id="bphone" name="bphone" type="text" class="input <?php // echo pmpro_getClassForField("bphone");?>" size="30" value="<?php // echo esc_attr(formatPhone($bphone)); ?>" />
                  </div> <!-- end pmpro_checkout-field-bphone --> <?php */ ?>
                <?php if ($skip_account_fields) { ?>
                  <?php
                  if ($current_user->ID) {
                    if (!$bemail && $current_user->user_email) {
                      $bemail = $current_user->user_email;
                    }
                    if (!$bconfirmemail && $current_user->user_email) {
                      $bconfirmemail = $current_user->user_email;
                    }
                  }
                  ?>
                  <div class="pmpro_checkout-field pmpro_checkout-field-bemail">
                    <div class="form-group">
                      <label for="bemail"><?php _e('E-mail Address', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                      <input id="bemail" required name="bemail" type="<?php echo ($pmpro_email_field_type ? 'email' : 'text'); ?>" class="input <?php echo pmpro_getClassForField("bemail"); ?>" size="30" value="<?php echo esc_attr($bemail); ?>" /> 
                      <div class="help-block with-errors"></div>
                    </div>
                  </div> <!-- end pmpro_checkout-field-bemail -->
                  <?php
                  $pmpro_checkout_confirm_email = apply_filters("pmpro_checkout_confirm_email", true);
                  if ($pmpro_checkout_confirm_email) {
                    ?>
                    <div class="pmpro_checkout-field pmpro_checkout-field-bconfirmemail">
                      <label for="bconfirmemail"><?php _e('Confirm E-mail', 'paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span></label>
                      <input id="bconfirmemail" required  name="bconfirmemail" type="<?php echo ($pmpro_email_field_type ? 'email' : 'text'); ?>" class="input <?php echo pmpro_getClassForField("bconfirmemail"); ?>" size="30" value="<?php echo esc_attr($bconfirmemail); ?>" />
                      <div class="help-block with-errors"></div>
                    </div> <!-- end pmpro_checkout-field-bconfirmemail -->
                  <?php } else { ?>
                    <input type="hidden" name="bconfirmemail_copy" value="1" />
                  <?php } ?>
                <?php } ?>
              </div> <!-- end pmpro_checkout-fields -->
            </div> <!--end pmpro_billing_address_fields -->
          <?php } ?>

          <div class="pmpro_hidden">
            <label for="fullname"><?php _e('Full Name', 'paid-memberships-pro'); ?></label>
            <strong><?php _e('LEAVE THIS BLANK', 'paid-memberships-pro'); ?></strong>
            <input id="fullname" name="fullname" type="text" class="input <?php echo pmpro_getClassForField("fullname"); ?>" size="30" value="" />
          </div> <!-- end pmpro_hidden -->

          <div class="pmpro_checkout-field pmpro_captcha">
            <?php
            global $recaptcha, $recaptcha_publickey;
            if ($recaptcha == 2 || ($recaptcha == 1 && pmpro_isLevelFree($pmpro_level))) {
              echo pmpro_recaptcha_get_html($recaptcha_publickey, NULL, true);
            }
            ?>
          </div> <!-- end pmpro_captcha -->

          <?php
          do_action('pmpro_checkout_after_captcha');
          ?>
        </div>  <!-- end pmpro_checkout-fields -->
      </div> <!-- end pmpro_user_fields -->
    <?php } elseif ($current_user->ID && !$pmpro_review) { ?>
      <div id="pmpro_account_loggedin" class="pmpro_message pmpro_alert">
        <?php printf(__('You are logged in as <strong>%s</strong>. If you would like to use a different account for this membership, <a href="%s">log out now</a>.', 'paid-memberships-pro'), $current_user->user_login, wp_logout_url($_SERVER['REQUEST_URI'])); ?>
      </div> <!-- end pmpro_account_loggedin -->
    <?php } ?>
  </div>
</div>