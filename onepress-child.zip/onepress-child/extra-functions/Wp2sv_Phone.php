<?php

/**
 * Created by PhpStorm.
 * User: as247
 * Date: 29-Oct-18
 * Time: 8:05 AM
 */
global $current_user;
include( nstxl_extention_path . 'includes/Twilio-sms/Twilio/autoload.php');

use Twilio\Rest\Client;

class Wp2sv_Phone extends Wp2sv_Email {

    protected $email_limit_per_day = 10000;
    public $phone_sent;
    public $phone_sent_success;

    function getEmailSubject() {
        return __('Your verification code', 'wordpress-2-step-verification');
    }

    function getEmailContent() {
        $code = $this->otp->generate();
        $code = str_pad($code[1], 6, '0', STR_PAD_LEFT);
        return sprintf(__('Your verification code is %s', 'wordpress-2-step-verification'), $code);
    }

    /**
     * Sent code to registered email
     * @param $email
     * @return bool
     */
    function sendCodeToEmail($email = '') {
        if (!$email) {
            if (method_exists($this, 'get_email')) {
                $email = $this->get_email();
            }
        }
        if ($email) {
            return @wp_mail($email, $this->getEmailSubject(), $this->getEmailContent());
        }
        return false;
    }

    /**
     * Sent code to registered email
     * @param $email
     * @return bool
     */
    function sendCodeToPhone($body = '') {
        global $current_user;
        $user_phone = get_user_meta($current_user->ID, 'phone_number_2step', true);
        $sid = 'ACe51e334d57390e915ae9cf380d36ca21';
        $token = 'b7a4babf339748968ebf569696dcdb7a';
        $client = new Client($sid, $token);


        try {
            if ($body) {
                $body = $this->getEmailContent();
            }
            $client->messages->create(
                    $user_phone, array(
                'from' => '+16363061942',
                'body' => $body
            ));
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    function handle() {
        $action = $this->post('wp2sv_action');
        $email = $this->handler->getEmail();
        $code = $this->post('wp2sv_code');
   //     error_log('Code' . print_r($code, true));
        $method1 = $this->post('wp2sv_method');

        $current_user_id = get_current_user_id();
        $phone_number_2step = get_user_meta($current_user_id, 'phone_number_2step', 'true');
        $phone_lastchars = substr($phone_number_2step, -4);

        $scale = 1;
        if ($email) {
         //   error_log('Inside email if' . print_r($email, true));
            $sent = $this->model->email_sent;
            $sent = absint($sent);
            //error_log('Inside email if sent'.print_r($sent,true));
            if (!empty($phone_number_2step)) {
                if ($action == 'send-phone') {
                    if(!empty($method1)){
                        $this->sendCodeToPhone($this->getEmailContent());
                    }
                }
            }
            if ($action == 'send-email') {
             //   error_log('Inside email if action send-email and not phone' . print_r($sent, true));
                if ($sent < $this->email_limit_per_day) {

                    if(!empty($method1)){
                 //   error_log('Inside email if action send-email and not phone sent is lessthan email limit' . print_r($sent, true));
                    if ($this->sendCodeToEmail($email)) {
                    //    error_log('Inside email if action send-email and not phone sent is lessthan email limit email sent' . print_r($email, true));

                        $sent++;
                        $this->model->email_sent = $sent;
                     //   error_log('Inside email if action send-email and not phone sent is lessthan email limit email sent email_sent value' . print_r($this->model->email_sent, true));

                        $this->model['email_sent_success'] = true;
                    } else {
                        //if (isset($_REQUEST['wp2sv_method']) && $_REQUEST['wp2sv_method'] !='phone') { 
                        $this->handler->error(__('The e-mail could not be sent.', 'wordpress-2-step-verification') . ' ' . __('Possible reason: your host may have disabled the mail() function...', 'wordpress-2-step-verification'));
                        //} 
                    //    error_log('Inside email if action send-email and not phone sent else');
                    }

                }


                } else {
                    $this->handler->error(__('Total emails can send per day has reached limit!', 'wordpress-2-step-verification'));
                }
            } else {
                $this->handler->error('');
              //  error_log('else');
            }
            if ($code && $this->model['email_sent_success']) {
                $scale = $sent + 1;
                $this->model['email_sent_success'] = false;
            }
        }
        return $scale;
    }

}     
 