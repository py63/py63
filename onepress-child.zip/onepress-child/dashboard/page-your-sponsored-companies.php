<?php
/**
 * Template Name: Sponsored Companies
 *
 * @package OnePress
 */
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
global $wpdb, $current_user;
if (!pmpro_hasMembershipLevel('6') || !pmpro_hasMembershipLevel('Incubator')) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
if (!empty($current_user)) {
  $cuserId = $current_user->ID;
  $incubatorId = nstxl_getIncubatorId($cuserId);
  if (empty($incubatorId)) {
    $incubatorId = $cuserId;
  }
  $sponsored_users = get_user_meta($incubatorId, 'sponsored_users', true);
}
get_header('admin');

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>
<style type="text/css">
.sponsor-company .add-company-block {display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 2px 15px 0 rgba(0,0,0,.14); height: 304px; margin-bottom: 20px; border-radius: 0px; background-color: #ffffff;}

@media screen and (max-width: 1199px) {
.sponsor-company .add-company-block { height: 411px;}
}
  <?php /* ?>.sponsor-company .sponsor-company-block {border-radius: 5px; background-color:  #bf3737; padding: 5px 20px;}
  .sponsor-company .company-form {
    margin: 20px 0 50px;
    box-shadow: 0 2px 15px 0 rgba(0,0,0,.14);
    background-color: #ffffff;
    padding: 20px 20px;
    border-radius: 5px;
  }<?php */ ?>
.sponsor-company .sponsor-company-block{border-radius:0;background-color:#bf3737;padding:5px 20px}.sponsor-company .company-form{margin:0 0 20px;box-shadow:0 2px 15px 0 rgba(0,0,0,.14);background-color:#fff;padding:20px 20px;border-radius:0}.sponsor-company .sponsor-company-header h6{color:#fff!important;font-family:AvenirNext-Regular,sans-serif;font-weight:300;font-size:14px;margin-bottom:0;opacity:.5}.sponsor-company .sponsor-company-header a{display:inline-flex;vertical-align:middle;margin-left:10px;justify-content:center;align-items:center;height:100%;margin-top:5px}.sponsor-company .sponsor-company-header h4{font-size:20px;color:#fff;font-weight:500;margin-bottom:0}.btn.btn-txt.btn-confirm-reminder{max-width:200px;margin:0 auto}.company-img-wrapper img{padding:10px;box-shadow:0 0 10px rgba(0,0,0,.2)}.managesponsor-container{padding-left:10px}
</style>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  // [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' ); ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>

              <div class="managesponsor-container dashboard-inner-wrapper">            
                <div class="managesponsor-form-container">    
                  <div class="sponsor-company"> 
                    <div class="row">
                      <?php
                      for ($i = 0; $i <= 4; $i++) {
                        if (!empty($sponsored_users[$i])) {
                          $user = get_userdata($sponsored_users[$i]);
                          $user->data->mebershipinfo = nstxl_MembershipInfoByUserid($sponsored_users[$i]);
                          $user->data->company_name = $user->company_name;
                          $user_ID = $user->ID;
                          $cur_id = $user_ID;
                          $display_name = $user->display_name;
                          $isPaid = nstxl_isPaidMember($user_ID);
                          $membershipInfo = $user->mebershipinfo;
                          if (!empty($membershipInfo)) {
                            if (!empty($membershipInfo->formated_startdate)) {
                              $membership_startdate = $membershipInfo->formated_startdate;
                            }
                            if (!empty($membershipInfo->formated_enddate)) {
                              $membership_enddate = $membershipInfo->formated_enddate;
                            }
                            $btnClass = 'remind';
                          } else {
                            $btnClass = 'delete';
                            $membership_enddate = $membership_startdate = '';
                          }
                          $company_name = $user->company_name;

                          if (empty($display_name)) {
                            $display_name = $user->first_name . ' ' . $user->last_name;
                          }
                          $user_email = $user->user_email;

                          $remindersent = get_user_meta($user_ID, 'remindersent', true);
                          $reminderdate = get_user_meta($user_ID, 'reminderdate', true);
                          if (!empty($reminderdate)) {
                            $reminderfdate = date('m-d-Y', strtotime($reminderdate));
                          } else {
                            $reminderfdate = '';
                          }
                          ?>
                          <div class="col-md-12 col-lg-6 col-xl-6">
                            <div class="sponsor-company-block">
                              <div class="sponsor-company-header clearfix">

                                <div class="float-left">
                                  <h6><?php _e('Company Name', 'paid-memberships-pro'); ?></h6>
                                  <h4><?php
                                    if (!empty($company_name)) {
                                      echo $company_name;
                                    } else {
                                      $company_name = '<span>&nbsp;</span>';
                                    }
                                    ?></h4>
                                </div>
                                <div class="float-right d-flex justify-content-center align-items-center" >
                                  <a class="btn-edit edit-scompany" href="<?php echo get_bloginfo('url'); ?>/edit-sponsor?member=<?php echo $user_ID; ?>" data-id="<?php echo esc_attr($user_ID); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/pencil-icon.png"></a>
                                  <?php if (!$isPaid) { ?><a class="btn-delete <?php echo $btnClass; ?>" style="margin-left:10px" href="#" data-reminder="<?php echo esc_attr($remindersent); ?>" data-reminderDate="<?php echo esc_attr($reminderfdate); ?>" data-id="<?php echo esc_attr($user_ID); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/delete-button.png"></a><?php } else { ?> &nbsp;<span style="color: #ffffff;font-weight: 700;margin-top: 6px;text-transform: uppercase;"><?php _e('Paid', 'pmpro'); ?></span> <?php } ?>
                                </div>
                              </div>
                            </div> 

                            <div class="company-form">
                              <div class="form">
                                <div class="row">
                                  <div class="col-md-12 col-lg-12 col-xl-4">
                                    <label class="com-label" for="bfirstname">
                                      <?php _e('Full Name', 'paid-memberships-pro'); ?>
                                    </label>
                                  </div>
                                  <div class="col-md-12 col-lg-12 col-xl-8">
                                    <div class="form-group">
                                      <input id="display_name" name="display_name" type="text" class="input" readonly value="<?php echo $display_name; ?>"> 
                                    </div>
                                  </div>

                                </div> 
                                <div class="row">
                                  <div class="col-md-12 col-lg-12 col-xl-4">
                                    <label class="com-label" for="poc-mail">
                                      <?php _e('POC Email', 'paid-memberships-pro'); ?>
                                    </label>
                                  </div>
                                  <div class="col-md-12 col-lg-12 col-xl-8">
                                    <div class="form-group">
                                      <input id="poc-mail" readonly name="poc-mail" type="text" class="input" value="<?php echo $user_email; ?>"> 
                                    </div>
                                  </div>

                                </div>
                                <div class="row">
                                  <div class="col-md-12 col-lg-12 col-xl-4">
                                    <label class="com-label" for="membership-confirmed">
                                      <?php _e('Membership Confirmed', 'paid-memberships-pro'); ?>
                                    </label>
                                  </div>
                                  <div class="col-md-12 col-lg-12 col-xl-8">
                                    <div class="form-group">
                                      <input id="membership-confirmed" readonly name="membership-confirmed" type="text" class="input" value="<?php
                                      if (!empty($membership_startdate)) {
                                        echo 'Yes';
                                      } else {
                                        echo'No';
                                      }
                                      ?>"> 
                                    </div>
                                  </div>                    
                                </div>
                                <div class="row">
                                  <div class="col-md-12 col-lg-12 col-xl-4">
                                    <label class="com-label" for="exp-date">
                                      <?php _e('Expiration Date', 'paid-memberships-pro'); ?>
                                    </label>
                                  </div>
                                  <div class="col-md-12 col-lg-12 col-xl-8">
                                    <div class="form-group">
                                      <input id="membership_enddate" readonly name="membership_enddate" type="text" class="input" value="<?php
                                      if (!empty($membership_enddate)) {
                                        echo $membership_enddate;
                                      }
                                      ?>"> 
                                    </div>
                                  </div>

                                </div>
                              </div>
                            </div>
                          </div>
                        <?php } else { ?>
                          <div class="col-md-12 col-lg-6 col-xl-6">
                            <div class="add-company-block">
                              <div class="scompany-icon">
                                <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/add-compny-logo.png">
                              </div>
                              <div class="add-scompany-btn mt-4">
                                <div class="btn-group">
                                  <a class="btn btn-txt add-scompany" data-toggle="modal" href="#"><?php _e('ADD COMPANY', 'paid-memberships-pro'); ?></a>  
                                </div>
                              </div>
                            </div> 
                          </div>
                          <?php
                        }
                      }
                      ?>
                    </div>
                  </div>
                </div>
              </div>


            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.   ?>

      </main><!-- #main -->
    </div><!-- #primary -->



  </div><!--#content-inside -->
</div><!-- #content -->
<?php /* ?>
  <!-- Modal box for delete sponsor-->
  <div id="deleteSponsorModal" class="modal fade">
  <div class="modal-dialog">
  <div class="modal-content">
  <form name="deletesponsor" id='deletesponsor'>
  <div class="modal-body">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <p>Are you sure you want to delete these Records?</p>
  <p class="text-warning"><small>This action cannot be undone.</small></p>
  <input type="hidden" class="sponsorid" name="sponsorid" value="">
  <div class="row">
  <div class="col-md-6">
  <button type="button" class="btn btn-default btn-cancel col-md-12" data-dismiss="modal" value="Cancel"><?php _e('Cancel', 'paid-memberships-pro'); ?></button>
  </div>
  <div class="col-md-6">
  <button class="btn btn-danger btn-confirm-delete col-md-12" type="submit"><?php _e('Delete', 'paid-memberships-pro'); ?></button>
  </div>
  </div>
  </div>
  </form>
  </div>
  </div>
  </div>
  <?php */ ?>
<?php
//Modal box for delete sponsor
$deleteSponsor_modal_id = 'deleteSponsorModal';
$deleteSponsor_modal_body_container_class = 'deleteSponsorModal-container';
$deleteSponsor_content_html = '<form name="deletesponsor" id="deletesponsor"><h4>Are you sure you want to delete these Records?</h4>
                  <input type="hidden" class="sponsorid" name="sponsorid" value="">
            <div class="row">
              <div class="col-md-6">            
                <button type="button" class="mb-2 btn btn-txt btn-cancel col-md-12" data-dismiss="modal" value="Cancel">' . __('Cancel', 'paid-memberships-pro') . '</button>
              </div>
              <div class="col-md-6">
                <button class="mb-2 btn btn-txt btn-confirm-delete col-md-12" type="submit">' . __('Delete', 'paid-memberships-pro') . '</button>
              </div>
            </div>          
        </form>';
nstxl_modal_popup($deleteSponsor_content_html, $deleteSponsor_modal_id, $deleteSponsor_modal_body_container_class);
?>
<?php /* ?>    
  <!-- Modal box for delete reminder -->
  <div id="remindSponsorModal" class="modal fade">
  <div class="modal-dialog">
  <div class="modal-content">
  <form name="remindsponsor" id='remindsponsor'>
  <div class="modal-body">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <div class="modalBody-container row">
  <p>Are you sure you want to delete these Records?</p>
  <div class="col-md-12">
  <button class="btn btn-danger btn-confirm-reminder" type="submit"><?php _e('Send Reminder', 'paid-memberships-pro'); ?></button>
  </div>
  </div>
  <input type="hidden" class="sponsorid" name="sponsorid" value="">
  </div>
  </form>
  </div>
  </div>
  </div>
  <?php */ ?>  
<?php
//Modal box for delete reminder
$deletereminder_modal_id = 'remindSponsorModal';
$deletereminder_modal_body_container_class = 'remindSponsorModal-container';
$deletereminder_content_html = '<form name="remindsponsor" id="remindsponsor">
            <div class="modalBody-container">
              <h4>Are you sure you want to delete these Records?</h4>
              <div class="btn-group col-sm-12">
                <button class="btn btn-txt btn-confirm-reminder" type="submit">' . __('Send Reminder', 'paid-memberships-pro') . '</button>
              </div>
            </div>
            <input type="hidden" class="sponsorid" name="sponsorid" value="">          
        </form>';
nstxl_modal_popup($deletereminder_content_html, $deletereminder_modal_id, $deletereminder_modal_body_container_class);
?>  
<?php /* ?>    
  <!-- Modal box for success message -->
  <div class="modal fade" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-body">
  <button type="button" class="close" aria-hidden="true">&times;</button>
  <div class="update-personalinfo-box-success-container">
  <p>Company has been registered successfully.</p>
  </div>
  </div>
  <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
  </div>
  </div>
  <!-- /.modal -->
  <?php */ ?>  
<?php
//Modal box for success message
$modalbox_success_modal_id = 'update-personalinfo-modal-success';
$modalbox_success_modal_body_container_class = 'update-personalinfo-box-success-container';
$modalbox_success_content_html = '<h4>Company has been registered successfully.</h4> ';
nstxl_modal_popup($modalbox_success_content_html, $modalbox_success_modal_id, $modalbox_success_modal_body_container_class);
?>  
<?php /* ?>
  <!-- Modal box for add company form -->
  <div class="modal fade" id="add-scompany-modal-success" tabindex="-1" role="dialog" aria-labelledby="add-scompany-modalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-body">
  <button type="button" class="close" aria-hidden="true"><span>&times;</span></button>
  <div class="add-scompany-box-success-container">
  <?php get_template_part('/dashboard/page', 'add-sponsor'); ?>
  </div>
  </div>
  <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
  </div>
  </div>
  <!-- /.modal -->
  <?php */ ?>
<?php
//Modal box for add company form
$add_scompany_modal_id = 'add-scompany-modal-success';
$add_scompany_modal_body_container_class = 'add-scompany-box-success-container';
//$add_scompany_template_path = locate_template('/dashboard/page-add-sponsor.php');
$add_scompany_template_path = '/dashboard/page-add-sponsor.php';
nstxl_modal_popup_templete($add_scompany_template_path, $add_scompany_modal_id, $add_scompany_modal_body_container_class);
?>  
<?php /* ?>
<div class="modal fade custom-popup" id="edit-scompany-modal-success" tabindex="-1" role="dialog" aria-labelledby="edit-scompany-modal-success" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
        </button>
        <div class="modal-body-container  edit-scompany-box-success-container">
          <?php
          //include(locate_template('/dashboard/page-edit-sponsor.php'));
          ?>
        </div><!-- /.modal-body -->            
      </div><!-- /.modal-content -->
      <!-- /.modal-dialog -->
    </div> 
  </div>
</div>  
<?php */ ?>
<?php
//Modal box for edit-sponsor success message copied from edit sponsor page
$edit_sponsor_modalbox_success_modal_id = 'edit-sponsor-modal-success';
$edit_sponsor_modalbox_success_modal_body_container_class = 'edit-sponsor-modal-success-container';
$edit_sponsor_modalbox_success_content_html = '<h4>Company has been registered successfully.</h4> ';
nstxl_modal_popup($edit_sponsor_modalbox_success_content_html, $edit_sponsor_modalbox_success_modal_id, $edit_sponsor_modalbox_success_modal_body_container_class);
?> 
<?php
//Modal box for edit-sponsor success message copied from edit sponsor page
$edit_scompany_modalbox_success_modal_id = 'edit-scompany-modal-success';
$edit_scompany_modalbox_success_modal_body_container_class = 'edit-scompany-box-success-container';
$edit_scompany_modalbox_success_content_html = '';
nstxl_modal_popup($edit_scompany_modalbox_success_content_html, $edit_scompany_modalbox_success_modal_id, $edit_scompany_modalbox_success_modal_body_container_class);
?> 
<?php
//Modal box add sponsor success message
$add_sponsor_modalbox_success_modal_id = 'add-sponsor-modal-success';
$add_sponsor_modalbox_success_modal_body_container_class = 'add-sponsor-modal-success-container';
$add_sponsor_modalbox_success_content_html = '<h4>Company has been registered successfully.</h4> ';
nstxl_modal_popup($add_sponsor_modalbox_success_content_html, $add_sponsor_modalbox_success_modal_id, $add_sponsor_modalbox_success_modal_body_container_class);
?>  
  <script type="text/javascript">
    jQuery(document).ready(function ($) {
      jQuery('.pmpro_asterisk').remove();

      jQuery('.add-scompany').on('click', function (e) {
        e.preventDefault();
        jQuery('#add-scompany-modal-success').modal('show');
        jQuery('.addsponsor-container .page-header-wrapper .rgs_title').text('Add Company');
      });

      jQuery('.edit-scompany').on('click', function (e) {
        e.preventDefault();
        var memberID = $(this).data('id');
        $.ajax({
          url: nstxl_ajaxurl,
          type: "POST",
          data: {'action': 'nstxl_edit_sponsored_company', 'memberid': memberID},
          cache: false,
          dataType: 'json',
          beforeSend: function () {
           jQuery('.preloader').fadeIn();
          },
          success: function (response, textStatus, jqXHR) {
           jQuery('.preloader').fadeOut();            
            if (response.data.status == "success") {
              jQuery('#edit-scompany-modal-success').modal('show');
              jQuery('.editsponsor-container .page-header-wrapper .rgs_title').text('Edit Company');
              jQuery('#edit-scompany-modal-success  .edit-scompany-box-success-container').html(response.data.msg);
            }
            if (response.data.status == "error") {              
              //var redirectUrl = siteurl + '/your-sponsored-companies';
              jQuery('#edit-scompany-modal-success').modal('show');
              jQuery('#edit-scompany-modal-success  .edit-scompany-modal-success-container').html('<h4 style="color:red">' + response.data.msg + '</h4>');
            }

          },
          error: function (jqXHR, textStatus, errorThrown) {
            jQuery('#edit-scompany-modal-success').modal('show');
            jQuery('#edit-scompany-modal-success  .edit-scompany-modal-success-container').html('<h4 style="color:red">' + errorThrown + '</h4>');
          },
        });        
        
      });


      jQuery('.btn-delete.delete').on('click', function (e) {
        e.preventDefault();
        jQuery('.sponsorid').val(jQuery(this).attr('data-id'));
        jQuery('#deleteSponsorModal').modal('show');
      });

      jQuery('.btn-confirm-delete').on('click', function (e) {
        e.preventDefault();
        jQuery('#deleteSponsorModal').modal('hide');
        var form = jQuery('form#deletesponsor')[0];
        var formData = new FormData(form);
        formData.append("action", "nstxl_deleteSponsor");
        $.ajax({
          url: nstxl_ajaxurl,
          type: "POST",
          data: formData,
          beforeSend: function () {
            jQuery('.preloader').fadeIn();
          },
          success: function (response, textStatus, jqXHR) {
            jQuery('.preloader').fadeOut();
            if (response.data.response == "success") {
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container').html('<h4>' + response.data.msg + '</h4>');
              jQuery('#update-personalinfo-modal-success').modal('show');
            }
            if (response.data.response == "error") {
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container').html('<h4 style="color:red">' + response.data.msg + '</h4>');
              var redirectUrl = siteurl + '/add-sponsor';
              jQuery('#update-personalinfo-modal-success').modal('show');
            }

          },
          error: function (jqXHR, textStatus, errorThrown) {
            add_message(textStatus, "danger");
          },
          complete: function () {
            form.reset();
          },
          cache: false,
          contentType: false,
          processData: false
        });
        jQuery('#update-personalinfo-modal-success').modal('hide');
      });
      jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
        location.reload(true);
      });

      jQuery('.btn-delete.remind').on('click', function (e) {
        e.preventDefault();
        jQuery('.sponsorid').val(jQuery(this).attr('data-id'));
        var remindersent = jQuery(this).attr('data-reminder');
        var reminderdate = jQuery(this).attr('data-reminderDate');
        if (remindersent == 1) {
          var mstr = '<h4>Reminder has been sent already on ' + reminderdate + '. Please renew your membership within 30 days</h4>';
          jQuery('.modalBody-container').html(mstr);
        }

        jQuery('#remindSponsorModal').modal('show');
      });
      jQuery('.pmpro_asterisk').remove();
      jQuery('.btn-confirm-reminder').on('click', function (e) {
        e.preventDefault();
        // alert(jQuery('.sponsorid').val());
        jQuery('#remindSponsorModal').modal('hide');
        var form = jQuery('form#remindsponsor')[0];
        var formData = new FormData(form);
        formData.append("action", "nstxl_remindSponsor");
        $.ajax({
          url: nstxl_ajaxurl,
          type: "POST",
          data: formData,
          beforeSend: function () {
            jQuery('.preloader').fadeIn();
          },
          success: function (response, textStatus, jqXHR) {
            jQuery('.preloader').fadeOut();
            if (response.data.response == "success") {
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container').html('<h4>' + response.data.msg + '</h4>');
              jQuery('#update-personalinfo-modal-success').modal('show');
            } else {
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container').html('<h4>' + response.data.msg + '</h4>');
              jQuery('#update-personalinfo-modal-success').modal('show');
            }
            if (response.data.response == "error") {
              jQuery('#update-personalinfo-modal-success  .update-personalinfo-box-success-container').html('<h4 style="color:red">' + response.data.msg + '</h4>');
              jQuery('#update-personalinfo-modal-success').modal('show');
            }

          },
          error: function (jqXHR, textStatus, errorThrown) {
            add_message(textStatus, "danger");
          },
          complete: function () {
            form.reset();
          },
          cache: false,
          contentType: false,
          processData: false
        });
        jQuery('#update-personalinfo-modal-success').modal('hide');
      });
      jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
        location.reload(true);
      })


      jQuery('.close').on('click', function (e) {
        jQuery('#update-personalinfo-modal-success').modal('hide');
        jQuery('#deleteSponsorModal').modal('hide');
        location.reload(true);
      });
      jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
        location.reload(true);
      });
    });
  </script>
  <?php get_footer('admin'); ?>
