<?php
/**
 * Template Name: Add Property
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */


get_header(); ?>


<?php 
/*$data='123, HB Road, Burdwan Compound, Lalpur, Ranchi, Jharkhand, India';
  $b='Hazaribag|Roasdfsdd';
  if(preg_match("($b)", $data) === 1) {
  echo 'MAtch'; die; } */
  /*if ( !is_user_logged_in()) {
      $current_url = $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
    //wp_redirect( site_url().'/new-property');
    wp_redirect( site_url().'/login' .'?redirect_to='.$current_url);
      //return $links;
    exit;
  }*/
?>

<!-- Start Head Section -->
  <section class="content-head">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="heading1"><?php the_title();?></h1>
              </div>
          </div>
      </div>
  </section>
<!-- End Head Section -->

<?php 

global $wpdb, $cfs, $post;
//print_r($cfs);die;
if (isset($_POST['submit']))
{ 
  //print_r($_POST);die;
  $address_details    = $_POST['address_details'];

  $title     = stripslashes($_POST['property_title']);
  //echo $title;die('ok');
  $content    = $_POST['property_detail'];  
  $price    = $_POST['price'];
  $psize    = $_POST['property_size'];  
  $phone    = $_POST['phone'];
  $pemail   = $_POST['email']; 
  $pwebsite   = $_POST['website'];

  $street_number  = $_POST['street_number'];
  $property_adr = $_POST['property_address'];
  $pcity    = $_POST['property_city'];
  $pstate   = $_POST['property_state'];
  $postcode   = $_POST['postcode'];
  $pcountry   = $_POST['property_country'];

  $postcode   = ltrim($postcode, "0");  
  $post_type  = 'property';

  
  

  $paddress = $street_number.''.$property_adr; 
      //$paddr = str_replace("'","''",$paddress);

      $metas = $wpdb->get_results( 
      $wpdb->prepare("SELECT meta_value FROM $wpdb->postmeta where meta_key = %s", '_property_address')
     );

    $metasres = $wpdb->get_results("SELECT post_id, meta_value FROM $wpdb->postmeta WHERE meta_key LIKE '_property_address' AND meta_value = '".$paddress."' LIMIT 0, 50" );

    $poid = array();
    $pstat_value = array();
    $pcity_value = array();
    $pzip_value = array();
    foreach ($metasres as $pmtavalue) {
      //echo "Post id: ".$pmtavalue->post_id;
      $poid[] = $pmtavalue->post_id;
      $pstat_value[] = get_post_meta( $pmtavalue->post_id, '_property_state', true );
      $pcity_value[] = get_post_meta( $pmtavalue->post_id, '_property_city', true );
      $pzip_value[] = get_post_meta( $pmtavalue->post_id, '_property_zip_code', true );
    }

    $arrvl = array();
      foreach ($metas as $key => $value) {      
        $arrvl[] = $value->meta_value;
    }






    if(in_array($paddress, $arrvl) && in_array($pstate, $pstat_value) && in_array($pcity, $pcity_value) && in_array($postcode, $pzip_value) ){

      /*$sechresult = $wpdb->get_results("SELECT * FROM wpsft_posts p, $wpdb->postmeta m1, $wpdb->postmeta m2, $wpdb->postmeta m3, wpsft_postmeta m4 WHERE p.ID = m1.post_id and p.ID = m2.post_id AND p.ID = m3.post_id and p.ID = m4.post_id AND m1.meta_key = '_property_address' AND m1.meta_value = '$paddress' AND m2.meta_key = '_property_city' AND m2.meta_value = '$pcity' AND m3.meta_key = '_property_state' AND m3.meta_value = '$pstate' AND m4.meta_key = '_property_zip_code' AND m4.meta_value = '$postcode' AND p.post_type = 'property'");
      print_r($sechresult[0]->ID);*/

    $permalink = get_permalink( $poid[0] );
    //echo $permalink;die;

    /*if ( wp_redirect( $permalink ) ) {
           exit;
         }*/
      ?>
      <section class="noticinfo property_form new-form">    
      <div class="container">
          <div class="alert alert-info alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong>Match found!!</strong> The Property already exist.
            <span><a href="<?php echo $permalink; ?>" target="_blank">View property</a></span>
          </div>
      </div>
      </section>
    <?php   
        /*}
      else
        {
        echo "Match not found";
        }*/
    }
    else {

      $new_post = array(
  'post_title'    => $title,
  'post_content'  => $content,
  'tags_input'  => $tags,
  'post_status'   => 'publish',      
  'post_type'     => $post_type 
  );

//echo "diiiiie";die;
  //$paddress = $_POST['street_number'].' '.$_POST['property_address'];
  
  //echo "paddress:".$paddress."<br/>";
  $paddr = str_replace("'","''",$paddress);
  //print_r($paddr);die;

  $pid=wp_insert_post($new_post);
  add_post_meta($pid, 'postflag', '1', true); 
  $field_data = array( '_property_address' =>  $paddress, '_property_city' => $pcity, '_property_state' => $pstate,
    '_property_zip_code' => $postcode, '_property_country' => $pcountry,
    '_property_phone' => $phone, '_property_email' => $pemail, '_property_management_company' => $pmc, '_website_address' => $pwebsite, '_property_price' => $price, '_property_size' => $psize );

  $gmapaddress=wp_insert_post($field_data);

  $post_data = array( 'ID' => $pid ); // the ID is required
  CFS()->save( $field_data, $post_data );
  
  global $current_user, $wpdb;
    get_currentuserinfo();
    //echo '<pre>'; print_r($current_user);die;
    $user_name = $current_user->display_name;
  $post_ID = get_the_ID();
  $post_id = $pid;
    $user_id = $current_user->ID;
    //$image_path = $new_imgpath;
    $status = 1;
    $image_featured_status = 1;
    $date = date('Y-m-d H:i:s');
  $j=0;
  $tableName = $wpdb->prefix.'post_slider_image';

  $upload_dir = wp_upload_dir();
  $up_Path =  $upload_dir['basedir'].'/front-slider-image/';

  if (is_uploaded_file($_FILES['image']['tmp_name']) && $_FILES['image']['error']==0) {
    $filenames= $_FILES['image']['name'];
    $ext = explode('.', $_FILES['image']['name']);//explode file name from dot(.) 
        $file_extension = end($ext); //store extensions in the variable
    $imgpath = site_url().'/wp-content/uploads/front-slider-image/'.$_FILES['image']['name'];
    $target_path = $up_Path . $ext[0] . "." . $ext[count($ext) - 1];
    //echo $imgpath;
    $nw = $imgpath.$_FILES['image']['name'];
     //echo $nw;
    // die();

    if (($_FILES["image"]["size"] < 20971520)) 
        {
          if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) 
            {
              chmod($target_path, 0777);
                $imgpath_orig = end(explode('/', $imgpath));
                $imgName     =  explode('.',$imgpath_orig,-1);
                //print_r($imgName);
                $imgName     = $imgpath_orig;
                $new_imgpath =  $imgpath.$imgpath_orig;

                $image_path = $new_imgpath.$_FILES['image']['name'];  
                //echo $new_imgpath;
                //die();
                $tableName = $wpdb->prefix.'post_slider_image';

                $insert = $wpdb->query("
                    INSERT INTO $tableName (post_id, user_id, user_name, image_path, image_name, date, status, image_featured_status) VALUES ('$post_id','$user_id', '$user_name', '$imgpath','$filenames' ,'$date','$status',$image_featured_status)
                    ");
               
            } 
        }

   }
    $the_custom_logo = get_bloginfo('template_directory').'/images/logo-share.png';
    $to = get_bloginfo('admin_email');
  $subject = 'Add New Property For Administrator Approval';
  $body .= '<table border="1" cellpadding="8" style="text-align:center;margin:0 auto;">';
  $body .= '<tr><td colspan="2" style="margin:5px;"><img src="'.$the_custom_logo.'"></td></tr>';
  $body .= '<tr><td colspan="2"><h3>Property Details</h3></td></tr>';
  if($title)
  {
    $body .= '<tr>
          <td>
            Property Name  
          </td>
          <td><strong>'.$title.'</strong></td>
         </tr>';
  }
  if($content)
  {
    $body .= '<tr>
          <td>
            Property Description  
          </td>
          <td><strong>'.$content.'</strong></td>
         </tr>';
  }
  if($paddress)
  {
    $body .= '<tr>
          <td>
            Property Address  
          </td>
          <td><strong>'.$paddress.'</strong></td>
         </tr>';
  }
  if($pcity)
  {
    $body .= '<tr>
          <td>
            Property City  
          </td>
          <td><strong>'.$pcity.'</strong></td>
         </tr>';
  }
  if($pstate)
  {
    $body .= '<tr>
          <td>
            Property State  
          </td>
          <td><strong>'.$pstate.'</strong></td>
         </tr>';
  }
  if($postcode)
  {
    $body .= '<tr>
          <td>
            Property Postcode  
          </td>
          <td><strong>'.$_POST['postcode'].'</strong></td>
         </tr>';
  }
  /*if($title)
  {
    $body .= '<tr>
          <td>
            Property Name 
          </td>
          <td><strong>'.$title.'</strong></td>
         </tr>';
  }*/
  if($phone)
  {
    $body .= '<tr>
          <td>
            Property Phone  
          </td>
          <td><strong>'.$phone.'</strong></td>
         </tr>';
  }
  if($pemail)
  {
    $body .= '<tr>
          <td>
            Property Email  
          </td>
          <td><strong>'.$pemail.'</strong></td>
         </tr>';
  }
  if($pwebsite)
  {
    $body .= '<tr>
          <td>
            Property Website  
          </td>
          <td><strong>'.$pwebsite.'</strong></td>
         </tr>';
  }
  if($price)
  {
    $body .= '<tr>
          <td>
            Property Price  
          </td>
          <td><strong>'.$price.'</strong></td>
         </tr>';
  }
  if($psize)
  {
    $body .= '<tr>
          <td>
            Property Size  
          </td>
          <td><strong>'.$psize.'</strong></td>
         </tr>';
  }
  if($imgpath)
  {
    $body .= '<tr>
          <td>
            Property Picture  
          </td>
          <td><strong><img src="'.$imgpath.'" style="width:150px" /></strong></td>
         </tr>';
  } 
  $body .= '</table>';
  $headers = array('Content-Type: text/html; charset=UTF-8','From: Safestan <support@example.com');
  wp_mail( $to, $subject, $body, $headers );
  }
}


?>
<!-- Start Add Property Form -->
  <section class="property_form new-form">
    <div class="container">
      <div class="row">
        <?php if ($pid == true) {
          $pageurl = home_url('/property/?page_id=').$pid.'&status=pending'; 
          header("Location:".$pageurl);
            /*echo '<div class="success-msg"><h4>Your property successfully added. Please Wait for administrator approval.<a href="'.$pageurl.'">Review the Property Listing</a></h4></div>';*/
          }
      ?>    
      </div>
    </div>

    <div class="container">
    <div class="row">

    <form class="form1" name="new_property" method="POST" action="" enctype="multipart/form-data">

    <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 width-48"> 
    <h3 class="heading3">About Property</h3>
    
    <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Property Name</label><br>
                <span><input type="text" placeholder="Enter Property Name" name="property_title" id = "property_title" class="form-control" value="Residence"></span>
            </div>
    </div>

    <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Property Management Company</label><br>
                <span><textarea rows="15" placeholder="Enter Property Management Company Details" name="property_detail" class="form-control" style="height: 215px;"></textarea></span>
                    </div>
      </div>

      <div class="row">
      <div class="form-group col-sm-6 col-xs-12">
                <label for="Name">Price in USD</label><br>
                <span class="doller"><strong>$</strong> <input type="text" placeholder="Enter Property Price" name="price" class="form-control"></span>
            </div>
            <div class="form-group col-sm-6 col-xs-12 ">
                <label for="Name">Property Size</label><br>
                <span><input type="text" placeholder="Enter Property Size" name="property_size" class="form-control"></span>
            </div>
    </div>
  

    </div>

    <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 width-48 pd-left-50"> 
    <h3 class="heading3">Property Location</h3>
    <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
        <div id="locationField">
        <label for="Name">Property Address<sup>*</sup></label><br>
            <input class="form-control" name="address_details" id="autocomplete" placeholder="Enter your address"
                   onFocus="geolocate()" type="text"></input>
          </div>
      </div>
    </div>

    <div class="prodetails">
    <label>Street Address</label>
    <input type="text" class="form-control" placeholder="Street Number" id="street_number" name="street_number" disabled="true">
    </input>

        <label>Property Address</label>
        <input type="text" class="form-control" placeholder="Enter Property Address" name="property_address"  id="route"
              disabled="true">  
        </input>
    
        <label>City</label>
        <input type="text" class="form-control"  placeholder="Enter Property City" name="property_city" id="locality" disabled="true">
        </input>

        <label>State</label>
        <input type="text" placeholder="Enter Property State" name="property_state" id="administrative_area_level_1" class="form-control" disabled="true">  
        </input>

        <label>Zip Code</label>
        <input type="text" placeholder="Enter Postal Code" name="postcode" class="form-control"  id="postal_code"
              disabled="true">  
        </input>

        <label>Country</label>
        <input type="text" class="form-control" placeholder="Country" id="country" name="property_country" disabled="true"> 
        </input>
        </div>
    <!-- <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Property Address<sup>*</sup></label><br>
                    <span><textarea rows="10" placeholder="Enter Property Address" name="property_address" class="form-control" style="height: 100px;"></textarea></span>
            </div>
      </div>

      <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Property City<sup>*</sup></label><br>
                    <span><input type="text" placeholder="Enter Property City" name="property_city" class="form-control"></span>
            </div>
    </div>
      <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Property State<sup>*</sup></label><br>
                    <span><input type="text" placeholder="Enter Property State" name="property_state" class="form-control"></span>
            </div>
    </div>
      <div class="row">
        <div class="form-group col-sm-12 col-xs-12 ">
                    <label for="Name">Postal Code<sup>*</sup></label><br>
                    <span><input type="text" placeholder="Enter Postal Code" name="postcode" class="form-control"></span>
                </div>
      </div>
-->
    </div> 

    <div class="clearfix"></div>


    <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12 width-48"><div class="divider"></div></div>

    <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 width-48"> 
    <h3 class="heading3">Other Information</h3>
    
    <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Property Phone</label><br>
                <span><input type="text" placeholder="Enter Property Phone" name="phone" class="form-control"></span>
            </div>
    </div>

    <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Upload Property Image</label>
                <div class="custom-upload-file">
            <input type="file" value="" name="image" class="form-control cus-form-control">
                <div class="fake-file">
                    <input disabled="disabled" class="form-control" placeholder="Browse file..." >
                </div>
        </div>
            </div>
    </div>


    </div>

    <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12 width-48 pd-left-50"> 
      
    <h3 class="heading3 pheading3"></h3>
    <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Email Address</label><br>
                <span><input type="text" placeholder="Enter Property Email Address" name="email" id="email" class="form-control"></span>
            </div>
      </div>

      <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <label for="Name">Property Website</label><br>
                <span><input type="text" placeholder="Enter Property Website" name="website" class="form-control"></span>
            </div>
    </div>
          
    </div>

    <div class="clearfix"></div>


    <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12 width-48"><div class="divider"></div></div>

    <div class="col-sm-5 col-md-6 col-lg-6 col-xs-12 width-48"> 
     <!--<h3 class="heading3">Upload Property Image</h3>
    
    <div class="row">
      <div class="form-group col-sm-12 col-xs-12 ">
                <!-- <label for="Name">Upload Property Image<sup>*</sup></label><br> -->
               <!--  <div class="custom-upload-file">
            <input type="file" value="" name="image" class="form-control cus-form-control">
                <div class="fake-file">
                    <input disabled="disabled" class="form-control" placeholder="Browse file..." >
                </div>
        </div>
            </div>
    </div> -->
    </div> 

    <div class="col-sm-7 col-md-6 col-lg-6 col-xs-12 width-48 pd-left-50"> 
      
    <div class="row">
    <div class="form-group col-sm-12 col-xs-12 text-right text-c ">
    <button type="cancel" class="property_cancel btn1 reset">Cancel</button>
    <!-- <input type="cancel" class="property_cancel btn1 reset" name="submit" value="Cancel"> -->
        <input type="submit" class="property_submit btn1" name="submit" value="Submit">
              </div>
    </div>
          
    </div>

    </form> 


    </div>
    </div>  
  </section>
  <!-- start script validate-->
  <script>
jQuery(document).ready(function($){

jQuery('.custom-upload-file input[type=file]').change(function(){
    jQuery(this).next().find('input').val($(this).val());
});
});
</script>

<script src="<?php bloginfo('template_url');?>/js/jquery.validate.min.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function(e){
        jQuery('.property_cancel').click(function(){
          //alert('ok');
     e.preventDefault();
        });
    });
</script>
<script> 

  jQuery('.property_submit').click(function(){
  jQuery("form[name='new_property']").validate({
      // Specify validation error rules
    rules: {
      //property_address: "required",
      address_details: "required",
      //property_city: "required",
      //property_state: "required",
      //postcode: "required",
      /*
      property_title: "required",
      property_detail: "required",
      image: "required",
      phone: {
      required: true,
      number: true 
    },
      email: {
        required: true,
        email: true
      },

      */
    },
    // Specify validation error messages
    messages: {
      //property_address: " Please Fill Out Property Address.",
      address_details: " Please Fill Out Property Details.",
      //property_city: "Please Fill Out Property City.",
      //property_state: "Please Fill Out Property State.",
      //postcode: "Please Fill Out Postal Code.",
      /*
      property_title: "Please Fill Out Property Name.",
      property_detail: "Please Fill Out Property Details.",
      email: "Please enter a valid email address.",
      phone: "Please Fill Out Contact Detail.",
      image: "Please upload property picture."
      */
    },
    submitHandler: function(form) {
      form.submit();
    }
  });
});
</script>
<!-- end script validate-->

<script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode','establishment']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();
        document.getElementById('autocomplete').value = place.formatted_address;
          //console.log(place);
        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }
        var addrs = place.adr_address.split(",")
        
         
         document.getElementById('property_title').value = place.name;
        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          //console.log(place.address_components);
          //console.log(place.address_components[i]);
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
            //console.log(componentForm[addressType]);
           
            
          }
          /*else if(place.address_components[i].types[0] == 'route'){
               var addressType1 = place.address_components[1].types[0];
                console.log(place.address_components[i].long_name);
                var val1 = place.address_components[i][componentForm[addressType1]];
              document.getElementById('route').value = place.address_components[i].long_name;
                //console.log(addressType1);
           
          } else if(place.address_components[i].types[0] == 'sublocality_level_1'){
             var addressType1 = place.address_components[i].types[0];
                console.log(place.address_components[i].long_name);
                var val1 = place.address_components[i][componentForm[addressType1]];
              document.getElementById('route').value = place.address_components[i].long_name;

          }*/
          else{
               var rex = /(<([^>]+)>)/ig;
               
               document.getElementById('street_number').value = addrs[0].replace(rex , "");
               document.getElementById('route').value = addrs[1].replace(rex , "");


          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcNH2i2PzorNJo8XnEyv5373mMx-Gmlwo&libraries=places&callback=initAutocomplete"
        async defer></script>


<!-- End Add Property Form -->
<?php get_footer(); ?>