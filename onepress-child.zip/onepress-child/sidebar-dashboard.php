<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OnePress
 */
?>

<div id="secondary" class="dashboard-sidebar widget-area sidebar" role="complementary">
  <?php echo do_shortcode('[elementor-template id="6159"]'); ?>

  <?php if (is_active_sidebar('sidebar-dashboard')) {
    dynamic_sidebar('sidebar-dashboard');
  } ?>
</div><!-- #secondary -->
