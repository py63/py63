<?php
if(class_exists('Wordpress2StepVerification')){
	$sw = Wp2sv();
	$sw->bind('email','Wp2sv_Phone');
	require 'Wp2sv_Phone.php';  
    
    $sw->bind('setup','Wp2sv_Setup');
	require 'Wp2sv_Setup.php';      
 }   

 // Phone Number meta key delete When 2FA Turn Off

add_action( 'wp_ajax_nstxl_phone_delete_metakey', 'nstxl_phone_delete_metakey' );
add_action( 'wp_ajax_nopriv_nstxl_phone_delete_metakey', 'nstxl_phone_delete_metakey' );

function nstxl_phone_delete_metakey() {
	global $current_user; 	
	$phone_number_2step = get_user_meta($current_user->ID, 'phone_number_2step','true' );	
	if ( ! empty( $phone_number_2step ) ) {
		delete_user_meta($current_user->ID, 'phone_number_2step');     
	}
}     



/* Anspress Ask question form fields  */

function my_custom_question_field( $form ) {

	global $user;
	if ( is_user_logged_in() ) {
		$user_info = wp_get_current_user();

		$form = array(
				'submit_label' => __( 'Submit', 'anspress-question-answer' ),
				'fields'			 => array(
						'qa_username'			 => array(
								'label'		 => __( '' ),
								'subtype'	 => 'text', // Default type is set to input.
								'order'		 => 1,
								'desc'		 => __( 'User Name', 'anspress-question-answer' ),
								'value'		 => $user_info->display_name,
								'attr'		 => array(
										'placeholder'	 => 'User Name',
										'disabled'		 => 'disabled',
								),
						),
						'qa_email'				 => array(
								'label'		 => __( '' ),
								'subtype'	 => 'email', // Default type is set to input.
								'order'		 => 1,
								'value'		 => $user_info->user_email,
								'desc'		 => __( 'Email Address', 'anspress-question-answer' ),
								'attr'		 => array(
										'placeholder'	 => 'Email Address',
										'disabled'		 => 'disabled',
								),
						),
						'qa_orgatization'	 => array(
								'label'		 => __( '' ),
								'subtype'	 => 'text', // Default type is set to input.
								'order'		 => 1,
								'desc'		 => __( 'Organization', 'anspress-question-answer' ),
								'value'		 => get_user_meta( $user_info->ID, 'company_name', true ),
								'attr'		 => array(
										'placeholder'	 => 'Organization',
										'disabled'		 => 'disabled',
								),
						),
						'post_title'			 => array(
								'type'			 => 'input',
								'label'			 => __( '', 'anspress-question-answer' ),
								'attr'			 => array(
										'autocomplete'	 => 'off',
										'placeholder'		 => __( 'Question title', 'anspress-question-answer' ),
										'data-action'		 => 'suggest_similar_questions',
										'data-loadclass' => 'q-title',
								),
								'min_length' => ap_opt( 'minimum_qtitle_length' ),
								'max_length' => 100,
								'validate'	 => 'required,min_string_length,max_string_length,badwords',
								'order'			 => 2,
						),
						'post_content'		 => array(
								'type'				 => 'textarea',
								'label'				 => __( '', 'anspress-question-answer' ),
								'attr'				 => array(
										'placeholder' => 'Question Description',
								),
								'min_length'	 => ap_opt( 'minimum_question_length' ),
								'validate'		 => 'required,min_string_length,badwords',
								'editor_args'	 => array(
										'quicktags' => ap_opt( 'question_text_editor' ) ? true : false,
								),
						),
				),
		);
	}

	return $form;
}

add_filter( 'ap_question_form_fields', 'my_custom_question_field', 10, 2 );

/* Login Rediection hook  */

function nstxl_login_redirect( $redirect_to, $request, $user ) {
	if ( isset( $_POST[ 'submit' ] ) ) {
		if ( isset( $_POST[ 'redirect_to' ] ) && ($_POST[ 'redirect_to' ] == get_bloginfo( 'url' ) . '/tracked-opportunities' ) ) {
			return $clogin_url = $_POST[ 'redirect_to' ];
		}

		if ( isset( $_POST[ 'redirect_to' ] ) ) {
			if ( ($_POST[ 'redirect_to' ] == get_bloginfo( 'url' ) . '/tracked-opportunities') || (	$_POST[ 'redirect_to' ] == get_bloginfo( 'url' ) . '/submit-aproposal')				
				|| (strpos($_POST[ 'redirect_to' ], 'tracked-opportunities') !== false) || (strpos($_POST[ 'redirect_to' ], 'submit-aproposal') !== false) ) {
				return $clogin_url = $_POST[ 'redirect_to' ];
		}
	}
}

	//is there a user to check?
	// global $current_user;
	//echo "string".$user->ID;
	if ( isset( $user->roles ) && is_array( $user->roles ) ) {
		//check for admins
		if ( in_array( 'administrator', $user->roles ) ) {
			// redirect them to the default place
			return $redirect_to;
		} else if ( in_array( 'subscriber', $user->roles ) ) {
			$cstep	 = get_user_meta( $user->ID, 'current_step', true ); //#step1
			$clevel	 = get_user_meta( $user->ID, 'cuser_level', true ); //1


			$today = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) );

			global $wpdb;
			$cuid			 = $user->ID;
			$cmp_name	 = get_user_meta( $cuid, 'company_name', true );
			$query		 = "SELECT user_id FROM " . $wpdb->prefix . "usermeta WHERE `meta_key` = 'company_name' AND `meta_value` = '{$cmp_name}' ";
			$result		 = $wpdb->get_results( $query );
			$uids			 = array();
			if ( ! empty( $result ) ) {
				foreach ( $result as $key => $value ) {
					$uids[] = $value->user_id;
				}
			}
			if ( ! empty( $uids ) ) {
				$uidStr		 = implode( ',', $uids );
				$query_mbr = "SELECT * FROM " . $wpdb->prefix . "pmpro_memberships_users WHERE `user_id` IN  ($uidStr)";
			}
			$result_mbr = $wpdb->get_results( $query_mbr );

			if ( ! empty( $result_mbr[ 0 ]->user_id ) ) {
				$statuses = nstxl_get_membership_status_expired_user( $result_mbr[ 0 ]->user_id );/** get membership status of main member * */
			} else {
				$statuses = '';
			}

			if ( ! empty( $result_mbr ) && ! empty( $statuses ) && ($statuses[ 0 ]->status != 'expired') && (strtotime( $today ) < strtotime( $statuses[ 0 ]->enddate )) ) {
				/** Redirect user to membership account page. If membership is not expired and today's date is smaller than membership end date. * */
				$clogin_url = home_url() . '/membership-account/';
			}
			if ( ! empty( $statuses ) && ($statuses[ 0 ]->status == 'expired') && (strtotime( $today ) > strtotime( $statuses[ 0 ]->enddate )) ) {

				if ( ! empty( $result_mbr[ 0 ]->user_id ) && ! empty( $cuid ) && ($result_mbr[ 0 ]->user_id == $cuid) ) {
					/** Check current user is a main member and redirect to membership levels page. * */
					$clogin_url = home_url() . '/membership-account/membership-levels/?exp=1';
				} else {
					/** Redirect additional user to membership account page. * */
					$clogin_url = home_url() . '/membership-account/';  
				}
			}


			//Added after found status changed from backend
			if ( ! empty( $statuses ) && ($statuses[ 0 ]->status !== 'expired') && (strtotime( $today ) > strtotime( $statuses[ 0 ]->enddate )) ) {
				if ( ! empty( $result_mbr[ 0 ]->user_id ) && ! empty( $cuid ) && ($result_mbr[ 0 ]->user_id == $cuid) ) {

					/** Check current user is a main member and redirect to membership levels page. * */
					$clogin_url = home_url() . '/membership-account/membership-levels/?expr=1';
				} else {
					/** Redirect additional user to membership account page. * */
					$clogin_url = home_url() . '/membership-account';
				}
			}

			if ( ! empty( $cstep ) && ! empty( $clevel ) && empty( $statuses ) ) {

				/** Redirect user to membership checkout page. If user not complete thier registration process. * */
				$clogin_url = home_url() . '/membership-account/membership-checkout/?level=' . $clevel . $cstep;
			}
			if ( empty( $cstep ) && empty( $clevel ) && empty( $statuses ) ) {

				/** Redirect subscriber user(non members) to membership levels page. * */
				$clogin_url = home_url() . '/membership-account/membership-levels/';
			}

			return $clogin_url;
		} else {
			$trexImportedUser = get_user_meta( $user->ID, 'trex_imported', true );
			if ( $trexImportedUser == 1 ) {
				$trex_loggedin = get_user_meta( $user->ID, 'trex_floggedin', true );
				if ( $trex_loggedin != 1 ) {
					update_user_meta( $user->ID, 'trex_floggedin', 1 );
				}
				if ( ($trexImportedUser == 1) && ($trex_loggedin != 1) ) {
					$clogin_url = esc_url( get_page_link( 2433 ) );
				} else {
					$clogin_url = home_url( '/membership-account/' );
				}
			} else {
				$clogin_url = home_url( '/membership-account/' );
			}
			return $clogin_url;
		}
	} else {
		return $redirect_to;
	}
}

add_filter( 'login_redirect', 'nstxl_login_redirect', 1000, 3 );

add_action( 'wp_logout', function() {
	wp_redirect( home_url( '/login' ) );
	exit;
} );

/* show current user name   */

function show_loggedin_function( $atts ) {
	global $current_user, $user_login;

	add_filter( 'widget_text', 'do_shortcode' );
	if ( $user_login )
		return '<h2 class="titlewel">Welcome <span class="wluser">' . ucwords( $current_user->display_name ) . '</span></h2>';
	else
		return '<p class="loginmesg">You need to login<a class="logauthen" href="' . site_url() . '/login">Here</a>to access this page.</p>';
}

add_shortcode( 'show_loggedin_as', 'show_loggedin_function' );


/* Customized paid membership pro price   */

function pmpro_getLevelCostPolar( &$level, $tags = true, $short = false ) {
	// initial payment
	if ( ! $short ) {
		$r = sprintf( __( 'The price for membership is <strong>%s</strong>', 'paid-memberships-pro' ), pmpro_formatPrice( $level->initial_payment ) );
	} else {

		$r = str_replace( ".00", "", pmpro_formatPrice( $level->initial_payment ) );
		$r = '<strong>' . $r . '</strong>';
	}

	// recurring part
	if ( $level->billing_amount != '0.00' ) {
		if ( $level->billing_limit > 1 ) {
			if ( $level->cycle_number == '1' ) {
				$r .= sprintf( __( ' and then <strong>%1$s per %2$s for %3$d more %4$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->billing_amount ), pmpro_translate_billing_period( $level->cycle_period ), $level->billing_limit, pmpro_translate_billing_period( $level->cycle_period, $level->billing_limit ) );
			} else {
				$r .= sprintf( __( ' and then <strong>%1$s every %2$d %3$s for %4$d more payments</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->billing_amount ), $level->cycle_number, pmpro_translate_billing_period( $level->cycle_period, $level->cycle_number ), $level->billing_limit );
			}
		} elseif ( $level->billing_limit == 1 ) {
			$r .= sprintf( __( ' and then <strong>%1$s after %2$d %3$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->billing_amount ), $level->cycle_number, pmpro_translate_billing_period( $level->cycle_period, $level->cycle_number ) );
		} else {
			if ( $level->billing_amount === $level->initial_payment ) {
				if ( $level->cycle_number == '1' ) {
					if ( ! $short ) {
						$r = sprintf( __( 'The price for membership is <strong>%1$s per %2$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->initial_payment ), pmpro_translate_billing_period( $level->cycle_period ) );
					} else {
						$r = sprintf( __( '<strong>%1$s per %2$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->initial_payment ), pmpro_translate_billing_period( $level->cycle_period ) );
					}
				} else {
					if ( ! $short ) {
						$r = sprintf( __( 'The price for membership is <strong>%1$s every %2$d %3$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->initial_payment ), $level->cycle_number, pmpro_translate_billing_period( $level->cycle_period, $level->cycle_number ) );
					} else {
						$r = sprintf( __( '<strong>%1$s every %2$d %3$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->initial_payment ), $level->cycle_number, pmpro_translate_billing_period( $level->cycle_period, $level->cycle_number ) );
					}
				}
			} else {
				if ( $level->cycle_number == '1' ) {
					$r .= sprintf( __( ' and then <strong>%1$s per %2$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->billing_amount ), pmpro_translate_billing_period( $level->cycle_period ) );
				} else {
					$r .= sprintf( __( ' and then <strong>%1$s every %2$d %3$s</strong>.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->billing_amount ), $level->cycle_number, pmpro_translate_billing_period( $level->cycle_period, $level->cycle_number ) );
				}
			}
		}
	} else {
		$r .= '';
	}

	// add a space
	$r .= ' ';

	// trial part
	if ( $level->trial_limit ) {
		if ( $level->trial_amount == '0.00' ) {
			if ( $level->trial_limit == '1' ) {
				$r .= ' ' . __( 'After your initial payment, your first payment is Free.', 'paid-memberships-pro' );
			} else {
				$r .= ' ' . sprintf( __( 'After your initial payment, your first %d payments are Free.', 'paid-memberships-pro' ), $level->trial_limit );
			}
		} else {
			if ( $level->trial_limit == '1' ) {
				$r .= ' ' . sprintf( __( 'After your initial payment, your first payment will cost %s.', 'paid-memberships-pro' ), pmpro_formatPrice( $level->trial_amount ) );
			} else {
				$r .= ' ' . sprintf( __( 'After your initial payment, your first %1$d payments will cost %2$s.', 'paid-memberships-pro' ), $level->trial_limit, pmpro_formatPrice( $level->trial_amount ) );
			}
		}
	}

	// taxes part
	$tax_state = pmpro_getOption( 'tax_state' );
	$tax_rate	 = pmpro_getOption( 'tax_rate' );

	if ( $tax_state && $tax_rate && ! pmpro_isLevelFree( $level ) ) {
		$r .= sprintf( __( 'Customers in %1$s will be charged %2$s%% tax.', 'paid-memberships-pro' ), $tax_state, round( $tax_rate * 100, 2 ) );
	}

	if ( ! $tags ) {
		$r = strip_tags( $r );
	}

	$r = apply_filters( 'pmpro_level_cost_text', $r, $level, $tags, $short ); // passing $tags and $short since v1.8
	return $r;
}

/* Customized paid membership pro Experition messege */

function pmpro_getLevelExpirationnstxl( &$level ) {
	if ( $level->expiration_number ) {
		$expiration_text = sprintf( __( '', 'paid-memberships-pro' ), $level->expiration_number, pmpro_translate_billing_period( $level->expiration_period, $level->expiration_number ) );
	} else {
		$expiration_text = '';
	}

	$expiration_text = apply_filters( 'pmpro_levels_expiration_text', $expiration_text, $level );
	$expiration_text = apply_filters( 'pmpro_level_expiration_text', $expiration_text, $level ); // Backwards compatible
	return $expiration_text;
}

/* Created custom paid membership pro Confirmation mail variable */
add_filter( "pmpro_email_filter", "my_pmpro_email_filter" );

function my_pmpro_email_filter( $email ) {
	global $wpdb, $current_user;

	$cmp_users_ids = get_user_meta( $current_user->ID, 'company_users_ids', true );

	if ( isset( $cmp_users_ids ) && ! empty( $cmp_users_ids ) ) {
		$adaarray = array();

		foreach ( $cmp_users_ids as $value ) {
			$cmp_user_id			 = $value;
			$company_userdata	 = nstxl_company_additional_userdata( $cmp_user_id );
			$additional_user	 = $company_userdata[ 'first_name' ] . ' ' . $company_userdata[ 'last_name' ];
			$adaarray[]				 = ucwords( $additional_user );

			$poc_info		 = get_userdata( $company_userdata[ 'poc_userid' ] );
			$pocemail		 = $poc_info->user_email;
			$pocfullname = ucwords( $poc_info->display_name );
		}

		$string_con	 = implode( ',', $adaarray );
		$string_html = $string_con;
	}

	// Expiration date
	$enddate = $wpdb->get_var( "SELECT UNIX_TIMESTAMP(enddate) FROM $wpdb->pmpro_memberships_users WHERE user_id = '" . $current_user->ID . "' AND status = 'active' LIMIT 1" );

	if ( isset( $enddate ) && ! empty( $enddate ) ) {

		$expirydate		 = sprintf( __( "%s", 'paid-memberships-pro' ), date_i18n( get_option( 'date_format' ), $enddate ) );
		$expriyforfree = "<p style='font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;'>" . sprintf( __( "This membership will expire on %s.", 'paid-memberships-pro' ), date_i18n( get_option( 'date_format' ), $enddate ) ) . "</p>\n";
	}
	// Extra fields
	global $discount_code;
	if ( ! empty( $discount_code ) )
		$discode = "<p style='font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;'>" . sprintf( __( "Discount Code", 'paid-memberships-pro' ) . ": " . $discount_code . "</p>\n" );
	else
		$discode = "";


	$extra_variables = array(
			'company_name'						 => $current_user->company_name,
			'expiration_date'					 => $expirydate,
			'expiration_for_freecheck' => $expriyforfree,
			'additional_user'					 => $string_html,
			'poc_email'								 => $pocemail,
			'poc_name'								 => $pocfullname,
			'diccode'									 => $discode,
	);

	$freeofcosttext = 'Your membership is good for up to one year or as long as the Incubator sponsors your firm.';
	if ( nstxl_isSponsor( $current_user->ID ) ) {
		$extra_variables[ 'freecosttext' ] = $freeofcosttext;
	} else {
		$extra_variables[ 'freecosttext' ] = '';
	}

	foreach ( $extra_variables as $key => $value ) {
		$email->subject	 = str_replace( "!!" . $key . "!!", $value, $email->subject );
		$email->body		 = str_replace( "!!" . $key . "!!", $value, $email->body );
	}
	return $email;
}

remove_filter( "pmpro_email_filter", "pmprorh_pmpro_email_filter", 10, 2 );


/* Add an attachment to confirmation emails. */
add_filter( 'pmpro_email_attachments', 'my_pmpro_email_attachments', 10, 2 );

function my_pmpro_email_attachments( $attachments, $email ) {

	global $current_user;
	//make sure it's a checkout email (but not the admin one)
	if ( strpos( $email->template, "checkout_" ) !== false && strpos( $email->template, "admin" ) === false ) {
		//make sure attachments is an array
		if ( is_array( $attachments ) )
			$attachments = array();

		//add our attachment
		$user_login = $email->data[ 'user_login' ];

		$upload_dir		 = wp_upload_dir();
		$user_dirname	 = $upload_dir[ 'basedir' ] . '/invoices/' . $user_login;
		if ( ! file_exists( $user_dirname ) ) {
			wp_mkdir_p( $user_dirname );
		}

		$date = date( "Y-m-d h:i:sa" );

		$expirydatenew = substr( $email->data[ 'membership_expiration' ], 33, -1 );


		$pdfhtml = ' <div style="max-width:750px; margin:0 auto; background-color:#fff;">
       <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width:750px; margin:0px auto;" class="contenttable">
          <tbody>
            <tr>
              <td valign="middle" style="background-color:#fff; text-align:center; border-top:3px solid #ff0000;border-bottom:3px solid #ff0000; padding-top:30px; padding-bottom:30px; " class="side-padding"><a href="https:www.nstxl.org" target="_blank"><img src="' . site_url() . '/wp-content/uploads/2019/04/nstxl-large-logo.png" height="75" alt="" border="0"/></a></td>
            </tr>
            </tbody>

            </table>
       <div style="margin-bottom:40px;"><img src="' . site_url() . '/wp-content/uploads/2019/04/header-bg.jpg" height="140px" width="100%" alt="" border="0"/></div>
      
      
      <div style="display:inline-block; vertical-align:top; width:65%; padding-right:4%; background-color:#fff; padding-top:12%;"><b style="    font-family: Arial, sans-serif;margin-bottom: 0; text-transform:uppercase;font-size:40px; color:#000; text-align:left;
    ">INVOICE<br><br>
                        </b>
                        
                                <table class="cstm-tbl" width="100%" border="1" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; text-align:center;font-family: Arial, sans-serif;">
                          <tr>
                            <th style="padding:5px 40px">Description</th>
                            <th style="padding:5px 20px">QTY</th>
                            <th style="padding:5px 40px">Price</th>
                          </tr>
                          <tr>
                            <td>1-year NSTXL Membership
                              ' . $email->data[ 'membership_level_name' ] . '</td>
                            <td>1</td>
                            <td>' . $email->data[ 'invoice_total' ] . '</td>
                          </tr>
                          <tr>
                            <th></th>
                            <th>Total</th>
                            <th>' . $email->data[ 'invoice_total' ] . '</th>
                          </tr>
                        </table>
                        </div>
      <div style=" display:inline-block; vertical-align:top; width:29%;background-color:#fff; border-left:2px solid #687279"> <div style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Amount Due</b> <br>
                              <span style="font-size:24px; color:#000;">' . $email->data[ 'invoice_total' ] . '</span></div>
                              
                              
                               <div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Billed To</b> <br>
                              <span style="font-size:16px; color:#000;">' . $email->data[ 'name' ] . '<br>
                             ' . $email->data[ 'billing_street' ] . '<br>
                        	 ' . $email->data[ 'billing_city' ] . ', ' . $email->data[ 'billing_state' ] . ', ' . $email->data[ 'billing_zip' ] . '</span></div>
                              
                              
                                  <div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Invoice Number</b> <br>
                              <span style="font-size:16px; color:#000;">' . $email->data[ 'invoice_id' ] . '</span></div>
                                <div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Start Date</b> <br>
                              <span style="font-size:16px; color:#000;">' . $email->data[ 'invoice_date' ] . '</span></div>
                              
                              
                                <div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:10px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Membership Expires</b> <br>
                              <span style="font-size:16px; color:#000;">' . $expirydatenew . '</span></div>
                              </div>
      
      <div style="clear:both;"></div>
         <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0;">
                          <tbody>
                            <tr>
                              <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff; max-width: 700px;padding: 0 0 0px; margin: 0 auto">
                                  <tbody>
                                    <tr>
                                      <td style="background-color:#fff;" bgcolor="#fff" height="80">&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="middle" align="center" style="font-family:Arial, sans-serif;line-height:14px; color:#5F5F5F; font-size:14px; padding-bottom:0px;"><img src="' . site_url() . '/wp-content/uploads/2019/04/nstxl-small-logo.png" style="padding-top:3px"  width="30" alt="" border="0"/> | National Security Technology Accelerator | 1-800-364-1545 | <span style="font-family:Arial, sans-serif; color:#ff0000; font-size:16px;line-height:0px; text-decoration:none;">www.nstxl.org</span></td>
                                    </tr>
                                  </tbody>
                                </table></td>
                            </tr>
                          </tbody>
                        </table>
     
      </div>';

  $pdfhtml_receipt = '<div style="max-width:750px; margin:0 auto; background-color:#fff;">
  		<table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width:750px; margin:0px auto;" class="contenttable">
  		<tbody>
  		<tr>
  		<td valign="middle" style="background-color:#fff; text-align:center; border-top:3px solid #ff0000;border-bottom:3px solid #ff0000; padding-top:30px; padding-bottom:30px; " class="side-padding"><a href="https:www.nstxl.org" target="_blank"><img src="' . site_url() . '/wp-content/uploads/2019/04/nstxl-large-logo.png" height="75" alt="" border="0"/></a></td>
  		</tr>
  		</tbody>

  		</table>
  		<div style="margin-bottom:40px;"><img src="' . site_url() . '/wp-content/uploads/2019/04/header-bg.jpg" height="140px" width="100%" alt="" border="0"/></div>


  		<div style="display:inline-block; vertical-align:top; width:65%; padding-right:4%; background-color:#fff; padding-top:12%;"><b style="    font-family: Arial, sans-serif;margin-bottom: 0; text-transform:uppercase;font-size:40px; color:#000; text-align:left;
  		">RECEIPT<br><br>  
  		</b>

  		<table class="cstm-tbl" width="100%" border="1" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; text-align:center;font-family: Arial, sans-serif;">
  		<tr>
  		<th style="padding:5px 40px">Description</th>
  		<th style="padding:5px 20px">QTY</th>
  		<th style="padding:5px 40px">Price</th>
  		</tr>
  		<tr>
  		<td>1-year NSTXL Membership
  		' . $email->data[ 'membership_level_name' ] . '</td>
  		<td>1</td>
  		<td>' . $email->data[ 'invoice_total' ] . '</td>
  		</tr>
  		<tr>
  		<th></th>
  		<th>Total</th>
  		<th>' . $email->data[ 'invoice_total' ] . '</th>
  		</tr>
  		</table>
  		</div>
  		<div style=" display:inline-block; vertical-align:top; width:29%;background-color:#fff; border-left:2px solid #687279"> <div style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
  		font-size: 18px;">Amount Paid</b> <br>
  		<span style="font-size:24px; color:#000;">' . $email->data[ 'invoice_total' ] . '</span></div>


  		<div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
  		font-size: 18px;">Billed To</b> <br>
  		<span style="font-size:16px; color:#000;">' . $email->data[ 'name' ] . '<br>
  		' . $email->data[ 'billing_street' ] . '<br>
  		' . $email->data[ 'billing_city' ] . ', ' . $email->data[ 'billing_state' ] . ', ' . $email->data[ 'billing_zip' ] . '</span></div>


  		<div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
  		font-size: 18px;">Invoice Number</b> <br>
  		<span style="font-size:16px; color:#000;">' . $email->data[ 'invoice_id' ] . '</span></div>
  		<div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
  		font-size: 18px;">Paid On</b> <br> 
  		<span style="font-size:16px; color:#000;">' . $email->data[ 'invoice_date' ] . '</span></div>


  		<div colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:10px;"><b style="    margin-bottom: 0;
  		font-size: 18px;">Membership Expires</b> <br>
  		<span style="font-size:16px; color:#000;">' . $expirydatenew . '</span></div>
  		</div>

  		<div style="clear:both;"></div>
  		<table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0;">
  		<tbody>
  		<tr>
  		<td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff; max-width: 700px;padding: 0 0 0px; margin: 0 auto">
  		<tbody>
  		<tr>
  		<td style="background-color:#fff;" bgcolor="#fff" height="80">&nbsp;</td>
  		</tr>
  		<tr>
  		<td colspan="2" valign="middle" align="center" style="font-family:Arial, sans-serif;line-height:14px; color:#5F5F5F; font-size:14px; padding-bottom:0px;"><img src="' . site_url() . '/wp-content/uploads/2019/04/nstxl-small-logo.png" style="padding-top:3px"  width="30" alt="" border="0"/> | National Security Technology Accelerator | 1-800-364-1545 | <span style="font-family:Arial, sans-serif; color:#ff0000; font-size:16px;line-height:0px; text-decoration:none;">www.nstxl.org</span></td>
  		</tr>
  		</tbody>
  		</table></td>
  		</tr>
  		</tbody>
  		</table>
  		</div> 
  		';

		$path = $user_dirname . "/invoice-" . $date . ".pdf";

		_print_pdf_custom( $pdfhtml, $path );
		//add our attachment
		$attachments[] = $path;

  		$path_receipt	 = $user_dirname . "/receipt-" . $date . ".pdf";
  		_print_pdf_custom( $pdfhtml_receipt, $path_receipt );
  		$attachments[] = $path_receipt;
	}
	return $attachments;
}

/* Add css and js */

function post_scripts() {


	//wp_enqueue_style( 'datepickercss', get_stylesheet_directory_uri() . '/dist/css/bootstrap-datetimepicker.css' );
	wp_register_script( 'moment-js', get_stylesheet_directory_uri() . '/js/moment.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'moment-js' );

	wp_register_script( 'moment-local-js', get_stylesheet_directory_uri() . '/js/moment-with-locales.js', array( 'jquery','moment-js' ), '', true );
	wp_enqueue_script( 'moment-local-js' );

	wp_register_script( 'bootstrap-datetimepicker-js', get_stylesheet_directory_uri() . '/js/bootstrap-datetimepicker.js', array( 'jquery','moment-local-js' ), '', true );
	wp_enqueue_script( 'bootstrap-datetimepicker-js' );
	

	wp_register_script( 'html2pdfbundle', get_stylesheet_directory_uri() . '/js/html2pdf.bundle.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'html2pdfbundle' );

	//wp_enqueue_script( 'moment-datepickerjs', get_stylesheet_directory_uri() . '/dist/js/moment-with-locales.js', array( 'jquery' ), '', true );
	//wp_enqueue_script( 'datepickerjs', get_stylesheet_directory_uri() . '/dist/js/bootstrap-datetimepicker.js', array( 'jquery' ), '', true );
	/* Loginpage JS */
	if ( is_page( '2128' ) ) {
		wp_enqueue_script( 'polar-login-form-script', get_stylesheet_directory_uri() . '/assets/js/custom.js', array( 'jquery' ), true );
	}

	if ( is_page( '3739' ) ) {
		wp_enqueue_script( 'contractthrunstxl', get_stylesheet_directory_uri() . '/assets/js/contractthrunstxl.js', array( 'jquery' ), true );
		wp_localize_script( 'contractthrunstxl', 'contractthrunstxls', array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ), ) );
	}

	if ( is_page( 'register-now' ) || is_page( 'change-password' ) ) {
		wp_enqueue_script( 'password-strength-meter' );
	}

	if ( is_page( 'reset-passwords' ) ) {
		// change your password and reset your password
		wp_register_script( 'reset-passwords', get_stylesheet_directory_uri() . '/assets/js/reset-passwords.js', array( 'jquery' ), true );
		// localization for reset passwords
		wp_localize_script( 'reset-passwords', 'changepassajax', array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
		) );

		wp_enqueue_script( 'reset-passwords' );
	}

	if ( is_page( 'news' ) ) {
		// Post load js
		wp_register_script( 'post-load-script', get_stylesheet_directory_uri() . '/assets/js/postload.js', array( 'jquery' ), true );
		wp_localize_script( 'post-load-script', 'postloadajax', array(
				'postload' => admin_url( 'admin-ajax.php' ),
		) );
		wp_enqueue_script( 'post-load-script' );

		// post filter js
		wp_register_script( 'post-script-handle', get_stylesheet_directory_uri() . '/assets/js/postfilter.js', array( 'jquery' ), true );
		wp_localize_script( 'post-script-handle', 'postajax', array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
		) );
		wp_enqueue_script( 'post-script-handle' );
	}

	if(is_page('contact-us') || is_page('search-the-nstxl-member-database') || is_page('contract-thru-nstxl'))
	{
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_register_style( 'jquery-ui', get_stylesheet_directory_uri() . '/assets/css/datepicker.css' );
		wp_enqueue_style( 'jquery-ui' );  
	}

}

add_action( 'wp_footer', 'post_scripts' );

/* Set Login Redirection */

function nstxl_loggedin_redirection() {
	if ( is_page( 'membership-levels' ) ) {
		if ( ! is_user_logged_in() ) {
			wp_redirect( get_bloginfo( 'url' ) . '/login/' );
			exit;
		}
	}
}

/* Set Logout Redirection */

add_action( 'wp', 'nstxl_loggedin_redirection', 100 );

add_action( 'wp_logout', 'auto_redirect_after_logout' );

function auto_redirect_after_logout() {
	wp_redirect( home_url( '/login' ) );
	exit();
}

/* Ajax for filter post  */

add_action( 'wp_ajax_post_fetch', 'post_fetch' );
add_action( 'wp_ajax_nopriv_post_fetch', 'post_fetch' );

function post_fetch() {

	global $post;

	$postperpage = (isset( $_POST[ "postperpage" ] )) ? $_POST[ "postperpage" ] : 6;
	$page				 = (isset( $_POST[ 'pageNumber' ] )) ? $_POST[ 'pageNumber' ] : 1;

	$args = array( 'post_type' => 'post', 'category__not_in' => array( 34, 71 ), 'posts_per_page' => $postperpage, 'paged' => $page );

	if ( isset( $_POST[ 'categoryfilter' ] ) && $_POST[ 'categoryfilter' ] != "" ) {

		$args[ 'tax_query' ] = array(
				array(
						'taxonomy' => 'category',
						'field'		 => 'slug',
						'terms'		 => trim( $_POST[ 'categoryfilter' ] ),
				),
		);
	}
	query_posts( $args );
	?>
	<!-- the loop -->
	<?php


	if ( have_posts() ) : while ( have_posts() ) : the_post();
			$posttitle = get_the_title();
			$wordcount = str_word_count( $posttitle );

			$show_thumbnail = true;
			if (get_theme_mod('onepress_hide_thumnail_if_not_exists', false)) {
			  if (!has_post_thumbnail()) {
			    $show_thumbnail = false;
			  }
			}
			?>
			<div class="card">
				<article id="post-<?php the_ID(); ?>" <?php post_class(array('list-article', 'clearfix')); ?>>
					  <?php if ($show_thumbnail) { ?>
				      <div class="list-article-thumb">
				        <a href="<?php echo esc_url(get_permalink()); ?>">
				          <?php
				          if (has_post_thumbnail()) {
				            //the_post_thumbnail( 'onepress-blog-small' );
				            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'onepress-blog-small');
				            echo '<img class="card-img-top" data-src="' . $featured_img_url . '" alt="blog" style="height: 200px; width: 100%; display: block;" src="' . $featured_img_url . '" data-holder-rendered="true">';
				          } else {
				            echo '<img class="card-img-top" alt="placholder" src="' . get_template_directory_uri() . '/assets/images/placholder2.png' . '" data-holder-rendered="true">';
				          }
				          ?>
				        </a>
				      </div>
				    <?php } ?>
				 <div class="card-body">
			      <h4 class="card-title"><?php
			        $wordcount = str_word_count(get_the_title());
			        if ($wordcount > 10) {
			          ?> 
			          <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo wp_trim_words(get_the_title(), 10, ''); ?></a>
			        <?php } else { ?>
			          <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo get_the_title(); ?></a>
			        <?php } ?></h4>
			      <h6 class="card-subtitle mb-2 text-muted"><?php echo get_the_date(); ?></h6>
			      <div class="entry-excerpt"><p class="card-text"><?php echo wp_trim_words(get_the_content(), 12, ''); ?></p></div>
			      <div class="readmore-button-section">
			        <a class="btn btn-secondary-outline btn-lg" href="<?php echo esc_url(get_permalink()); ?>"><?php _e('Read More', 'onepress'); ?></a>
			      </div> 
			    </div>
					<!-- the title, the content etc.. -->
				</article>
			</div>
		<?php endwhile; ?>
	<?php else : ?>
	
		<div class="nf-post">Post Not Found.</div>
		<!-- No posts found -->
	<?php endif; ?>
	<?php
	global $wp_query;

	$max_page = $wp_query->max_num_pages;
	if ( $max_page > $page ) {
		?>
		<div id="loadmore" class="loadmore wow animated fadeInUp"><a>Load More</a></div>
	<?php } ?>
	<!-- End of Blog Query -->
	<?php
	wp_reset_query();
	die();
}

/* Setup url on join now page based on user  */
add_action( 'wp_footer', 'add_css_joinbtn' );

function add_css_joinbtn() {
	global $current_user;
   if ( is_page('membership-list') || is_page('membership') ) {  		
		if ( ! is_user_logged_in() ) {
			?>
			<style>
				.btn-login { 
					display: none !important;   
				}
				.btn-purchaselevel{
					display: none !important;
				}
			</style>
			<?php
		} elseif ( pmpro_getMembershipLevelForUser( $current_user->ID ) ) {
			?>
			<style>
				.btn-login { 
					display: none !important;   
				}
				.btn-nonlogin {   
					display: none !important;    
				}
			</style>
			<?php
		} else {
			?>
			<style>
				.btn-nonlogin {   
					display: none !important;    
				}
				.btn-purchaselevel{
					display: none !important;
				}
			</style>
			<?php
		}
	} 
}

/* Remove .00  from price */

add_filter( 'pmpro_format_price', 'nstxl_filter_price', 10, 4 );

function nstxl_filter_price( $formatted, $price, $pmpro_currency, $pmpro_currency_symbol ) {

	$formatted = number_format( (double) $price, 0 );
	return $formatted = $pmpro_currency_symbol . $formatted;
}

/*
  Remove now from price
  Shortcode to show membership account information
 */

function pmpro_shortcode_account_nstxl( $atts, $content = null, $code = "" ) {
	global $wpdb, $pmpro_msg, $pmpro_msgt, $pmpro_levels, $current_user, $levels;


	extract( shortcode_atts( array(
			'section'	 => '',
			'sections' => 'membership,profile,invoices,links'
			), $atts ) );

	//did they use 'section' instead of 'sections'?
	if ( ! empty( $section ) )
		$sections = $section;

	//Extract the user-defined sections for the shortcode
	$sections = array_map( 'trim', explode( ",", $sections ) );
	ob_start();

	//if a member is logged in, show them some info here (1. past invoices. 2. billing information with button to update.)
	if ( pmpro_hasMembershipLevel() ) {
		$ssorder			 = new MemberOrder();
		$ssorder->getLastMemberOrder();
		$mylevels			 = pmpro_getMembershipLevelsForUser();
		$pmpro_levels	 = pmpro_getAllLevels( false, true ); // just to be sure - include only the ones that allow signups
		$invoices			 = $wpdb->get_results( "SELECT *, UNIX_TIMESTAMP(timestamp) as timestamp FROM $wpdb->pmpro_membership_orders WHERE user_id = '$current_user->ID' AND status NOT IN('refunded', 'review', 'token', 'error') ORDER BY timestamp DESC LIMIT 6" );
		?>	
		<div id="pmpro_account">		
			<?php if ( in_array( 'membership', $sections ) || in_array( 'memberships', $sections ) ) { ?>
				<div id="pmpro_account-membership" class="pmpro_box">

					<h3><?php _e( "My Memberships", 'paid-memberships-pro' ); ?></h3>
					<table width="100%" cellpadding="0" cellspacing="0" border="0">
						<thead>
							<tr>
								<th><?php _e( "Level", 'paid-memberships-pro' ); ?></th>
								<th><?php _e( "Billing", 'paid-memberships-pro' ); ?></th>
								<th><?php _e( "Expiration", 'paid-memberships-pro' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ( $mylevels as $level ) {
								?>
								<tr>
									<td class="pmpro_account-membership-levelname">
										<?php echo $level->name ?>
										<div class="pmpro_actionlinks">
											<?php do_action( "pmpro_member_action_links_before" ); ?>

											<?php if ( array_key_exists( $level->id, $pmpro_levels ) && pmpro_isLevelExpiringSoon( $level ) ) { ?>
												<a href="<?php echo pmpro_url( "checkout", "?level=" . $level->id, "https" ) ?>"><?php _e( "Renew", 'paid-memberships-pro' ); ?></a>
											<?php } ?>

											<?php if ( (isset( $ssorder->status ) && $ssorder->status == "success") && (isset( $ssorder->gateway ) && in_array( $ssorder->gateway, array( "authorizenet", "paypal", "stripe", "braintree", "payflow", "cybersource" ) )) && pmpro_isLevelRecurring( $level ) ) { ?>
												<a href="<?php echo pmpro_url( "billing", "", "https" ) ?>"><?php _e( "Update Billing Info", 'paid-memberships-pro' ); ?></a>
											<?php } ?>

											<?php
											//To do: Only show CHANGE link if this level is in a group that has upgrade/downgrade rules
											if ( count( $pmpro_levels ) > 1 && ! defined( "PMPRO_DEFAULT_LEVEL" ) ) {
												?>
												<a href="<?php echo pmpro_url( "levels" ) ?>" id="pmpro_account-change"><?php _e( "Change", 'paid-memberships-pro' ); ?></a>
											<?php } ?>
											<a href="<?php echo pmpro_url( "cancel", "?levelstocancel=" . $level->id ) ?>" id="pmpro_account-cancel"><?php _e( "Cancel", 'paid-memberships-pro' ); ?></a>
											<?php do_action( "pmpro_member_action_links_after" ); ?>
										</div> <!-- end pmpro_actionlinks -->
									</td>
									<td class="pmpro_account-membership-levelfee">
										<p><?php echo pmpro_getLevelCostPolar( $level, true, true ); ?></p>
									</td>
									<td class="pmpro_account-membership-expiration">
										<?php
										if ( $level->enddate )
											$expiration_text = date( get_option( 'date_format' ), $level->enddate );
										else
											$expiration_text = "---";

										echo apply_filters( 'pmpro_account_membership_expiration_text', $expiration_text, $level );
										?>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
					<?php //Todo: If there are multiple levels defined that aren't all in the same group defined as upgrades/downgrades   ?>
					<div class="pmpro_actionlinks">
						<a href="<?php echo pmpro_url( "levels" ) ?>"><?php _e( "View all Membership Options", 'paid-memberships-pro' ); ?></a>
					</div>

				</div> <!-- end pmpro_account-membership -->
			<?php } ?>

			<?php if ( in_array( 'profile', $sections ) ) { ?>
				<div id="pmpro_account-profile" class="pmpro_box">	
					<?php wp_get_current_user(); ?> 
					<h3><?php _e( "My Account", 'paid-memberships-pro' ); ?></h3>
					<?php if ( $current_user->user_firstname ) { ?>
						<p><?php echo $current_user->user_firstname ?> <?php echo $current_user->user_lastname ?></p>
					<?php } ?>
					<ul>
						<?php do_action( 'pmpro_account_bullets_top' ); ?>
						<li><strong><?php _e( "Username", 'paid-memberships-pro' ); ?>:</strong> <?php echo $current_user->user_login ?></li>
						<li><strong><?php _e( "Email", 'paid-memberships-pro' ); ?>:</strong> <?php echo $current_user->user_email ?></li>
						<?php do_action( 'pmpro_account_bullets_bottom' ); ?>
					</ul>
					<div class="pmpro_actionlinks">
						<a href="<?php echo admin_url( 'profile.php' ) ?>" id="pmpro_account-edit-profile"><?php _e( "Edit Profile", 'paid-memberships-pro' ); ?></a>
						<a href="<?php echo admin_url( 'profile.php' ) ?>" id="pmpro_account-change-password"><?php _e( 'Change Password', 'paid-memberships-pro' ); ?></a>
					</div>
				</div> <!-- end pmpro_account-profile -->
			<?php } ?>

			<?php if ( in_array( 'invoices', $sections ) && ! empty( $invoices ) ) { ?>		
				<div id="pmpro_account-invoices" class="pmpro_box">
					<h3><?php _e( "Past Invoices", 'paid-memberships-pro' ); ?></h3>
					<table width="100%" cellpadding="0" cellspacing="0" border="0">
						<thead>
							<tr>
								<th><?php _e( "Date", 'paid-memberships-pro' ); ?></th>
								<th><?php _e( "Level", 'paid-memberships-pro' ); ?></th>
								<th><?php _e( "Amount", 'paid-memberships-pro' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php
							$count = 0;
							foreach ( $invoices as $invoice ) {
								if ( $count ++ > 4 )
									break;

								//get an member order object
								$invoice_id	 = $invoice->id;
								$invoice		 = new MemberOrder;
								$invoice->getMemberOrderByID( $invoice_id );
								$invoice->getMembershipLevel();
								?>
								<tr id="pmpro_account-invoice-<?php echo $invoice->code; ?>">
									<td><a href="<?php echo pmpro_url( "invoice", "?invoice=" . $invoice->code ) ?>"><?php echo date_i18n( get_option( "date_format" ), $invoice->timestamp ) ?></td>
									<td><?php
										if ( ! empty( $invoice->membership_level ) )
											echo $invoice->membership_level->name;
										else
											echo __( "N/A", 'paid-memberships-pro' );
										?></td>
									<td><?php echo pmpro_formatPrice( $invoice->total ) ?></td>
								</tr>
								<?php
							}
							?>
						</tbody>
					</table>						
					<?php if ( $count == 6 ) { ?>
						<div class="pmpro_actionlinks"><a href="<?php echo pmpro_url( "invoice" ); ?>"><?php _e( "View All Invoices", 'paid-memberships-pro' ); ?></a></div>
				<?php } ?>
				</div> <!-- end pmpro_account-invoices -->
			<?php } ?>

		<?php if ( in_array( 'links', $sections ) && (has_filter( 'pmpro_member_links_top' ) || has_filter( 'pmpro_member_links_bottom' )) ) { ?>
				<div id="pmpro_account-links" class="pmpro_box">
					<h3><?php _e( "Member Links", 'paid-memberships-pro' ); ?></h3>
					<ul>
						<?php
						do_action( "pmpro_member_links_top" );
						?>

						<?php
						do_action( "pmpro_member_links_bottom" );
						?>
					</ul>
				</div> <!-- end pmpro_account-links -->		
		<?php } ?>
		</div> <!-- end pmpro_account -->		
		<?php
	}

	$content = ob_get_contents();
	ob_end_clean();

	return $content;
}

/* Ajax for dashboard reset_password */
add_action( 'wp_ajax_reset_password_nstxl', 'reset_password_nstxl' );
add_action( 'wp_ajax_nopriv_reset_password_nstxl', 'reset_password_nstxl' );

function reset_password_nstxl() {

	$user_id			 = $_POST[ 'getcurid' ];
	$user_password = $_POST[ 'getpassword' ];

	if ( isset( $user_id ) && ! empty( $user_id ) ) {
		$user_info	 = get_userdata( $user_id );
		$user_email	 = $user_info->user_email;
		$user_name	 = $user_info->display_name;

		wp_set_password( $user_password, $user_id );

		if ( isset( $user_email ) && ! empty( $user_email ) ) {
			$to			 = $user_email;
			$subject = 'Your password has been changed';

			$message = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center">
		<thead>
			<tr><td style=" padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer"></a></td></tr>
			<tr>
				<td>
					<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
				<tr>
					<td style=" text-align: center; color: #fff;">
						<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Your password has been changed</p>
					</td>
				</tr>
					</table>
				</td>
			</tr>
			</thead>
			<tbody >
			<tr>
			<td>
			<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
			<tr>
			<td>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello ' . ucwords( $user_name ) . ',</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Your Email : ' . ucwords( $user_email ) . ',</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Your password has been changed.</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">New password is: ' . $user_password . '</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Please click here to login: ' . site_url() . '/login</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
			$message .= '</td></tr></table>
		</td>
		</tr>
		</tbody>
				<tfoot>
		<tr>
			<td>
			<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
			<tr>
			<td>
			<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
			</td>
			</tr>
			</table>
			</td>
		</tr>
		</tfoot>
		</table>';

			$headers							 = 'MIME-Version: 1.0' . "\r\n";
			$headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";

			$mail = wp_mail( $to, $subject, $message, $confirmation_headers );

			if ( $mail ) {
				$success = 'Check your email address for you new password.';
			} else {
				$error = 'Oops something went wrong updaing your account.';
			}
		}
	}
	die();
}

/* Ajax for dashboard change user password */
add_action( 'wp_ajax_change_yourpassword', 'change_yourpassword' );
add_action( 'wp_ajax_nopriv_change_yourpassword', 'change_yourpassword' );

function change_yourpassword() {

	$user_id						 = $_POST[ 'getpocid' ];
	$user_newpass				 = $_POST[ 'newpass' ];
	$user_newconfirmpass = $_POST[ 'newconfirmpass' ];

	if ( isset( $user_id ) && ! empty( $user_id ) ) {
		if ( $user_newpass == $user_newconfirmpass ) {

			$user_info	 = get_userdata( $user_id );
			$user_email	 = $user_info->user_email;
			$user_name	 = $user_info->display_name;

			wp_set_password( $user_newpass, $user_id );

			if(isset($user_newpass) && !empty($user_newpass)){ 	 	

					$start_date = date('Y-m-d H:i:s', current_time('timestamp'));  
					$end_date =  date('Y-m-d H:i:s', strtotime($start_date. ' + 90 days'));       
					if (current_user_can('administrator'))  
					{
						update_user_meta( $user_id, 'expiry-password-change', $end_date );
					}  
				}

			if ( isset( $user_email ) && ! empty( $user_email ) ) {
				$to			 = $user_email;
				$subject = 'Your new password';

				$message							 = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center">
		<thead>
			<tr><td style=" padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer"></a></td></tr>
		<tr>
			<td>
			<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
			<tr>
			<td style=" text-align: center; color: #fff;">
			<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Your new password</p>
			</td>
			</tr>
			</table>
			</td>
			</tr>
			</thead>
			<tbody >
		<tr>
		<td>
		<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
		<tr>
		<td>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello ' . ucwords( $user_name ) . ',</p>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Your password has been changed.</p>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Please click here to login: ' . site_url() . '/login</p>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">If this was not you please click this <a href="' . site_url() . '/login">link.</a></p>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
				$message .= '</td></tr></table>
		</td>
		</tr></tbody><tfoot>
		<tr><td>
		<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
		<tr><td>
		<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
		</td>
		</tr>
		</table>
		</td></tr>
		</tfoot></table>';
				$headers							 = 'MIME-Version: 1.0' . "\r\n";
				$headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";

				$mail = wp_mail( $to, $subject, $message, $confirmation_headers );

				if ( $mail ) {
					$success = 'Check your email address for you new password.';
				} else {
					$error = 'Oops something went wrong updaing your account.';
				}
			}
		}
	}
	die();
}

/*
  remove now from price
  Shortcode to show membership account information
 */

function renewyouraccount_shortcode_nstxl( $atts, $content = null, $code = "" ) {
	global $wpdb, $pmpro_msg, $pmpro_msgt, $pmpro_levels, $current_user, $levels;


	extract( shortcode_atts( array(
			'section'	 => '',
			'sections' => 'membership,profile,invoices,links'
			), $atts ) );

	//did they use 'section' instead of 'sections'?
	if ( ! empty( $section ) )
		$sections = $section;

	//Extract the user-defined sections for the shortcode
	$sections = array_map( 'trim', explode( ",", $sections ) );
	ob_start();

	//if a member is logged in, show them some info here (1. past invoices. 2. billing information with button to update.)
	if ( pmpro_hasMembershipLevel() ) {
		$ssorder			 = new MemberOrder();
		$ssorder->getLastMemberOrder();
		$mylevels			 = pmpro_getMembershipLevelsForUser();
		$pmpro_levels	 = pmpro_getAllLevels( false, true ); // just to be sure - include only the ones that allow signups
		$invoices			 = $wpdb->get_results( "SELECT *, UNIX_TIMESTAMP(timestamp) as timestamp FROM $wpdb->pmpro_membership_orders WHERE user_id = '$current_user->ID' AND status NOT IN('refunded', 'review', 'token', 'error') ORDER BY timestamp DESC LIMIT 6" );
		?>	
		<div id="pmpro_account">		
		<?php if ( in_array( 'membership', $sections ) || in_array( 'memberships', $sections ) ) { ?>
				<div id="pmpro_account-membership" class="pmpro_box">

					<h3><?php _e( "My Memberships", 'paid-memberships-pro' ); ?></h3>
					<table width="100%" cellpadding="0" cellspacing="0" border="0">
						<thead>
							<tr>
								<th><?php _e( "Level", 'paid-memberships-pro' ); ?></th>
								<th><?php _e( "12 month Membership Dues", 'paid-memberships-pro' ); ?></th>
								<th><?php _e( "Expiration", 'paid-memberships-pro' ); ?></th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ( $mylevels as $level ) {
								?>
								<tr>
									<td class="pmpro_account-membership-levelname">
				<?php echo $level->name ?>
									</td>
									<td class="pmpro_account-membership-levelfee">
										<p><?php echo pmpro_getLevelCostPolar( $level, true, true ); ?></p>
									</td>
									<td class="pmpro_account-membership-expiration">
										<?php
										if ( $level->enddate )
											$expiration_text = date( get_option( 'date_format' ), $level->enddate );
										else
											$expiration_text = "---";

										echo apply_filters( 'pmpro_account_membership_expiration_text', $expiration_text, $level );
										?>
									</td>
									<td>
										<div class="pmpro_actionlinks">
											<?php do_action( "pmpro_member_action_links_before" ); ?>

											<?php if ( array_key_exists( $level->id, $pmpro_levels ) && pmpro_isLevelExpiringSoon( $level ) ) { ?>
												<a style="font-size: 16px;border-color: #e35e67;padding: 11.5px 30px;width: auto;display: inline-block;float: right;font-family: 'robotomedium';font-weight: 500;    background-color: #dc323e;color: #fff;font-size: 14px;transition: all 0.2s;border-color: #e35e67;padding: 10px 25px;border-radius: 5px ;" class="pmpro_checkout pmpro_btn-select" href="/membership-account/membership-levels"><?php _e( "Renew", 'paid-memberships-pro' ); ?></a>
											<?php } ?>								
				<?php do_action( "pmpro_member_action_links_after" ); ?>
										</div> <!-- end pmpro_actionlinks -->	
									</td>
								</tr>
			<?php } ?>
						</tbody>
					</table>
				</div> <!-- end pmpro_account-membership -->
		<?php } ?>

		</div> <!-- end pmpro_account -->		
		<?php
	}

	$content = ob_get_contents();
	ob_end_clean();

	return $content;
}

/* Added filter for set numeric validation on text field */
add_filter( 'wpcf7_validate_text', 'alphanumeric_validation_filter', 20, 2 );
add_filter( 'wpcf7_validate_text*', 'alphanumeric_validation_filter', 20, 2 );

function alphanumeric_validation_filter( $result, $tag ) {
	$tag = new WPCF7_Shortcode( $tag );

	if ( 'approximatevalue' == $tag->name ) {
		$name_of_the_input = isset( $_POST[ 'approximatevalue' ] ) ? trim( $_POST[ 'approximatevalue' ] ) : '';

		if ( ! preg_match( '/^[0-9]+$/', $name_of_the_input ) ) {
			$result->invalidate( $tag, "Allowed characters are numbers only" );
		}
	}

	return $result;
}

/* Ajax for contract thru nstxl dashboard page if click yes on radio button */

add_action( 'wp_ajax_contract_thru_nstxl', 'contract_thru_nstxl' );
add_action( 'wp_ajax_nopriv_contract_thru_nstxl', 'contract_thru_nstxl' );

function contract_thru_nstxl() {

	$currentemail		 = $_POST[ 'currentemail' ];
	$currentusername = $_POST[ 'currentusername' ];

	if ( isset( $currentemail ) && ! empty( $currentemail ) ) {
		$to			 = 'vikesh.tokhare@galaxyweblinks.in';
		$subject = 'Contract Thru NSTXL';

		$message = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center">
		<thead>
			<tr><td style=" padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer"></a></td></tr>
<tr><td>
<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
<tr>
<td style=" text-align: center; color: #fff;">
<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Contract Thru NSTXL</p>
</td>
</tr>
</table>
</td>
</tr>
</thead><tbody >
<tr>
<td>
<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
<tr>
<td>';
		$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello NSTXL,</p>';
		$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">' . ucwords( $currentusername ) . '(' . $currentemail . ') has requested to work with NSTXL.</p>';
		$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
		$message .= '</td></tr>
</table>
</td></tr>
</tbody><tfoot>
<tr>
<td>
<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
<tr>
<td>
<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
</td>
</tr>
</table>
</td>
</tr>
</tfoot>
</table>';

		$headers							 = 'MIME-Version: 1.0' . "\r\n";
		$headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";

		$mail = wp_mail( $to, $subject, $message, $confirmation_headers );

		if ( $mail ) {
			$success = 'Check your email address.';
		} else {
			$error = 'Oops something went wrong updaing your account.';
		}
	}
	die();
}

/* Fetched poc */

function nstxl_is_poc( $current_user_ID ) {
	global $wpdb;
	$results = $wpdb->get_row( "SELECT user_id FROM $wpdb->usermeta WHERE meta_key = 'poc' AND meta_value='" . $current_user_ID . "'" );
	if ( ! empty( $results ) ) {
		$main_userid = $results->user_id;
	} else {
		$main_userid = '';
	}
	return $main_userid;
}

/*
 * function to save membership level tab value.
 */

function nstxl_pmpro_save_membership_level_tab( $level_id ) {
	if ( $level_id <= 0 ) {
		return;
	}
	$tab = $_REQUEST[ 'pmpro_member_tab' ];
	update_option( 'pmpro_tab_' . $level_id, $tab );
}

add_action( 'pmpro_save_membership_level', 'nstxl_pmpro_save_membership_level_tab' );

/*
 * function to add membership level tab field on add/edit membership level page.
 */

function nstxl_pmpro_membership_level_tab_after_other_settings() {
	?>
	<h3 class="topborder"><?php _e( 'Membership Level Category', 'paid-memberships-pro' ); ?></h3>
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row" valign="top"><label for="pmpro_member_tab"><?php _e( 'Select Category:', 'paid-memberships-pro' ); ?></label></th>
				<td>
					<?php
					if ( isset( $_REQUEST[ 'edit' ] ) ) {
						$edit	 = intval( $_REQUEST[ 'edit' ] );
						$tab	 = get_option( 'pmpro_tab_' . $edit );
					} else {
						$tab = "";
					}
					?>
					<select name="pmpro_member_tab" id="pmpro_member_tab">
						<option value="corporate" <?php
						if ( $tab == 'corporate' ) {
							echo "selected";
						}
						?> >Corporate (based on parent company Annual Revenues) </option>
						<option value="non-profit" <?php
						if ( $tab == 'non-profit' ) {
							echo "selected";
						}
						?> >Non-Profit (based on Annual Revenues)</option>
						<option value="non-corporate" <?php
						if ( $tab == 'non-corporate' ) {
							echo "selected";
						}
						?> >Non Corporate (based on Annual Revenues)</option>
					</select>
					<p class="description"><?php _e( 'Set the category for this level.', 'paid-memberships-pro' ); ?></p>
				</td>
			</tr>
		</tbody>
	</table>
	<?php
}

add_action( 'pmpro_membership_level_after_other_settings', 'nstxl_pmpro_membership_level_tab_after_other_settings' );

/**
 * Filter the settings of email frequency sent when using the Extra Expiration Warning Emails Add On.
 */
function nstxl_custom_email_frequency( $settings = array() ) {
	$settings = array(
			2	 => '',
			3	 => '',
			4	 => '',
	);
	return $settings;
}

add_filter( 'pmproeewe_email_frequency_and_templates', 'nstxl_custom_email_frequency', 10, 1 );

/**
 * Register a custom post type called "book".
 *
 * @see get_post_type_labels() for label keys.
 */
function nstxl_opportunity_init() {
	$labels = array(
			'name'							 => _x( 'Opportunities', 'Post type general name', 'onepress' ),
			'singular_name'			 => _x( 'Opportunity', 'Post type singular name', 'onepress' ),
			'menu_name'					 => _x( 'Opportunities', 'Admin Menu text', 'onepress' ),
			'name_admin_bar'		 => _x( 'Opportunity', 'Add New on Toolbar', 'onepress' ),
			'add_new'						 => __( 'Add New', 'onepress' ),
			'add_new_item'			 => __( 'Add New Opportunity', 'onepress' ),
			'new_item'					 => __( 'New Opportunity', 'onepress' ),
			'edit_item'					 => __( 'Edit Opportunity', 'onepress' ),
			'view_item'					 => __( 'View Opportunity', 'onepress' ),
			'all_items'					 => __( 'All Opportunities', 'onepress' ),
			'search_items'			 => __( 'Search Opportunities', 'onepress' ),
			'parent_item_colon'	 => __( 'Parent Opportunities:', 'onepress' ),
			'not_found'					 => __( 'No Opportunities found.', 'onepress' ),
			'not_found_in_trash' => __( 'No Opportunities found in Trash.', 'onepress' ),
	);

	$args = array(
			'labels'							 => $labels,
			'public'							 => true,
			'publicly_queryable'	 => true,
			'show_ui'							 => true,
			'show_in_menu'				 => true,
			'query_var'						 => true,
			'rewrite'							 => array( 'slug' => 'opportunity' ),
			'capability_type'			 => 'post',
			'has_archive'					 => false,
			'taxonomies'					 => array( 'opportunity-type' ),
			'menu_position'				 => null,
			'exclude_from_search'	 => false,
			'supports'						 => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
	);

	register_post_type( 'opportunity', $args );

	register_taxonomy( 'opportunity-type', 'opportunity', array(
			'label'				 => __( 'Categories', 'onepress' ),
			'rewrite'			 => array( 'slug' => 'opportunity-type' ),
			'hierarchical' => true,
			'query_var'		 => true,
	) );
}

add_action( 'init', 'nstxl_opportunity_init' );

/* Dequeue script on checkout page */

function nstxl_dequeue_script() {
	if ( ! is_page( 'membership-checkout' ) ) {
		wp_dequeue_script( 'pmpropbc' );
	}
}

add_action( 'wp_print_scripts', 'nstxl_dequeue_script', 100 );

function nstxl_dequeue_style() {
	wp_dequeue_style( 'custom-css' );
}

add_action( 'wp_print_styles', 'nstxl_dequeue_style', 100 );


/* Disabled text field in post type question */

function my_head_input() {
	global $post_type;
	if ( 'nstxl-question' == $post_type ) {
		?>
		<script>
			jQuery( document ).ready( function ( $ ) {
				( function ( $ ) {
					jQuery( "#acf-field_5bfb9139f825d" ).attr( "readonly", "readonly" );
					jQuery( "#acf-field_5bfb912cf825c" ).attr( "readonly", "readonly" );
					jQuery( "#acf-field_5bfb90d4f8258" ).attr( "readonly", "readonly" );
					jQuery( "#acf-field_5bfb90eef8259" ).attr( "readonly", "readonly" );
					jQuery( "#acf-field_5bfb9103f825a" ).attr( "readonly", "readonly" );
				} )( jQuery );
			} );
		</script>
		<?php
	}

	/* Added text counter */

	if ( 'opportunity' == $post_type ) {
		?>
		<script type="text/javascript">
			jQuery( document ).ready( function ( $ ) {
				( function ( $ ) {
					$.fn.textareaacfCounter = function ( options ) {

						var defaults = {
							limit: 100
						};
						var options = $.extend( defaults, options );

						return this.each( function () {
							var obj, text, wordcount, limited;

							obj = $( this );

							obj.parent().append( '<span style="font-size: inherit; clear: both; margin-top: 3px; color: #999; display: block;" id="counter-text">Max. ' + options.limit + ' words</span>' );
							obj.keyup( function () {
								text = obj.val();
								if ( text === "" ) {
									wordcount = 0;
								} else {
									wordcount = $.trim( text ).split( " " ).length;
								}
								if ( wordcount > options.limit ) {
									$( "#counter-text" ).html( '<span style="color: #DD0000;">0 words left</span>' );
									limited = $.trim( text ).split( " ", options.limit );
									limited = limited.join( " " );
									$( this ).val( limited );
								} else {
									$( "#counter-text" ).html( ( options.limit - wordcount ) + ' words left' );
								}
							} );
						} );
					};
				} )( jQuery );
				jQuery( "#acf-field_5bec10628602d" ).textareaacfCounter( { limit: 500 } );
			} );
		</script>
		<?php
	}
}

add_action( 'acf/input/admin_head', 'my_head_input' );


/* Comment form validation */

function comment_validation_init() {
	if ( is_single() && comments_open() ) {
		?>        
		<script type="text/javascript">
			jQuery( document ).ready( function ( $ ) {
				jQuery( '#commentform' ).validate( {
					rules: {
						author: {
							required: true,
						},
						email: {
							required: true,
							email: true
						},
						comment: {
							required: true,
						}
					},
					messages: {
						author: "Please fill the required field",
						email: "Please enter a valid email address.",
						comment: "Please fill the required field"
					},
					errorElement: "div",
					errorPlacement: function ( error, element ) {
						element.after( error );
					}

				} );
			} );
		</script>
		<?php
	}
}

add_action( 'wp_footer', 'comment_validation_init' );

/**
 * Register a custom post type called "Question".
 */
function nstxl_question_init() {
	$labels = array(
			'name'							 => _x( 'Question', 'Post type general name', 'onepress' ),
			'singular_name'			 => _x( 'Question', 'Post type singular name', 'onepress' ),
			'menu_name'					 => _x( 'Questions', 'Admin Menu text', 'onepress' ),
			'name_admin_bar'		 => _x( 'Question', 'Add New on Toolbar', 'onepress' ),
			'add_new'						 => __( 'Add New', 'onepress' ),
			'add_new_item'			 => __( 'Add New Question', 'onepress' ),
			'new_item'					 => __( 'New Question', 'onepress' ),
			'edit_item'					 => __( 'Edit Question', 'onepress' ),
			'view_item'					 => __( 'View Question', 'onepress' ),
			'all_items'					 => __( 'All Questions', 'onepress' ),
			'search_items'			 => __( 'Search Questions', 'onepress' ),
			'parent_item_colon'	 => __( 'Parent Question:', 'onepress' ),
			'not_found'					 => __( 'No Question found.', 'onepress' ),
			'not_found_in_trash' => __( 'No Question found in Trash.', 'onepress' ),
	);

	$args = array(
			'labels'						 => $labels,
			'public'						 => true,
			'publicly_queryable' => false,
			'show_ui'						 => true,
			'show_in_menu'			 => true,
			'exclude_from_search' => true,
			'query_var'					 => true,
			'rewrite'						 => array( 'slug' => 'nstxl-question' ),
			'capability_type'		 => 'post',
			'capabilities'			 => array(
					'create_posts' => 'do_not_allow', // Removes support for the "Add New" function, including Super Admin's
			),
			'map_meta_cap'			 => true,
			'has_archive'				 => false,
			'taxonomies'				 => array( 'nstxl-question-type' ),
			'menu_position'			 => null,
			'supports'					 => array( 'title', 'editor', 'author', 'thumbnail' ),
	);

	register_post_type( 'nstxl-question', $args );

	register_taxonomy( 'nstxl-question-type', 'nstxl-question', array(
			'label'				 => __( 'Categories', 'onepress' ),
			'rewrite'			 => array( 'slug' => 'nstxl-question-type' ),
			'hierarchical' => true,
	) );
}

add_action( 'init', 'nstxl_question_init' );

/**
 * Submit "Question" Ajax.
 */
function nstxl_submit_question() {
	global $current_user;
	$val			 = $_POST;
	$result		 = array();
	$getposts	 = $val[ 'question_title' ];
	// print_r($getposts);
	// die();
	if ( ! empty( $val ) ) {

		if ( isset( $val[ 'user_name_que' ] ) && ! empty( $val[ 'user_name_que' ] ) ) {
			$user_name_que = stripslashes_deep( $val[ 'user_name_que' ] );
		}

		if ( isset( $val[ 'user_email_que' ] ) && ! empty( $val[ 'user_email_que' ] ) ) {
			$user_email_que = stripslashes_deep( $val[ 'user_email_que' ] );
		}

		if ( isset( $val[ 'user_company_que' ] ) && ! empty( $val[ 'user_company_que' ] ) ) {
			$user_company_que = stripslashes_deep( $val[ 'user_company_que' ] );
		}
		if ( isset( $val[ 'queid' ] ) && ! empty( $val[ 'queid' ] ) ) {
			$user_que = stripslashes_deep( $val[ 'queid' ] );
		}

		if ( isset( $val[ 'question_title' ] ) && ! empty( $val[ 'question_title' ] ) ) {

			if ( ! empty( $getposts ) ) {
				foreach ( $getposts as $quevalue ) {
					$post = array(
							'post_title'			 => stripslashes_deep( $quevalue ),
							'nstxl_user_name'	 => $_POST[ 'user_name_que' ],
							'post_status'			 => 'publish', // Could be: publish
							'post_type'				 => 'nstxl-question' // Could be: `page` or your CPT
					);

					$pid = wp_insert_post( $post );

					update_post_meta( $pid, 'nstxl_user_name', $val[ 'user_name_que' ], true );
					update_post_meta( $pid, 'nstxl_user_email', $val[ 'user_email_que' ], true );
					update_post_meta( $pid, 'nstxl_user_company', $val[ 'user_company_que' ], true );
					update_post_meta( $pid, 'nstxl_answer_import', '0', true );
					update_post_meta( $pid, 'question_post_id', $val[ 'queid' ], true );
					update_post_meta( $pid, 'nstxl_que_opportunity_name', get_the_title( $val[ 'queid' ] ), true );
				}
			}
		}

		$quedeadline = get_field( 'nstxl_question_deadline', $val[ 'queid' ] );

		echo 'Saved your question successfully!';

		if ( isset( $_POST[ 'user_email_que' ] ) && ! empty( $_POST[ 'user_email_que' ] ) ) {
			$to	 = 'vikesh.tokhare@galaxyweblinks.in';
			$to1 = $_POST[ 'user_email_que' ];

			$subject	 = 'New question has been submitted to "' . get_the_title( $val[ 'queid' ] ) . '"';
			$subject1	 = 'Your question has been submitted successfully.';

			$mge1 = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
						<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
			<tr>
			<td>
			<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
			<tr>
			<td style=" text-align: center; color: #fff;">
			<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">New question has been submitted to "' . get_the_title( $val[ 'queid' ] ) . '"</p>
			</td></tr>
			</table>
			</td>
			</tr>
			</thead><tbody >
			<tr>
			<td>
			<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
			<tr>
			<td>';

			$mge2 = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
								<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
					<tr>
					<td>
					<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
					<tr>
					<td style=" text-align: center; color: #fff;">
					<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Your question has been submitted successfully.</p>
					</td></tr>
					</table>
					</td>
					</tr>
					</thead><tbody >
					<tr>
					<td>
					<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
					<tr>
					<td>';

			$newMsg	 = '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Thank you for submitting a question to regarding "' . get_the_title( $val[ 'queid' ] ) . '" Project. We will submit your question to the government for review.  After they have released responses, NSTXL email you the answer to your question and post all Q&A on the website.</p><p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p></td></tr></tbody>
							<tfoot style=" background-color: #545454;">
								<tr><td style=""><p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p></td></tr>
							</tfoot>
						</table>';
			$ico		 = 1;
			if ( ! empty( $getposts ) ) {
				foreach ( $getposts as $newque ) {
					$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Question ' . $ico . ': ' . $newque . '</p>';
					$ico ++;
				}
			}
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Name : ' . $_POST[ 'user_name_que' ] . '</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Email : ' . $_POST[ 'user_email_que' ] . '</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Company : ' . $_POST[ 'user_company_que' ] . '</p>';

			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
			$message .= '</td></tr></table></td></tr></tbody><tfoot><tr><td>
					<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
					<tr>
					<td>
					<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
					</td>
					</tr>
					</table>
					</td>
					</tr>
					</tfoot>
					</table>';


			$headers							 = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";
			$confirmation_headers .= "Bcc:vivek.jha@galaxyweblinks.in";

			if ( $to == 'vikesh.tokhare@galaxyweblinks.in' ) {
				$mge1 .= $message;
				$mail = wp_mail( $to, $subject, $mge1, $confirmation_headers );
			}
			if ( $to1 == $_POST[ 'user_email_que' ] ) {
				$mge2 .= $newMsg;
				$mail = wp_mail( $to1, $subject1, $mge2, $confirmation_headers );
			}

			if ( $mail ) {
				$success = 'Check your new question';
			} else {
				$error = 'Oops something went wrong updaing your account.';
			}
		}
	} else {
		$result[ "response" ]	 = "error";
		$result[ "msg" ]			 = "Submited data is empty";
	}
	wp_send_json_success( $result );
}

add_action( 'wp_ajax_nstxl_submit_question', 'nstxl_submit_question' );
add_action( "wp_ajax_nopriv_nstxl_submit_question", "nstxl_submit_question" );

/**
 * Add Import and Export button in custom post "Question".
 */
add_action( 'restrict_manage_posts', 'add_export_button' );

function add_export_button() {
	global $current_screen;
	$screen = get_current_screen();

	if ( isset( $screen->parent_file ) && ('edit.php?post_type=nstxl-question' == $screen->parent_file) ) {
		if ( 'nstxl-question' == $current_screen->post_type ) {
			?>
			<input type="submit" name="export_all_question" id="export_all_question" class="button button-primary" value="Export Questions">
			<a id="import_all_question" class="button button-primary" href= "<?php echo get_admin_url(); ?>/edit.php?post_type=nstxl-question&page=import-question">Import Answers</a>

			<script type="text/javascript">
				jQuery( function ( $ ) {
					$( '#export_all_question' ).insertAfter( '#post-query-submit' );
					$( '#import_all_question' ).insertAfter( '#export_all_question' );
				} );
			</script>
			<style>
				#myquestionfile {
					display:none;
				}
				#export_all_question {
					margin-right: 5px;
				}
				#import_all_question {
					float: right;
					margin-top: 0px;
				}
			</style>
			<?php
		}
	}
}

/* Export notice error */

function export_allquestion_notice() {
	?>
	<div class="notice notice-success is-dismissible">
		<p><?php _e( 'All questions have answer.', 'onepress' ); ?></p>
	</div>
	<?php
}

/**
 * Export "Question".
 */
add_action( 'init', 'func_export_all_question' );

function func_export_all_question() {
	if ( isset( $_GET[ 'export_all_question' ] ) ) {
		$arg			 = array(
				'post_type'			 => 'nstxl-question',
				'post_status'		 => 'publish',
				'posts_per_page' => -1,
				'meta_query'		 => array(
						array(
								'key'		 => 'nstxl_answer_import',
								'value'	 => 0,
						),
				)
		);
		global $post;
		$arr_post	 = get_posts( $arg );
		if ( $arr_post ) {

			$file = fopen( 'php://output', 'w' );

			header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
			header( 'Content-type: text/csv' );
			header( 'Content-Disposition: attachment; filename="question.csv"' );
			header( 'Pragma: no-cache' );
			header( 'Expires: 0' );

			fputcsv( $file, array( 'Opportunity ID', 'Opportunity Name', 'Question ID', 'Question', 'Answer' ) );

			foreach ( $arr_post as $post ) {
				setup_postdata( $post );
				$getoppid = get_field( 'question_post_id', $post );
				fputcsv( $file, array( $getoppid, get_the_title( $getoppid ), get_the_ID(), get_the_title(), '' ) );
			}
			exit();
		} else {
			add_action( 'admin_notices', 'export_allquestion_notice' );
		}
	}
}

/**
 * Register submenu import "Question"
 */
function import_question_settings_submenu_page() {
	add_submenu_page( 'edit.php?post_type=nstxl-question', 'Import  Answers', 'Import Answers', "manage_options", 'import-question', 'import_question_settings', '' );
}

add_action( 'admin_menu', 'import_question_settings_submenu_page' );

/**
 * Import "Question".
 */
function import_question_settings() {
	global $wpdb;
	if ( isset( $_POST[ "upfile" ] ) ) {

		$filename_temp = $_FILES[ "uploaded" ][ "tmp_name" ];
		$ext					 = pathinfo( $_FILES[ "uploaded" ][ "name" ], PATHINFO_EXTENSION );
		if ( $ext == 'csv' ) {
			$f_name = basename( $_FILES[ "uploaded" ][ "name" ], "." . $ext );
			if ( $_FILES[ "uploaded" ][ "size" ] > 0 ) {
				$file			 = fopen( $filename_temp, "r" );
				$firstline = true;
				while ( ($data			 = fgetcsv( $file, 10000, "," )) !== FALSE ) {
					if ( array_filter( $data ) ) {
						if ( $firstline ) {
							$firstline = false;
							continue;
						}
						$postid = $data[ '2' ];

						$useremail = get_field( 'nstxl_user_email', $data[ '2' ] );
						$username	 = get_field( 'nstxl_user_name', $data[ '2' ] );

						if ( ! empty( $data[ '4' ] ) ) {
							update_post_meta( $postid, 'nstxl_opportunity_answer', $data[ '4' ] );
							update_post_meta( $postid, 'nstxl_answer_import', '1' );
							if ( isset( $useremail ) && ! empty( $useremail ) ) {
								$to			 = $useremail;
								$subject = 'Your question has been answered.';

								$message = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
																			<tr><td style="padding: 25px 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
																<tr>
																<td>
																<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
																<tr>
																<td style=" text-align: center; color: #fff;">
																<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Your question has been answered.</p>
																</td></tr>
																</table>
																</td>
																</tr>
																</thead><tbody >
																<tr>
																<td>
																<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
																<tr>
																<td>';
								$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello ' . $username . ',</p>';
								$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Answer has been added for your question. Please visit the site to check the answer of your question.</p>';
								$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;"><a href="' . get_the_permalink( $data[ '0' ] ) . '">To view the answer click here</a></p>';
								$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
								$message .= '</td></tr></table></td></tr></tbody><tfoot><tr><td>
										<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
										<tr>
										<td>
										<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
										</td>
										</tr>
										</table>
										</td>
										</tr>
										</tfoot>
										</table>';

								$headers							 = 'MIME-Version: 1.0' . "\r\n";
								$headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
								$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";

								$mail = wp_mail( $to, $subject, $message, $confirmation_headers );

								if ( $mail ) {
									$success = 'Check your email address.';
								} else {
									$error = 'Oops something went wrong updaing your account.';
								}
							}
						}
					}
				}

				fclose( $file );
			}
			echo '<h3>Answers imported successfully.</h3>';
		} else {
			echo '<h1>You Must Upload Only CSV with .CSV Extension</h1>';
		}
	}
	?>
	<div class="wrap">
		<form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER[ 'REQUEST_URI' ]; ?>">
			<table class="form-table">
				<h3>Import Answers</h3>
				File:<input name="uploaded" type="file" id="csvfile"/>
				<input type="submit" style="background: #d2232a !important;color: #fff !important;padding: 5px;font-size: 17px;border: #d2232a 1px solid;border-radius: 5px !important;" name="upfile" value="Upload File">
				</form>
			</table>
	</div>
	<?php
}

/* Save metabox question */

add_action( 'save_post', 'save_post_callback' );

function save_post_callback( $post_id ) {
	//global $post; 
	$nstxl_answer	 = get_post_meta( $post_id, 'nstxl_opportunity_answer', true );
	$post_type		 = get_post_type( $post_id );
	if ( $post_type == 'nstxl-question' ) {
		if ( isset( $nstxl_answer ) && ! empty( $nstxl_answer ) ) {
			update_post_meta( $post_id, 'nstxl_opportunity_answer', $nstxl_answer );
			update_post_meta( $post_id, 'nstxl_answer_import', '1' );
		} else {
			update_post_meta( $post_id, 'nstxl_answer_import', '0' );
		}
	}
	//if you get here then it's your post type so do your thing....
}

/* Added Extra column in questions */
add_filter( 'manage_edit-nstxl-question_columns', 'my_edit_question_columns' );

function my_edit_question_columns( $columns ) {

	$columns[ 'cb' ]							 = '<input type="checkbox" />';
	$columns[ 'opportunity_name' ] = __( 'Opportunity Name' );
	$columns[ 'opportunity_ids' ]	 = __( 'Opportunity IDs' );
	$columns[ 'title' ]						 = _x( 'Questions', 'onepress' );
	$columns[ 'author' ]					 = __( 'Author' );
	$columns[ 'date' ]						 = _x( 'Date', 'onepress' );
	unset( $columns[ 'views' ] );
	return $columns;
}

add_action( 'manage_nstxl-question_posts_custom_column', 'manage_question_columns', 10, 2 );

function manage_question_columns( $column_name, $id ) {
	global $wpdb;
	switch ( $column_name ) {
		case 'opportunity_name':
			$getoppids = get_post_meta( $id, 'question_post_id', true );
			echo get_the_title( $getoppids );
			break;
		case 'opportunity_ids':
			echo get_post_meta( $id, 'question_post_id', true );
			break;
		default:
			break;
	} // end switch
}

add_filter( 'manage_edit-nstxl-question_sortable_columns', 'my_movie_sortable_columns' );

function my_movie_sortable_columns( $columns ) {

	$columns[ 'opportunity_name' ] = 'opportunity_name';
	$columns[ 'opportunity_ids' ]	 = 'opportunity_ids';
	return $columns;
}

/* Loader filter */

add_action( 'wp_head', 'add_loader_gif' );

function add_loader_gif() {

	echo '<script type="text/javascript" src="https://addevent.com/libs/atc/1.6.1/atc.min.js" async defer></script>';

	echo '<style>
	.ajax-loader.is-active {
  display: inline-block !important;
}
  	.wpcf7 .ajax-loader{
  		background-image: url(' . get_stylesheet_directory_uri() . '/assets/images/Preloader_10.gif) !important;
    display: none;
    width: 50px !important;
		height: 50px !important;
		border: none !important;
		padding: 0 !important;
		margin: 12px 0 0 18px !important;
		vertical-align: middle !important;
		background-repeat: no-repeat !important;
		background-size: 28px !important;
		background-position: 0px 2px;
  		}
  		.ask-to-nstxl .contact-form-field select, .contact-with-us .contact-form-field select {
    background-repeat: no-repeat !important;
    background-image: url(' . site_url() . '/wp-content/plugins/nstxl-memberhip-extension/images/arrow-down.png) !important;
    background-position: 100% !important;
}
.objectfit img{
      object-fit: cover;
      height: 1013px !important;
}
.objectfit-small{
  object-fit: cover;
      height: 506px !important;
}
  	</style>';

} 

/**
 * hook the posts search if we're on the admin page for our type
 */
function admin_init_example_type() {
	global $typenow;

	if ( $typenow === 'nstxl-question' ) {
		add_filter( 'posts_search', 'posts_search_example_type', 10, 2 );
	}
}

/**
 * add query condition for custom meta
 * @param string $search the search string so far
 * @param WP_Query $query
 * @return string
 */
function posts_search_example_type( $search, $query ) {
	global $wpdb;

	if ( $query->is_main_query() && ! empty( $query->query[ 's' ] ) ) {
		$sql		 = "
		or exists (
		select * from {$wpdb->postmeta} where post_id={$wpdb->posts}.ID
		and meta_key in ('question_post_id','nstxl_que_opportunity_name')
		and meta_value like %s
		)
		";
		$like		 = '%' . $wpdb->esc_like( $query->query[ 's' ] ) . '%';
		$search	 = preg_replace( "#\({$wpdb->posts}.post_title LIKE [^)]+\)\K#", $wpdb->prepare( $sql, $like ), $search );
	}

	return $search;
}

//* Password reset activation E-mail -> Body
add_filter( 'retrieve_password_message', 'tml_reset_pass_msg', 10, 2 );

function tml_reset_pass_msg( $message, $key ) {
	$user_data = '';
	// If no value is posted, return false
	if ( ! isset( $_POST[ 'user_login' ] ) ) {
		return '';
	}
	// Fetch user information from user_login
	if ( strpos( $_POST[ 'user_login' ], '@' ) ) {

		$user_data = get_user_by( 'email', trim( $_POST[ 'user_login' ] ) );
	} else {
		$login		 = trim( $_POST[ 'user_login' ] );
		$user_data = get_user_by( 'login', $login );
	}
	if ( ! $user_data ) {
		return '';
	}
	$user_login	 = $user_data->user_login;
	$user_email	 = $user_data->user_email;
	$firstname	 = $user_data->first_name;
	$lastname		 = $user_data->last_name;
	$fullname		 = $firstname . ' ' . $lastname;
	// Setting up message for retrieve password

	$message = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center">
	<thead width="100%">
		<tr>
		   <td width="100%" style="padding: 25px 0 0;text-align: center;"><a>
		   <img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer">
		   </a>
		   </td>
		 </tr>
		<tr>
		   <td style="width: 100% !important;">
		    <table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
			  <tr>
			    <td width="100% !important" style=" text-align: center; color: #fff;">
			      <p  style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Password Reset</p>
				 </td>
		      </tr>
			 </table>
			</td>
		</tr>
	</thead>
	<tbody >
		<tr>
			<td >
			<table style="width: 100%; padding: 0 25px 25px 25px;" cellpadding="0" align="left">
				<tr>
					<td>';
	$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Someone has requested a password reset for the following account:</p>';

	$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Site Name: NSTXL</p>';

	$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Username: ' . ucwords( $fullname ) . '</p>';

	$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">If this was a mistake, just ignore this email and nothing will happen.</p>';

	$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">To reset your password, Please click <a href="' . network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' ) . '">here</a>.</p>';
	$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Sincerely,<br>Team NSTXL</p>
					</td>
				</tr>
			</table>

			</td>
		</tr>
	</tbody>
	<tfoot>
		<tr>
		<td>
	<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
		<tr>
			<td>
			<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
			</td>
		</tr>
		</table>
		</td>
		</tr>
	</tfoot>
</table>';
	// Return completed message for retrieve password
	return $message;
}

/* Filter for wordpress default admin */

add_filter( 'password_change_email', 'wpse207879_change_password_mail_message', 10, 3 );

function wpse207879_change_password_mail_message(
 $pass_change_mail, $user, $userdata
 ) {

	$new_message_txt = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
						<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
			<tr>
			<td>
			<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
			<tr>
			<td style=" text-align: center; color: #fff;">
			<p style="width: 100% !important; margin:0 ;text-align: center; font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Notice of Password Change</p>
			</td></tr>
			</table>
			</td>
			</tr>
			</thead><tbody >
			<tr>
			<td>
			<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
			<tr>
			<td>';
	$new_message_txt .= '<p style="font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:22px;padding:0 25px;margin-top:20px;text-transform: capitalize;">Hi ' . $userdata[ 'first_name' ] . ',</p>';

	$new_message_txt .= '<p style="font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:22px;padding:0 25px;margin-top:20px;">This notice confirms that your password was changed on ###SITENAME###.</p>';

	$new_message_txt .= '<p style="font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:22px;padding:0 25px;margin-top:20px;">If you did not change your password, please contact the Site Administrator at</br>###ADMIN_EMAIL###</p>';

	$new_message_txt .= '<p style="font-family:Helvetica,Arial,sans-serif;font-size:14px;line-height:22px;padding:0 25px;margin-top:20px;">This email has been sent to ###EMAIL###</p>';

	$new_message_txt .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Regards,<br>All at NSTXL</br>###SITEURL###</p>
			</td></tr></table></td></tr></tbody><tfoot><tr><td>
		<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
		<tr>
		<td>
		<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
		</td>
		</tr>
		</table>
		</td>
		</tr>
		</tfoot>
		</table>';
	$pass_change_mail[ 'message' ] = $new_message_txt;

	return $pass_change_mail;
}

/* function to get status of expired users */

function nstxl_get_membership_status_expired_user( $user_id ) {
	global $wpdb;
	$expiredusers = $wpdb->get_results( "SELECT enddate, status, membership_id FROM " . $wpdb->prefix . "pmpro_memberships_users WHERE user_id = '" . $user_id . "' LIMIT 1" );
	if ( ! empty( $expiredusers ) ) {
		return $expiredusers;
	}
}

add_filter( "pmpro_send_expiration_warning_email", "__return_false" );


/* Added menu for company list */

add_action( 'admin_menu', 'company_list_menu' );

function company_list_menu() {
	add_menu_page( 'Companies List', 'Companies List', 'edit_posts', 'companies_list', 'companies_list_function', 'dashicons-media-spreadsheet', 29 );
}

/* Company list data */

function companies_list_function() {
	echo '<h2>' . _e( 'Companies List', 'paid-memberships-pro' ) . '</h2>';

	global $wpdb;
	if ( isset( $_REQUEST[ 'cl' ] ) )
		$s	 = sanitize_text_field( trim( $_REQUEST[ 'cl' ] ) );
	else
		$s	 = "";
	?>
	<form id="companies-list-form" method="get" action="">
		<p class="search-box">
			<label class="hidden" for="post-search-input"><?php _e( 'Search Members', 'paid-memberships-pro' ); ?>:</label>
			<input type="hidden" name="page" value="companies_list" />
			<input id="post-search-input" type="text" value="<?php echo esc_attr( $s ); ?>" name="cl"/>
			<input class="button" type="submit" value="<?php _e( 'Search Members', 'paid-memberships-pro' ); ?>"/>
		</p>
		<?php
		//some vars for the search
		if ( isset( $_REQUEST[ 'pn' ] ) )
			$pn	 = intval( $_REQUEST[ 'pn' ] );
		else
			$pn	 = 1;

		if ( isset( $_REQUEST[ 'limit' ] ) )
			$limit = intval( $_REQUEST[ 'limit' ] );
		else {
			/**
			 * Filter to set the default number of items to show per page
			 * on the Members List page in the admin.
			 *
			 * @since 1.8.4.5
			 *
			 * @param int $limit The number of items to show per page.
			 */
			$limit = apply_filters( 'pmpro_memberslist_per_page', 15 );
		}

		$end	 = $pn * $limit;
		$start = $end - $limit;

		if ( $s ) {
			$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email, UNIX_TIMESTAMP(u.user_registered) as joindate, mu.membership_id, mu.initial_payment, mu.billing_amount, mu.cycle_period, mu.cycle_number, mu.billing_limit, mu.trial_amount, mu.trial_limit, UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership FROM $wpdb->users u LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->usermeta um1 ON u.ID = um1.user_id LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id ";

			if ( $l == "oldmembers" || $l == "expired" || $l == "cancelled" )
				$sqlQuery .= " LEFT JOIN $wpdb->pmpro_memberships_users mu2 ON u.ID = mu2.user_id AND mu2.status = 'active' ";

			$sqlQuery .= " WHERE mu.membership_id > 0 AND (u.user_login LIKE '%" . esc_sql( $s ) . "%' OR u.user_email LIKE '%" . esc_sql( $s ) . "%' OR um.meta_value LIKE '%" . esc_sql( $s ) . "%' OR u.display_name LIKE '%" . esc_sql( $s ) . "%') ";

			$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%administrator%') ";

			$sqlQuery .= " AND mu.status = 'active' ";

			$sqlQuery .= "GROUP BY u.ID ";

			$sqlQuery .= "ORDER BY u.user_registered DESC ";

			$sqlQuery .= "LIMIT $start, $limit";
		}
		else {
			$sqlQuery = "SELECT SQL_CALC_FOUND_ROWS u.ID, u.user_login, u.user_email, UNIX_TIMESTAMP(u.user_registered) as joindate, mu.membership_id, mu.initial_payment, mu.billing_amount, mu.cycle_period, mu.cycle_number, mu.billing_limit, mu.trial_amount, mu.trial_limit, UNIX_TIMESTAMP(mu.startdate) as startdate, UNIX_TIMESTAMP(mu.enddate) as enddate, m.name as membership FROM $wpdb->users u LEFT JOIN $wpdb->usermeta um ON u.ID = um.user_id LEFT JOIN $wpdb->pmpro_memberships_users mu ON u.ID = mu.user_id LEFT JOIN $wpdb->pmpro_membership_levels m ON mu.membership_id = m.id";

			$sqlQuery .= " WHERE mu.membership_id > 0  ";
			$sqlQuery .= " AND (um.meta_key = 'nstxl_capabilities' AND um.meta_value NOT LIKE '%administrator%') ";
			$sqlQuery .= " AND mu.status = 'active' ";
			$sqlQuery .= "GROUP BY u.ID ";
			$sqlQuery .= "ORDER BY u.user_registered DESC ";

			$sqlQuery .= "LIMIT $start, $limit";
		}

		$sqlQuery = apply_filters( "pmpro_members_list_sql", $sqlQuery );

		$theusers	 = $wpdb->get_results( $sqlQuery );
		$totalrows = $wpdb->get_var( "SELECT FOUND_ROWS() as found_rows" );
		if ( $theusers ) {
			$calculate_revenue = apply_filters( "pmpro_memberslist_calculate_revenue", false );
			if ( $calculate_revenue ) {
				$initial_payments		 = pmpro_calculateInitialPaymentRevenue( $s, $l );
				$recurring_payments	 = pmpro_calculateRecurringRevenue( $s, $l );
				?>
				<p class="clear"><?php echo strval( $totalrows ) ?> members found. These members have paid <strong>$<?php echo number_format( $initial_payments ) ?> in initial payments</strong> and will generate an estimated <strong>$<?php echo number_format( $recurring_payments ) ?> in revenue over the next year</strong>, or <strong>$<?php echo number_format( $recurring_payments / 12 ) ?>/month</strong>. <span class="pmpro_lite">(This estimate does not take into account trial periods or billing limits.)</span></p>
				<?php
			} else {
				?>
				<p class="clear"><?php printf( __( "%d members found.", 'paid-memberships-pro' ), $totalrows ); ?></span></p>
				<?php
			}
		}
		?>
		<table class="widefat">
			<thead>
				<tr class="thead">
					<th><?php _e( 'ID', 'paid-memberships-pro' ); ?></th>
					<th><?php _e( 'POC User Name', 'paid-memberships-pro' ); ?></th>
					<th><?php _e( 'Company Name', 'paid-memberships-pro' ); ?></th>
					<th><?php _e( 'POC Email', 'paid-memberships-pro' ); ?></th>
					<th><?php _e( 'Expiration Date', 'paid-memberships-pro' ); ?></th>
					<th><?php _e( 'Action', 'paid-memberships-pro' ); ?></th>
				</tr>
			</thead>
			<tbody id="users" class="list:user user-list">
				<?php
				$count = 0;

				foreach ( $theusers as $auser ) {
					$auser	 = apply_filters( "pmpro_members_list_user", $auser );
					//get meta
					$theuser = get_userdata( $auser->ID );

					$puid = nstxl_get_parent_userid( $auser->ID );
					if ( ! empty( $puid ) ) {
						$cur_id = $puid;
					} else {
						$cur_id = $auser->ID;
					}
					$poc_user_id = get_user_meta( $cur_id, "poc", true );

					if ( ! empty( $poc_user_id ) ) {

						$poc_name			 = get_userdata( $poc_user_id );
						$poc_fullname	 = $poc_name->first_name . ' ' . $poc_name->last_name;
						$poc_email		 = $poc_name->user_email;
						$users_roles	 = $theuser->roles;
						?>
						<tr <?php if ( $count ++ % 2 == 0 ) { ?>class="alternate"<?php } ?>>
							<td><?php echo esc_html( $theuser->ID ); ?></td>
							<td><?php echo esc_html( $poc_fullname ); ?></td>
							<td><?php echo esc_html( $theuser->company_name ); ?></td>
							<td><?php echo esc_html( $poc_email ); ?></td>
							<td>
								<?php
								if ( $auser->enddate )
									echo apply_filters( "pmpro_memberslist_expires_column", date_i18n( get_option( 'date_format' ), $auser->enddate ), $auser );
								else
									echo __( apply_filters( "pmpro_memberslist_expires_column", "Never", $auser ), "pmpro" );
								?>
							</td>
							<td>
								<?php
								if ( in_array( 'deleted_member', $users_roles, true ) ) {
									?>
									<a style="color:red"  class="addinaluser-rejected-button" data-index="<?php echo esc_html( $theuser->ID ); ?>"><?php _e( 'Rejected Company', 'paid-memberships-pro' ); ?></a>
									<?php
									//echo User is a administrator';
								} else {
									?>
									<a style="color:green" class="addinaluser-modal-button" data-index="<?php echo esc_html( $theuser->ID ); ?>"><?php _e( 'Reject Company', 'paid-memberships-pro' ); ?></a>
									<?php
								}
								?>
							</td>
						</tr>
					<input type="hidden" class="mainid" value="<?php echo esc_html( $theuser->ID ); ?>">
					<?php
				}
				if ( ! $theusers ) {
					?>
					<tr>
						<td colspan="9"><p><?php _e( "No members found.", 'paid-memberships-pro' ); ?> <?php if ( $l ) { ?><a href="?page=companies_list&cl=<?php echo esc_attr( $s ); ?>"><?php _e( "Search all levels", 'paid-memberships-pro' ); ?></a>.<?php } ?></p></td>
					</tr>
					<?php
				}
			}
			?>
			</tbody>
		</table>
	</form>
	<script type="text/javascript" >
		jQuery( document ).ready( function () {
			jQuery( '.addinaluser-modal-button' ).click( function ( e ) {
				var idmain = jQuery( this ).attr( "data-index" );
				jQuery.ajax( {
					url: nstxl_ajaxurl, //Here you will fetch records      
					type: 'post',
					data: {
						action: "member_user_data_ajax",
						id_main: idmain,
					},
					success: function ( result ) {
						jQuery( '.companylist-box-success-container' ).html( result );

						jQuery( '#addinaluser-modal-success' ).modal( 'show' ); //Show fetched data from database
					}
				} );
			} );
		} );
	</script>
	<style type="text/css">
		.addinaluser-modal-button {
			background-color: #0073aa;
			color: #fff !important;
			padding: 5px;
			border-radius: 5px;
			cursor: pointer;
			display: block;
			width: 120px;
			text-align: center;
		}
		.addinaluser-rejected-button {
			background-color: #dc323e;
			color: #fff !important;
			padding: 5px;
			border-radius: 5px;
			display: block;
			width: 120px;
		}
		#addinaluser-modal-success{
			z-index:9999;
		}
		body.modal-open {
			overflow: hidden;
			z-index: -1;
		}
		#addinaluser-modal-success .modal-dialog {
			transform: translateY(-50%);
			top: 50%;
			width: 100%;
			margin: 0 auto;
			max-width: 700px;
			font-family: 'Montserrat', sans-serif !important;
		}

		input.disabled, input:disabled, select.disabled, select:disabled, textarea.disabled, textarea:disabled {
			background: rgba(255,255,255,.5);
			border-color: transparent;
			box-shadow: none;
			color: rgba(51,51,51,.5);
		}
		#addinaluser-modal-success {
			padding-left: 15px;
		}

		#addinaluser-modal-success  .modal-dialog h2{

			font-size: 28px;
			margin-bottom: 40px;
		}


		#addinaluser-modal-success .modal-dialog p {
			margin-bottom: 0;
		}

		#addinaluser-modal-success button.close {
			-webkit-appearance: none !important;
			padding: 0px 0 0 0;
			cursor: pointer;
			color: #fff;
			background-color: #d22329;
			width: 32px;
			height: 32px;
			font-weight: 300;
			font-size: 41px;
			line-height: 0 !important;
			opacity: 0.8;
			text-shadow: none;
			display: inline-block;
			vertical-align: top;
			border: none;
			float: right;
			position: relative;
			right: -45px;
			border-radius: 50%;
			top: -45px;
			background-image: url(../../wp-content/themes/polar-child/assets/images/close.png);
			background-size: 17px;
			background-repeat: no-repeat;
			background-position: 8px 8px;
		}


		#addinaluser-modal-success .modal-content{
			border: none;
		}
		#addinaluser-modal-success .poc_radio{
			border: 1.5px solid #333 !important;
			-webkit-appearance: none;
			-moz-appearance: none;
			appearance: none;
			width: 17px !important;
			height: 17px;
			border-radius: 3px;
			border-radius: 50% !important;
			padding: 0 !important;
			position:relative;

		}

		#addinaluser-modal-success .poc_radio input[type="radio"]:checked::before {
			content: "\2022";
			text-indent: -9997px;
			border-radius: 50px;
			font-size: 24px;
			width: 9px;
			height: 9px;
			margin: 4px;
			line-height: 16px;
			background-color: #333;
			opacity: 1 !important;
			top: -1px !important;
			left: -1px !important;
			position: absolute;
		}
		#addinaluser-modal-success .widefat td{
			font-weight: 300;
		}
		#addinaluser-modal-success table.widefat {
			margin-bottom: 20px;

		}
		#addinaluser-modal-success .modal-body{
			padding: 30px 30px
		}

		#addinaluser-modal-success .change_confirm_role {
			float: right;
			width: auto;
			background-color: #0073aa !important;
			border: 1px solid #0073aa !important;
			color: #fff !important;
			font-weight: 400 !important;
			font-size: 16px !important;
			margin: 10px 0 0 !important;
			text-transform: uppercase !important;
			background-image: none !important;
			transition: all 0.2s;
			padding: 14px 20px !important;
			border-radius: 4px !important;
			display: inline-block;
			line-height: 16px !important;
			text-decoration: none !important;
			cursor: pointer;
		}
		#addinaluser-modal-success .change_confirm_role:hover{
			background-color: #e35e67 !important;
			color: #fff !important;
			border-color: #e35e67 !important;
		}
		#addinaluser-modal-success .change_Cancel_role {
			float: right;
			width: auto;
			background-color: #cccccc !important;
			border: 1px solid #cccccc !important;
			color: #666 !important;
			font-weight: 400 !important;
			font-size: 16px !important;
			margin: 10px 0 0 !important;
			margin-right: 0px;
			margin-right: 0px;
			text-transform: uppercase !important;
			background-image: none !important;
			transition: all 0.2s;
			padding: 14px 20px !important;
			border-radius: 4px !important;
			display: inline-block;
			line-height: 16px !important;
			text-decoration: none !important;
			margin-right: 15px !important;
			cursor: pointer;
		}
		#addinaluser-modal-success .change_Cancel_role:hover{
			background-color: #e35e67 !important;
			color: #fff !important;
			border-color: #e35e67 !important;
		}
		@media(max-width:360px){

			#addinaluser-modal-success .change_Cancel_role{
				margin-right:5px !important;
			}
			#addinaluser-modal-success .modal-body {
				padding: 30px 20px;
			}
			#addinaluser-modal-success .modal-dialog h2 {
				font-size: 24px;
			}
			#addinaluser-modal-success button.close{
				right: -35px;
			}
		}
	</style>
	<?php
	wp_register_script( 'nstxl-dashboard-bootstrap-js', get_stylesheet_directory_uri() . '/assets/js/bootstrap.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'nstxl-dashboard-bootstrap-js' );

	wp_register_style( 'nstxl-dashboard-bootstrap-css', get_stylesheet_directory_uri() . '/assets/css/bootstrap.min.css' );
	wp_enqueue_style( 'nstxl-dashboard-bootstrap-css' );
	?>

	<div id="addinaluser-modal-success" class="modal fade in" style=" padding-right: 10px;" tabindex="-1" role="dialog" aria-labelledby="organization-modalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-body">
					<p><button class="close clshide" type="button" data-dismiss="modal" aria-hidden="true"></button></p>
					<div class="companylist-box-success-container">
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
	echo pmpro_getPaginationString( $pn, $totalrows, $limit, 1, add_query_arg( array( "cl" => urlencode( $s ), "limit" => $limit ) ) );
}

/* Ajax data fetch in popup */

function member_user_data_ajax() {
	$companyuserid = $_POST[ 'id_main' ];
	$cmp_users_ids = get_user_meta( $companyuserid, 'company_users_ids', true );
	echo '<h2 class="adduserhead" style="text-align:center;">Additional Users</h2>';

	echo '<form><div class="table-responsive tblres"><table class="widefat"><thead>';
	echo '<th>POC User Name</th>';
	echo '<th>Company Name</th>';
	echo '<th>POC Email</th>';
	echo '<th>POC</th>';
	echo '</thead><tbody>';

	if ( isset( $cmp_users_ids ) && ! empty( $cmp_users_ids ) ) {
		foreach ( $cmp_users_ids as $cmp_user_id ) {
			$company_userdata	 = nstxl_company_additional_userdata( $cmp_user_id );
			$user_meta				 = get_userdata( $cmp_user_id );
			$user_role				 = $user_meta->roles;

			if ( in_array( 'subscriber', $user_role, true ) ) {
				echo '<input type="hidden" class="delete_sub" value="' . $company_userdata[ 'ID' ] . '">';
			} else {
				echo '<input type="hidden" id="delete_mem" value="' . $company_userdata[ 'ID' ] . '">';
			}
			echo '<tr><td>' . $company_userdata[ 'first_name' ] . ' ' . $company_userdata[ 'last_name' ] . '</td>';
			echo '<td>' . $company_userdata[ 'company_name' ] . '</td>';
			echo '<td>' . $company_userdata[ 'user_email' ] . '</td>';

			$puid = nstxl_get_parent_userid( $company_userdata[ 'ID' ] );
			if ( ! empty( $puid ) ) {
				$cur_id = $puid;
			} else {
				$cur_id = $companyuserid;
			}
			$poc_user_id = get_user_meta( $cur_id, "poc", true );


			if ( $company_userdata[ 'ID' ] == $poc_user_id ) {
				$poc_checked = 'yes';
			} else {
				$poc_checked = '';
			}
			?>
			<td><div class="poc_radio">
					<label><input readonly="" disabled="" <?php echo checked( $poc_checked, 'yes' ); ?> class="poc" value="yes" name="poc" type="radio"></label>
				</div></td></tr>
			<?php
		}
	} else {
		$puid = nstxl_get_parent_userid( $companyuserid );
		if ( ! empty( $puid ) ) {
			$cur_id = $puid;
		} else {
			$cur_id = $companyuserid;
		}
		$poc_user_id = get_user_meta( $cur_id, "poc", true );
		$poc_name		 = get_userdata( $poc_user_id );

		$user_role = $poc_name->roles;

		if ( in_array( 'subscriber', $user_role, true ) ) {
			echo '<input type="hidden" class="delete_sub" value="' . $poc_name->ID . '">';
		} else {
			echo '<input type="hidden" id="delete_mem" value="' . $poc_name->ID . '">';
		}

		$poc_fullname = $poc_name->first_name . ' ' . $poc_name->last_name;
		echo '<tr><td>' . $poc_fullname . '</td>';
		echo '<td>' . $poc_name->company_name . '</td>';
		echo '<td>' . $poc_name->user_email . '</td>';
		echo '<td><div class="poc_radio">
        <label><input readonly="" disabled="" class="poc" value="yes" checked="checked" name="poc" type="radio"></label>
      </div></td></tr>';
	}

	echo '</tbody></table></div>';
	echo '<a class="change_confirm_role">Confirm</a>';
	echo '<a class="change_Cancel_role" data-dismiss="modal" aria-hidden="true">Cancel</a>';
	'</form>';
	echo '<p class="updatemessage" style="display:none;color: green;text-align: center;font-size: 18px;padding-bottom: 30px;"> Member Rejected Successfully. </p>';
	?>
	<p style="text-align: center;">
		<button type="button" style="display: none;position: absolute;bottom: 15px;
						background: #0073aa;padding: 4px 23px 4px 23px;color: #fff !important;border:none;margin-left: -26px !important;cursor: pointer !important;" onClick="refreshPage()" class="com-modal-ok" aria-hidden="true">Ok</button>

		<script type="text/javascript" >
			jQuery( document ).ready( function () {
				jQuery( '.change_confirm_role' ).click( function ( e ) {

					var sub_id = [ ];
					jQuery( '.delete_sub' ).each( function () {
						sub_id.push( this.value );
					} );

					var mem_id = jQuery( '#delete_mem' ).val();

					jQuery.ajax( {
						url: nstxl_ajaxurl, //Here you will fetch records      
						type: 'post',
						data: {
							action: "member_user_role_update",
							sub_id_role: sub_id,
							mem_id_role: mem_id,
						},
						beforeSend: function () {
							jQuery( '.updatemessage' ).hide();
							jQuery( '.clshide' ).hide();
							jQuery( '.preloader' ).show();
						},
						success: function ( data ) {
							jQuery( '.updatemessage' ).show();
							jQuery( '.com-modal-ok' ).show();
							jQuery( '.clshide' ).show();
							jQuery( '.preloader' ).hide();
							jQuery( '.change_confirm_role' ).hide();
							jQuery( '.change_Cancel_role' ).hide();
							jQuery( '.adduserhead' ).hide();
							jQuery( '.tblres' ).hide();
						},
						complete: function () {
							jQuery( '.preloader' ).hide();
							jQuery( '.clshide' ).show();
							jQuery( '.change_confirm_role' ).hide();
							jQuery( '.change_Cancel_role' ).hide();
							jQuery( '.adduserhead' ).hide();
							jQuery( '.tblres' ).hide();
						},
					} );
				} );
			} );
		</script>
		<script>
			function refreshPage() {
				window.location.reload();
			}
		</script>
	<div class="preloader" style="display: none;">
		<div class="nst-ripple">
			<div class="nst-pos">

			</div>
		</div>
	</div>
	<style type="text/css">
		.preloader {
			width: 100%;
			height: 100%;
			top: 0px;
			position: fixed;
			z-index: 99999;
			background: #fff;
		}
		.nst-ripple {
			display: inline-block;
			position: relative;
			width: 150px;
			height: 150px;
			position: absolute;
			top: calc(50% - 100px);
			left: calc(50% - 100px);
		}
		.nst-ripple .nst-pos {
			position: absolute;
			opacity: 1;
			background: url(<?php echo site_url(); ?>/wp-content/themes/polar-child/assets/images/Preloader_10.gif) center no-repeat #fff !important;
			width: 150px;
			height: 150px;
		}
	</style>
	<?php
	die();
}

add_action( 'wp_ajax_nopriv_member_user_data_ajax', 'member_user_data_ajax' );
add_action( 'wp_ajax_member_user_data_ajax', 'member_user_data_ajax' );

/* User role update delete member and subscriber */

function member_user_role_update() {
	$subscriber	 = $_POST[ 'sub_id_role' ];
	$member			 = $_POST[ 'mem_id_role' ];

	$admin_email = get_option( 'admin_email' );

	if ( isset( $admin_email ) && ! empty( $admin_email ) ) {
		$to			 = $admin_email;
		$subject = 'Rejected members list';

		$message = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
																			<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
																<tr>
																<td>
																<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
																<tr>
																<td style=" text-align: center; color: #fff;">
																<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Rejected members list</p>
																</td></tr>
																</table>
																</td>
																</tr>
																</thead><tbody >
																<tr>
																<td>
																<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
																<tr>
																<td>';
		$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello NSTXL,</p>';

		$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Below is the rejected members list : </p>';

		$cmp_users_ids = get_user_meta( $member, 'company_users_ids', true );

		if ( isset( $cmp_users_ids ) && ! empty( $cmp_users_ids ) ) {
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;margin-bottom:20px;">';

			foreach ( $cmp_users_ids as $cmp_user_id ) {
				$company_userdata = nstxl_company_additional_userdata( $cmp_user_id );
				$message .= $company_userdata[ 'first_name' ] . ' ' . $company_userdata[ 'last_name' ];
				$message .= '</br>';
			}
			$message .= '</p>';
		}
		$message .= '</td></tr></table></td></tr></tbody><tfoot><tr><td>
									<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
									<tr>
									<td>
									<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
									</td>
									</tr>
									</table>
									</td>
									</tr>
									</tfoot>
									</table>';

		$headers							 = 'MIME-Version: 1.0' . "\r\n";
		$headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";

		$mail = wp_mail( $to, $subject, $message, $confirmation_headers );

		if ( $mail ) {
			$success = 'Check your email address for you new password.';
		} else {
			$error = 'Oops something went wrong updaing your account.';
		}
	}

	if ( isset( $subscriber ) && ! empty( $subscriber ) ) {
		foreach ( $subscriber as $subscribers ) {
			$u = new WP_User( $subscribers );
			// Remove role
			$u->remove_role( 'subscriber' );
			// Add role
			$u->add_role( 'deleted_subscriber' );

			$user_info = get_userdata( $subscribers );

			$user_email	 = $user_info->user_email;
			$user_name	 = $user_info->display_name;

			$sessions	 = WP_Session_Tokens::get_instance( $user_id	 = $subscribers );
			$sessions->destroy_all();

			if ( isset( $user_email ) && ! empty( $user_email ) ) {
				$to			 = $user_email;
				$subject = 'Account rejected by NSTXL';

				$message = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
																			<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
																<tr>
																<td>
																<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
																<tr>
																<td style=" text-align: center; color: #fff;">
																<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Account rejected by NSTXL</p>
																</td></tr>
																</table>
																</td>
																</tr>
																</thead><tbody >
																<tr>
																<td>
																<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
																<tr>
																<td>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello ' . ucwords( $user_name ) . ',</p>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Your account has deleted from NSTXL.</p>';
				$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
				$message .= '</td></tr></table></td></tr></tbody><tfoot><tr><td>
									<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
									<tr>
									<td>
								<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
									</td>
									</tr>
									</table>
									</td>
									</tr>
									</tfoot>
									</table>';

				$headers							 = 'MIME-Version: 1.0' . "\r\n";
				$headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";

				$mail = wp_mail( $to, $subject, $message, $confirmation_headers );

				if ( $mail ) {
					$success = 'Check your email address for you new password.';
				} else {
					$error = 'Oops something went wrong updaing your account.';
				}
			}
		}
	}

	if ( isset( $member ) && ! empty( $member ) ) {
		$member_meta	 = get_userdata( $member );
		$member_roles	 = $member_meta->roles;

		$u = new WP_User( $member );
		// // Remove role
		$u->remove_role( $member_roles[ 0 ] );
		// // Add role
		$u->add_role( 'deleted_member' );

		$user_info = get_userdata( $member );

		$user_email	 = $user_info->user_email;
		$user_name	 = $user_info->display_name;

		$sessions	 = WP_Session_Tokens::get_instance( $user_id	 = $member );
		$sessions->destroy_all();

		if ( isset( $user_email ) && ! empty( $user_email ) ) {
			$to			 = $user_email;
			$subject = 'Account rejected by NSTXL';

			$message							 = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
																			<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
																<tr>
																<td>
																<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
																<tr>
																<td style=" text-align: center; color: #fff;">
																<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Account rejected by NSTXL</p>
																</td></tr>
																</table>
																</td>
																</tr>
																</thead><tbody >
																<tr>
																<td>
																<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
																<tr>
																<td>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello ' . ucwords( $user_name ) . ',</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Your membership has rejected to NSTXL.</p>';
			$message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
			$message .= '</td></tr></table></td></tr></tbody><tfoot><tr><td>
									<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
									<tr>
									<td>
									<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
									</td>
									</tr>
									</table>
									</td>
									</tr>
									</tfoot>
									</table>';
			$headers							 = 'MIME-Version: 1.0' . "\r\n";
			$headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$confirmation_headers	 = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";

			$mail = wp_mail( $to, $subject, $message, $confirmation_headers );

			if ( $mail ) {
				$success = 'Check your email address for you new password.';
			} else {
				$error = 'Oops something went wrong updaing your account.';
			}
		}
	}
	die();
}

add_action( 'wp_ajax_nopriv_member_user_role_update', 'member_user_role_update' );
add_action( 'wp_ajax_member_user_role_update', 'member_user_role_update' );


add_role( 'deleted_subscriber', 'Deleted Subscriber' );
add_role( 'deleted_member', 'Deleted Member' );


/* Theme my login authentication validation error for deleted user */
add_filter( 'authenticate', 'user_role_check', 20, 3 );

	function user_role_check( $user, $username, $password ) {
				$suspended_user	 = get_user_meta( $user->ID, 'suspended_user', true ); 


	//* Check if the user has the pending role
				if ( ! is_wp_error( $user ) && in_array( 'deleted_member', $user->roles ) || in_array( 'deleted_subscriber', $user->roles ) || 
					$suspended_user == '1' ) {   
		//* Throw an error
					$error				 = new WP_Error();

				if($suspended_user == '1') 
				{	
					$errorMessage	 = __( '<b>ERROR</b>: Member has been suspended by NSTXL.' );  
				}
				else 
				{
					$errorMessage	 = __( '<b>ERROR</b>: Your membership has been rejected by NSTXL.' ); 	
				}  

				$error->add( 401, $errorMessage );
				return $error;
			}
	//* Or return the user
			return $user;
		}
		
/* Custom user search */
add_action( 'pre_user_query', function( $uqi ) {
	global $wpdb;

	$search	 = '';
	if ( isset( $uqi->query_vars[ 'search' ] ) )
		$search	 = trim( $uqi->query_vars[ 'search' ] );

	if ( $search ) {
		$search			 = trim( $search, '*' );
		$the_search	 = '%' . $search . '%';

		$search_meta = $wpdb->prepare( "
        ID IN ( SELECT user_id FROM {$wpdb->usermeta}
        WHERE ( ( meta_key='first_name' OR meta_key='last_name' OR meta_key='company_name')
            AND {$wpdb->usermeta}.meta_value LIKE '%s' )
        )", $the_search );

		$uqi->query_where = str_replace(
			'WHERE 1=1 AND (', "WHERE 1=1 AND (" . $search_meta . " OR ", $uqi->query_where );
	}
} );


/* Filter Email Change Email Text */

function so43532474_custom_change_email_address_change( $email_change, $user, $userdata ) {

	$new_message_txt = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
									<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
						<tr>
						<td>
						<table width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;">
						<tr>
						<td style=" text-align: center; color: #fff;">
						<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Notice of Email Change</p>
						</td></tr>
						</table>
						</td>
						</tr>
						</thead><tbody >
						<tr>
						<td>
						<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
						<tr>
				<td>';
	$new_message_txt .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hi ###USERNAME###,</p>';
	$new_message_txt .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">This notice confirms that your email address on ###SITENAME### was changed to ###NEW_EMAIL###.</p>';
	$new_message_txt .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">If you did not change your email, please contact the Site Administrator at
		###ADMIN_EMAIL###</p>';
	$new_message_txt .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">This email has been sent to ###EMAIL###</p>';
	$new_message_txt .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
	$new_message_txt .= '</td></tr></table></td></tr></tbody><tfoot><tr><td>
									<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
									<tr><td>
					<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
					</td>
					</tr>
					</table>
					</td>
					</tr>
					</tfoot>
					</table>';

	$email_change[ 'message' ] = $new_message_txt;

	return $email_change;
}

add_filter( 'email_change_email', 'so43532474_custom_change_email_address_change', 100, 3 );



/* * ******* Export users to csv ********** */
add_action( 'admin_footer', 'nstxl_export_users' );

function nstxl_export_users() {
	$screen = get_current_screen();
	if ( $screen->id != "users" )	// Only add to users.php page
		return;
	?>
	<script type="text/javascript">
		jQuery( document ).ready( function ( $ )
		{
			jQuery( '.tablenav.top .clear, .tablenav.bottom .clear' ).before( '<form action="#" method="POST"><input type="hidden" id="nstxl_export_users" name="nstxl_export_users" value="1" /><input class="button button-primary user_export_button" style="margin-top:3px;" type="submit" value="<?php esc_attr_e( 'Export Users', 'mytheme' ); ?>" /></form>' );
		} );
	</script>
	<?php
}

/* Export user from users */

function export_csv() {
	if ( ! empty( $_POST[ 'nstxl_export_users' ] ) ) {
		if ( current_user_can( 'manage_options' ) ) {

			// WP_User_Query arguments
			if ( ! empty( $_GET[ 'role' ] ) ) {
				$args = array(
						'order'		 => 'ASC',
						'orderby'	 => 'display_name',
						'fields'	 => 'all',
						'role'		 => $_GET[ 'role' ],
				);
			} else if ( ! empty( $_GET[ 's' ] ) ) {
				$args = array(
						'order'		 => 'ASC',
						'orderby'	 => 'display_name',
						'fields'	 => 'all',
						'search'	 => '*' . esc_attr( $_GET[ 's' ] ) . '*',
				);
			} else {
				$args = array(
						'order'		 => 'ASC',
						'orderby'	 => 'display_name',
						'fields'	 => 'all',
				);
			}


			// The User Query
			$blogusers = get_users( $args );
			//echo count((array) $blogusers);

			$otavalue = implode( ", ", $otaresult );

			$file = fopen( 'php://output', 'w' );


			//header("Content-type: application/force-download");
			// header('Content-Disposition: inline; filename="users' . date('YmdHis') . '.csv"');

			header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
			header( 'Content-Description: File Transfer' );
			header( 'Content-type: text/csv' );
			header( "Content-Disposition: attachment; filename=users" . date( 'YmdHis' ) . ".csv" );
			header( 'Expires: 0' );
			header( 'Pragma: public' );

			fputcsv( $file, array( 'User Id', 'User Name', 'First Name', 'Last Name', 'Company Name', 'POC', 'Trex Imported User', 'Email', 'OTA Interest', 'Technology Solution Areas', 'Role' ) );
			// Array of WP_User objects.
			foreach ( $blogusers as $user ) {
				$meta = get_user_meta( $user->ID );

				$role	 = $user->roles;
				$email = $user->user_email;

				
				$ota_interest	 = get_user_meta( $user->ID, 'primary_domain_interest', true );
				if (!empty($ota_interest) && is_array($ota_interest)) {
				$otaresult		 = array();
				foreach ( $ota_interest as $ota_interests ) {
					$otaresult[] = $ota_interests;
				}

				$otavalue = implode( ", ", $otaresult );
				}
				else{
					$otavalue = $ota_interest;
				}

				$poc = nstxl_is_poc( $user->ID );
				if ( ! empty( $poc ) ) {
					$checkpoc = 'YES';
				} else {
					$checkpoc = 'NO';
				}

				$first_name					 = ( isset( $meta[ 'first_name' ][ 0 ] ) && $meta[ 'first_name' ][ 0 ] != '' ) ? $meta[ 'first_name' ][ 0 ] : '';
				$last_name					 = ( isset( $meta[ 'last_name' ][ 0 ] ) && $meta[ 'last_name' ][ 0 ] != '' ) ? $meta[ 'last_name' ][ 0 ] : '';
				$company_name				 = ( isset( $meta[ 'company_name' ][ 0 ] ) && $meta[ 'company_name' ][ 0 ] != '' ) ? $meta[ 'company_name' ][ 0 ] : '';
				$nickname						 = ( isset( $meta[ 'nickname' ][ 0 ] ) && $meta[ 'nickname' ][ 0 ] != '' ) ? $meta[ 'nickname' ][ 0 ] : '';
				$trex_imported_user	 = get_user_meta( $user->ID, 'trex_imported', true );

				if ( $trex_imported_user == 1 ) {
					$trexcheck = 'YES';
				} else {
					$trexcheck = 'NO';
				}


				$techsolution							 = array();
				$technology_solution_areas = get_user_meta( $user->ID, 'primary_application', true );

				if ( ! empty( $technology_solution_areas ) ) {
					foreach ( $technology_solution_areas as $value ) {
						$techsolution[] = $value;
					}
					$primary_application = implode( ", ", $techsolution );
					$primary_applicationremove = preg_replace("/[\-_]/", " ", $primary_application);
					$primary_applicationcap = ucwords($primary_applicationremove);
					$techsolution_val = $primary_applicationcap;
    
				} else {
					$techsolution_val = '';
				}
				fputcsv( $file, array( $user->ID, $nickname, $first_name, $last_name, $company_name, $checkpoc, $trexcheck, $email, $otavalue, $techsolution_val, ucfirst( $role[ 0 ] ) ) );
			}
			exit();
		}
	}
}

add_action( 'admin_init', 'export_csv' ); //you can use admin_init as well

/* Wp user notification for user */
add_filter( 'wp_new_user_notification_email', 'nstxl_welcome_email', 10, 3 );

function nstxl_welcome_email( $wp_new_user_notification_email, $user, $blogname ) {
	$user_data = '';
	$checklong = $user->user_login;
	// If no value is posted, return false
	if ( ! isset( $checklong ) ) {
		return '';
	}
	// Fetch user information from user_login
	if ( strpos( $checklong, '@' ) ) {

		$user_data = get_user_by( 'email', trim( $checklong ) );
	} else {
		$login		 = trim( $checklong );
		$user_data = get_user_by( 'login', $login );
	}
	if ( ! $user_data ) {
		return '';
	}
	$user_login																	 = $user_data->user_login;
	# change the default email
	$wp_new_user_notification_email[ 'message' ] = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
				<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
		<tr>
		<td>
		<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
		<tr>
		<td style=" text-align: center; color: #fff;">
		<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">[NSTXL] Your username and password info</p>
		</td></tr>
		</table>
		</td>
		</tr>
		</thead><tbody >
		<tr>
		<td>
		<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
		<tr>
		<td>';
	$wp_new_user_notification_email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Username : ' . ucwords( $user->user_login ) . '</p>';

	$wp_new_user_notification_email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Email : ' . $user->user_email . '</p>';

	$wp_new_user_notification_email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">To set your password, visit the following address: <a href="' . network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' ) . '">here</a>.</p>';
	$wp_new_user_notification_email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">If you have already set your own password, you may disregard this email and use the password you have already set.</p>';
	$wp_new_user_notification_email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p></td></tr></table></td></tr></tbody><tfoot><tr><td>
									<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
		<tr>
		<td>
		<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
		</td>
		</tr>
		</table>
		</td>
		</tr>
		</tfoot>
		</table>';

	return $wp_new_user_notification_email;
}

/* Wp user notification for admin */

add_filter( 'wp_new_user_notification_email_admin', 'nstxl_admin_new_user_email', 10, 3 );

function nstxl_admin_new_user_email( $email, $user ) {

	$email[ 'message' ] = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center"><thead>
				<tr><td style="padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer" alt="logo-mailer"></a></td></tr>
		<tr>
		<td>
		<table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
		<tr>
		<td style=" text-align: center; color: #fff;">
		<p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">[NSTXL] New User Registration</p>
		</td></tr>
		</table>
		</td>
		</tr>
		</thead><tbody >
		<tr>
		<td>
		<table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
		<tr>
		<td>';
	$email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">New user registration on your site NSTXL:</p>';
	$email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Username : ' . ucwords( $user->user_login ) . '</p>';
	$email[ 'message' ] .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Email : ' . $user->user_email . '</p>';
	$email[ 'message' ] .= '</td></tr></table></td></tr></tbody><tfoot><tr><td>
									<table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
		<tr>
		<td>
		<p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
		</td>
		</tr>
		</table>
		</td>
		</tr>
		</tfoot>
		</table>';
	return $email;
}

/* Ajax for load more in opporuniy questions answer */

add_action( 'wp_ajax_answer_fetch', 'answer_fetch' );
add_action( 'wp_ajax_nopriv_answer_fetch', 'answer_fetch' );

function answer_fetch() {

	global $post;

	$postperpage = (isset( $_POST[ "postperpage" ] )) ? $_POST[ "postperpage" ] : 5;

	$page = (isset( $_POST[ 'pageNumber' ] )) ? $_POST[ 'pageNumber' ] : 1;

	$opr_id = $_POST[ 'oppid' ];

	$queans = get_field( 'nstxl_opportunity_answer', $post->ID );

	$queimport = get_field( 'nstxl_answer_import', $post->ID );
	$args			 = array( 'post_type'			 => 'nstxl-question', 'posts_per_page' => $postperpage, 'meta_query'		 => array( 'relation' => 'AND',
					array(
							'key'			 => 'question_post_id',
							'value'		 => $opr_id,
							'compare'	 => '=',
					),
					array(
							'key'			 => 'nstxl_answer_import',
							'value'		 => 1,
							'compare'	 => '=',
					)
			), 'paged'					 => $page );

	$query = new WP_Query( $args );
	?>
	<!-- the loop -->
	<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); ?>
			<li class="comment even thread-even depth-1">
				<div class="comment-wrapper clearfix">
					<div class="comment-body">
						<h5 class="author"><?php the_title(); ?></h5>
						<div class="comment-text">
			<?php $queanss = get_field( 'nstxl_opportunity_answer', $post->ID ); ?>
							<p><?php echo $queanss; ?></p>
						</div>
						<div class="comment-meta">
							<span class="date meta-field">
								<?php
								printf( esc_html_x( '%1$s at %2$s ago', '%1$s = normal date, %2$s = human-readable time difference', 'onepress' ), get_the_date( 'M j, Y' ), human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) );
								?>				
							</span>
						</div>
					</div>
				</div>
			</li>
		<?php endwhile; ?>
	<?php else : ?>

		<div class="nf-post">Post Not Found.</div>
		<!-- No posts found -->
	<?php endif; ?>
	<?php
	$max_page = $query->max_num_pages;
	if ( $max_page > $page ) {
		?>
		<div id="loadmoreans" oppid="<?php echo $opr_id; ?>" class="loadmore wow animated fadeInUp" ><a>Load more</a>
	<?php } ?>
		<!-- End of Blog Query -->
	</div>
	<?php
	wp_reset_query();
	die();
}

/*
  Added BCC email.
 */

function nstxl_bcc_pmpro_email_headers( $headers, $email ) {
	//bcc email add when membership expire email sent.
	if ( ! empty( $email->template ) && ( $email->template == 'membership_expiring_two' || $email->template == 'membership_expiring_seven' || $email->template == 'membership_expiring_thirty' || $email->template == 'membership_expiring' ) ) {
		//add bcc
		$headers[] = "Bcc:rajat.sharma@galaxyweblinks.in";
		$headers[] = "Bcc:vikesh.tokhare@galaxyweblinks.in";
	}

	return $headers;
}

add_filter( "pmpro_email_headers", "nstxl_bcc_pmpro_email_headers", 10, 2 );


/* Display none linkedln notice error */
add_action( 'admin_head', 'nstxl_custom_admin_css' );

function nstxl_custom_admin_css() {
	echo '<style>
    .notice.is-dismissible.error {
     display:none;
    } 
  </style>';
}

/* Deactivate classic editor and added code for Disable gutenberg */

if ( version_compare( $GLOBALS[ 'wp_version' ], '5.0-beta', '>' ) ) {
	// WP > 5 beta
	add_filter( 'use_block_editor_for_post_type', '__return_false', 100 );
} else {
	// WP < 5 beta
	add_filter( 'gutenberg_can_edit_post_type', '__return_false' );
}

/* This code copied from Hide Admin Bar From Non-admins */

function nstxl_hide_admin_bar_settings() {
	?>
	<style type="text/css">
		.show-admin-bar {
			display: none;
		}
	</style>
	<?php
}

function nstxl_disable_admin_bar() {
	if ( ! current_user_can( 'administrator' ) ) {
		add_filter( 'show_admin_bar', '__return_false' );
		add_action( 'admin_print_scripts-profile.php', 'nstxl_hide_admin_bar_settings' );
	}
}

add_action( 'init', 'nstxl_disable_admin_bar', 9 );


/**************** Force Password Change functions start*******************************/


function nstxl_force_password_redirect_dashboard()
{
	global $current_user; 
	global $user; 
	if (current_user_can('administrator')) { 
		{
			$start_date = date('Y-m-d H:i:s', current_time('timestamp'));  
			$expiry_end_date = get_user_meta($current_user->ID, 'expiry-password-change', true );  
			if(!empty($expiry_end_date) && ($expiry_end_date <= $start_date)) 
			{	 
				if (!is_page('change-your-password')) {	
					wp_redirect(get_bloginfo('url') . '/change-your-password/?expire=1');
					exit;  

				}	
			}	
		}  
	}	 
} 
add_action('template_redirect', 'nstxl_force_password_redirect_dashboard'); 


function nstxl_force_password_redirect()
{
	global $current_user; 
	global $user; 
	if (current_user_can('administrator')) { 
		{
			$start_date = date('Y-m-d H:i:s', current_time('timestamp'));  
			$expiry_end_date = get_user_meta($current_user->ID, 'expiry-password-change', true );  
			if(!empty($expiry_end_date) && ($expiry_end_date <= $start_date)) 
			{ 
				if ( is_admin() ) { 
					$screen = get_current_screen();
					if ( 'profile' == $screen->base )
						return; 		
					wp_redirect( admin_url( 'profile.php' ) );	
					exit;  
				}	
			}	
		}   
	}	   
} 
add_action('current_screen', 'nstxl_force_password_redirect');


function nstxl_notice_password() {

	global $current_user; 
	global $user; 
	if (current_user_can('administrator')) { 
		{
			$start_date = date('Y-m-d H:i:s', current_time('timestamp'));  
			$expiry_end_date = get_user_meta($current_user->ID, 'expiry-password-change', true );  
			if(!empty($expiry_end_date) && ($expiry_end_date <= $start_date)) 
			{ 
				printf(
					'<div class="error"><h3>%s</h3></div>',
					__( 'Please change your password to continue using this website.', 'force-password-change' ) 
				);
			}	
		}   

	}
}	
add_action( 'admin_notices', 'nstxl_notice_password'); 

/**
 * Proposal Access Multiple select customize control class.
 */
include_once ABSPATH . 'wp-includes/class-wp-customize-control.php';
class nstxl_proposal_Control_Multiple_Select extends WP_Customize_Control {
	public $type = 'multiple-select';
	public function render_content() 
	{
		if ( empty( $this->choices ) )
			return;
		?>
		<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<select <?php $this->link(); ?> multiple="multiple" id="userlist_multiple" class="input" name="userlist_multiple" style="height: 100%;"> 
				<?php
				foreach ( $this->choices as $value => $label ) {
					if($value!='application')
					{	
						$selected = ( in_array( $value, $this->value() ) ) ? selected( 1, 1, false ) : '';
						echo '<option value="' . esc_attr( $value ) . '"' . $selected . '>' . $label . '</option>';
					}
				} 
				?>
			</select>  
		</label> 
		<script type="text/javascript">
			var siteurl = '<?php echo get_bloginfo("url"); ?>';   
			jQuery(document).ready(function(){
				jQuery('#userlist_multiple').multiselect({
					includeSelectAllOption: true,
					nonSelectedText: "Please Select"
				});

				if (jQuery('#userlist_multiple').find(':selected').val() == null || jQuery('#userlist_multiple').val() == null) {
					jQuery('#userlist_multiple').trigger('change');  
				}
			});       
		</script> 

		<style type="text/css">
			#sub-accordion-section-proposal_access_users_list{
				min-height: 100%;
			}
			#sub-accordion-section-proposal_access_users_list .multiselect-container {
				position: relative;
				margin-top: 20px;
			}
			#sub-accordion-section-proposal_access_users_list .multiselect-container>li>a>label{
				padding: 3px 20px 3px 0px;
			}
			#sub-accordion-section-proposal_access_users_list button.multiselect.dropdown-toggle.btn.btn-default {
				background: none;
				border: 1px solid #ccc;
				padding: 5px 10px;
			}
		</style>     


	<?php }   
}  



/**
* Proposal access admin dropdown users
*/

function nstxl_proposal_user_list( $wp_customize ) {
	global $current_user; 
	if(($current_user->user_login=='galaxytemp')||  ($current_user->user_login=='erik@nstxl.org'))	
	{
		$wp_customize->add_section('proposal_access_users_list', array(
			'title'    => __('Select Users For Proposal Access'),
			'description' => '',
			'priority' => 25,
		));

		$val = array(); 

		$args = array(
			'role' => 'administrator'
		);
		$users = get_users($args);

		if ( ! empty($users ) ) {  	

			foreach( $users as $user ){ 

				$val[$user->user_login] = $user->user_login;
			}


			$wp_customize->add_setting( 'multiple_user_select_setting', array(
				'default' => array(),  
			) );

			$wp_customize->add_control(
				new nstxl_proposal_Control_Multiple_Select(
					$wp_customize,
					'multiple_user_select_setting',
					array(
						'settings' => 'multiple_user_select_setting', 
						'label'    => 'Select Users For Proposal Access',
						'section'  => 'proposal_access_users_list', 
						'type'     => 'multiple-select',  
						'choices' => $val,  
					)
				)
			);

		}
	} 
} 

add_action( 'customize_register', 'nstxl_proposal_user_list' ); 



// Shortcode for fetch opprtunity by their slug start //

/**
 * Current Opportunity Slider shortcode
 */
function nstxl_opportunity_slider_shortcode( $atts ) {
	global $current_user;
	
	wp_enqueue_style( 'slick-theme-css', get_stylesheet_directory_uri() . '/css/slick-theme.css' );

	global $wp_query, $post;
	$atts = shortcode_atts(
		array(
			'posts_per_page' => -1, 
			'post_type'			 => 'opportunity',
			'taxonomy'			 => 'opportunity-type',
			'terms'					 => 'current-opportunities',
		), $atts );

	$args = array(
		'post_type'			 => array( $atts[ 'post_type' ] ),
		'orderby'				 => 'date',
		'order'					 => 'DESC',
		'posts_per_page' => $atts[ 'posts_per_page' ],
	);


	// only add if we have both keys in the original values

	if ( isset( $atts[ 'taxonomy' ], $atts[ 'terms' ] ) ) {
		$tax_queries				 = array(
			array(
				'field'		 => 'slug',
				'taxonomy' => $atts[ 'taxonomy' ],
				'terms'		 => array( sanitize_title( $atts[ 'terms' ] ) )
			),
		);
		$args[ 'tax_query' ] = $tax_queries;
	}

	// run the query

	$Newquery		 = new WP_Query( $args );
	//echo $Newquery->found_posts;
	ob_start();
	$opportunity = '';

	$opportunity .= '<div class="opportunity-content">';
	$opportunity .= '<div class="opportunity-posts">';
	$opportunity .= '<div class="card-deck current-opportunities-slider">';
	if ( $Newquery->have_posts() ) : while ( $Newquery->have_posts() ) : $Newquery->the_post();

	$posttitle = get_field('nstxl_short_title', $Newquery->ID);
	$wordcount = str_word_count($posttitle);

	$opportunity .= '<div class="card">';
//	$opportunity .= '<article id="post-'.$Newquery->ID.'" '.post_class('opportunity-post opportunity-isotope-item').'>'; 
    $opportunity .= '<article>';  
    $opportunity .= nstxl_proposal_due_soon_tag(get_the_ID());            

	$proposal_deadline_date = get_post_meta(get_the_ID(), 'nstxl_proposal_deadline', true);
    $featuredimageshow = 0;
    if ($featuredimageshow == 1) {
      if (has_post_thumbnail()) {

        /* grab the url for the full size featured image */
        $featured_img_url = get_the_post_thumbnail_url($Newquery->ID, 'medium');

        /* link thumbnail to full size image for use with lightbox */
        $opportunity .= '<a href="' . esc_url(get_permalink()) . '">';
        $opportunity .= '<img class="card-img-top" data-src="'. $featured_img_url.'" alt="100%x200" style="height: 200px; width: 100%; display: block;" src="'.$featured_img_url.'" data-holder-rendered="true">';
        $opportunity .= '</a>';
      } else {
        $opportunity .= '<a href="' . esc_url(get_permalink()) . '">';
        $opportunity .= '<img class="card-img-top" src="'.get_bloginfo('stylesheet_directory').'/images/placeholder.png" data-holder-rendered="true" />';
        $opportunity .= '</a>';
      }
    }
    $opportunity .= '<div class="featured-media">' . get_ota_logos() . '</div>';

    $opportunity .= '<div class="card-body">';
    $opportunity .= '<h4 class="card-title">';

     if ($wordcount > 10) {
     $opportunity .=  '<a href="'.esc_url(get_permalink()).'">'.wp_trim_words($posttitle, 10, '').'</a>';
        } else { 
     $opportunity .= '<a href="'.esc_url(get_permalink()).'">'.$posttitle.'</a>';
         }
     $opportunity .=  '</h4>';
     $opportunity .= '<p class="card-text">';
     $opportunity .= wp_trim_words(get_the_content(), 12, '');    
     $opportunity .= '</p>';
    $opportunity .= '<div class="ota-list-section">';   
   // $opportunity .=  '<a class="card-link" href="'.esc_url(get_permalink()).'"><img src="'.get_bloginfo('stylesheet_directory').'/images/documents.svg">Documents</a>';   
    $opportunity .=  '<a class="card-link documentsmodal" href="" data-check="'.get_the_ID().'"><img src="'.get_bloginfo('stylesheet_directory').'/images/documents.svg">Documents</a>';
 
        if (is_user_logged_in()) {
          $cusr_id = $current_user->ID;
          $trckid = get_the_ID();
          $mytrackIDs = get_user_meta($cusr_id, 'myopportunitiesposts', true);
          if (!empty($mytrackIDs)) {
            if (in_array($trckid, $mytrackIDs)) {
    $opportunity .= '<a class="untrackopportunity1 card-link trackoppid" data-id="'.get_the_ID().'" data-check="'.get_the_ID().'" href="'.site_url().'/tracked-opportunities/"><img src="'.get_bloginfo('stylesheet_directory').'/images/track.svg">Tracked</a>';
            } else { 
    $opportunity .= '<a href="'.site_url().'/tracked-opportunities/" class="trackopportunity1 card-link trackoppid" data-id="'.get_the_ID().'" data-check="'.get_the_ID().'"><img src="'.get_bloginfo('stylesheet_directory').'/images/track.svg">Track Opportunity</a>';
            }
          } else {
     
     $opportunity .= '<a href="'.site_url().'/tracked-opportunities/" class="trackopportunity1 card-link trackoppid" data-id="'.get_the_ID().'" data-check="'.get_the_ID().'"><img src="'.get_bloginfo('stylesheet_directory').'/images/track.svg">Track Opportunity</a>';   
          }
        } else {
 	$opportunity .= '<a class="card-link" href="'.get_bloginfo('url').'/login?redirect_to='.urlencode(get_bloginfo('url') . '/tracked-opportunities').'"><img src="'.get_bloginfo('stylesheet_directory').'/images/track.svg">Track Opportunity</a>';
         } 

    $opportunity .= '<a href="" class="card-link event-date-modal" data-toggle="modal" data-check="'.get_the_ID().'" data-target="#event-date-modal-'. get_the_ID().'"><img src="'.get_bloginfo('stylesheet_directory').'/images/calendar.svg">Due'; 
    if(!empty($proposal_deadline_date))
    	{ 
    		$opportunity .= '<span class="date">&nbsp'.date("m/d/Y", strtotime($proposal_deadline_date)).'</span>';
    	} else { // echo
    	$opportunity .=''; 
    	}  

    '</a>';

    $opportunity .= '<a href="" class="card-link submitquestionlink homeoppid" data-check="'.get_the_ID().'" data-toggle="modal"  data-target="#submit-question-modal-'.get_the_ID().'"><img src="'.get_bloginfo('stylesheet_directory').'/images/submit question.svg">Submit a Question</a>';
  
      $term_list = wp_get_post_terms( get_the_ID(), 'opportunity-type', array( 'fields' => 'ids' ) );
      $termID = $term_list[0];
        
        if ($termID == '40') { 
        $opportunity .= '<div class="submit-button-section">';
          if (is_user_logged_in()) { 
         $opportunity .= '<a class="btn btn-secondary-outline btn-lg" href="'.get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID().'">Submit a Solution</a>';
            } else {
        $opportunity .= '<a class="btn btn-secondary-outline btn-lg" href="'.get_bloginfo('url').'/login?redirect_to='.urlencode(get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID()).'">Submit a Solution</a>';
         } 
          }

     $opportunity .=  '</div>        
      </div>
      <!-- the title, the content etc.. -->
  </article>
</div>';
endwhile;
endif;


wp_reset_query();
$opportunity .= ob_get_contents();
$opportunity .= ob_get_clean();
$opportunity .= '</div></div></div>';
$opportunity .= '<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery(".card-deck").slick({
		arrows: true,
		autoplay: false,
		autoplaySpeed: 3000,
		slidesToShow: 3,
		dots: true,
		slidesToScroll: 3,
		responsive: [
		{
			breakpoint: 768,
			settings: {
				slidesToShow: 2,
				slidesToScroll: 1,
			}
			},
			{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
				}
			}
			]
			});
			});
			</script>';


	$opportunity .= '<div id="opppopslider">';
	$opportunity .= '</div>'; 
	$opportunity .= '<div id="keydocumentsmodal">';
	$opportunity .= '</div>'; 
	$opportunity .= '<div id="trackmodal">';
	$opportunity .= '</div>';
	$opportunity .= '<div id="eventdatemodal">';
	$opportunity .= '</div>';  

	$opportunity .= '<script>
    jQuery(document).on("click",".homeoppid",function(e){ // When btn is pressed.
    	e.preventDefault();
    	var did = jQuery(this).attr("data-check");
		jQuery.ajax({
	        url: nstxl_ajaxurl,
	        type: "post",
	        data: {action: "submit_question_data", dataid: did,
	    },
	        success: function(response) {
	        	 jQuery("#opppopslider").html(response); 
	        	jQuery("#submit-question-modal-"+did).modal("show");
	        }
 	 	});

	});


	jQuery(document).on("click",".documentsmodal",function(e){ // When btn is pressed.
    	e.preventDefault();
    	var did = jQuery(this).attr("data-check");
		jQuery.ajax({
	        url: nstxl_ajaxurl,
	        type: "post",
	        data: {action: "key_documents_data", dataid: did,
	    },
	        success: function(response) {
	        	 jQuery("#keydocumentsmodal").html(response); 
	        	jQuery("#key-documents-modal-"+did).modal("show");
	        }
 	 	});

	});

	jQuery(document).on("click",".event-date-modal",function(e){ // When btn is pressed.
    	e.preventDefault();
    	var did = jQuery(this).attr("data-check");
		jQuery.ajax({
	        url: nstxl_ajaxurl,
	        type: "post",
	        data: {action: "event_date_data", dataid: did,
	    },
	        success: function(response) {
	        	 jQuery("#eventdatemodal").html(response); 
	        	jQuery("#event-date-modal-"+did).modal("show");
	        }
 	 	});

	});
	

	</script>';		


	return $opportunity;
		}

		add_shortcode( 'opprtunity', 'nstxl_opportunity_slider_shortcode' );

// Shortcode for fetch opprtunity by their slug ends //  

function submit_question_data(){ 
	$oppid = $_POST['dataid'];
?>
<!-- submit question Modal -->
<div class="modal fade custom-popup show homeliderpop" id="submit-question-modal-<?php echo $oppid; ?>" data-id="<?php echo $_POST['dataid']; ?>" tabindex="-1" role="dialog" aria-labelledby="submit-question-modal-success" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo get_the_title($oppid); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
        </button>
      </div>
      <div class="modal-body">

        <div class="submit-quetion-box-success-container modal-body-container">

          <?php include(locate_template('templates/opportunity/sidebar/submitquestion.php')); ?>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery("#submit-question-modal-<?php echo $oppid; ?>").modal("show");
	jQuery(document).on("click","#submit-question-modal-<?php echo $oppid; ?> .close",function(e){
		jQuery("#submit-question-modal-<?php echo $oppid; ?>").modal("hide");
	});
	jQuery("#submit-question-modal-<?php echo $oppid; ?>").on("hidden.bs.modal", function () {
      location.reload(true);
    });
	});
</script>
<?php
die();
}
add_action( 'wp_ajax_submit_question_data', 'submit_question_data' );
add_action( 'wp_ajax_nopriv_submit_question_data', 'submit_question_data' );


// Shortcode for fetch opprtunity by their slug ends //  

function event_date_data(){ 
	$oppid = $_POST['dataid'];
?>
<!-- submit question Modal -->
<div class="modal fade custom-popup show" id="event-date-modal-<?php echo $oppid; ?>" data-id="<?php echo $_POST['dataid']; ?>" tabindex="-1" role="dialog" aria-labelledby="event-date-modal-success" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo get_the_title($oppid); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
        </button>
      </div>
      <div class="modal-body">

        <div class="event-date-box-success-container modal-body-container">

          <?php include(locate_template('templates/opportunity/sidebar/eventdates.php')); ?>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery("#event-date-modal-<?php echo $oppid; ?>").modal("show");
	jQuery(document).on("click","#submit-question-modal-<?php echo $oppid; ?> .close",function(e){
		jQuery("#event-date-modal-<?php echo $oppid; ?>").modal("hide");
	});
	jQuery("#event-date-modal-<?php echo $oppid; ?>").on("hidden.bs.modal", function () {
      location.reload(true);
    });
	});
</script>
<?php
die();
}
add_action( 'wp_ajax_event_date_data', 'event_date_data' );
add_action( 'wp_ajax_nopriv_event_date_data', 'event_date_data' );


function track_opp_data(){ 
$oppid = $_POST['dataid'];

$track_modal_id = 'track-opportunity-modal-' . $oppid;
$track_modal_body_container_class = 'track-opportunity-modal-container';
$track_content_html = '';
nstxl_modal_popup($track_content_html, $track_modal_id, $track_modal_body_container_class);

?>
<script type="text/javascript">
  jQuery(document).ready(function ($) {
  	trackOpportunity();
    untrackOpportunity();
  	 //jQuery('#<?php //echo $track_modal_id; ?>').modal('show');
    jQuery('#<?php echo $track_modal_id; ?> .close').on('click', function (e) {
      jQuery('#<?php echo $track_modal_id; ?>').modal('hide');
    });
    jQuery('#<?php echo $track_modal_id; ?>').on('hidden.bs.modal', function () {
      location.reload(true);
    })
  });
<?php
die();
}
add_action( 'wp_ajax_track_opp_data', 'track_opp_data' );
add_action( 'wp_ajax_nopriv_track_opp_data', 'track_opp_data' );


function key_documents_data(){ 
	$oppid = $_POST['dataid'];
?>
<!-- submit question Modal -->
<!-- Keydocuments popup -->
<div class="modal fade custom-popup documentsmodals show" id="key-documents-modal-<?php echo $oppid; ?>" data-id="<?php echo $oppid; ?>" tabindex="-1" role="dialog" aria-labelledby="submit-quesdasdsation-modal-success" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
        </button>
        <div class="modal-body-container key-documents-modal-container">
          <?php 
         // include(locate_template('/templates/opportunity/sidebar/keydocuments.php')); 
          global $post;
$nstxl_statement_of_need = get_field('nstxl_statement_of_need', $oppid);
$presentations = get_field('nstxl_presentations', $oppid);
$qandansresponse = get_field('nstxl_q_&_a_responses', $oppid);
$repeater_update = get_field('latest_updates_section', $oppid);
if (isset($repeater_update) && !empty($repeater_update)) { ?>
  <aside class="aside-opportunity-content widget">
 <?php if (isset($_POST['downloadkeydoc'])) {
  $upload_dir = wp_upload_dir();
  $upload_dir_path = $upload_dir["basedir"];
  $date = current_time('timestamp');
  $downloaded_keydoc_path = $upload_dir_path . '/opportunity-documents/';
  if (!file_exists($downloaded_keydoc_path)) {
    mkdir($downloaded_keydoc_path, 0777, true);
  }
  $downloaded_keydoc_url = $upload_dir["baseurl"] . '/opportunity-documents/';


  $zip_destination = $downloaded_keydoc_path . '/keydocuments-' . $date . '.zip';
  $exported_keydoc_path_url = $downloaded_keydoc_url . basename($zip_destination);
  $zipname = basename($zip_destination);
  $za = new ZipArchive;

  if ($za->open($zip_destination, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    echo '<div class="notice notice-error"><p>' . (!empty($this->last_error) ? sprintf(__('Error: %s', 'download-plugins-dashboard'), $this->last_error) : __('Something went wrong...', 'download-plugins-dashboard') ) . '</p></div>';
    exit();
  }
  if (isset($_POST['keydoc']) && !empty($_POST['keydoc'])) {
    $download_keydocs = $_POST['keydoc'];

    foreach ($download_keydocs as $download_keydoc) {
      $document_parse_array = parse_url($download_keydoc);
      $document_half_path = $document_parse_array['path'];
      $document_full_path = get_home_path() . $document_half_path;
      //$fpath = '/opportunity-documents/' . get_the_title() . '-' . get_the_ID() . '/' . basename($document_half_path);
      $fpath = '/opportunity-documents/' . basename($document_half_path);
      $za->addFile($document_full_path, $fpath);
    }
  }
  $za->close();
  //if (file_exists($exported_keydoc_path_url)) {
  ?>
  <h4 class="doc-success-msg"><?php _e('Your key documents zip have generated successfully please click', 'nstxl'); ?> <a id='downloadproposal' href="<?php echo $exported_keydoc_path_url; ?>" download> here </a><?php _e('to download the documents.', 'nstxl'); ?> </h4>
  <?php
  // }
}
  ?>
    <div class="widget-content">
      <div class="table table-responsive">
        <form method="post" name="keydocumentform-<?php echo $oppid; ?>" id="keydocumentform-<?php echo $oppid; ?>" >
          <input type="hidden" name="action" value="nstxl_keydocuments_download" />
          <table class="table table-striped table-bordered table-hover">
            <thead>
              <tr>        
                <th><h2 class="widget-title"><?php _e('Key Documents', 'onepress'); ?></h2></th>
                <th><div class="hidden-check"><input type="checkbox" id="select_all_keydocuments-<?php echo $oppid; ?>"  value=""/><label class="select_all_keydocuments" for="select_all_keydocuments-<?php echo $oppid; ?>"><?php _e('Select All', 'onepress'); ?></label></div></th>
              </tr>
            </thead>
            <tbody>              
              <?php if (isset($nstxl_statement_of_need) && !empty($nstxl_statement_of_need)) { ?>
                <tr>
                  <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/pdf-dark.svg" class="oppt-doc-icons"><a href="<?php echo $nstxl_statement_of_need['url']; ?>" download><?php echo $nstxl_statement_of_need['title']; ?></a></td>
                  <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $nstxl_statement_of_need['ID']; ?>" data-id="<?php echo $nstxl_statement_of_need['ID']; ?>" value="<?php echo $nstxl_statement_of_need['url']; ?>">
                      <label class="custom-control-label" for="keydoc<?php echo $nstxl_statement_of_need['ID']; ?>">&nbsp;</label>
                    </div>
                  </td>
                </tr>
                <?php
              }
              if (isset($presentations) && !empty($presentations)) {
                ?>
                <tr>
                  <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ppt-dark.svg" class="oppt-doc-icons"><a href="<?php echo $presentations['url']; ?>" download><?php echo $presentations['title']; ?></a></td>
                  <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $presentations['ID']; ?>" data-id="<?php echo $presentations['ID']; ?>" value="<?php echo $presentations['url']; ?>">
                      <label class="custom-control-label" for="keydoc<?php echo $presentations['ID']; ?>">&nbsp;</label>
                    </div>
                  </td>
                </tr>
                <?php
              }
              if (isset($qandansresponse) && !empty($qandansresponse)) {
                ?>
                <tr>
                  <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/documents-dark.svg" class="oppt-doc-icons"><a href="<?php echo $qandansresponse['url']; ?>" download><?php echo $qandansresponse['title']; ?></a></td>
                  <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $qandansresponse['ID']; ?>" data-id="<?php echo $qandansresponse['ID']; ?>" value="<?php echo $qandansresponse['url']; ?>">
                      <label class="custom-control-label" for="keydoc<?php echo $qandansresponse['ID']; ?>">&nbsp;</label>
                    </div>
                  </td>
                </tr>
              <?php } ?>

              <?php
              if (!empty($repeater_update)) {
                foreach ($repeater_update as $row) {
                  ?>        
                  <tr>
                    <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/documents-dark.svg" class="oppt-doc-icons"><a href="<?php echo $row['latest_update_doc']['url']; ?>" download><?php echo $row['latest_update_doc']['title']; ?></a></td>
                    <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                        <input type="checkbox" name="keydoc[]" class="custom-control-input keydocumentcheck" id="keydoc<?php echo $row['latest_update_doc']['ID']; ?>" data-id="<?php echo $row['latest_update_doc']['ID']; ?>" value="<?php echo $row['latest_update_doc']['url']; ?>">
                        <label class="custom-control-label" for="keydoc<?php echo $row['latest_update_doc']['ID']; ?>">&nbsp;</label>
                      </div></td>
                  </tr>
                  <?php
                }
              }
              ?>
            <input type="hidden" name="oprid" id="oprid" value="<?php echo esc_attr($oppid); ?>">
            <tr>
              <td colspan="3" class="text-right"><button type="submit" name="downloadkeydoc" id="downloadkeydoc" value="downloadkeydoc" class="btn btn-txt no-btn" disabled><?php _e('Download', 'onepress'); ?></button></td>
            </tr>
            </tbody>
          </table>
        </form>
      </div>
    </div>
  </aside>

<script type="text/javascript">
      
  jQuery(document).ready(function ($) {

jQuery("#key-documents-modal-<?php echo $oppid; ?>").on("hidden.bs.modal", function () {
      location.reload(true);
    });


    $('.modal').on('shown.bs.modal', function (e) {
      opriD = $(this).attr('data-id');
      modelID = '#' + $(this).attr('id');
      
      if ($(modelID + ' .keydocumentcheck:checked').length != 0) {  
        $(modelID + ' #downloadkeydoc').prop('disabled', false);
      } else {
        $(modelID + ' #downloadkeydoc').prop('disabled', true);
      }
      $(modelID + ' #select_all_keydocuments-'+opriD).on('click', function () {
        if (this.checked) {
          $(modelID + ' .keydocumentcheck').each(function () {
            this.checked = true;
            $(modelID + ' #downloadkeydoc').prop('disabled', false);
          });
        } else {
          $(modelID + ' .keydocumentcheck').each(function () {
            this.checked = false;
            $(modelID + ' #downloadkeydoc').prop('disabled', true);
          });
        }
      });

      $(modelID + ' .keydocumentcheck').on('click', function () {
        if ($(modelID + ' .keydocumentcheck:checked').length == $(modelID + ' .keydocumentcheck').length) {
          $(modelID + ' #select_all_keydocuments-'+opriD).prop('checked', true);
        } else {
          $(modelID + ' #select_all_keydocuments-'+opriD).prop('checked', false);
        }

        if ($(modelID + ' .keydocumentcheck:checked').length != 0) {
          $(modelID + ' #downloadkeydoc').prop('disabled', false);
        } else {
          $(modelID + ' #downloadkeydoc').prop('disabled', true);
        }
      });

      var formID = "#keydocumentform-" + opriD;
      $(formID).on("submit", function (e) {
        e.preventDefault();
        var ch_data = new Array();

        $('.keydocumentcheck:checked').each(function () {
          ch_data.push($(this).attr('value'));
        });
        console.log(ch_data);
        console.log(ch_data);
        $.ajax({
          url: nstxl_ajaxurl,
          type: 'POST',
          data: {'action': 'nstxl_keydocuments_download', 'data': ch_data},
          cache: false,
          dataType: 'json',
          beforeSend: function () {
            jQuery('.nstxl-loader').show();
            jQuery('.loader-overlay').show();
          },
          complete: function () {
            jQuery('.nstxl-loader').hide();
            jQuery('.loader-overlay').hide();
          },
          success: function (data, textStatus, jqXHR) {
            if (data.data.status == "success") {
              jQuery('.table.table-responsive').append(data.data.msg);
            }

            if (data.data.status == "error") {
              console.log(data.error);
            }
          },

        });
      });

    });


  });
</script>

  <?php
} else {
  echo '<h4>This opportunity has not found any key documents</h4>';
}
          ?>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 
<div class="modal-backdrop fade documentsmodals show"></div>
<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery("body").addClass("modal-open");
	jQuery(document).on("click",".close",function(e){
		jQuery("body").removeClass("modal-open");
		jQuery(".documentsmodals").removeClass("show");
		jQuery(".documentsmodals").css("display", "none");
	});
	});
</script>
<?php
die();
}
add_action( 'wp_ajax_key_documents_data', 'key_documents_data' );
add_action( 'wp_ajax_nopriv_key_documents_data', 'key_documents_data' );



function ea_primary_menu_extras( $menu, $args ) {
    if( 'primary' != $args->theme_location ){return $menu;}
      $menu .= '<li class="menu-item search"><a href="#" class="search-toggle"><i class="fa fa-search" aria-hidden="true"></i></a></li>';

  	 $menu .= '<div class="header-search">'.get_search_form( false ).'<a href="#" class="search-close"><i class="fa fa-times-circle" aria-hidden="true"></i></a></div>';

  	 if(is_user_logged_in()){
  	 	global $current_user;
  	 	$menu .= '<li class="menu-item profile-info-box"><a href="#" class="profile-info-box-toggle">HI,'.$current_user->first_name.' <i class="fa fa-user" aria-hidden="true"></i></a></li>';

  	 $menu .= '<div class="header-profile-info-box">
  
  	 <ul>
  	 	 <li>	 
  	 	 <p class="headerprofile">
		  	 <span><a href="javascript:void(0)">'.ucfirst($current_user->first_name).' '.ucfirst($current_user->last_name).'</a></span>
		  	 <span class="profileemail"><a href = "mailto: '.$current_user->user_email.'">'.$current_user->user_email.'</a></span>
	  	 </p>
  	 </li>
	  	 <li><a href="'.site_url().'/edit-personal-profile/">Edit My profile</a></li>';

	  	 if(current_user_can('administrator') ){
	  	 	$menu .= '<li><a href="'.admin_url().'/users.php?page=wp2sv">2-Step Verification</a></li>';
	  	 }
	  	  $menu .=	'<li><a href="'.wp_logout_url( home_url() ).'">Log Out</a></li>
  	 </ul>
  	 </div>';
  	 }	
    return $menu;
}
add_filter( 'wp_nav_menu_items', 'ea_primary_menu_extras', 10, 2 );



/* Custom post type team */

function post_type_team() {
 
    register_post_type( 'team',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Team' ),
                'singular_name' => __( 'Team' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'team'),
            'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields' ),
        )
    );
}
// Hooking up our function to theme setup
add_action( 'init', 'post_type_team' );


/* Customized recent post widget */

/**
 * Extend Recent Posts Widget 
 *
 * Adds different formatting to the default WordPress Recent Posts Widget
 */

Class NSTXL_Recent_Posts_Widget extends WP_Widget_Recent_Posts {

	function widget($args, $instance) {
	
		extract( $args );
		
		$title = apply_filters('widget_title', empty($instance['title']) ? __('Recent Posts') : $instance['title'], $instance, $this->id_base);
				
		if( empty( $instance['number'] ) || ! $number = absint( $instance['number'] ) )
			$number = 10;
					
		$r = new WP_Query( apply_filters( 'widget_posts_args', array( 'posts_per_page' => $number, 'no_found_rows' => true, 'post_status' => 'publish','post__not_in' => array( get_the_ID() ), 'ignore_sticky_posts' => true ) ) );
		if( $r->have_posts() ) :
			
			echo $before_widget;
			if( $title ) echo $before_title . $title . $after_title; ?>
				<?php while( $r->have_posts() ) : $r->the_post(); ?>
				<div class="card">	
					<article id="<?php echo get_the_ID(); ?>" class="list-article">
					<?php if (has_post_thumbnail() ) { ?>	
					<div class="list-article-thumb">
						<a href="<?php the_permalink(); ?>">
			            <?php
			            the_post_thumbnail('full');
			            ?>
			        </a>
			        </div>
			    <?php } ?>
			    <div class="card-body">
					<h4 class="card-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
					<h6 class="card-subtitle mb-2 text-muted"><span><?php echo get_the_date(); ?></span></h4>	
					<div class="entry-excerpt"><p class="card-text"><?php echo get_the_excerpt(); ?></p></div>
					<div class="readmore-button-section"><a class="btn btn-secondary-outline btn-lg" href="<?php the_permalink(); ?>" tabindex="0">READ MORE</a>
					</div>
				</div>
				</article>
			</div>
				<?php endwhile; ?>
			 
			<?php
			echo $after_widget;
		
		wp_reset_postdata();
		
		endif;
	}
}
function nstxl_recent_widget_registration() {
  unregister_widget('WP_Widget_Recent_Posts');
  register_widget('NSTXL_Recent_Posts_Widget');
}
add_action('widgets_init', 'nstxl_recent_widget_registration');




add_filter('if_menu_conditions', 'nstxl_ispoc_menu_conditions');

function nstxl_ispoc_menu_conditions($conditions) {

  // $conditions[] = array(
  //   'id'        =>  'check-if-is-poc',                       // unique ID for the rule
  //   'name'      =>  __('If POC', 'onepress'),    // name of the rule
  //   'condition' =>  function($item) {  
  //   	global $current_user;                                // callback - must return Boolean
  //     return nstxl_is_poc($current_user->ID);
  //   }
  // );


$conditions[] = array(
    'id'        =>  'check-if-is-poc',                       // unique ID for the rule
    'name'      =>  __('If POC', 'onepress'),    // name of the rule
    'condition' =>  function($item) {  
    	global $current_user;                                // callback - must return Boolean
      return nstxl_is_poc($current_user->ID);
    }
  );




$conditions[] =  array(
    'id'        =>  'check-if-is-incubator',                       // unique ID for the rule
    'name'      =>  __('If Incubator', 'onepress'),    // name of the rule
    'condition' =>  function($item) {  
    	if (pmpro_hasMembershipLevel('6') || pmpro_hasMembershipLevel('Incubator')) {
      return pmpro_hasMembershipLevel('6');
    }
}
  );

  return $conditions;
}


function nstxl_update_proposal_summery_meta_save( $post_id ) {
//echo '<pre>';print_r( $_REQUEST['acf']); echo '</pre>';
	 //echo $_REQUEST["[acf]['field_5bec10eb667ab']"];

	if (isset($_REQUEST['acf']) && !empty($_REQUEST['acf']) ) {
		$acfArray = $_REQUEST['acf'];
		$deadlindate_post_value = $acfArray['field_5bec10eb667ab'];
		$nstxl_proposal_deadline = get_post_meta($post_id,'nstxl_proposal_deadline' ,true);
		if (!empty($deadlindate_post_value)) {	

			if(strtotime($deadlindate_post_value) != strtotime($nstxl_proposal_deadline) ){
				update_post_meta($post_id, 'proposal_summary_sent', 0);		
			} 
		}

	}
}

add_action( 'save_post_opportunity', 'nstxl_update_proposal_summery_meta_save' );







// $book = new OnePress_MetaBox();



// $book->add_meta_box(
//                 'onepress_page_settings',
//                 __( 'Page Settings', 'onepress' ),
//                 array( $this, 'render_meta_box_content' ),
//                 'opportunity',
//                 'side',
//                 'low'
//             );


/****************** Nstxl Suspended Users id *************************/

function nstxl_suspended_users(){
	global $wpdb;
	$sqlQuery = "SELECT DISTINCT u.ID FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id
	LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id
	LEFT JOIN nstxl_usermeta um2 ON u.ID = um2.user_id
	LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id
	WHERE 1=1 AND mu.status = 'active' " ;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$sqlQuery .= " AND (um2.meta_key = 'suspended_user' AND um2.meta_value NOT LIKE '%0%')";

	$theusers = $wpdb->get_results($sqlQuery); 
	foreach($theusers as $auser)
	{
		if (!empty($theusers) ) {
			$resultstr[]= $auser->ID; 

		}
	}
	if (!empty($theusers) ) {
		return $user_id = implode(",",$resultstr);
	}
	else
	{
		return $user_id = "";
	}
}


/** 
* Members by Tech Area count
*/

function nstxl_members_count_by_tech_area($tech_area){
	global $wpdb;

	if (!empty($tech_area)) {
		$condition = "AND um.meta_key ='primary_application' AND um.meta_value LIKE '%{$tech_area}%'";
	}

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users}  {$condition}  AND mu.status = 'active' " ;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$techarea_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $techarea_users ) ) {
		return $techarea_users;  
	}
	else
	{
		return $techarea_users = 0;
	}
}


/** 
* Members by Tech Area Total count
*/

function nstxl_members_count_by_tech_area_total(){
	global $wpdb;

	$condition = "AND um.meta_key ='primary_application'";

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users}  {$condition}  AND mu.status = 'active' " ;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$techarea_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $techarea_users ) ) {
		return $techarea_users; 
	}
	else
	{
		return $techarea_users = 0;
	}
}


/** 
* Members by company size count
*/

function nstxl_members_count_by_size($size_type){
	global $wpdb;

	if (!empty($size_type)) {
		$condition = "AND um.meta_key ='cnumberofemployees' AND um.meta_value LIKE '%{$size_type}%'";
	}

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users}  {$condition}  AND mu.status = 'active' " ;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
}

/** 
* Members by company size Total
*/

function nstxl_members_total_by_size(){
	global $wpdb;

	$condition = "AND um.meta_key ='cnumberofemployees'";

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users}  {$condition}  AND mu.status = 'active' " ;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
} 



/** 
* New Members by company size count
*/

function nstxl_members_count_by_size_today($size_type){
	global $wpdb;

	if (!empty($size_type)) {
		$condition = "AND um.meta_key ='cnumberofemployees' AND um.meta_value LIKE '%{$size_type}%'";
	}

	$date = date("Y-m-d", current_time("timestamp"));

	try {
//	$current_date = new DateTime($date.' 23:59:59');
		$current_date = new DateTime($date.' 00:00:00');   
	} catch (Exception $e) {
		echo $e->getMessage(); 
		exit(1);    
	}
	$current_date = $current_date->format('Y-m-d H:i:s');  

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users} {$condition}  AND mu.status = 'active' AND DATE(mu.startdate) = '{$current_date}'";

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
}



/** 
* New Members by company size count Total today
*/

function nstxl_members_count_by_size_today_total(){
	global $wpdb;

	$condition = "AND um.meta_key ='cnumberofemployees'";

	$date = date("Y-m-d", current_time("timestamp"));

	try {
		$current_date = new DateTime($date.' 00:00:00');   
	} catch (Exception $e) {
		echo $e->getMessage(); 
		exit(1);    
	}
	$current_date = $current_date->format('Y-m-d H:i:s');  

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	}

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users} {$condition}  AND mu.status = 'active' AND DATE(mu.startdate) = '{$current_date}'";;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
}


/** 
* Members by company type count
*/

function nstxl_members_count_by_company_type($company_type){
	global $wpdb;

	if (!empty($company_type)) {
		$condition = "AND um.meta_key ='corganization_type' AND um.meta_value LIKE '%{$company_type}%'";
	}

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	}

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users}  {$condition}  AND mu.status = 'active' " ;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$company_type_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $company_type_users ) ) {
		return $company_type_users; 
	}
	else
	{
		return $company_type_users = 0; 
	}
}


/** 
* Members by company type count Total
*/

function nstxl_members_count_by_company_type_total(){ 
	global $wpdb;

	$condition = "AND um.meta_key ='corganization_type'";

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	}

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users}  {$condition}  AND mu.status = 'active' " ;

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$company_type_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $company_type_users ) ) {
		return $company_type_users; 
	}
	else
	{
		return $company_type_users = 0; 
	}
}


/** 
* New Members by company type count 
*/

function nstxl_members_count_by_company_type_today($company_type){
	global $wpdb;

	if (!empty($company_type)) {
		$condition = "AND um.meta_key ='corganization_type' AND um.meta_value LIKE '%{$company_type}%'";
	}   

	$date = date("Y-m-d", current_time("timestamp"));

	try {
//	$current_date = new DateTime($date.' 23:59:59');
		$current_date = new DateTime($date.' 00:00:00');   
	} catch (Exception $e) {
		echo $e->getMessage(); 
		exit(1);    
	}
	$current_date = $current_date->format('Y-m-d H:i:s');  

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users} {$condition}  AND mu.status = 'active' AND DATE(mu.startdate) = '{$current_date}'";

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
}


/** 
* New Members by company type count Total Today 
*/

function nstxl_members_count_by_company_type_today_total(){
	global $wpdb;

	$condition = "AND um.meta_key ='corganization_type'";

	$date = date("Y-m-d", current_time("timestamp"));

	try {
//	$current_date = new DateTime($date.' 23:59:59');
		$current_date = new DateTime($date.' 00:00:00');   
	} catch (Exception $e) {
		echo $e->getMessage(); 
		exit(1);    
	}
	$current_date = $current_date->format('Y-m-d H:i:s');  

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users} {$condition}  AND mu.status = 'active' AND DATE(mu.startdate) = '{$current_date}'";

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
}


/** 
* New Members by Companies count over the past 30 days
*/

function nstxl_members_count_by_company_type_past_thirty_days($company_type){
	global $wpdb;

	if (!empty($company_type)) {
		$condition = "AND um.meta_key ='corganization_type' AND um.meta_value LIKE '%{$company_type}%'";
	}   

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users} {$condition}  AND mu.status = 'active' AND DATE(mu.startdate) BETWEEN NOW() - INTERVAL 30 DAY AND NOW()"; 

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";  

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
}

/** 
* New Members by Companies count over the past 30 days Total Count
*/

function nstxl_members_count_by_company_type_past_thirty_days_total(){
	global $wpdb;

	$condition = "AND um.meta_key ='corganization_type'";

	$exclude_users =  nstxl_suspended_users(); 

	if(!empty($exclude_users))
	{
		$exclude_users = "u.ID NOT IN (".$exclude_users.")";
	}
	else
	{
		$exclude_users = "1=1";    
	} 

	$sqlQuery = "SELECT count(DISTINCT u.ID) FROM nstxl_users u LEFT JOIN nstxl_usermeta um ON u.ID = um.user_id LEFT JOIN nstxl_usermeta um1 ON u.ID = um1.user_id LEFT JOIN nstxl_pmpro_memberships_users mu ON u.ID = mu.user_id WHERE {$exclude_users} {$condition}  AND mu.status = 'active' AND DATE(mu.startdate) BETWEEN NOW() - INTERVAL 30 DAY AND NOW()"; 

	$sqlQuery .= " AND (um1.meta_key = 'nstxl_capabilities' AND um1.meta_value NOT LIKE '%deleted_member%')";  

	$cnumberofemployees_users = $wpdb->get_var( $sqlQuery );
	if (!empty( $cnumberofemployees_users ) ) {
		return $cnumberofemployees_users; 
	}
	else
	{
		return $cnumberofemployees_users = 0;
	}
}  