<?php
/**
 * The template part for displaying single posts
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>	
	<div class="media">
      	<div class="media-left circel"><?php if (has_post_thumbnail( $post->ID ) )
			{ 
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); 
				 ?>
		  			<img src="<?php echo $image[0];?>" class="media-object" alt="singleblog">
				<?php 
			}
			else
			{
				?>
					<img  src="<?php bloginfo('template_directory');?>/images/logo-blog-detail.png" class="media-object" alt="singleblog" />
				<?php 
			}
			 ?>
		</div>
        <div class="media-body">
        	<?php the_title( '<h4 class="blog-hadding mt-2">', '</h4>' ); ?>
        	<p class="blog-timing gray-color"><span><img src="<?php bloginfo('stylesheet_directory'); ?>/images/gray-date.png" alt="graydate"></span> <?php the_time('M j, Y');?> <span class="ml-12"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/gray-admin.png" alt="grayuser"></span> <?php echo get_the_author();?> <br class="visible-xs"><span class="ml-12"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/gray-list.png" alt="graylist"></span> <?php 
					$post_categories = get_the_category( get_the_ID() );
					$i = 1;
					foreach ($post_categories as $post_category) {
						if($i!= 1) { echo $separator_cat = ', ';}					
						echo '<a href="'.get_term_link( $post_category ).'">'.$post_category->name.'</a>';
						$i++;
					}
					?></p>
        </div>
    </div>	
	<div class="content">
	<?php
			the_content();
			/*if(!empty(get_the_content()))
			{
				echo get_the_content();
			}
			else
			{
				echo "Pellentesque diam metus, dapibus id vulputate in, ultrices a dui. Proin scelerisque, nisl a vulputate sollicitudin, nibh velit venenatis enim, sit amet tempus ipsum arcu sit amet justo. Nam sed ante sed leo porttitor dictum euismod a nulla. Nullam mollis, diam vitae cursus malesuada.";
			}*/

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );			
		?>
		<span class="social">
		<?php //echo do_shortcode('[Sassy_Social_Share]'); ?>
		<span>
	</div>

</article><!-- #post-## -->
