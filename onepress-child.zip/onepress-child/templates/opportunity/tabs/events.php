<?php
$datePosted = get_field('nstxl_date_posted', get_the_ID());
$qusdeadline = get_field('nstxl_question_deadline', get_the_ID());
$industryday = get_field('nstxl_industry_day', get_the_ID());
$expected_question_posting = get_field('nstxl_expected_question_posting', get_the_ID());
$proposal_deadline = get_field('nstxl_proposal_deadline', get_the_ID());
$expected_date_of_award = get_field('nstxl_expected_date_of_award', get_the_ID());
if (!empty($datePosted) || !empty($qusdeadline) || !empty($industryday) || !empty($expected_question_posting) || !empty($proposal_deadline) || !empty($expected_date_of_award)) {
  ?>
  <div class="aside-card-content">
    <h3><?php _e('Important Dates', 'polar'); ?></h3>
    <ul>
      <?php if (!empty($datePosted)) { ?>
        <li><?php _e('Date Posted', 'polar'); ?>: <?php $idates = date("M d, Y g:i A", current_time(strtotime($datePosted))); 
        echo $idates;
        ?></li>
      <?php } ?>
      <?php if (!empty($qusdeadline)) { ?>
         <li><?php _e('Question Deadline', 'polar'); ?>: <?php $qd = date("M d, Y g:i A", current_time(strtotime($qusdeadline)));
          echo $qd;
         ?></li>
      <?php } ?>
      <?php if (!empty($industryday)) { ?>
        <li><?php _e('Industry Day', 'polar'); ?>: <?php echo $industryday; ?></li>
      <?php } ?>
      <?php if (!empty($expected_question_posting)) { ?>
        <li><?php _e('Expected Question Posting', 'polar'); ?>: <?php echo $expected_question_posting; ?></li>
      <?php } ?>
      <?php if (!empty($proposal_deadline)) { ?>
         <li><?php _e('Proposal Submission Deadline', 'polar'); ?>: <?php $psd = date("M d, Y g:i A", current_time(strtotime($proposal_deadline)));
        echo $psd;
         ?></li>
      <?php } ?>
      <?php if (!empty($expected_date_of_award)) { ?>
        <li><?php _e('Expected Date Of Award', 'polar'); ?>: <?php $adoa = date("M d, Y g:i A", current_time(strtotime($expected_date_of_award)));
        echo $adoa; ?></li>
      <?php } ?>
    </ul>
  </div>
<?php } ?>