<?php
/**
 * Template Name: registration
 */
get_header();

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */

do_action( 'onepress_page_before_content' );

//global $wpdb;
function RandomToken($length = 32) {
  if(!isset($length) || intval($length) <= 8 ){

    $length = 32;
  }
  if (function_exists('random_bytes')) {
    return bin2hex(random_bytes($length));
  }
  if (function_exists('mcrypt_create_iv')) {
    return bin2hex(mcrypt_create_iv($length, MCRYPT_DEV_URANDOM));
  }
  if (function_exists('openssl_random_pseudo_bytes')) {
    return bin2hex(openssl_random_pseudo_bytes($length));
  }
}


if(!is_user_logged_in()){
  $err = '';
  $success = '';
  global $wpdb, $PasswordHash, $current_user, $user_ID;
  $nstxl_company_request_table = $wpdb->prefix.'company_request';
  if (isset($_POST['registration_submit'])) {

  // Post values
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $password = sanitize_text_field($_POST['password']);
    $password2 = sanitize_text_field($_POST['password_confirm']);
    $username = sanitize_text_field($_POST['username']);
    $email = sanitize_text_field($_POST['email']);
    $email2 = sanitize_text_field($_POST['email_confirm']);
    $company_name = $_POST['company_name'];  
    if(!empty($company_name)) {
  //$query = "SELECT * FROM {$wpdb->usermeta} WHERE `meta_key` LIKE 'company_name' AND `meta_value` LIKE '{$company_name}' ORDER BY `umeta_id` DESC";
  //$company_name_match = $wpdb->get_results($query);
 //echo $query = "SELECT * FROM {$wpdb->usermeta} WHERE `meta_key` LIKE 'company_name' AND `meta_value` LIKE '{$company_name}' ORDER BY `umeta_id` ASC Limit 0,1";
      $query = "SELECT * FROM {$wpdb->usermeta} WHERE `meta_key` LIKE 'company_name' AND `meta_value` LIKE '{$company_name}'  ORDER BY `umeta_id` ASC LIMIT 1";  
      $company_name_match = $wpdb->get_row($query);
    }
  /**
   * IMPORTANT: You should make server side validation here!
   *
   */

// Recaptcha validate
  if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) { 
$secret = '6LdqTcIUAAAAALRM7ylQI2_YM1g7P2-vXjoSRCNp'; //secret key
// create a new cURL resource
$handle=curl_init('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
curl_setopt($handle, CURLOPT_VERBOSE, true);
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
$content = curl_exec($handle);
    // close cURL resource, and free up system resources
curl_close($handle);
if (!empty($content)) { 
  $responseData = json_decode($content);
  $success_resp = $responseData->success;     
} 
}


if ($email == "" || $username == "" || $password == "" || $first_name == "" || $last_name == "" || $company_name == "") {
  $err = 'Please don\'t leave the required fields.';
} else if(empty($_POST['g-recaptcha-response'])){
 $err = 'reCAPTCHA is mandatory.';
} else if(empty($success_resp)){
 $err = 'Please enter a valid reCAPTCHA.';
} else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $err = 'Invalid email address.';
} else if (email_exists($email)) {
  if ( $user = get_user_by( 'email', $email) ) {
   $role = $user->roles[0];
   if($role == 'deleted_member' || $role == 'deleted_subscriber'){
    $err = 'blocked';
  }else {
    $err = 'true'; 
  }
}else{
  $err = 'true';
}
    //$err = 'Looks like you are already registered. Please <a href="'.home_url('/login').'">&nbsp;log in </a> with your password.';

wp_redirect( home_url().'/login?err='.$err);
exit();
} else if (username_exists($username)) {
  $err = 'true';
  wp_redirect( home_url().'/login?err='.$err);
  exit();
} else if ($password <> $password2) {
  $err = 'Password do not match.';
} else if ($email <> $email2) {
  $err = 'Email do not match.';
} else if (!empty($company_name_match)) {
  $cmp_user_id =  $company_name_match->user_id;
  if(!empty($cmp_user_id)) {

   $cmp_meta = get_userdata($cmp_user_id);
   $cmp_roles = $cmp_meta->roles;
   $cmprole = $cmp_roles[0];

   if($cmprole == 'deleted_member' || $cmprole == 'deleted_subscriber'){
    $err = 'blocked';
    wp_redirect( home_url().'/login?err='.$err);
    exit();
  }else {
    $err = 'org_exists.'; 
  }
  //echo'pocid <br/>'. $poc_user_id = get_user_meta($cmp_user_id,'poc',true);

  $poc_user_id = get_user_meta($cmp_user_id,'poc',true); 
  if(empty($poc_user_id)){
    $puid = nstxl_get_parent_userid($cmp_user_id);      
    $poc_user_id = get_user_meta($puid,'poc',true); 
  } else {
    $poc_user_id = $poc_user_id;
  }
  //if (!empty($poc_user_id)) { 
    //echo'pocuidiF <br/>';
  $poc_user_data = get_userdata($poc_user_id);
          //print_r($poc_user_data);
  if(!empty($poc_user_data)){
    $poc_user_first_name = $poc_user_data->first_name;
    $poc_user_last_name = $poc_user_data->last_name;
    $poc_user_email = $poc_user_data->user_email; 
    $confirmkey = RandomToken(12); 

    $query_array = array('id' => NULL,'firstname' => $first_name, 'lastname' => $last_name, 'username' => $username, 'company' => $company_name, 'email' => $email, 'confirmkey' => $confirmkey,'confirmed' => '0', 'created' => '0', 'createddate' => current_time('mysql', 1));
    $wpdb->insert($nstxl_company_request_table,$query_array);         
    $confirm_request_link = get_site_url().'/confirm-request/?cmprequestkey='.$confirmkey;
    ?>         
    <!-- Modal -->
    <div class="modal fade custom-popup" id="organization-modal" tabindex="-1" role="dialog" aria-labelledby="organization-modalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-body">
           <button type="button" class="close" data-dismiss="modal" aria-label="Close" aria-hidden="true"><span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span></button> 
           <h4 class="color-red">Good news!</h4><h4> We think your organization is already a member.</h4>
           <div class="org-inner-content modal-body-container">
            <p>Click <a href="#" data-poc-email='<?php echo $poc_user_email; ?>' data-user-email="<?php echo $email; ?>" data-user-firstname="<?php echo $first_name; ?>" data-user-lastname="<?php echo $last_name; ?>" data-user-username="<?php echo $username; ?>" poc-user-firstname="<?php echo $poc_user_first_name;?>" data-confirm-request-link ="<?php echo $confirm_request_link; ?>"              
              poc-user-lastname="<?php echo $poc_user_last_name; ?>"
              data-company-name="<?php echo $company_name; ?>"   class="org-request-link">here</a> to request access from <b><?php echo $company_name; ?></b>&nbsp;Point of Contact, <b><?php  echo ucfirst($poc_user_first_name); ?></b>&nbsp;<b><?php echo ucfirst($poc_user_last_name); ?></b>.
              Once the Point of Contact has confirmed your access, you’ll receive an email from us to continue registering yourself.
            </p>
          </div>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

  <!-- Modal -->
  <div class="modal fade custom-popup" id="organization-modal-success" tabindex="-1" role="dialog" aria-labelledby="organization-modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" aria-hidden="true"><span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span></button> 
         <div class="organization-box-success-container modal-body-container text-center">
          <h4>Your request has been submitted successfully.</h4>
          <button style="text-align: center;" type="button" data-target="<?php echo get_site_url(); ?>" class="org-modal-ok btn-txt" aria-hidden="true">Ok</button>   </div>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->


<?php }
// } else{
//   echo"pocnotfound";
// }
}

} else {
  $user_id = wp_insert_user(array('first_name' => apply_filters('pre_user_first_name', $first_name), 'last_name' => apply_filters('pre_user_last_name', $last_name), 'user_pass' => apply_filters('pre_user_user_pass', $password), 'user_login' => apply_filters('pre_user_user_login', $username), 'user_email' => apply_filters('pre_user_user_email', $email), 'role' => 'subscriber'));
  if (is_wp_error($user_id)) {
    $err = 'Error on user creation.';
  } else {
    update_user_meta($user_id, "poc", $user_id);
    update_user_meta($user_id, "puid", $user_id);
    update_user_meta($user_id, "company_name", $company_name);
    $usr_data = array(
      'first_name' => $first_name,
      'last_name' => $last_name,
      'user_login' => $username,
      'user_email' => $email,
      'company_name' => $company_name,      
      'user_pass' => $password  // When creating an user, `user_pass` is expected.
    );
    nstxl_prepare_user_email($usr_data);		
    do_action('user_register', $user_id);
		//nstxl_send_users_as_monday_item( $user_id );
    constant_contact_custom_request( $user_id );
    $success = 'You\'re successfully register';
    $creds = array();
    $creds['user_login'] = $username;
    $creds['user_password'] = $password;
      //$creds['remember'] = true;
    $user = wp_signon( $creds, false );
    if ( is_wp_error($user) ){
      echo $user->get_error_message();
    }else{     
      if(!empty($success)) { // wp_redirect( home_url().'/membership-account/membership-levels/');      
      //exit(); ?>
      <script>jQuery(window).load(function(){ jQuery('#register-modal-success').modal('show'); jQuery('.close').click( function(){
        window.location.href= jQuery(this).data('target');
      });
    });</script>   

    <!-- Modal -->
    <div class="modal fade custom-popup" id="register-modal-success" tabindex="-1" role="dialog" aria-labelledby="register-modalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-body">
           <button type="button" class="close" data-target="<?php  echo home_url('/membership-account/membership-levels/'); ?>" data-dismiss="modal" aria-label="Close" aria-hidden="true"><span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span></button> 
           <div class="organization-box-success-container modal-body-container text-center">
            <h4 class="color-red">Thank you! </h4><h4>You have been registered.</h4>
            <p style="text-align: center;font-family: inherit;color: #333333;">You will receive an email confirmation shortly. For any question please contact us via our <a target="_blank" href="<?php echo get_site_url(); ?>/contact-us/">contact form</a>.</p>
          </div>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- /.modal -->

<?php } else {
        //wp_redirect( home_url().'/singup/?success=false&msg='.$err );
        //exit();
}  
}
}
}
}
?>
<div id="content" class="site-content form-page register-page">



<div class="clearfix"></div>
<div class="reg-form-container clearfix"><!-- REGISTRATION FORM -->
  <div class="text-center">
   <?php /* ?> <div class="logo"><h3>Register Now</h3></div> <?php */ ?>
   <!-- Main Form -->
   <div class="registration-form">
    <form id="register-form" method="post" class="text-left">
        <section>
<div class="qualification-member">
<div class="container">
<h2>Check all to qualify for membership and ensure that your company is in compliance</h2>
<ul>
 <li>
<div class="custom-control custom-checkbox">
<input id="question1" name="question1" type="checkbox" value="1" class="custom-control-input">
<label class="custom-control-label" for="question1">Corporate, academic, or non-profit organizations with solutions in technology areas covered by NSTXL OTAs</label>
</div>
</li>
 <li>
<div class="custom-control custom-checkbox">
<input id="question2" name="question2" type="checkbox" value="1" class="custom-control-input">
<label class="custom-control-label" for="question2">Organization must be permitted to do business with the US federal government.</label>
</div>
</li>
 <li>
<div class="custom-control custom-checkbox">
<input id="question3" name="question3" type="checkbox" value="1" class="custom-control-input">
<label class="custom-control-label" for="question3">Organization must agree to <a href="<?php echo site_url(); ?>/wp-content/uploads/2019/01/NSTXL-Principles-of-Engagement-Sept-2018.pdf" target="_blank">Principles of Engagement</a>.</label>
</div>
</li>

</ul>
</div>
</div>

</section>

      <div class="login-form-main-message"></div>
      <div class="container">
      <div class="main-login-form">
        <div class="row login-group">                                      
          <div class="form-group col-sm-6">
            <label for="first_name"><?php _e('First name','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="text" required="" value="<?php if(isset($first_name) && !empty($first_name)){ echo $first_name;
            } ?>" class="form-control" id="first_name" name="first_name">
          </div>
          <div class="form-group col-sm-6">
            <label for="last_name"><?php _e('Last name','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="text" required="" value="<?php if(isset($last_name) && !empty($last_name)){ echo $last_name;
            } ?>" class="form-control" id="last_name" name="last_name">
          </div>                                  
          <div class="form-group col-sm-12">
             <label for="username"><?php _e('Username','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="text" required="" value="<?php if(isset($username) && !empty($username)){ echo $username;
            } ?>" class="form-control" id="user_name1" name="username">
           
          </div>
          <div class="form-group col-sm-12">
            <label for="company_name"><?php _e('Company','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="text" required="" value="<?php if(isset($company_name) && !empty($company_name)){ echo $company_name;
            } ?>" class="form-control" id="company_name" name="company_name">
          </div>   
          <div class="form-group col-sm-6">
            <label for="email"><?php _e('Email','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="email" required="" value="<?php if(isset($email) && !empty($email)){ echo $email; } ?>"  class="form-control" id="reg_email1" name="email">
          </div>

          <div class="form-group col-sm-6">
             <label for="email_confirm"><?php _e('Confirm Email','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="email" required="" value="<?php if(isset($email2) && !empty($email2)){ echo $email2; } ?>" class="form-control" id="email_confirm" name="email_confirm">
          </div>

          <div class="form-group col-sm-6">
            <label for="password"><?php _e('Password','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="password" required="" class="form-control" id="password" name="password">  
          </div>
          <div class="form-group col-sm-6">
            <label for="password_confirm"><?php _e('Confirm password','paid-membership-pro'); ?><span class="required" aria-required="true"> *</span></label>
            <input type="password" required="" class="form-control" id="password_confirm" name="password_confirm">
          </div>	

          <div class="col-sm-12 passwordmeter">
            <span id="password-strength"></span>  
            <span class="pasindicator">
             <strong>Hint : </strong>The password should be at least nine characters long. To make it stronger,
             use upper</br> case and lower case letters, numbers and symbols like !"?$%^&). 
           </span>
         </div> 

          <div class="col-sm-12">
              <div class="form-group">  
                <p>
                  <div class="g-recaptcha" id="recaptcha" data-sitekey="6LdqTcIUAAAAAFvtcVWAGOzIjND6qzChkYsDbcdE" data-callback="vcc"></div>
                  <label class="captcha-error error" style="color:#a94442"></label>
                </p>
                         <!--display error/success message-->
  <div id="message">
    <?php
    if (!empty($err)) {
      //if($err === 'org_exists.') { 
      if (strpos($err, 'org_exists.') !== false) { ?>
        <script>jQuery(window).load(function(){
        //   setTimeout(function(){
          jQuery('#organization-modal').modal('show');      
        // }, 500);
      });          
    </script>
  <?php } else {
    echo '<p style="color:red" class="error">' . $err . '';
  }

}    
?>

<?php
if (!empty($success)) :
      //echo '<p style="color:red" class="success">' . $success . '';
endif;
?>
</div> 
              </div>
          </div>



      	
      
          <div class="form-group col-sm-12">
            <input name="registration_submit" type="submit" class="login-button" value="Start Application"><span id="pmpro_processing_nextstep" style="visibility: hidden;"><img src="/wp-content/plugins/nstxl-memberhip-extension/images/Reloader.gif"></span></div>
          </div>
       
        </div>
          </div>
        </form>
      </div>
      <!-- end:Main Form -->
    </div>
  </div>

</div>

 

<!--- Modal -->
<div id="joinnow-modal-success" class="modal fade custom-popup" style="display: none; padding-right: 10px;" tabindex="-1" role="dialog" aria-labelledby="organization-modalLabel" aria-modal="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
          </button><div class="modal-body-container"><h4>Check all to qualify for membership.</h4></div>
      </div>
    </div>
  </div>
</div>
<!--- Modal -->

<!-- <script type="text/javascript">
     jQuery(function () {
        jQuery('input[name=registration_submit]').click(function(e){
          var isChecked1 = jQuery("#question1").is(":checked");
          var isChecked2 = jQuery("#question2").is(":checked");
          var isChecked3 = jQuery("#question3").is(":checked");
          if (isChecked1 && isChecked2 && isChecked3) {
           jQuery('#joinnow-modal-success').modal('hide');

        } else {
          jQuery('#joinnow-modal-success').modal('show');
          }
        });
  });
</script> -->



<script>
 var vcc = function(g_recaptcha_response) {
   var $captcha = jQuery( '#recaptcha' );

   jQuery( '.captcha-error' ).text('');
   $captcha.removeClass( "error" );
 };
</script> 
<script>
  var ajaxUrl = '<?php echo admin_url("admin-ajax.php"); ?>';
</script>
<script>jQuery(document).ready(function ($) {
  "use strict";

    // Options for Message
    //----------------------------------------------
    var options = {
      'btn-loading': '<i class="fa fa-spinner fa-pulse"></i>',
      'btn-success': '<i class="fa fa-check"></i>',
      'btn-error': '<i class="fa fa-remove"></i>',
      'msg-success': 'All Good! Redirecting...',
      'msg-error': 'Wrong login credentials!',
      'useAJAX': false,
    };
    
// Register Form
//----------------------------------------------
// Validation
$("#register-form").validate({
  rules: {
    // user_name: {
    //   required: true,
    //   minlength: 5,
    //   remote: {
    //     url: ajaxUrl+'?action=nstxl_check_username',
    //     dataType: 'post',
    //     data: {
    //       'username': $('#username').val()
    //     },
    //     success: function (response) {
    //       if (response.data.status == 'available')
    //       {
    //         message: {
    //           username: 'The username is already in use!'
    //         }
    //       } else {
    //         message: {
    //           username: 'The username Available!'
    //         }
    //       }
    //     }
    //   }
    // },
            username: {
          required: true,
          minlength: 5,
          remote: {
            url: nstxl_ajaxurl,
            type: 'post',
            data: {
              action: 'nstxl_check_userbemail',
              username: function () {
                return $("#register-form input[name='username']").val();
              }
            },
          }
        },
    password: {
      required: true,
      minlength: 5
    },
    company_name:{
      required: true,
    },
    password_confirm: {
      required: true,
      minlength: 5,
      equalTo: "#register-form [name=password]"
    },
            email: {
          required: true,
         // validemail: true,
          remote: {
            url: nstxl_ajaxurl,
            type: 'post',
            data: {
              action: 'nstxl_check_userbemail',
              semail: function () {
                return $("#register-form input[name='email']").val();
              }
            },
          }
        },
    email_confirm: {
      required: true,
      email: true,
      equalTo: "#register-form [name=email]"
    },
    reg_agree: "required",
  }, messages: { 
    company_name:{
      required: "Please enter the Company Name",
    },
      username: {
          required: "Please enter the Username",
          remote: 'Username is already taken.'
        },
     email: {
          required: "Please enter the Email",
          //validemail: "Please enter the valid Email",
          remote: 'Email is already taken.'
        },           
    email_confirm: {
      equalTo: "Emails do not match.",                
    },
    password_confirm: {
      equalTo: "Password do not match.",                
    },
  },
  errorClass: "form-invalid",
  errorPlacement: function (label, element) {
    if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
      console.log(element);
      console.log(label);
          element.parent().append(label); // this would append the label after all your checkboxes/labels (so the error-label will be the last element in <div class="controls"> )
        } else {
          //label.insertAfter(element); // standard behaviour
          element.parent().append(label);
        }
      }
    });

    // Form Submission
    $("#register-form").submit(function () {
         var isChecked1 = jQuery("#question1").is(":checked");
          var isChecked2 = jQuery("#question2").is(":checked");
          var isChecked3 = jQuery("#question3").is(":checked");
          if (isChecked1 && isChecked2 && isChecked3) {
           jQuery('#joinnow-modal-success').modal('hide');
           return true;

        } else {
          jQuery('#joinnow-modal-success').modal('show');
          return false;
          }

      remove_loading($(this));

      if (options['useAJAX'] == true)
      {
        // Dummy AJAX request (Replace this with your AJAX code)
        // If you don't want to use AJAX, remove this
        // dummy_submit_form($(this));

        // Cancel the normal submission.
        // If you don't want to use AJAX, remove this
        // return false;
      }
      //     $(this).submit();        
      var $form = $(this);

      // Captcha validatio start
      var $captcha = jQuery( '#recaptcha' ),
      response = grecaptcha.getResponse();
      
      if (response.length === 0) {
        jQuery( '.captcha-error').text( "reCAPTCHA is mandatory" );
        if( !$captcha.hasClass( "error" ) ){
          $captcha.addClass( "error" );
        }
        return false;
      } else {
                  //alert(response.length);
                  jQuery( '.captcha-error' ).text('');
                  $captcha.removeClass( "error" );

                }
        // Captcha validatio End

        if ($form.valid()) {
       // form_loading($form);
        //console.log($form);       
        jQuery('.nstxl-loader').show();
        jQuery('.loader-overlay').show();
        setTimeout(function () {
          //form_success($form);
          jQuery('.nstxl-loader').hide();
          jQuery('.loader-overlay').hide();
        }, 2000);
      } else {
        jQuery('.nstxl-loader').hide();
        jQuery('.loader-overlay').hide();
        jQuery('html,body').animate({ scrollTop: jQuery('.form-control.form-invalid').first().offset().top -120 },'slow');
      }
    });

    // Forgot Password Form
    //----------------------------------------------
    // Validation
    $("#forgot-password-form").validate({
      rules: {
        fp_email: "required",
      },
      errorClass: "form-invalid"
    });

    // Form Submission
    $("#forgot-password-form").submit(function () {
      remove_loading($(this));

      if (options['useAJAX'] == true)
      {
        // Dummy AJAX request (Replace this with your AJAX code)
        // If you don't want to use AJAX, remove this
        dummy_submit_form($(this));

        // Cancel the normal submission.
        // If you don't want to use AJAX, remove this
        return false;
      }
    });

    // Loading
    //----------------------------------------------
    function remove_loading($form)
    {
      $form.find('[type=submit]').removeClass('error success');
      $form.find('.login-form-main-message').removeClass('show error success').html('');
    }

    function form_loading($form)
    {
      $form.find('[type=submit]').addClass('clicked').html(options['btn-loading']);
    }

    function form_success($form)
    {
      $form.find('[type=submit]').addClass('success').html(options['btn-success']);
      $form.find('.login-form-main-message').addClass('show success').html(options['msg-success']);
    }

    function form_failed($form)
    {
      $form.find('[type=submit]').addClass('error').html(options['btn-error']);
      $form.find('.login-form-main-message').addClass('show error').html(options['msg-error']);
    }

    // Dummy Submit Form (Remove this)
    //----------------------------------------------
    // This is just a dummy form submission. You should use your AJAX function or remove this function if you are not using AJAX.
    function dummy_submit_form($form)
    {
      if ($form.valid())
      {
        form_loading($form);
        console.log($form);

        setTimeout(function () {
          form_success($form);
        }, 2000);
      }
    }
    jQuery('#register-modal-success').on('hidden.bs.modal', function () {    
      //location.reload(true);
      window.location.href ="<?php echo home_url('/membership-account/membership-levels/'); ?>";
    });  
  });</script>
<?php } else { ?>
  <div id="content" class="site-content">
    <div class="logged-in-message"><p> Already logged in please <a href="<?php echo home_url('/membership-account/membership-levels/'); ?>"><?php _e('click here','paid-membership-pro'); ?></a> to access the membership level page.</p></div>

  </div>
<?php } ?>
<script src='https://www.google.com/recaptcha/api.js'></script>
<?php $cmpnames = nstxl_get_all_active_company();?>
<script>
  jQuery(document).ready(function($){
   availableTags = <?php echo $cmpnames; ?>;
// Implemented the autocomplete
jQuery('#company_name').autoComplete({
  minChars: 1,
  delay: 0,
  source: function(term, suggest){
    term = term.toLowerCase();
    var i;
    var choices = availableTags;
    var matches = [];
    for (i=0; i<choices.length; i++)
      if (~choices[i].toLowerCase().indexOf(term)) matches.push(choices[i]);
    suggest(matches);
  }
});
}); 
</script>
<?php

get_footer();

