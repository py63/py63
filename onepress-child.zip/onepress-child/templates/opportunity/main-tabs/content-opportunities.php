<?php
/**
 * Template part for displaying page content in opportunity.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package OnePress
 */
global $post;

$posttitle = get_field('nstxl_short_title', get_the_ID());
$wordcount = str_word_count($posttitle);
if (empty($termID)) {
  $term_list = wp_get_post_terms(get_the_ID(), 'opportunity-type', array('fields' => 'ids'));
  $termID = $term_list[0];
}
?>
<div class="card">
  <article id="post-<?php the_ID(); ?>" <?php echo post_class('opportunity-post opportunity-isotope-item') ?>>
    <?php
     if ($termID == '40') { echo nstxl_proposal_due_soon_tag(get_the_ID()); }
    $proposal_deadline_date = get_post_meta(get_the_ID(), 'nstxl_proposal_deadline', true);
    $featuredimageshow = 0;
    if ($featuredimageshow == 1) {
      if (has_post_thumbnail()) {
//        echo '<div class="featured-media"><a href="' . esc_url(get_permalink()) . '">';
//        the_post_thumbnail('polar_grid_thumbnail_fixed', array('class' => 'featured-image'));
//        echo '</a></div>';
        /* grab the url for the full size featured image */
        $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'medium');

        /* link thumbnail to full size image for use with lightbox */
        echo '<a href="' . esc_url(get_permalink()) . '">';
        echo '<img class="card-img-top" data-src="' . $featured_img_url . '" alt="100%x200" style="height: 200px; width: 100%; display: block;" src="' . $featured_img_url . '" data-holder-rendered="true">';
        echo '</a>';
      } else {
        echo '<a href="' . esc_url(get_permalink()) . '">';
        echo '<img class="card-img-top" src="' . get_bloginfo('stylesheet_directory') . '/images/placeholder.png" data-holder-rendered="true" />';
        echo '</a>';
      }
    }
    echo '<div class="featured-media">' . get_ota_logos() . '</div>';
    ?>
    <div class="card-body">
      <h4 class="card-title"><?php if ($wordcount > 10) { ?> 
          <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo wp_trim_words($posttitle, 10, ''); ?></a>
        <?php } else { ?>
          <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo $posttitle; ?></a>
        <?php } ?></h4>
      <div class="entry-excerpt"><p class="card-text"><?php echo wp_trim_words(get_the_content(), 12, ''); ?></p></div>
      <?php /* ?><p class="card-text tags">#Tag Name #Tag Name</p><?php */ ?>
      <div class="ota-list-section">      
        <a class="card-link documentsmodal" href="#" data-toggle="modal" data-target="#key-documents-modal-<?php echo get_the_ID(); ?>"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/documents.svg"><?php _e('Documents', 'onepress'); ?></a>
        <?php
        if (is_user_logged_in()) {
          global $current_user;
          $cusr_id = $current_user->ID;
          $trckid = get_the_ID();
          $mytrackIDs = get_user_meta($cusr_id, 'myopportunitiesposts', true);
          if (!empty($mytrackIDs)) {
            if (in_array($trckid, $mytrackIDs)) {
              ?>
              <a class="untrackopportunity card-link" data-id="<?php echo get_the_ID(); ?>" href="#"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/track.svg"><?php _e('Tracked', 'onepress'); ?></a>
            <?php } else { ?>
              <a href="#" class="trackopportunity card-link" data-id="<?php echo get_the_ID(); ?>"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/track.svg"><?php _e('Track Opportunity', 'onepress'); ?></a>
              <?php
            }
          } else {
            ?>      
            <a href="#" class="trackopportunity card-link" data-id="<?php echo get_the_ID(); ?>"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/track.svg"><?php _e('Track Opportunity', 'onepress'); ?></a>   
            <?php
          }
        } else {
          ?>    
          <a class="card-link" href="<?php echo get_bloginfo('url'); ?>/login?redirect_to=<?php echo urlencode(get_bloginfo('url') . '/tracked-opportunities'); ?>"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/track.svg"><?php _e('Track Opportunity', 'onepress'); ?></a>
        <?php } ?>   
          <a href="" class="card-link event-date-modal" data-toggle="modal" data-target="#event-date-modal-<?php echo get_the_ID(); ?>"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/calendar.svg"><?php _e('Due', 'onepress'); ?><?php if(!empty($proposal_deadline_date)){ echo '<span class="date">&nbsp'.date("m/d/Y", strtotime($proposal_deadline_date)).'</span>';} else { echo''; } ?><!-- <img class="arrow" src="<?php // echo get_bloginfo('stylesheet_directory'); ?>/assets/images/down-arrow.svg"> --> 
        </a>
        <?php if (($termID == '40') || ($termID == '43')) { 
         if(is_page('dashboard-submit-question')) { ?>
        <a href="<?php echo site_url() ?>/submit-question?oppid=<?php echo get_the_ID(); ?>" class="card-link submitquestionlink"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/submit question.svg"><?php _e('Submit a Question', 'onepress'); ?></a>
        <?php } else { ?>
        <a href="" class="card-link submitquestionlink" data-toggle="modal" data-target="#submit-question-modal-<?php echo get_the_ID(); ?>"><img src="<?php echo get_bloginfo('stylesheet_directory'); ?>/images/submit question.svg"><?php _e('Submit a Question', 'onepress'); ?></a>
      <?php }
} 
       ?>
        <?php
        /*    if ($termID == '40') { ?>
          <div class="submit-button-section">
          <?php if (is_user_logged_in()) { ?>
          <a class="btn btn-secondary-outline btn-lg" href="<?php echo get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID(); ?>"><?php _e('Submit a Proposal', 'onepress'); ?></a>
          <?php } else { ?>
          <a class="btn btn-secondary-outline btn-lg" href="<?php echo get_bloginfo('url'); ?>/login?redirect_to=<?php echo urlencode(get_bloginfo('url') . '/submit-aproposal?opid=' . get_the_ID()); ?>"><?php _e('Submit a Proposal', 'onepress'); ?></a>
          <?php } ?>
          </div>
          <?php
          } */
        ?>  
        <?php if ($termID == '40') {
          include(locate_template('templates/opportunity/sidebar/submitproposal.php'));
        } ?>

      </div>
    </div>
    <!-- the title, the content etc.. -->
  </article>
</div>
<?php
$track_modal_id = 'track-opportunity-modal-' . get_the_ID();
$track_modal_body_container_class = 'track-opportunity-modal-container';
$track_content_html = '';
nstxl_modal_popup($track_content_html, $track_modal_id, $track_modal_body_container_class);
$keydoc_modal_id = 'key-documents-modal-'.get_the_ID();
?>  
<!-- submit question Modal -->
<div class="modal fade custom-popup" id="submit-question-modal-<?php echo get_the_ID(); ?>" data-id="<?php echo get_the_ID(); ?>" tabindex="-1" role="dialog" aria-labelledby="submit-question-modal-success" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo get_the_title(); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
        </button>
      </div>
      <div class="modal-body">

        <div class="submit-quetion-box-success-container modal-body-container">

          <?php include(locate_template('templates/opportunity/sidebar/submitquestion.php')); ?>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 

<!-- Keydocuments popup -->
<div class="modal fade custom-popup" id="key-documents-modal-<?php echo get_the_ID(); ?>" data-id="<?php echo get_the_ID(); ?>" tabindex="-1" role="dialog" aria-labelledby="submit-question-modal-success" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
        </button>
        <div class="modal-body-container key-documents-modal-container">
          <?php include(locate_template('/templates/opportunity/sidebar/keydocuments.php')); ?>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 


<!-- Event-date-modal Modal -->
<div class="modal fade custom-popup" id="event-date-modal-<?php echo get_the_ID(); ?>" data-id="<?php echo get_the_ID(); ?>" tabindex="-1" role="dialog" aria-labelledby="event-date-modal-success" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo get_the_title(); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
        </button>
      </div>
      <div class="modal-body">
        <div class="event-date-modal-box-success-container modal-body-container">
          <?php include(locate_template('templates/opportunity/sidebar/eventdates.php')); ?>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 

<script type="text/javascript">
  jQuery(document).ready(function ($) {
    jQuery('#<?php echo $track_modal_id; ?> .close').on('click', function (e) {
      jQuery('#<?php echo $track_modal_id; ?>').modal('hide');
    });
    jQuery('#<?php echo $track_modal_id; ?>').on('hidden.bs.modal', function () {
      location.reload(true);
    })
  });
   jQuery(document).ready(function ($) {
    jQuery('#<?php echo $keydoc_modal_id; ?> .close').on('click', function (e) {
      jQuery('#<?php echo $keydoc_modal_id; ?>').modal('hide');
    });
    jQuery('#<?php echo $keydoc_modal_id; ?>').on('hidden.bs.modal', function () {
      location.reload(true);
    })
  }); 
</script>