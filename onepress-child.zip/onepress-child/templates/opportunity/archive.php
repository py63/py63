<?php
global $current_user;
$cusr_id = $current_user->ID;
$query_object = get_queried_object();
$termID = $query_object->term_id;
$posts_per_page = get_option('posts_per_page');
?>
<div class='polar-content gray-back section-space polar-content-blog'>
  <div class="container polar-content-container">  
    <!-- Blog Query  -->
    <div class="polar-posts">

      <?php
      $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
// $args =  array( 'post_type' => 'opportunity','posts_per_page' => 6, 'paged' => $paged);
//  query_posts($args); 
      $args = array(
          'post_type' => 'opportunity',
          'posts_per_page' => 6, 'paged' => $paged,
          'tax_query' => array(
              array(
                  'taxonomy' => 'opportunity-type',
                  'field' => 'term_id',
                  'terms' => $termID,
              ),
          ),
      );
      $Newquery = new WP_Query($args);
      ?>
      <div class='row'>
        <!-- the loop -->
        <?php
        if ($Newquery->have_posts()) : while ($Newquery->have_posts()) : $Newquery->the_post();
            $posttitle = get_field('nstxl_short_title', get_the_ID());
            $wordcount = str_word_count($posttitle);
            ?>
            <div class="col-sm-6 col-md-4 wow animated fadeInUp">
              <article id="post-<?php the_ID(); ?>" <?php echo post_class('polar-post polar-isotope-item') ?>>
                <?php
                if (has_post_thumbnail()) {
                  echo '<div class="featured-media"><a href="' . esc_url(get_permalink()) . '">';
                  the_post_thumbnail('polar_grid_thumbnail_fixed', array('class' => 'featured-image'));
                  echo '</a></div>';
                } else {
                  echo '<div class="featured-media"><a href="' . esc_url(get_permalink()) . '">';
                  echo '<img src="' . get_bloginfo('stylesheet_directory') . '/assets/images/placeholder.png" />';
                  echo '</a></div>';
                }
                ?>
                <div class="card-content">
                  <p class='post-title single-line-title'>
                    <?php if ($wordcount > 8) { ?> 
                      <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo wp_trim_words($posttitle, 8, ''); ?></a>
                    <?php } else { ?>
                      <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo $posttitle; ?></a>
                    <?php } ?>
                  </p>
                  <ul class="opporutnity-info-list">
                    <li>
                      <a href="<?php echo esc_url(get_permalink()); ?>#events-md"><img src="/wp-content/uploads/2018/11/Dates-and-events.png">Dates and Events</a>
                    </li>
                    <li>
                      <a href="<?php echo esc_url(get_permalink()); ?>#keydocuments-md"><img src="/wp-content/uploads/2018/11/key-documents.png">Key Documents</a>
                    </li>
                    <li>
                      <a href="<?php echo esc_url(get_permalink()); ?>#submitquestion-md"><img src="/wp-content/uploads/2018/11/submit-a-question.png">Submit a Question</a>
                    </li>

                    <li>
                      <a href="<?php echo esc_url(get_permalink()); ?>#submitproposal-md"><img src="/wp-content/uploads/2018/11/submit-a-proposal.png">Submit a Proposal</a>
                    </li>
                    <li>
                      <a href="<?php echo esc_url(get_permalink()); ?>#overview-md"><img src="/wp-content/uploads/2018/11/updates.png">Updates</a>
                    </li>
                    <li>
                      <?php
                      if (is_user_logged_in()) {
                        $trckid = get_the_ID();
                        $mytrackIDs = get_user_meta($cusr_id, 'myopportunitiesposts', true);
                        if (!empty($mytrackIDs)) {
                          if (in_array($trckid, $mytrackIDs)) {
                            ?>
                            <a class="untrackopportunity" data-id="<?php echo get_the_ID(); ?>" href="#"><img src="/wp-content/uploads/2018/11/track-opportunity.png"><?php _e('Untrack Opportunity', 'polar'); ?></a>
                          <?php } else { ?>
                            <a href="#" class="trackopportunity" data-id="<?php echo get_the_ID(); ?>"><img src="/wp-content/uploads/2018/11/track-opportunity.png"><?php _e('Track Opportunity', 'polar'); ?></a>
                            <?php
                          }
                        } else {
                          ?>      
                          <a href="#" class="trackopportunity" data-id="<?php echo get_the_ID(); ?>"><img src="/wp-content/uploads/2018/11/track-opportunity.png"><?php _e('Track Opportunity', 'polar'); ?></a>   
                          <?php
                        }
                      } else {
                        ?>    
                        <a href="<?php echo esc_url(get_bloginfo('url')); ?>/login"><img src="/wp-content/uploads/2018/11/track-opportunity.png"><?php _e('Track Opportunity', 'polar'); ?></a>
                      <?php } ?>   
                    </li>
                  </ul>
                </div>
                <!-- the title, the content etc.. -->
              </article>
            </div>
          <?php endwhile; ?></div>
      <?php else : ?>
        <!-- No posts found -->
      <?php endif; ?>

      <!-- End of Blog Query -->
    </div>
    <div class="loadmore wow animated fadeInUp" id="loadmores"><?php echo get_next_posts_link('Load more', $Newquery->max_num_pages); ?></div>
    <?php wp_reset_query(); ?>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" aria-hidden="true">&times;</button> 
        <div class="update-personalinfo-box-success-container">
          <p></p> 
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
</div> 
<!-- /.modal --> 
<script type="text/javascript">
  jQuery(document).ready(function ($) {
    trackOpportunity();
    untrackOpportunity();
    $('body').on('click', '.loadmore a', function (e) {
      e.preventDefault();
      var temphref = $(this).attr('href');
      $("#loadmores").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> <img src='" + loademoreimg + "' /> Loading...</div>");

      $.post(temphref, function (response) {
        $("#loadmores").remove();
        var tempdata = $(response).find('.polar-posts').html();
        $(".polar-posts").append(tempdata);
        trackOpportunity();
        untrackOpportunity();
      });
    });

    jQuery('.close').on('click', function (e) {
      jQuery('#update-personalinfo-modal-success').modal('hide');
    });
    jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
      location.reload(true);
    })
  });
</script>
