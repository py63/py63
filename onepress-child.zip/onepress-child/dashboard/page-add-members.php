<?php
/**
*Template Name: Add Members
*/

global $wpdb, $current_user;
if (!is_user_logged_in() ) { 
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit; }  
if (empty(nstxl_is_poc($current_user->ID))) {  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit; } 
get_header('admin');

 $join_lists = "";
 do_action('onepress_page_before_content');
  ?>
  <div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">
  <div class="adduser-container dashboard-inner-wrapper dashboard-bg-white">
   <a class="arrow-back" href="<?php echo site_url(); ?>/manage-your-users/"><img src="<?php echo get_stylesheet_directory_uri().'/images/arrow-back.png'; ?>" /></a>
    <div class="adduser-form-container dashboard-form-wrapper">
      <form method="post" class="adduser-form" enctype="multipart/form-data" name="adduser" id="adduser">
        <div class="row">
          <div class="form-group col-lg-6 col-md-6"> 
            <label for="first_name"><?php _e('First Name','paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span>
</label>
            <input name="first_name" required value="" type="text">
          </div>
          <div class="form-group col-lg-6 col-md-6"> 
            <label for="last_name"><?php _e('Last Name','paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span>
</label>
            <input name="last_name" required value="" type="text">  
          </div>
        </div>
        <div class="row">
          <div class="form-group col-lg-12 col-md-12">
            <label for="email"><?php _e('Email','paid-memberships-pro'); ?><span class="required" aria-required="true"> *</span>
</label>
            <input name="email" required value="" type="email">
          </div> 
      </div>
      <div class="row">
       <div class="btn-group col-lg-6 col-md-6">
        <button type="submit" class="btn-txt mt-4" name="addmember-save"><?php _e( 'ADD USER','paid-memberships-pro'); ?></button>
      </div>
      </div>
      </form>
    </div>
  </div>
</main>
</div>
</div>
</div>
 <!-- Modal -->
  <div class="modal fade custom-popup" id="update-personalinfo-modal-success" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
          </button>
          <div class="update-personalinfo-box-success-container modal-body-container">
            <h4>Member has been registered successfully.</h4> 
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
  </div> 
  <!-- /.modal -->  


  <script>
    jQuery(document).ready( function($) {
     mainemail = "<?php echo $current_user->user_email; ?>";
   });
  </script>
  <script>
    jQuery(document).ready( function($) {   
    	    jQuery.validator.addMethod("validemail1", function(value, element) {
				   var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
          // allow any non-whitespace characters as the host part
          return this.optional( element ) || filter.test( value );
          }, 'Please enter a valid email address.');
    jQuery.validator.addMethod("domaincheck", function(value, element) {
      var this_field = jQuery('#adduser [name=email]');
          var useremail = jQuery('#adduser [name=email]').val();  
          var cmp_email = mainemail;  
          var sp = cmp_email.split('@');
          var cmp_domain = sp[1];   
          var spls = cmp_domain.split('.');
          var d;
          var ext;
          if(spls.length > 2 ){ 
            d = spls[spls.length - 1];
            ext = spls[spls.length];
          } else {
            d = spls[0];
            ext = spls[1];
          }  
          var re = new RegExp('^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?('+d+')\.'+ext+'$');
          // allow any non-whitespace characters as the host part
          return this.optional( element ) || re.test( value );
          }, 'Domains must match.');
   
      jQuery('.pmpro_asterisk').remove();
      jQuery('ul.multiselect-container.dropdown-menu li label.checkbox').each(function (index) {
        spclength1 = jQuery(this).find('span.checkmark').length;
        if (spclength1 == 0) {
          jQuery(this).append('<span class="checkmark"></span>');
        } 
      });
      $("#adduser").validate({

        rules: {
          first_name: {
            required: true,
          },
          action: "required",
          email: {
            required: true,    
            validemail1: true, 
            //domaincheck: true,     
            remote: {
              url: nstxl_ajaxurl,
              type: 'post',        
              data: {
                action: 'nstxl_check_memail',
                email: function () {
                  return $("input[name='email']").val();
                }
              },
            }         
          },
          last_name: {
            required: true,
          },         
        },
        messages: {      
          email: {
            required: "Please enter email",
            validemail1:"Please enter a valid email address",
            //domaincheck:'Email domain must match with company domain',
            remote: 'Email is already taken.'
          }      
        },
        errorClass: "form-invalid",
        // errorLabelContainer:'.help-block.with-errors',
        errorElement: 'div',
        highlight: function(element, errorClass, validClass) {
          $(element).closest("div.field").addClass("error").removeClass("success");
        },
        unhighlight: function(element, errorClass, validClass){
          $(element).closest(".error").removeClass("error").addClass("success");
        },
        errorPlacement: function (error, element) {

          if(element.parent().find("div.help-block.with-errors").length === 0) {
            if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {         
              element.parent().append(error);
            } else {              
              error.addClass("help-block with-errors").appendTo( element.closest('div.form-group'));
            }
          } else {
            if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
              element.parent().append(error);
            } else {            
              error.appendTo(element.parent().find("div.help-block.with-errors"));
            }
          }
        },   
        submitHandler: function(form) { 
          jQuery('.preloader').fadeIn();    
          var form = jQuery('form#adduser')[0]; 
          var formData = new FormData(form);
          formData.append("action", "nstxl_add_single_member");
          $.ajax({
            url: nstxl_ajaxurl,
            type: "POST",
            data: formData,
            //async: false,
            beforeSend: function() {           
              $(".preloader").show();
              jQuery('.preloader').css('display', 'block'); 
            },        
            success: function (response, textStatus) {
              jQuery('.preloader').fadeOut();
              if (response.data.response == "success") {
                jQuery('#update-personalinfo-modal-success').modal('show');
              } else {
                jQuery('#update-personalinfo-modal-success').modal('show');
                jQuery('#update-personalinfo-modal-success p').html('Member was not created');
              }

            },
            error: function(textStatus, errorThrown) { 
              add_message( textStatus, "danger" );
            },
            complete: function(){
              //$(".preloader").hide(); 
              form.reset();       
            },
            cache: false,
            contentType: false,
            processData: false
          });
        }    
      });

    jQuery('.join_our_mailing_list').multiselect({                 
      nonSelectedText: "Stay Informed",
      includeSelectAllOption: true,
    });
    jQuery('.close').on('click', function(e){
      jQuery('#update-personalinfo-modal-success').modal('hide');      
    }); 
    jQuery('#update-personalinfo-modal-success').on('hidden.bs.modal', function () {
      window.location.href = siteurl+'/manage-your-users';
    })
});
</script> 
<?php

get_footer('admin');