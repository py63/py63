<?php
/**
 * Template Name: Search FAQS
 *
 * @package OnePress
 */
global $wpdb, $current_user;
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
if (is_user_logged_in() && empty(nstxl_is_poc($current_user->ID))) {
  wp_redirect(get_bloginfo('url') . '/membership-account', 301);
  exit;
}
get_header('admin');
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">
  <?php
 // onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
   <?php get_sidebar('dashboard'); ?>
   <div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

      <?php while (have_posts()) : the_post(); ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <header class="entry-header">
            <?php //the_title( '<h1 class="entry-title">', '</h1>' );   ?>
          </header><!-- .entry-header -->

          <div class="entry-content">
            <div class="faqs-container">  
              <?php the_content(); ?>
              <?php

              if(isset($_GET['sa']) && !empty($_GET['sa']))
              {
               $sa =$_GET['sa'];

             }else{
              $sa = '';
            }

            $term = get_term_by('name', $sa, 'nstxl-faq-type'); 
            if(!empty($term))
            {
              $name = $term->name; 
              $termid = $term->term_id;
            }

            ?>

            <div class="search_header">
              <div class='search-title' style="">
                <h3 class='title'><?php printf( esc_html( _x( 'Search results for: "%s"', '%s - search keyword', 'polar' ) ), "<span>" . esc_html( $sa ) . "</span>" ); ?></h3>
              </div>
            </div>  
            <div style="clear: both;"></div>
            <div class="search-form-section faqs-page">
             <form role="search" method="get" class="search" action="<?php echo get_bloginfo('url');?>/search-faqs/"> 
              <input type="search" id="faqsearch" class="search-field"  name="sa" >  
              <button type="submit" class="search-submit">Search</button>
            </form>
          </div>


          <!--   <div class="row"> -->
           <div class="faqs-dashboard faqs-container-archive dashboard-bg-white" > 
            <?php
            if(!empty($term))
            {

              $args = array(
                'post_type' => 'nstxl-faq',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'tax_query' => array(
                  array(
                    'taxonomy' => 'nstxl-faq-type',
                    'field' => 'term_id',
                    'terms' => array($termid), 
                  )
                )
              );
            }
            else
            {
             $args=array("post_type"=>"nstxl-faq","s"=>$sa,'posts_per_page' =>-1); 
           }  ?>

           <?php   $faq_query = new WP_Query($args); 
           if ($faq_query->have_posts()) : ?>
             <table width="100%">
               <thead> <tr>
                <th align="left">Title</th>
                <th align="right">Likes</th></thead>
                <tbody>  
                 <?php while ($faq_query->have_posts()) : $faq_query->the_post();
                  $total_like = nstxl_faq_article_like_total(get_the_ID());  
                  ?> 
                  <tr>
                    <td><a href="<?php the_permalink();?>"><?php the_title(); ?></a></td>  
                    <td align="right"><?php echo $total_like; ?></td> 
                  </tr>
                <?php endwhile;  ?>

                <?php else : ?>  

                  <p class="mt-4">No FAQ's found.</p>   


                <?php endif; ?>
              </tbody>
            </table>

            <?php wp_reset_query(); ?> 
          </ul>
        </div>
      </div>   

    </div><!-- .entry-content -->
  </article><!-- #post-## -->

<?php endwhile; // End of the loop.  ?>   

</main><!-- #main -->
</div><!-- #primary -->



</div><!--#content-inside -->
</div><!-- #content -->  



<?php
get_footer('admin'); 

