<?php
/**
 * Template Name: Opportunity Dashboard
 *
 * @package OnePress
 */
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
get_header('admin');

/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  // [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">

    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' ); ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop. ?>

      </main><!-- #main -->
    </div><!-- #primary -->
  </div><!--#content-inside -->
</div><!-- #content -->

<?php get_footer('admin'); ?>
