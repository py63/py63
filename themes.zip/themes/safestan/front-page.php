<?php 
  get_header();
  //echo do_shortcode('[RICH_REVIEWS_SNIPPET]');

  global $wpdb;
                    $getvl = "SELECT 
                                wpsft_posts.ID,
                                wpsft_posts.post_title,
                                wpsft_posts.post_type,
                                wpsft_posts.post_content,
                                wpsft_richreviews.review_rating,
                                wpsft_richreviews.review_text,
                                wpsft_richreviews.reviewer_image,
                                wpsft_richreviews.reviewer_id,
                                wpsft_richreviews.reviewer_name
                              FROM
                                wpsft_posts
                                INNER JOIN wpsft_richreviews ON wpsft_posts.ID = wpsft_richreviews.post_id
                                WHERE wpsft_richreviews.review_status = 1 ORDER BY wpsft_richreviews.date_time DESC LIMIT 9";
  
?>
  <section class="main-header main-content new-content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 col-lg-12  col-sm-12 plr-0 ">
          <div class="section1">
            <?php 
            if(CFS()->get('_home_heading'))
              {
                  $home_heading = CFS()->get('_home_heading');
                  echo '<h4 class="slide-hadding">'.$home_heading.'</h4>';
              }
            ?>
            <div  class="section2 pos-rel">
              <div class="row">
                <div class="margintop20">
                  <div class="search">
                    <div class="form">
                      <form role="form" class="form1" name="new_property" method="POST" action="" enctype="multipart/form-data" id="form1id">
                    <!--<div class="width-48"> 
                      <div class="row">
                        <div class="gsearch"> 
                          <div id="locationField"> -->        
                            <div class="input-group">
                              <?php //print_r($_GET);
                              if(!empty($_GET['searchval'])){ ?>
                                <input class="form-control" placeholder="Enter an address" name="address_details" id="autocomplete" onFocus="geolocate()" type="text" value="<?php echo $_GET['searchval']; ?>">
                               <?php } else{ ?>
                                <input class="form-control" placeholder="Enter an address" name="address_details" id="autocomplete" 
                                       onFocus="geolocate()" type="text">
                                <?php } ?>
                                <span class="input-group-btn">
                                <!-- <a href="javascript:void(0)" class="btn1 form_open" id="addproperty">Search</a> -->
                                   <button id="addproperty" class="btn1 searchbtn" name="search" >Search <!-- <span><img src="<?php bloginfo('stylesheet_directory'); ?>/images/search.png"></span> -->
                                   <!-- <span id="ajxlod"></span> --></button> 
                                </span> 
                            </div>   
                          <!-- </div> -->


<!--  9 March, 2018 changes begin -->
                            <input type="hidden" name="addresshide" id="addresshide">

                          <div id="address" class="prodetails" style="display:none;">
                            <label for="Name">Property Name</label><br>
                            <span><input type="text" placeholder="Enter Property Name" name="property_title" id = "property_title0" class="form-control" value="Residence"></span>
                            <label>Street Address</label>
                            <input type="text" class="form-control" placeholder="Street Number" id="street_number0" name="street_number" disabled="true">
                            </input>

                            <label>Property Address</label>
                            <input type="text" class="form-control" placeholder="Enter Property Address" name="property_address"  id="route0"
                                  disabled="true">  
                            </input>
                        
                            <label>City</label>
                            <input type="text" class="form-control"  placeholder="Enter Property City" name="property_city" id="locality0" disabled="true">
                            </input>

                            <label>State</label>
                            <input type="text" placeholder="Enter Property State" name="property_state" id="administrative_area_level_10" class="form-control" disabled="true">  
                            </input>

                            <label>Zip Code</label>
                            <input type="text" placeholder="Enter Postal Code" name="postcode" class="form-control"  id="postal_code0"
                                  disabled="true">  
                            </input>

                            <label>Country</label>
                            <input type="text" class="form-control" placeholder="Country" id="country0" name="property_country" disabled="true"> 
                            </input>
                          </div>
<!--  9 March, 2018 changes end -->   

                      <!-- </div> 
                      <div class="clearfix"></div>
                    </div> -->
                  </form>  
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="header_banner"><img class="img-responsive hidden-xs" src="<?php bloginfo('stylesheet_directory'); ?>/images/banner_new.png"> <img class="img-responsive visible-xs" src="<?php bloginfo('stylesheet_directory'); ?>/images/banner_new_mobile.png"> </div>
        </div>
      </div>
    </div>
  </section>
  <div class="clearfix"></div>
 <!-- Search end -->

<div class="feature-section new-feature">
  <div class="container">
    <div class="row">
      <div class="review">
          <div class="full-width text-center">
            <h4 class="hadding">Featured Reviews</h4>
          </div>

          <div> 
            <section id="features" class="blue full-width">   
              <div class="content-2">
                <div class="slider responsive"> 
                <?php
                $gtres = $wpdb->get_results($getvl);
                foreach ($gtres as $gtpost) { ?>
                  <div>
                    <div class="card">
                      <a href="<?php echo the_permalink($gtpost->ID); ?>">
                        <div class="map"> 
                          <?php 
                        $imfeatureds = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id = ".$gtpost->ID." AND image_featured_status = 1");
                            if($imfeatureds[0]->image_path)
                            { ?>
                                <img src="<?php echo $imfeatureds[0]->image_path; ?>" class="img-responsive feature-img" alt=""/ style="width: auto; text-align: center; max-height: 112px;">
                              <?php 
                            }

                            else
                            {
                              
                              if(CFS()->get('_property_address',$gtpost->ID))
                              {
                                  $property_address = CFS()->get('_property_address', $gtpost->ID);

                              }
                              if(CFS()->get('_property_city', $gtpost->ID))
                              {
                                  $property_city = CFS()->get('_property_city', $gtpost->ID);
                              }
                              if(CFS()->get('_property_state', $gtpost->ID))
                              {
                                  $property_state = CFS()->get('_property_state', $gtpost->ID);
                              }
                              if(CFS()->get('_property_zip_code', $gtpost->ID))
                              {
                                  $property_zip_code = CFS()->get('_property_zip_code', $gtpost->ID);
                              }
                            
                              $property_fulladdr = array('property_address' => urlencode($property_address),
                              'property_city' => urlencode($property_city),
                              'property_state' => urlencode($property_state),
                              '_property_zip_code' => urlencode($property_zip_code)
                              );

                             $gimg = '<img src="https://maps.googleapis.com/maps/api/staticmap?size=150x150&zoom=11&markers=';
                             $gimg .= implode(',', $property_fulladdr);
                             $gimg .= '&format=png&style=feature:road.highway|element:geometry|visibility:simplified|color:0xc280e9&style=feature:transit.line|visibility:simplified|color:0xbababa&style=feature:road.highway|element:labels.text.stroke|visibility:on|color:0xb06eba&style=feature:road.highway|element:labels.text.fill|visibility:on|color:0xffffff&key=AIzaSyC4-HR84x2TvV5bYmp2u_LSP7c_rEgypmw';
                             $gimg .='">';
                             print $gimg;                           
                            
                           }?>
                        </div>
                        <h4 class="user-name"><?php 
                        $ttl_length = strlen($gtpost->post_title);
                        if($ttl_length > 25){
                          $gt_ttl = substr($gtpost->post_title, 0, 25);
                          echo $gt_ttl."...";
                        }
                        else{
                          echo $gtpost->post_title;
                        }

                         ?></h4>
                        <div class="discripation-text">                           
                            <?php
                            $content = $gtpost->review_text;
                            $maistr = strlen($content);
                            echo '<p><span class="text-info">"</span>';
                            if($maistr >= 65){
                              $contentnew = substr($content, 0, 65);
                              echo $contentnew."...";
                            }
                            else{
                              echo $content;                         
                            }
                            echo '<span class="text-info">"</span>';
                            echo '</p>';
                          ?>                          
                        </div>
                        <div class="discripation-name"> <?php
                              $userimg = get_wp_user_avatar_src($gtpost->reviewer_id, 'thumb');
                               ?> 
                               <?php echo $author = $gtpost->reviewer_name; ?>
                        </div>
                        <div class="text-center"> 
                        <?php
                            echo do_shortcode('[RICH_REVIEWS_SNIPPET category="post" id="'.$gtpost->ID.'" stars_only="true"]');
                          ?>
                        </div>
                      </a>    
                    </div>
                  </div>

                <?php } ?>
                </div>
              </div>
            </section>
          </div>
      </div>
      
      <div class="add-property">
        <div class="cross">
        <a href="javascript:void(0)" id="close"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/cross.png"></a>
        </div>

        <div class="full-width">

          <form class="formnew" id="formnewid" name="another_property" method="POST" action="" enctype="multipart/form-data">
            <div class="prodetails">

              <div class="col-md-8 col-sm-10 col-md-offset-2 col-sm-offset-1">
                <div class="row">
<!--  9 March, 2018 changes begin -->                
                  <div class="full-width">
                    <div class="col-md-12 col-sm-12">
                       <h4 class="add-hadding">About Property</h4>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">Property Name</p>
                        <input type="text" placeholder="Enter Property Name" name="property_title" id = "property_title" class="form-control" value="Residence" required="required">
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">Price in USD</p>
                        <input type="text" placeholder="Enter Property Price" name="price" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">Property Size</p>
                        <input type="text" placeholder="Enter Property Size" name="property_size" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-12 col-sm-12">
                      <div class="form-group">
                        <p class="label-had mt-1">Property Management Company</p>
                        <textarea rows="4" placeholder="Enter Property Management Company Details" name="property_detail" class="form-control"></textarea>
                      </div>
                    </div>
                  </div>

                  <div class="full-width margintop20">
                    <div class="col-md-12 col-sm-12">
                         <h4 class="add-hadding">Property Location</h4>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">Street Address</p>
                        <input type="text" class="form-control" placeholder="Street Number" id="street_number" name="street_number" required="required">
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">Property Address</p>
                        <input type="text" class="form-control" placeholder="Enter Property Address" name="property_address"  id="route" required="required">  
                          </input>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">City</p>
                        <input type="text" class="form-control"  placeholder="Enter Property City" name="property_city" id="locality">
                          </input>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had mt-1">State</p>
                        <input type="text" placeholder="Enter Property State" name="property_state" id="administrative_area_level_1" class="form-control">  
                          </input>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had mt-1">ZIP Code</p>
                        <input type="text" placeholder="Enter Postal Code" name="postcode" class="form-control"  id="postal_code">  
                          </input>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had mt-1">Country</p>
                        <input type="text" class="form-control" placeholder="Country" id="country" name="property_country"> 
                          </input>
                      </div>
                    </div>                
                  </div>

<!--  9 March, 2018 changes end -->

                  <div class="full-width margintop20">
                    <div class="col-md-12 col-sm-12">
                         <h4 class="add-hadding">Other Information</h4>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">Property Phone</p>
                        <input type="text" placeholder="Enter Property Phone" name="phone" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <div class="form-group">
                        <p class="label-had">Email Address</p>
                        <input type="text" placeholder="Enter Property Email Address" name="email" id="email" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                      <p class="label-had">Property Website</p>
                      <input type="text" placeholder="Enter Property Website" name="website" class="form-control">
                    </div>
                    <div class="col-md-12 col-sm-12">
                      <p class="label-had mt-1">Upload Property Image</p>
                      <div class="box custom-upload-files">
                        <input type="file" name="image" id="imageUpload" class="inputfile inputfile-6" data-multiple-caption="{count} files selected"/>
                        <label for="imageUpload"> <strong><img src="<?php bloginfo('stylesheet_directory'); ?>/images/uplod-image.png" width="20" height="17"> Browse</strong><span></span></label>                      
                      <!-- <input type="file" name="image" id="imageUpload" class="hide form-control cus-form-control"/> 
                      <label for="imageUpload" class="btn btn-large btn-upload"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/uplod-image.png"> Browse</label> -->
                              <!-- <input type="file" value="" name="image" class="form-control cus-form-control"> -->
                                <!-- <div class="fake-file">
                                    <input class="form-control" placeholder="Browse file..." >
                                </div> -->
                      </div> 
                    </div>                  
                  </div>
                  <div class="full-width margintop20 text-right">
                    <div class="col-md-12 col-sm-12">
                      <span id="preloder" style="display:none;"><img src="<?php bloginfo("stylesheet_directory"); ?>/images/Filling broken ring.gif"> loading...</span>
                      <button type="reset" class="btn-balck btn property_cancel btn1 reset">Cancel</button>
                      <!-- <input type="cancel" class="property_cancel btn1 reset" name="submit" value="Cancel"> -->
                      <input type="submit" class="property_submit btn1 btn btn-blue" name="submit" value="Submit">

                      <!-- <a href="#" class="btn btn-balck">Cancel</a>
                      <a href="#" class="btn btn-blue">Submit</a> -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>



<!-- Modal -->
<div class="modal fade" id="myModalt" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
              <a href="#" class="close-modal" data-dismiss="modal"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/cross.png"></a>
              <img src="<?php bloginfo('stylesheet_directory'); ?>/images/succes.png">
        <h4>Congratulation! The Property Has Been Added Successfully</h4>
              <a href="" class="addprop btn btn-primary">OK</a>
      </div>
    </div>
  </div>
</div>
  
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
              <a href="#" class="close-modal" data-dismiss="modal"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/cross.png"></a>
              <img src="<?php bloginfo('stylesheet_directory'); ?>/images/warning.png">
        <h4>The Property Already Exists </h4>
              <a href="" class="viewproperty btn btn-primary">Visit Property</a>
      </div>
    </div>
  </div>
</div>
  
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
              <a href="#" class="close-modal" data-dismiss="modal"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/cross.png"></a>
              <img src="<?php bloginfo('stylesheet_directory'); ?>/images/warning.png">
        <h4> Please Enter an address </h4>           
      </div>
    </div>
  </div>
</div>
  
<div class="loader">
  <img src="<?php bloginfo('stylesheet_directory'); ?>/images/loader.gif">
</div>



<!-- start script validate-->
  <script>
  jQuery(document).ready(function($){

  jQuery('.custom-upload-file input[type=file]').change(function(){
      jQuery(this).next().find('input').val($(this).val());
  });
  });
  </script>

  <script src="<?php bloginfo('template_url');?>/js/jquery.validate.min.js"></script>
  <script type="text/javascript">
      jQuery(document).ready(function(e){
          jQuery('.property_cancel').click(function(){
            //alert('ok');
       //e.preventDefault();
          });
      });
  </script>
  


<script>
jQuery(document).ready(function($) {
jQuery(".form1").submit(function(e){
   e.preventDefault();
    //alert(jQuery(this).serialize());
  setTimeout(function(){
   jQuery.ajax({
        url : headJS.ajaxurl,
        type: "POST",
        //dataType: "json",
        data: {
            'action': 'saf_data_send',
            'data' : jQuery(".form1").serialize(),
             },
        beforeSend: function(){
          /*jQuery('#ajxlod').html('<img style="width:20px;" src="<?php bloginfo("stylesheet_directory"); ?>/images/ajx-imgloder.gif">');*/          
          
        },
        complete: function(){
          //jQuery('#ajxlod').hide();
        },
        success: function(response,data)
        {
            //console.log(data);
           //alert(response.success);
           //alert(response.res);
           console.log(response);
          
         /* if (response.success == true && response.getres == true) {
            //window.location.href = response.res;
            var geturls = response.res;
            alert(response.res);
            var url = 'http://localhost/safestn/landlord-reviews/?gpr=' + geturls;
            alert("You will now be redirected.");
            window.location.href = url;

          }*/ 
          if (response.success == true) 
          {
            //window.location.href = response.res;
            if(response.posearch) 
            {
              //window.location.href = '<?php echo home_url() ?>/landlord-reviews/?posearch='+response.posearch;
           //var getpro = '<?php echo home_url() ?>/landlord-reviews/?posearch='+response.posearch;
           //alert(getpro);
           jQuery(".loader").show();
           //jQuery('.viewproperty').attr('href',getpro);
            setTimeout(function(){
              jQuery(".loader").hide();
              //jQuery('#myModal').modal('toggle');
              window.location.href = '<?php echo home_url() ?>/landlord-reviews/?posearch='+response.posearch;
            },2000);

              
            }
            else
            {
              console.log(response.res);
              //window.location.href = response.res;
               jQuery(".loader").show();
               //jQuery('.viewproperty').attr('href',response.res);
                setTimeout(function(){
                  jQuery(".loader").hide();
                  //jQuery('#myModal').modal('toggle');
                  window.location.href = response.res;
                },2000);
               
            } 
          }           
          else{
            if(response.success == false && response.emptyres == true)
            {
              alert("Please Enter an address.");
              /*jQuery(".loader").show();
              setTimeout(function(){
                jQuery(".loader").hide();
                jQuery('#myModal1').modal('toggle');
              },2000);*/

              jQuery(".add-property").hide();
              jQuery(".review").show();
              jQuery("#mobslid").show();
            }else{
            //document.getElementById("formnewid").reset();
            jQuery(".add-property").show();
            jQuery('html, body').animate({
               scrollTop: jQuery(".add-property").offset().top
            }, 1000);
            jQuery(".dndformdetails").removeAttr("style");
            //jQuery(".add-property").show();
            jQuery(".review").hide();
            jQuery("#mobslid").hide();
            console.log(response.address_details);
            jQuery('#property_title1').val(response.title);
            jQuery('#street_number1').val(response.street_number);
            jQuery('#route1').val(response.property_adr);
            jQuery('#locality1').val(response.property_city);
            jQuery('#administrative_area_level_11').val(response.property_state);
            jQuery('#postal_code1').val(response.postcode);
            jQuery('#country1').val(response.property_country);
            
           }
          }          
   //alert(response.data);
          

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            console.log('error');
            console.log(errorThrown);

        }
    });
 },400);
});


jQuery(".formnew").submit(function(e){
    //alert(headJS.ajaxurl);
    e.preventDefault();

    /*var fd = new FormData();
    var file = jQuery(document).find('input[type="file"]');
    var caption = jQuery(this).find('input[name=image]');
    //alert(caption);die;
    var individual_file = file[0].files[0];  
  alert(individual_file.toSource());die;

    fd.append("file", individual_file);
    var individual_capt = caption.val();
    fd.append("caption", individual_capt);  
    fd.append('action', 'saf_data_insert');*/

    var fd = new FormData(this);
    var file = jQuery(document).find('input[type="file"]');
    var caption = jQuery(this).find('input[name=image]');
    var individual_file = file[0].files[0];
    fd.append("file", individual_file);
    var individual_capt = caption.val();
    fd.append("caption", individual_capt);  
    //fd.append('action', 'saf_data_insert');
    fd.append('action', 'saf_data_in');
    //fd.append('textPost', jQuery(this).serialize());
    //alert(jQuery(this).serialize());die;

      jQuery.ajax({
        url : headJS.ajaxurl,
        type: "POST",
        //dataType: "json",
        data: fd,
        //async: false,
        processData: false,
        contentType: false,
        beforeSend: function(){
          //jQuery('#preloder').show();
          //jQuery('.loader').show();
          //jQuery(".loader").fadeOut("slow");
          /*jQuery(".loader").show();
          setTimeout(function(){
            jQuery(".loader").hide();
            jQuery('#myModal').modal('toggle');
          },2000);*/
          jQuery(".loader").show();
        },
        complete: function(){
          //jQuery(".loader").hide();
          //jQuery('#preloder').hide();
          //jQuery('.loader').hide();
        },
        success: function(response,data)
        {
            console.log(response);
            //alert(response);
            //window.location.href = response;
          //alert(response.success);
          if(response.success == true)
          {
            //alert("The property already exist, you can refer it automatically");
            //window.location.href = response.res;
            //window.location.href = response.gt_result;
            //console.log(response.gt_result);           
            jQuery('.viewproperty').attr('href',response.gt_result);
            setTimeout(function(){
              jQuery(".loader").hide();
              jQuery('#myModal').modal('toggle');
            },2000);           

          }
          else{            
            jQuery('.addprop').attr('href',response);
            setTimeout(function(){
              jQuery(".loader").hide();
              jQuery('#myModalt').modal('toggle');
            },2000);

            //window.location.href = response;
          }          
      
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            console.log('error');
            console.log(errorThrown);

        }
    });
   
});


});

/*9 March, 2018 changes begin*/



      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode','establishment']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();
        var undifnd = place.formatted_address;
        if(undifnd == undefined ){
          //alert("test"+undifnd);
          document.getElementById('street_number').value = '';
          document.getElementById('route').value = '';
          document.getElementById('locality').value = '';
          document.getElementById('administrative_area_level_1').value = '';
          document.getElementById('postal_code').value = '';
          document.getElementById('country').value = '';
          //return false;
        }
        /*else{
          document.getElementById('autocomplete').value = place.formatted_address;
        }*/

        document.getElementById('property_title').value = place.name;
        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

       var str_num = get_mykeyvaladd(place,"street_number");
        if(str_num==false)
        {
          str_num ="";
        }
        else
        {
         str_num = str_num+" "; 
        }        
        var p_add = get_mykeyvaladd(place,"route");
        if(p_add==false)
        {
          p_add ="";
        }
        else
        {
         p_add = p_add+", "; 
        }
        var cty = get_mykeyvaladd(place,"locality");
        if(cty==false)
        {
          cty ="";
        }
        else
        {
         cty = cty+", "; 
        }
        var stat = get_mykeyvaladd(place,"administrative_area_level_1");
        if(stat==false)
        {
          stat ="";
        }
        else
        {
         stat = stat+", "; 
        }
        var p_code = get_mykeyvaladd(place,"postal_code");
        if(p_code==false)
        {
          p_code ="";
        }
        else
        {
         p_code = p_code+""; 
        }
       
        var gaddress = str_num+p_add+cty+stat+p_code;
        //alert(str_num+p_add+cty+stat+p_code);
        document.getElementById("addresshide").value = gaddress; 
        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      function get_mykeyvaladd(place,q_addresstype)
      {
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          //alert(addressType);
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            //var vlu = place.address_components[i][componentForm[addressType]];
            if(q_addresstype==addressType)
            {
              return val;
            }
          }          
        }
        return false;
      }
      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcNH2i2PzorNJo8XnEyv5373mMx-Gmlwo&libraries=places&callback=initAutocomplete"
        async defer></script>

<!--  9 March, 2018 changes end -->
        
    <script>
    
      jQuery(document).ready(function(){
        /*jQuery(".form1 button").click(function(){
        jQuery(".review").hide();
        jQuery(".add-property").show();
      });*/

      jQuery("#close").click(function(){
        jQuery(".review").show();
        jQuery("#mobslid").show();
        jQuery(".add-property").hide();
      });
      jQuery("#myInput").click(function(){
        jQuery("#myUL").toggle();
      });


/*9 March, 2018 changes begin */



      /* disable enter key*/
      /*jQuery('#autocomplete').bind('keyup keypress', function(e) {
          var keyCode = e.keyCode || e.which;
          if (keyCode === 13) { 
            e.preventDefault();            
            return false;            
          }
      });*/
      
/*9 March, 2018 changes end*/  


      });
      

    function myFunction() {
        var input, filter, ul, li, a, i;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        ul = document.getElementById("myUL");
        li = ul.getElementsByTagName("li");
        for (i = 0; i < li.length; i++) {
            a = li[i].getElementsByTagName("a")[0];
            if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
                li[i].style.display = "";
            } else {
                li[i].style.display = "none";

            }
        }
    }
    </script>  

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
  <link href="<?php bloginfo('template_directory');?>/css/component.css" rel="stylesheet">
  <script src="<?php bloginfo('template_directory');?>/js/custom-file-input.js"></script>
   <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="http://kenwheeler.github.io/slick/slick/slick.js"></script>
  <script src="<?php bloginfo('template_directory');?>/js/slide.js"></script>
  <script>
  /*jQuery(document).on('click', '#submit', function(){
       jQuery(".loader").show();
      setTimeout(function(){
          jQuery(".loader").hide();
          jQuery('#myModal').modal('toggle');
        },2000);
  });*/
  </script>
<script>
  jQuery(document).ready(function(){
    jQuery("#addproperty").click(function(){
    //jQuery(".review").hide();
   
    /*jQuery(".add-property").show();
    jQuery('html, body').animate({
       scrollTop: jQuery(".add-property").offset().top
    }, 1000);*/
  });
  jQuery("#close").click(function(){
    jQuery(".review").show();
    jQuery(".add-property").hide();
     jQuery('html, body').animate({
       scrollTop: jQuery("body").offset().top
    }, 1000);
  });
  jQuery("#myInput").click(function(){
    jQuery("#myUL").toggle();
  });
  jQuery("#carousel-inner-1").click(function(){
  jQuery('html, body').animate({
       scrollTop: jQuery("#carousel-inner").offset().top
    }, 1000);
  });
  
  });
  </script>
    <script type="text/javascript">
    //document.getElementById("new-task");
      /*document.getElementById("autocomplete").addEventListener('keypress', function (event) {
        
        //check to see if the enter key was pressed
        if (event.code == 'Enter')
          event.preventDefault();
        alert(event.code);
        
      });*/

    </script>
    <style type="text/css">
      /*.loader {
          position: fixed;
          left: 0px;
          top: 0px;
          width: 100%;
          height: 100%;
          z-index: 9999;
          background: url('<?php bloginfo("stylesheet_directory"); ?>/images/Filling broken ring.gif') 50% 50% no-repeat rgb(249,249,249);
          opacity: .8;
      }*/
    </style>
    <!-- <script type="text/javascript">
      jQuery(window).load(function() {
          jQuery(".loader").fadeOut("slow");
      });
    </script> -->
<?php 
  get_footer();
?>
