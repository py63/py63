<?php
/**
 * Template Name: Mytest
 *
 * @package OnePress
 */
get_header();
/**
 * @since 2.0.0
 * @see onepress_display_page_title
 */
do_action('onepress_page_before_content');
?>
 <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri();?>/css/slick-theme.css">
 <!--  <script src="<?php//  echo get_stylesheet_directory_uri();?>/js/slick.min.js"></script> -->
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  ?>
<div id="content-inside" class="container no-sidebar member-ship-list">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <?php while (have_posts()) : the_post(); ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
              <?php //the_title( '<h1 class="entry-title">', '</h1>' );  ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
              <?php the_content(); ?>

       

              <div class='membercontent container'>
               <div class="row">
  <div class="large-12 columns">
  
      <!-- MAIN SLIDES -->
      <div class="slider">
        <div data-index="1">
          <img src="http://placehold.it/1200x600&text=one" alt="One">
          <figcaption>Caption for image one. 
          </figcaption>
        </div>
        <div data-index="2">
          <img src="http://placehold.it/1200x600&text=two" alt="One">
          <figcaption>Caption for image two. 
          </figcaption>
        </div>
        <div data-index="3">
          <img src="http://placehold.it/1200x600&text=three" alt="One">
          <figcaption>Caption for image three. 
          </figcaption>
        </div>
        <div data-index="4">
          <img src="http://placehold.it/1200x600&text=four" alt="One">
          <figcaption>Caption for image four. 
          </figcaption>
        </div>
        <div data-index="5">
          <img src="http://placehold.it/1200x600&text=five" alt="One">
          <figcaption>Caption for image five. 
          </figcaption>
        </div>
      </div>
      
      <!-- THUMBNAILS -->
      <div class="slider-nav-thumbnails">
        <div><img src="http://placehold.it/1200x600&text=one" slide="slide_1">
        </div>
        <div><img src="http://placehold.it/1200x600&text=two" slide="slide_2">
        </div>
        <div><img src="http://placehold.it/1200x600&text=three" slide="slide_3">
        </div>
        <div><img src="http://placehold.it/1200x600&text=four" slide="slide_4">
        </div>
        <div><img src="http://placehold.it/1200x600&text=five" slide="slide_5">
        </div>
      </div>

<section class="content one" data-id="1"> 
  Content for slide 1
</section> 

<section class="content two" data-id="2"> 
  Content for slide 2
</section> 

<section class="content three" data-id="3"> 
  Content for slide 3
</section> 

<section class="content four" data-id="4"> 
  Content for slide 4
</section> 

<section class="content five" data-id="5"> 
  Content for slide 5
</section> 

    </div>
</div>



              </div>

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

        <?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->
  </div><!--#content-inside -->
</div><!-- #content -->
<script type="text/javascript">
jQuery(document).ready(function(){ 

 jQuery('.slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: false,
  asNavFor: '.slider-nav-thumbnails',
 });

 jQuery('.slider-nav-thumbnails').slick({
  slidesToShow: 5,
  slidesToScroll: 1,
  asNavFor: '.slider',
  dots: true,
  focusOnSelect: true
 });

 //remove active class from all thumbnail slides
 jQuery('.slider-nav-thumbnails .slick-slide').removeClass('slick-active');

 //set active class to first thumbnail slides
 jQuery('.slider-nav-thumbnails .slick-slide').eq(0).addClass('slick-active');

 // On before slide change match active thumbnail to current slide
 jQuery('.slider').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
  var mySlideNumber = nextSlide;
  jQuery('.slider-nav-thumbnails .slick-slide').removeClass('slick-active');
  jQuery('.slider-nav-thumbnails .slick-slide').eq(mySlideNumber).addClass('slick-active');
});

//UPDATED 
  
jQuery('.slider').on('afterChange', function(event, slick, currentSlide){   
  jQuery('.content').hide();
  jQuery('.content[data-id=' + (currentSlide + 1) + ']').show();

});
});
</script> 



<style type="text/css"> 

.slider-nav-thumbnails .slick-slide {
  opacity: 0.5;
}

.slider-nav-thumbnails .slick-slide.slick-active {
  opacity: 1;
  background: green;
}

.content {
  font-size: 18px;
  padding: 20px;
  text-align:center;
  color: white;
}
.one {
  background: blue;
}
.two {
  background: red;
}
.three {
  background: purple;
}
.four {
  background: green;
}
.five {
  background: pink;
}
.two, .three, .four, .five {
  display:none;
}
</style>  



<?php get_footer(); ?>
