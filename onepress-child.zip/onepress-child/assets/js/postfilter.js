jQuery(function($){
    jQuery('#categoryfilter').change(function(e){
    	e.preventDefault();
    	pageNumber = 1;
		jQuery.ajax({
	        url: postajax.ajaxurl,
	        type: 'post',
	        data: {action: 'post_fetch', categoryfilter: jQuery('#categoryfilter').val(),
	    },
	        success: function(data) {
	          jQuery('#posts').html(data).show();
	        }
	        
 	 	});

	});
});
