<?php
/**
 * Template Name: Contact Us
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();?>
	<!-- Start Head Section -->
	<div class="top-banner">
	    <div class="container">
	      	<div class="row">
				<div class="col-md-12 col-sm-12">
	        		<h1 class="banner-hadding"><?php the_title();?></h1>
				</div>
	      	</div>
	    </div>
	</div>
	
	<!-- End Head Section -->

	<div class="contact">
		<div class="container">
			<?php the_content();?>			
			<div class="full-width mt-4">
				<div class="row">
				<?php echo do_shortcode('[contact-form-7 id="268351" title="Contact Us"]');?>
				</div>			
            </div>
		</div>
	</div>

	<?php // End of the loop.
	endwhile;
	?>
<?php get_footer(); ?>
