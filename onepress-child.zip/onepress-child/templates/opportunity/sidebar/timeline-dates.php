<?php
$datePosted = get_field('nstxl_date_posted', get_the_ID());
$qusdeadline = get_field('nstxl_question_deadline', get_the_ID());
$industryday = get_field('nstxl_industry_day', get_the_ID());
$expected_question_posting = get_field('nstxl_expected_question_posting', get_the_ID());
$proposal_deadline = get_field('nstxl_proposal_deadline', get_the_ID());
$expected_date_of_award = get_field('nstxl_expected_date_of_award', get_the_ID());
if (!empty($datePosted) || !empty($qusdeadline) || !empty($industryday) || !empty($expected_question_posting) || !empty($proposal_deadline) || !empty($expected_date_of_award)) {
  ?>
  <aside class="aside-opportunity-content widget timeline-date">
    <h2 class="widget-title"><?php _e('Important Dates', 'onpress'); ?></h2>
    <div class="widget-content">
      <ul>
        <?php if (!empty($datePosted)) { ?>
          <li><?php _e('Date Posted', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($datePosted))); ?></li>
        <?php } ?>
        <?php if (!empty($qusdeadline)) { ?>
          <li><?php _e('Question Deadline', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($qusdeadline))); ?></li>
        <?php } ?>
        <?php if (!empty($industryday)) { ?>
          <li><?php _e('Industry Day', 'onpress'); ?>: <?php echo $industryday; ?></li>
        <?php } ?>
        <?php if (!empty($expected_question_posting)) { ?>
          <li><?php _e('Expected Question Posting', 'onpress'); ?>: <?php echo $expected_question_posting; ?></li>
        <?php } ?>
        <?php if (!empty($proposal_deadline)) { ?>
          <li><?php _e('Proposal Submission Deadline', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($proposal_deadline))); ?></li>
        <?php } ?>
        <?php if (!empty($expected_date_of_award)) { ?>
          <li><?php _e('Expected Date Of Award', 'onpress'); ?>: <?php echo date("M d, Y g:i A", current_time(strtotime($expected_date_of_award))); ?></li>
        <?php } ?>
      </ul>
    </div> 
  </aside>
<?php } ?>