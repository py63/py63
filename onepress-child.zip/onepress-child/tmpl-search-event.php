<?php
/*
 * Template Name: Event Search
 */
get_header();
do_action('onepress_page_before_content');
?>
<div id="content" class="site-content">  
  <div id="content-inside" class="container no-sidebar">
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

        <div class="blog-section">
    <?php

    if(isset($_GET['sa']) && !empty($_GET['sa']))
    {
       $sa =$_GET['sa'];
    }else{
        $sa = '';
    }
    ?>
    <div class="search_header">
        <div class='search-title' style="">
            <h3 class='title'><?php printf( esc_html( _x( 'Search results for: "%s"', '%s - search keyword', 'polar' ) ), "<span>" . esc_html( $sa ) . "</span>" ); ?></h3>
        </div>
        <div class="form-01">
            <?php $unique_id = esc_attr( uniqid( 'search-form-' ) ); ?>
            <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>/search-event">
                <input type="search" id="<?php echo $unique_id; ?>" class="search-field" placeholder="<?php echo esc_attr_x( 'Search again', 'placeholder', 'twentyseventeen' ); ?>" value="<?php echo get_search_query(); ?>" name="sa" />
                <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text"><?php echo _x( 'Search', 'submit button', 'twentyseventeen' ); ?></span></button>
            </form>
        </div>
    </div>
    <?php
        $paged = get_query_var( 'paged', 1 );
        $args=array("post_type"=>"post", "posts_per_page" => 9,'category__in' => array(46), "paged"=>$paged,"s"=>$sa);
        query_posts( $args );
        if(have_posts()) 
        {
    ?>
    <div class="blog-posts">
            <div class="card-deck" id="posts">
        <?php
        while(have_posts()): the_post();
        $posttitle = get_the_title(); 
        $wordcount = str_word_count($posttitle);
        if(get_post_type() == 'post') 
        {
        $show_thumbnail = true;
        if (get_theme_mod('onepress_hide_thumnail_if_not_exists', false)) {
          if (!has_post_thumbnail()) {
            $show_thumbnail = false;
          }
        }
        ?>
            <div class="card">
              <article id="post-<?php the_ID(); ?>" <?php post_class(array('list-article', 'clearfix')); ?>>
                <?php if ($show_thumbnail) { ?>
                  <div class="list-article-thumb">
                    <a href="<?php echo esc_url(get_permalink()); ?>">
                      <?php
                      if (has_post_thumbnail()) {
                        //the_post_thumbnail( 'onepress-blog-small' );
                        $featured_img_url = get_the_post_thumbnail_url(get_the_ID(), 'onepress-blog-small');
                        echo '<img class="card-img-top" data-src="' . $featured_img_url . '" alt="blog" style="height: 200px; width: 100%; display: block;" src="' . $featured_img_url . '" data-holder-rendered="true">';
                      } else {
                        echo '<img class="card-img-top" alt="placholder" src="' . get_template_directory_uri() . '/assets/images/placholder2.png' . '" data-holder-rendered="true">';
                      }
                      ?>
                    </a>
                  </div>
                <?php } ?>

                <div class="card-body">
                  <h4 class="card-title"><?php
                    $wordcount = str_word_count(get_the_title());
                    if ($wordcount > 10) {
                      ?> 
                      <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo wp_trim_words(get_the_title(), 10, ''); ?></a>
                    <?php } else { ?>
                      <a href='<?php echo esc_url(get_permalink()); ?>'><?php echo get_the_title(); ?></a>
                    <?php } ?></h4>
                  <h6 class="card-subtitle mb-2 text-muted"><?php echo get_the_date(); ?></h6>
                  <div class="entry-excerpt"><p class="card-text"><?php echo wp_trim_words(get_the_content(), 12, ''); ?></p></div>
                  <div class="readmore-button-section">
                    <a class="btn btn-secondary-outline btn-lg" href="<?php echo esc_url(get_permalink()); ?>"><?php _e('Read More', 'onepress'); ?></a>
                  </div> 
                </div>

              </article><!-- #post-## -->
            </div>
        <?php }
        endwhile;
        ?>
    </div>
     <div class="loadmore">
          <?php  the_posts_pagination(array('mid_size' => 2, 'prev_text' => '<span class="meta-nav"><i class="fa fa-chevron-left" aria-hidden="true"></i></span> ' . __('Previous page', 'simple-life'), 'next_text' => __('Next page', 'simple-life') . ' <span class="meta-nav"><i class="fa fa-chevron-right" aria-hidden="true"></i></span>', 'before_page_number' => '<span class="meta-nav screen-reader-text">' . __('Page', 'simple-life') . ' </span>')); ?>
        </div> 
    <?php
    } 
    else 
    {
    ?>
    <section class="no-results not-found">  
            <article>
              <header class="entry-header">
               <h3><?php echo esc_html__( 'No posts found.', 'polar' ) ?></h3>
        <p><?php echo esc_html__( 'You might want to consider some of our suggestions to get better results:', 'polar' ) ?></p>
        <ul>
            <li><?php echo esc_html__( 'Check your spelling.', 'polar' ) ?></li>
            <li><?php echo esc_html__( 'Try a similar keyword', 'polar' ) ?></li>
            <li><?php echo esc_html__( 'Try using more than one keyword', 'polar' ) ?></li>
        </ul>
              </header><!-- .entry-header -->
              <!-- .entry-summary -->
            </article>  
          </section>  
        
    <?php }
    wp_reset_query();
    ?>
     </div>
        </div><!--blog-section -->
      </main><!-- #main -->

    </div><!-- #primary -->
  </div><!--#content-inside -->
</div><!-- #content -->

<?php
get_footer();
