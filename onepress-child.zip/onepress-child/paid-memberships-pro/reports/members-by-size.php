<?php

global $pmpro_reports;

$pmpro_reports['members_by_size'] = __('Members by Size', 'paid-memberships-pro' );

 
//widget
function pmpro_report_members_by_size_widget() {
	global $wpdb;

	$numberofemployees1 = nstxl_members_count_by_size('1-19_Employees');
	$numberofemployees2 = nstxl_members_count_by_size('20-99_Employees');
	$numberofemployees3 = nstxl_members_count_by_size('100-499_Employees');
	$numberofemployees4 = nstxl_members_count_by_size('500-2,499_Employees');
	$numberofemployees5 = nstxl_members_count_by_size('5,000+_Employees');  
	$total_employees = nstxl_members_total_by_size();  
	?>

	<span id="pmpro_report_members_by_size_memberships" class="pmpro_report-holder">
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php _e('Company Size', 'paid-memberships-pro' ); ?></th>
					<th scope="col"><?php _e('All Members', 'paid-memberships-pro' ); ?></th>
				</tr>
				<tr>
					<th scope="col"><strong><?php _e('Total Members', 'paid-memberships-pro' ); ?></strong></th>
					<th scope="col"><strong><?php echo $total_employees;?></strong></th>
				</tr>
			</thead>

			<tbody>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('1-19 Employees', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $numberofemployees1; ?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('20-99 Employees', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $numberofemployees2;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('100-499 Employees', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $numberofemployees3;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('500-2,499 Employees', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $numberofemployees4;?></td>

				</tr>
				<tr class="pmpro_report_tr2">
					<th scope="row">
						<?php _e('5,000+ Employees', 'paid-memberships-pro' ); ?>
					</th>
					<td><?php echo $numberofemployees5;?></td>

				</tr>

			</tbody>

		</table>
		<?php if ( function_exists( 'pmpro_report_members_by_size_page' ) ) { ?>
			<p class="pmpro_report-button">
				<a class="button button-primary" href="<?php echo admin_url( 'admin.php?page=pmpro-reports&report=members_by_size' ); ?>"><?php _e('Details', 'paid-memberships-pro' );?></a>
			</p>
		<?php } ?>
	</span>

	<?php
}

function pmpro_report_members_by_size_page()
{
	global $wpdb, $pmpro_currency_symbol;

	$numberofemployees1 = nstxl_members_count_by_size('1-19_Employees');
	$numberofemployees2 = nstxl_members_count_by_size('20-99_Employees');
	$numberofemployees3 = nstxl_members_count_by_size('100-499_Employees');
	$numberofemployees4 = nstxl_members_count_by_size('500-2,499_Employees');
	$numberofemployees5 = nstxl_members_count_by_size('5,000+_Employees'); 
	$total_employees = nstxl_members_total_by_size(); 
	?>

	<div style="clear: both;"></div>

	<?php if($total_employees == '0') { echo "<h3>No members found.</h3>"; } ?>	

	<div id="piechart"></div>
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript">
		google.charts.load('current', {'packages':['corechart']});
		google.charts.setOnLoadCallback(drawChart); 

// Draw the chart and set the chart values
function drawChart() {
	var data = google.visualization.arrayToDataTable([
		['Members', ''],
		['1-19 Employees', <?php echo $numberofemployees1;?>],
		['20-99 Employees', <?php echo $numberofemployees2;?>],
		['100-499 Employees',<?php echo $numberofemployees3;?>],
		['500-2,499 Employees', <?php echo $numberofemployees4;?>],
		['5,000+ Employees', <?php echo $numberofemployees5;?>]
		]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'Members by Size', 'width':1000, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>

<?php
}





