<?php
global $post;
$add_repeater_update = get_field('latest_documents');
if (isset($add_repeater_update) && !empty($add_repeater_update)) { ?>
 <aside class="aside-opportunity-content widget">
  <?php if (isset($_POST['downloadadditionaldoc'])) {
    $upload_dir = wp_upload_dir();
    $upload_dir_path = $upload_dir["basedir"];
    $date = current_time('timestamp');
    $downloaded_additionaldoc_path = $upload_dir_path . '/opportunity-documents/';
    if (!file_exists($downloaded_additionaldoc_path)) {
      mkdir($downloaded_additionaldoc_path, 0777, true);
    }
    $downloaded_additionaldoc_url = $upload_dir["baseurl"] . '/opportunity-documents/';


    $zip_destination = $downloaded_additionaldoc_path . '/additionaldocuments-' . $date . '.zip';
    $exported_additionaldoc_path_url = $downloaded_additionaldoc_url . basename($zip_destination);
    $zipname = basename($zip_destination);
    $za = new ZipArchive;

    if ($za->open($zip_destination, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
      echo '<div class="notice notice-error"><p>' . (!empty($this->last_error) ? sprintf(__('Error: %s', 'download-plugins-dashboard'), $this->last_error) : __('Something went wrong...', 'onepress') ) . '</p></div>';
      exit();
    }
    if (isset($_POST['additional_doc']) && !empty($_POST['additional_doc'])) {
      $download_additionaldocs = $_POST['additional_doc'];

      foreach ($download_additionaldocs as $download_additionaldoc) {
        $document_parse_array = parse_url($download_additionaldoc);
        $document_half_path = $document_parse_array['path'];
        $document_full_path = get_home_path() . $document_half_path;
        //$fpath = '/opportunity-documents/' . get_the_title() . '-' . get_the_ID() . '/' . basename($document_half_path);
        $fpath = '/opportunity-documents/' . basename($document_half_path);
        $za->addFile($document_full_path, $fpath);
      }
    }
    $za->close();
    //if (file_exists($exported_additionaldoc_path_url)) {
    ?>
   <h4 class="doc-success-msg"><?php _e('Your additional documents zip have generated successfully please click', 'nstxl'); ?> <a id='downloadproposal' href="<?php echo $exported_additionaldoc_path_url; ?>" download> here </a><?php _e('to download the documents.', 'nstxl'); ?> </h4>
    <?php
    //}
  }
//if(count(array_filter(array_values($add_repeater_update))) != count(array_values($add_repeater_update))) {
  ?>
    <div class="widget-content">
      <div class="table table-responsive">
        <form method="post"  name="additionaldocumentform" id="additionaldocumentform" action="" enctype="multipart/form-data">
          <table class="table table-striped table-bordered table-hover">
            <thead>
              <tr>        
                <th><h2 class="widget-title"><?php _e(' ADDITIONAL DOCUMENTS', 'onepress'); ?></h2></th>
                <th><div class="hidden-check"><input type="checkbox" id="select_all_adddocuments" /><label for="select_all_adddocuments"><?php _e('Select All', 'onepress'); ?></label></div></th>
              </tr>
            </thead>
            <tbody> 
              <?php foreach ($add_repeater_update as $row) { ?>
                <tr>
                  <td><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/documents-dark.svg" class="oppt-doc-icons"><a href="<?php echo $row['additional_documents']['url']; ?>" download><?php echo $row['additional_documents']['title']; ?></a></td>
                  <td class="td-right"><div class="custom-control custom-checkbox mb-3">
                      <input type="checkbox" name="additional_doc[]" class="custom-control-input adddocumentcheck" id="additional<?php echo $row['additional_documents']['ID']; ?>" data-id="<?php echo $row['additional_documents']['ID']; ?>" value="<?php echo esc_url($row['additional_documents']['url']); ?>">
                      <label class="custom-control-label" for="additional<?php echo $row['additional_documents']['ID']; ?>">&nbsp;</label>
                    </div>
                  </td>
                </tr>
              <?php } ?>
              <tr>
                <td colspan="3" class="text-right"><button type="submit" name="downloadadditionaldoc" id="downloadadditionaldoc" value="downloadadditionalydoc" class="btn btn-txt no-btn" disabled><?php _e('Download', 'onepress'); ?></button></td>
              </tr>
            </tbody>
          </table>
        </form>
      </div>
    </div>
  </aside>
  <script type="text/javascript">
    jQuery(document).ready(function ($) {
      if ($('.adddocumentcheck:checked').length != 0) {
        $('#downloadadditionaldoc').prop('disabled', false);
      } else {
        $('#downloadadditionaldoc').prop('disabled', true);
      }
      $('#select_all_adddocuments').on('click', function () {
        if (this.checked) {
          $('.adddocumentcheck').each(function () {
            this.checked = true;
            $('#downloadadditionaldoc').prop('disabled', false);
          });
        } else {
          $('.adddocumentcheck').each(function () {
            this.checked = false;
            $('#downloadadditionaldoc').prop('disabled', true);
          });
        }
      });

      $('.adddocumentcheck').on('click', function () {
        if ($('.adddocumentcheck:checked').length == $('.adddocumentcheck').length) {
          $('#select_all_adddocuments').prop('checked', true);
        } else {
          $('#select_all_adddocuments').prop('checked', false);
        }

        if ($('.adddocumentcheck:checked').length != 0) {
          $('#downloadadditionaldoc').prop('disabled', false);
        } else {
          $('#downloadadditionaldoc').prop('disabled', true);
        }
      });
    });
  </script>
  <?php
}