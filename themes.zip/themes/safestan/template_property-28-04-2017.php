<?php
/**
 * Template Name: Property
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
<?php 
global $wpdb, $args1, $args2;
//echo do_shortcode('[wpdreams_ajaxsearchlite]');

 ?>
	<?php
	$value =  trim($_POST['searchValue']);

	//ltrim zero value from string for numeric value
	$valueArray = explode(' ', $value);
	foreach ($valueArray as $key => $val) {
		if(is_numeric($val))
		{
			$newValue = ltrim($val, "0");
			$valueArray[$key] = $newValue;
		}	
	}
	$value = implode(' ', $valueArray);
	// Start the loop.
	while ( have_posts() ) : the_post();?>
	<!-- Start Head Section -->
	<section class="property-head">
		<div class="container">
    		<div class="row">
            	<div class="col-md-12">
            		<div class="search">
                    	<div class="form">
                        		<form role="form" class="form-inline" method="post">
                            	    <div class="form-group">
                                    	<input type="text" placeholder="Enter an address, city or ZIP code" value="<?php echo $value ?>" class="form-control" name="searchValue" />
                                    </div>
                                    <div class="form-group">
                                    	<button type ="submit" class="btn1">Search</button>
                                    </div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
	        </div>
	</section>
	<!-- End Head Section -->
	<section class="property-search">
		<div class="container">
	     	<?php
	     	
	     	if($value != '')
	     	{
	     		$value = str_replace(",", '', $value);
	     		$ex_value = strtolower ($value);	     		
	     		$search = array(); $replace = array();

	     		$val = explode(' ', $ex_value);
	     		$str = ''; $count = 0;
	     		//echo "<pre>";print_r($val);
	     		if( !empty($val) ) {
	     			foreach($val as $key => $values) {
		     			if( !empty($values) ) { $count++;
		     				if( $count == 1)
		     					$str.= "search_term = '$values' ";
		     				else
		     					$str.= "OR search_term = '$values' ";
		     			}
	     			}
	     		}
	     		$searchrows = $wpdb->get_results("SELECT search_term,term_prefix FROM wpsft_search_term WHERE $str ");
	     		//echo "SELECT search_term,term_prefix FROM wpsft_search_term WHERE $str ";die();
	     		if( !empty($searchrows) ) {
	     			foreach ($searchrows as $searchrow) { 
	    				$search[] = $searchrow->search_term;
	    				$replace[] = $searchrow->term_prefix;
	    			}
	     		}
	     		//echo "<pre>";print_r($search);print_r($replace);
	     		$param1 = str_replace($search, $replace, $ex_value);
	     		
	     	}
	     	else
	     	{
	     		$ex_value = '';
	     	}
	     		//print_r($ex_value);die;
	     		//if(!empty($value) && count($value) >= 1)
	     	
		    if($ex_value !='') 
      		{
      			
      			$searchnewRows1 = $wpdb->get_results("SELECT search_term FROM wpsft_search_term WHERE term_prefix = '$param1'");

      			if(count($searchnewRows1)){
					foreach($searchnewRows1 as $abc){
						$where_cond .= " OR address1 LIKE '%".$abc->search_term."%'";
					}
				}
				$where = ltrim($where_cond, " OR ");
				$where = rtrim($where, " ");

      			$searchnewRows2 = $wpdb->get_results("SELECT term_prefix FROM wpsft_search_term WHERE term_prefix = '$param1'");
      			//print_r($searchnewRows2);/*

      			if(count($searchnewRows2)){
					foreach($searchnewRows2 as $abc){
						$array_searchTerm[] = $abc->term_prefix;
					}
				}
      			
      			if(is_array($array_searchTerm))
				{      				
	      			if(in_array($param1, $array_searchTerm))
			     	{
			     		$myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') GROUP BY p.ID ) as t1 WHERE $where LIMIT 0, 10");

			     		$myrows_count = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') GROUP BY p.ID ) as t1 WHERE $where");
			     	}
			    } 	
		     	else
		     	{
	     			$myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') GROUP BY p.ID ) as t1 WHERE address LIKE '%".$value."%' OR address LIKE '%".$param1."%' LIMIT 0, 10" );

	     			$myrows_count = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') GROUP BY p.ID ) as t1 WHERE address LIKE '%".$value."%' OR address LIKE '%".$param1."%' " );
		     	}
			}
			else
			{
				$myrows = $wpdb->get_results("SELECT * FROM wpsft_posts WHERE 1=1 AND wpsft_posts.post_type = 'property' AND ((wpsft_posts.post_status = 'publish')) ORDER BY wpsft_posts.post_date DESC LIMIT 0, 10");

				$myrows_count = $wpdb->get_results("SELECT * FROM wpsft_posts WHERE 1=1 AND wpsft_posts.post_type = 'property' AND ((wpsft_posts.post_status = 'publish')) ORDER BY wpsft_posts.post_date");
				//echo count($myrows);
		  	}
			
		    

		    //echo count($myrows);
		    //echo '<pre>';print_r($myrows);
	     	if(isset($_POST) && !empty($_POST)){
				if(count($myrows_count) == 1)
		        {
		        	echo '<h3 class="heading3">'.count($myrows_count).' Property found</h3>
		     		<div class="matchkey">Matching with your keywords</div>';	
		        }
		        else if(empty(count($myrows_count)))
		        {	
		        	if(!empty($value))
		        	{
		        		echo '<h3 class="heading3">No Properties found</h3>
		     		<div class="matchkey">Matching with your keywords</div>';	
		        	}
		        }
		        else
		        {	
		        	echo '<h3 class="heading3">'.count($myrows_count).' Properties found</h3>
		     		<div class="matchkey">Matching with your keywords</div>';
		        }
	        }
	     	?>
	     	<input type="hidden" value="" name="post_id" id="post_id" />
            <input type="hidden" value="<?php echo $ex_value;?>" name="searchValue" id="SearchValue" />
	     	<div id="searchWrappper">
				<?php
			    foreach ($myrows as $myrow)
			    {
				 	?>
			 		<div class="search">
				        <div class="row">
				          	<div class="col-sm-5 align-center">
				            	<div class="search-result pos-rel">
				   		 		 	<?php 
				   		 		 		$imfeatureds = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id = ".$myrow->ID." AND image_featured_status = 1");
				   		 		 		//echo '<pre>';print_r($imfeatureds);
				   		 		 		/*$image = wp_get_attachment_image_src( get_post_thumbnail_id( $myrow->ID ), 'single-post-thumbnail' );*/ 
					   		 		 	if($imfeatureds[0]->image_path)
					   		 		 	{	?>
					                        <img src="<?php echo $imfeatureds[0]->image_path; ?>" class="img-responsive" alt=""/>
					                    	<?php 
					                    }
					                    else
					                    {
					                    	/*echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found.jpg" class="img-responsive feature-img" alt=""/>';*/
					                    	if(CFS()->get('_property_address',$myrow->ID))
					                        {
					                            $property_address = CFS()->get('_property_address', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_city', $myrow->ID))
					                        {
					                            $property_city = CFS()->get('_property_city', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_state', $myrow->ID))
					                        {
					                            $property_state = CFS()->get('_property_state', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_zip_code', $myrow->ID))
					                        {
					                            $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
					                        }
					                    	
					    $property_fulladdr = array('property_address' => urlencode($property_address),
					                    	'property_city' => urlencode($property_city),
					                    	'property_state' => urlencode($property_state),
					                    	'_property_zip_code' => urlencode($property_zip_code)
					                    	);
					                    	//print_r($property_fulladdr);
					    				   $op = '<div class="google-map-embed">';
										   $op .= '<iframe width="470" height="275" frameborder="0" style="border:0" allowfullscreen ';
										   $op .= 'src="https://www.google.com/maps/embed/v1/place?q=';
										   $op .= implode(',', $property_fulladdr);
										   $op .= '&key=AIzaSyCUpXt8H-Wd6-_SHbSmnYwdBPXLDQD-gc0';  
										   $op .= '&zoom=11"></iframe></div>';

										   print $op;
					                    }
				                    ?>
				                 	<!--<div class="img-overlay">&nbsp;</div>-->
				                    <div class="content">	
				                        <div class="top-content">
				                        	<?php 
				                        	$fields = CFS()->get('_propery_gallery', $myrow->ID);
				                        	
				                        	$countPhoto = count($fields);
				                        	if($countPhoto > 0)
				                        	{
				                        		if($countPhoto == 1)
				                        		{	
				                        			echo '<div class="num-photo">'.$countPhoto.' Photo</div>';	
				                        		}
				                        		else
				                        		{
				                        			echo '<div class="num-photo">'.$countPhoto.' Photos</div>';
				                        		}
				                        	}	
				                        	?>
				                            <!-- <div class="like-dislike"><a href="javascript:" class="favorite-property">&nbsp;</a></div> -->
				                        </div>
				                        <div class="bottom-content">
				                            <span class="common-align-center">
				                            	 <img src="<?php bloginfo('template_directory');?>/images/ready-icon.png"  alt=""/>
				                             </span>
				                             <span class="common-align-center">
				                            	<!--<span class="property-move">Upload Images ( New Property) </span>-->
				                             	<?php 
				                             		if(CFS()->get('_property_price', $myrow->ID))
				                                    {
				                                        $property_price = CFS()->get('_property_price', $myrow->ID);
				                                    	echo '<div class="property-price">$'.$property_price.'</div>';
				                                    }
				                             	?>
				                             </span>
				                        </div>
				                    </div>
				                </div>
				            </div>
				            <div class="col-sm-7 align-center">
				           	  	<div class="details">
				            		<h3  class="heading3"><a href="<?php echo $myrow->guid;?>" class="ptl">
                            <?php echo $myrow->post_title;?>
                          </a></h3> 
				            		<?php 
				                 		if(CFS()->get('_property_size', $myrow->ID))
				                        {
				                            $property_size = CFS()->get('_property_size', $myrow->ID);
				                        	echo '<div class="num-feet">'.$property_size.' sqft</div>';
				                        }
				                 	?>
				                	<div class="property-address">
				                		<?php
				                        if(CFS()->get('_property_address',$myrow->ID))
				                        {
				                            $property_address = CFS()->get('_property_address', $myrow->ID);
				                        }
				                        if(CFS()->get('_property_city', $myrow->ID))
				                        {
				                            $property_city = CFS()->get('_property_city', $myrow->ID);
				                        }
				                        if(CFS()->get('_property_state', $myrow->ID))
				                        {
				                            $property_state = CFS()->get('_property_state', $myrow->ID);
				                        }
				                        if(CFS()->get('_property_zip_code', $myrow->ID))
				                        {
				                            $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
				                        }                                       
				                        echo $property_address.', '.$property_city.', '.$property_state.' '.$property_zip_code;
				                        ?>                                        
				                	</div>
				                	<p class="para2">
				                		<?php
				                          $content = $myrow->post_content;
				                          echo $contentnew = substr($content, 0, 200);
				                        ?>
				                	</p>
				                    <div  class="footer-details my-foot">
				                   		
							<?php 
						            echo do_shortcode('[RICH_REVIEWS_SNIPPET category="post" id="'.$myrow->ID.'" stars_only="true"]');
						            ?>
							<span class="count-review">
				                        	<img src="<?php bloginfo('template_directory');?>/images/review-icon.png" class="mr-5"  alt=""/> 
				                        <a href="<?php echo $myrow->guid;?>">
				                        	<?php 
				                        		$ID = $myrow->ID;
				                        		$myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$ID' and review_status='1' ORDER BY id DESC");
				                        		$count_reviews = count($myrows);
				                        		if($count_reviews == 1)
				                        		{
				                        			echo '1 + Review';
				                        		}
				                        		if($count_reviews == 0)
				                        		{
				                        			echo 'No Reviews';
				                        		}
				                        		else
				                        		{
				                        			if($count_reviews != 1)
				                        			{
				                        				echo $count_reviews.'+ Reviews';
				                        			}
				                        		}
				                        	?>
				                        </a>
				                        <a href="<?php echo $myrow->guid;?>" class="property_page_reivew">
				                        Write a review
				                        </a>
				                        </span>
				                  	</div>
				              	</div>
				            </div>
				        </div>
					</div>
					<?php 
					$count++; 
				}     
			    ?>
			</div>
			<?php

	        if(count($myrows_count) > 10 || count($myrows_count) > 10)
	   		{
	   			?>
		   		<div class="text-center">
		   		<!-- <img src="<?php //bloginfo('template_directory');?>/images/loader.svg" width="32" height="30" alt=""/> -->
		   		<a href="javascript:void(0);" class="load_more" data-nonce="<?php echo wp_create_nonce('load_posts') ?>">
	                  <img src="<?php bloginfo('template_directory');?>/images/loader.svg" alt="" width="32" height="30">
	            </a>
		   		</div>
	    		<?php 
	    	}
	    	?>
	    </div>
	</section>
	<?php // End of the loop.
	endwhile;
	?>
<?php get_footer(); ?>
