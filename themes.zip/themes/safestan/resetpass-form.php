<?php
/*
If you would like to edit this file, copy it to your current theme's directory and edit it there.
Theme My Login will always look in your theme's directory first, before using this default template.
*/
?>
<div class="row">
	<div class="login-box tmls tml-resetpass" id="theme-my-login<?php $template->the_instance(); ?>">
		<div class="align-middle1">
			<?php $template->the_action_template_message( 'resetpass' ); ?>
			<?php $template->the_errors(); ?>
			<form name="resetpassform" id="resetpassform<?php $template->the_instance(); ?>" action="<?php $template->the_action_url( 'resetpass', 'login_post' ); ?>" method="post" autocomplete="off" class="form1">
				<div class="form-group">
				<div class="user-pass1-wrap row">
					<div class="col-sm-12 col-xs-12 form-group">
						<label for="pass1"><?php _e( 'New password', 'theme-my-login' ); ?></label>
						<div class="wp-pwd">
							<span class="password-input-wrapper">
								<input type="password" data-reveal="1" data-pw="<?php echo esc_attr( wp_generate_password( 16 ) ); ?>" name="pass1" id="pass1" class="input form-control" size="20" value="" autocomplete="off" aria-describedby="pass-strength-result" />
							</span>
							<div id="pass-strength-result" class="hide-if-no-js" aria-live="polite"><?php _e( 'Strength indicator', 'theme-my-login' ); ?></div>
						</div>
					</div>	
				</div>

				<div class="user-pass2-wrap row">
					<div class="col-sm-12 col-xs-12 form-group">
						<label for="pass2"><?php _e( 'Confirm new password', 'theme-my-login' ); ?></label>
						<input type="password" name="pass2" id="pass2" class="input form-control" size="20" value="" autocomplete="off" />
					</div>
				</div>

				<div class="description indicator-hint"><?php echo wp_get_password_hint(); ?></div>

				<?php do_action( 'resetpassword_form' ); ?>
				</div>
				
				<center>
					<div class="tml-submit-wrap form-group">
						<input type="submit" name="wp-submit" id="wp-submit<?php $template->the_instance(); ?>" value="<?php esc_attr_e( 'Reset Password', 'theme-my-login' ); ?>" class="btn btn-primary w-auto btn1" />
						<input type="hidden" id="user_login" value="<?php echo esc_attr( $GLOBALS['rp_login'] ); ?>" autocomplete="off" />
						<input type="hidden" name="rp_key" value="<?php echo esc_attr( $GLOBALS['rp_key'] ); ?>" />
						<input type="hidden" name="instance" value="<?php $template->the_instance(); ?>" />
						<input type="hidden" name="action" value="resetpass" />
					</div>
				</center>
			</form>
			<?php $template->the_action_links( array(
				'login' => false,
				'register' => false,
				'lostpassword' => false
			) ); ?>
		</div>
		<!-- <div class="col-sm-5 col-md-6 col-lg-6 col-xs-12 align-middle divider">
	    	<div class="or or1"> <span>Or</span> </div>
	        <div class="login-social">
	         	<?php //echo do_shortcode("[wordpress_social_login]");?>
	        </div>
	    </div>	 -->
	</div>
</div>