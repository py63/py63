<?php
/**
 * The template for displaying comments
 *
 * The area of the page that contains both current comments
 * and the comment form.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">
	
	<?php if ( have_comments() ) : ?>
		<div class="content">
			<div class="coment-section">
		        <h4 class="sub-hadding"><?php
					$comments_number = get_comments_number();
					if ( 1 === $comments_number ) {
						/* translators: %s: post title */
						printf( _x( 'One thought on &ldquo;%s&rdquo;', 'comments title', 'twentysixteen' ), get_the_title() );
					} else {
						printf(
							/* translators: 1: number of comments, 2: post title */
							_nx(
								'%1$s thought on &ldquo;%2$s&rdquo;',
								'%1$s thoughts on &ldquo;%2$s&rdquo;',
								$comments_number,
								'comments title',
								'twentysixteen'
							),
							number_format_i18n( $comments_number ),
							get_the_title()
						);
					}
				?></h4>
		        <div class="coment">
		          	<div class="media">
		          		<?php the_comments_navigation(); ?>
						<ol class="comment-list">
							<?php
								/*wp_list_comments( array(
									'style'       => 'ol',
									'short_ping'  => true,
									'avatar_size' => 42,
								) );*/
							

	wp_list_comments('callback=mytheme_comment');
	
	






							?>
						</ol><!-- .comment-list -->
						<?php the_comments_navigation(); ?>

			            <!-- <div class="media-left"> <img src="images/user-1.png" class="media-object" alt=""> </div>
			            <div class="media-body">
			              	<h4 class="hadd-coment m-0">Resident <span> February 21, 2018</span></h4>
			              	<p class="m-0"> <a href="#"><img src="images/star-coment.png" alt="..."></a> <a href="#"><img src="images/star-coment.png" alt="..."></a> <a href="#"><img src="images/star-coment.png" alt="..."></a> <a href="#"><img src="images/star-coment.png" alt="..."></a> <a href="#"><img src="images/star-coment.png" alt="..."></a> </p>
			              	<p class="m-0">I love living in a room with 6 people. 2 of us have singles and then there are 2 rooms with doubles. It sucks sharing one shower and toilet and sink with 6 people and you have to clean everything and buy everything yourself.</p>
							<a href="#" class="reply">Reply</a>
			            </div> -->
		          	</div>
		        </div>
		    </div>
		</div>
		

	<?php endif; // Check for have_comments(). ?>

	<?php
		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
	?>
		<p class="no-comments"><?php _e( 'Comments are closed.', 'twentysixteen' ); ?></p>
	<?php endif; ?>
	<div class="content button-coment">
		<div class="full-width text-center pt-3 pb-3">
			<a href="javascript:void(0)" class="btn btn-primary " id="coment-feild">Leave a Comment</a>
		</div>
	</div>
	<div class="coment-form mt-3">
	<?php
		comment_form( array(
			'title_reply_before' => '<h4 class="hading-form">',
			'title_reply_after'  => '</h4>',
			'cancel_reply_before'=>'<p class="canrep">',
			'cancel_reply_after'=>'</p>',
			'label_submit'  => __( 'POST REPLY' ),
			'class_submit' => 'btn btn-primary pull-right mt-2',
		) );
	?>
		<a id="close-form" class="close-form" href="javascript:void(0)">
			<img src="<?php bloginfo('stylesheet_directory'); ?>/images/cross-2.png" alt="crossimg">
		</a>
	</div>

</div><!-- .comments-area -->
