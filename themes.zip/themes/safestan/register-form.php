<?php
/*
If you would like to edit this file, copy it to your current theme's directory and edit it there.
Theme My Login will always look in your theme's directory first, before using this default template.
*/
?>
<div class="sign-up tmls tml-register" id="theme-my-login<?php $template->the_instance(); ?>" >  
	<?php //$template->the_action_template_message( 'register' ); ?>
	<?php $template->the_errors(); ?>
	<form name="registerform" id="registerform<?php $template->the_instance(); ?>" action="<?php $template->the_action_url( 'register', 'login_post' ); ?>" method="post" class="form1">
        <div class="row">
          	<div class="col-md-6 col-sm-6">
	          	<div class="form-group">
	            	<p class="label-had"><?php _e( 'First Name<sup>*</sup>', 'theme-my-login' ) ?></p>
	            	<input type="text" name="first_name" id="first_name<?php $template->the_instance(); ?>" class="input form-control" value="<?php $template->the_posted_value( 'first_name' ); ?>" placeholder="First Name" />
	            </div>
          	</div>
          	<div class="col-md-6 col-sm-6">
          		<div class="form-group">		            
	            	<p class="label-had"><?php _e( 'Last Name<sup>*</sup>', 'theme-my-login' ) ?></p>	            	            
	            	<input type="text" name="last_name" id="last_name<?php $template->the_instance(); ?>" class="input form-control" value="<?php $template->the_posted_value( 'last_name' ); ?>" placeholder="Last Name" />
	            </div>
          	</div>
        </div>
        <div class="row">
          	<div class="col-md-12 col-sm-12">
	          	<div class="form-group">
	        		<p class="label-had"><?php _e( 'Username<sup>*</sup>', 'theme-my-login' ); ?></p>
	            	<input type="text" name="user_login" id="user_login<?php $template->the_instance(); ?>" class="input form-control" value="<?php $template->the_posted_value( 'user_login' ); ?>" placeholder="Username" />
	            </div>
          	</div>
        </div>		        
        <div class="row">
          	<div class="col-md-6 col-sm-6">
	          	<div class="form-group">
	        		<p class="label-had"><?php _e( 'Email Address<sup>*</sup>', 'theme-my-login' ); ?></p>
	            	<input type="text" name="user_email" id="user_email<?php $template->the_instance(); ?>" class="input form-control" value="<?php $template->the_posted_value( 'user_email' ); ?>" placeholder="Email Address" />
	            </div>
          	</div>
        	<div class="col-md-6 col-sm-6">
        		<div class="form-group">
        			<p class="label-had"><?php _e( 'Zip Code', 'theme-my-login' ) ?></p><input type="text" name="zip_code" id="zip_code<?php $template->the_instance(); ?>" class="input form-control" value="<?php $template->the_posted_value( 'zip_code' ); ?>" placeholder="Zip Code" />
        		</div>
	        </div>
        </div>
        <div class="row">
	        <div class="col-md-6 col-sm-6">
		      	<div class="form-group">
		        	<p class="label-had"><?php _e( 'Password<sup>*</sup>', 'theme-my-login' ); ?></p>
		        	<input autocomplete="off" name="pass1" id="pass1<?php $template->the_instance(); ?>" class="input form-control" value="" type="password" placeholder="Password" />
		        </div>
		    </div>
		    <div class="col-md-6 col-sm-6">
		      	<div class="form-group">
		        	<p class="label-had"><?php _e( 'Confirm Password<sup>*</sup>', 'theme-my-login' ); ?></p>
		        	<input autocomplete="off" name="pass2" id="pass2<?php $template->the_instance(); ?>" class="input form-control" value="" type="password" placeholder="Confirm Password" />
		        </div>
		    </div>
	    </div>

        <p class="mt-1"><input type="checkbox" name="login_accept" id="login_accept" value="" /> <label for="login_accept" class="terms">I Agree to the Site Terms of Services *</label></p>
        <div class="btn-align">			              	
        	<input type="submit" name="wp-submit" id="wp-submit<?php $template->the_instance(); ?>" value="<?php esc_attr_e( 'Sign up', 'theme-my-login' ); ?>" class="btn btn-primary btn-block mt-0 w-100" />
			<input type="hidden" name="redirect_to" value="<?php $template->the_redirect_url( 'register' ); ?>" />
			<input type="hidden" name="instance" value="<?php $template->the_instance(); ?>" />
			<input type="hidden" name="action" value="register" />
        </div>
  	</form>							 
</div>
<center>
  	<div class="login-social sign-social fb-gplus-twit"> 
  		<span class="login-with"> OR Login with </span>
  		<?php echo do_shortcode("[wordpress_social_login]");?>
    	<p class="other-option">Already have an account?  <br class="visible-xs"><a href="<?php bloginfo('url');?>/login/">Sign In</a></p>
  	</div>
</center>

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#login_accept').change(function(){
		  if(jQuery('#login_accept').is(':checked')){
		    jQuery('#login_accept').attr('value','1');
		  }else{
		    jQuery('#login_accept').attr('value','');
		  }
		});
	});
</script>
