<?php 
  global $wpdb, $current_user, $pmpro_invoice, $pmpro_msg, $pmpro_msgt;

  if(empty($current_user->membership_level))
    $confirmation_message = "";
  else
    $confirmation_message = "";   

  //confirmation message for this level
  $level_message = $wpdb->get_var("SELECT l.confirmation FROM $wpdb->pmpro_membership_levels l LEFT JOIN $wpdb->pmpro_memberships_users mu ON l.id = mu.membership_id WHERE mu.status = 'active' AND mu.user_id = '" . $current_user->ID . "' LIMIT 1");
  if(!empty($level_message))
   $confirmation_message .= "\n".stripslashes($level_message) . "\n";
?>  
<?php if(!empty($pmpro_invoice) && !empty($pmpro_invoice->id)) { ?>   
  
    <?php
    $pmpro_invoice->getUser();
    $pmpro_invoice->getMembershipLevel();     
    $getdetails = $pmpro_invoice->getMembershipLevel();
  
    if($pmpro_invoice->gateway == "check" && !pmpro_isLevelFree($pmpro_invoice->membership_level))
    //$confirmation_message .= wpautop(wp_unslash( pmpro_getOption("instructions") ) );
    $confirmation_message = apply_filters("pmpro_confirmation_message", $confirmation_message, $pmpro_invoice);       
    
    echo $confirmation_message;
  ?>
 <div class="printpdf clearfix">
   <button id="cmd" class="btn btn-txt"><?php _e('Save Invoice', 'paid-memberships-pro' ); ?></button>
 <?php /* ?><a class="pmpro_a-print" href="javascript:window.print()"><?php _e('Print Invoice', 'paid-memberships-pro' ); ?></a><?php */ ?>
</div> 
<style>
td {
    padding: 8px;
    border-bottom: 0px solid silver;
}
.cstm-td td {
    padding-right: 0px;
}
.cstm-td td,.cstm-td th {padding-right: 0px; text-align:center;}
.cstm-tbl td {padding: 10px;}
.titlewel {margin-top: 20px;}

#element-to-print-invoice td {padding: 0px;}

.cstm-tbl{-fs-table-paginate:paginate !important ;border-spacing:0 !important}

.cstm-tbl td{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child td{border-top-width:2px !important} 
.cstm-tbl td:first-child{border-left-width:2px !important}  

.cstm-tbl tr th{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child th{border-top-width:2px !important} 
.cstm-tbl tr th:first-child{border-left-width:2px !important}

@media print {
    .cstm-td td b {color: #ed193e !important;}
  .cstm-tbl td,.cstm-tbl th{ border:1px solid #687279 !important;}
  .titlesingle {display: none}
.cstm-tbl td{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child td{border-top-width:2px !important} 
.cstm-tbl td:first-child{border-left-width:2px !important}  

.cstm-tbl tr th{border-width:0 2px 2px 0 !important;border-color:#687279 !important}
.cstm-tbl tr:first-child th{border-top-width:2px !important} 
.cstm-tbl tr th:first-child{border-left-width:2px !important}

}


@media (max-width:991px) {

}
@media (max-width:575px) {
.side-padding-inner {
  padding: 0px !important;
}
.side-padding-inner td.cstm-td {
  display: block !important;
  width: 100% !important;
  padding: 30px 0px !important;
}
.side-padding-inner td {
  text-align: left !important;
}
.side-padding-inner td table {
  border: none !important;
}
.side-padding-inner td table.cstm-tbl td {
  padding: 5px 15px !important;
}
.side-padding-inner th {
  padding: 5px 15px !important;
  text-align: left;
}

}
</style>

<!-- strat new  -->

<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" id="element-to-print" style="border:0 none;">
  <tr>
    <td align="center" style="border:0 none;"><!--[if gte mso 9]>
  <table id="tableForOutlook" align="center"><tr><td>
<![endif]-->
      
      <div style="max-width:750px; margin:0 auto;">
        <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width:750px; margin:0px auto;" class="contenttable">
          <tbody>
            
            <!--  <tr>
              <td style="background-color:#fff;" bgcolor="#fff" height="40">&nbsp;</td>
            </tr>-->
            <tr>
              <td valign="middle" style="background-color:#fff; text-align:center; border-top:3px solid #ff0000; padding-top:30px; padding-bottom:30px; " class="side-padding"><a href="https:www.nstxl.org" target="_blank"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/nstxl-large-logo.png" height="75" alt="" class="manageheight" border="0"/></a></td>
            </tr>
            <tr>
              <td valign="middle" style="background-color:#fff; text-align:center;border-top:3px solid #ff0000; padding-top:0px; padding-right:0px; padding-left:0px; " class="side-padding"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/header-bg.jpg" height="140px" width="100%" alt="" border="0"/></td>
            </tr>
            <tr>
              <td style="background-color:#fff; padding-top:20px; padding-bottom:10px; padding-left:0px; padding-right:0px;" class="side-padding-inner"><table width="100%" border="0" cellpadding="0" cellspacing="10">
                  <tbody>
                    <tr>
                      <td class="cstm-td" width="70%" style="font-family: Arial, sans-serif; font-size:16px; 
                 line-height:26px;   background-color: #fff;color: #000;padding: 8px 15px;padding-left: 0px;"><b style="    margin-bottom: 0; text-transform:uppercase;font-size:40px; color:#000; text-align:left;
    ">INVOICE<br>
                        <br>
                        </b>
                        <table class="cstm-tbl" width="100%" border="1" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; text-align:center;">
                          <tr>
                            <th style="padding:5px 40px">Description</th>
                            <th style="padding:5px 20px">QTY</th>
                            <th style="padding:5px 40px">Price</th>
                          </tr>
                          <tr>
                            <td>1-year NSTXL Membership</br>
                              <?php
                              if(!empty($getdetails))
                                {
                                  echo $getdetails->name; 
                              }
                              else{
                                $getdetails = '';
                              }

                               ?></td>
                            <td>1</td>
                            <td><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></td>
                          </tr>
                          <tr>
                            <th></th>
                            <th>Total</th>
                            <th><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></th>
                          </tr>
                        </table></td>
                      <td  class="cstm-td"  width="30%" style="font-family: Arial, sans-serif; font-size:16px; 
                 line-height:26px; text-align:right;  background-color: #fff;color: #fff;padding: 8px 15px;padding-right: 0px;"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; border-left:2px solid #687279" >
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:20px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Amount Due</b> <br>
                              <span style="font-size:24px; color:#000;"><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></span></td>
                          </tr>
                       
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:20px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Billed To</b> <br>
                <?php if(!empty($pmpro_invoice->billing->name)) { ?>
                              <span style="font-size:16px; color:#000;"><?php echo $pmpro_invoice->billing->name?><br>

                              <?php echo $pmpro_invoice->billing->street?><br>
                              <?php echo $pmpro_invoice->billing->city; ?>, <?php echo $pmpro_invoice->billing->state; ?>, <?php echo $pmpro_invoice->billing->zip; ?> </span>
                              <?php } ?>

                          </td>
                          </tr>
                           <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:20px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Invoice Number</b> <br>
                              <span style="font-size:16px; color:#000;"><?php printf(__('%s', 'paid-memberships-pro' ), $pmpro_invoice->code, date_i18n(get_option('date_format'), $pmpro_invoice->timestamp));?></span></td>
                          </tr>
                           <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:20px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Start Date</b> <br>
                              <span style="font-size:16px; color:#000;"><?php echo date_i18n(get_option('date_format'), $pmpro_invoice->timestamp);?></span></td>
                          </tr>
                          <tr>
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:0px;"><b style="    margin-bottom: 0;
    font-size: 18px;">Membership Expires</b> <br>
                              <span style="font-size:16px; color:#000;">
                             <?php echo date_i18n(get_option('date_format'), $current_user->membership_level->enddate)?>
              </span></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr>
                      <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0;">
                          <tbody>
                            <tr>
                              <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff; max-width: 700px;padding: 0 0 0px; margin: 0 auto">
                                  <tbody>
                                    <tr>
                                      <td style="background-color:#fff;" bgcolor="#fff" height="20">&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td colspan="2" valign="top" align="center" style="font-family:Arial, sans-serif; color:#5F5F5F; font-size:14px; padding-bottom:0px;"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/nstxl-small-logo.png" width="30" alt="" border="0"/> | National Security Technology Accelerator | 1-800-364-1545 | <a href="https://www.nstxl.org" target="_blank" style="font-family:Arial, sans-serif; color:#ff0000; font-size:14px; text-decoration:none;">www.nstxl.org</a></td>
                                    </tr>
                                  </tbody>
                                </table></td>
                            </tr>
                          </tbody>
                        </table></td>
                    </tr>
                    
                    <!--table order list-->
                    
                  </tbody>
                </table></td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <!--[if gte mso 9]>
  </td></tr></table>
<![endif]--></td>
  </tr>
</table>
<?php 
  } 
  else 
  {
  
  ?>  
<div class="member-confirmation">
  <div class="title-section">
    <h3 class="border-bottom-red"><?php _e('Welcome', 'paid-memberships-pro' );?> <?php echo $current_user->user_firstname; ?></h3>
    <?php
    $confirmation_message .= "<p class='font-16'>" . sprintf(__('A welcome email has been sent to %s. <span> Below are details about your membership account:</span>', 'paid-memberships-pro' ), $current_user->user_email) . "</p>";
    $confirmation_message = apply_filters("pmpro_confirmation_message", $confirmation_message, false);
    
    echo $confirmation_message;
    ?>
</p>
  </div>
    <div class="row">
      <div class="col-sm-6">
        <div class="account">
          <p class="font-16"><b><?php _e('Account', 'paid-memberships-pro' );?>:</b></p>
          <p  class="font-16"><?php echo $current_user->display_name?></p>
          <p class="font-16">(<?php echo $current_user->user_email?>)</p>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="account">
            <p class="font-16"><b><?php _e('Membership Level', 'paid-memberships-pro' );?>:</b></p>
          <p  class="font-16"><?php if(!empty($current_user->membership_level)) echo $current_user->membership_level->name; else _e("Pending", 'paid-memberships-pro' );?> </p>
        </div>
      </div>
    </div>

  </div>


<?php 
  } 
?>  

<script type="text/javascript">
jQuery('#cmd').click(function() {


  var element = document.getElementById('element-to-print');
var opt = {
  margin:       .2,
  filename:     'confirmation.pdf',
  image:        { type: 'jpeg', quality: 0.98 },
  html2canvas:  { scale: 1 },
  jsPDF:        { unit: 'in', format: 'A4', orientation: 'portrait' }
};

// New Promise-based usage:
html2pdf().from(element).set(opt).save();
});
</script>

<style type="text/css">
  @media print {
    @page { size: auto !important;  margin: 0mm !important; }
    .btn-confirmation {display: none}
}
</style>