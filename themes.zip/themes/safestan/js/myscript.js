jQuery(document).ready(function($) {
	
	$('#example_admin').DataTable({ stateSave: true});
	$('#example_admin_inner').DataTable({ stateSave: true});

	var inputValue = $('.field-_property_zip_code input').val();
	var inputCondition = inputValue.toString().length;
	
	if(inputCondition == 4)
	{
		var changeValue = '0'.concat(inputValue);
		$('.field-_property_zip_code input').val(changeValue);
	}
	if(inputCondition == 3){
		var changeValue = '00'.concat(inputValue);
		$('.field-_property_zip_code input').val(changeValue);
	}
	if(inputCondition == 2){
		var changeValue = '000'.concat(inputValue);
		$('.field-_property_zip_code input').val(changeValue);
	}
	if(inputCondition == 1){
		var changeValue = '0000'.concat(inputValue);
		$('.field-_property_zip_code input').val(changeValue);
	}
} );