<?php 
	global $wpdb, $pmpro_invoice, $pmpro_msg, $pmpro_msgt, $current_user;
 $gda = get_user_meta($current_user->ID,'',true);

?>	
<?php 
	if($pmpro_invoice) 
	{ 
		?>
		<?php
			$pmpro_invoice->getUser();
			$pmpro_invoice->getMembershipLevel();
		?>
<div class="printpdf clearfix">
<button id="cmd"><?php _e('Save Invoice', 'paid-memberships-pro' ); ?></button>
<a class="pmpro_a-print" href="javascript:window.print()"><?php _e('Print Invoice', 'paid-memberships-pro' ); ?></a>
</div>
<div class="membership-recipt invoice-recipt" id="element-to-print-invoice">
	<div class="logo-recipt">
	  <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.png" alt="logo">
	</div>
  <h4 class="title-of-recipt">Membership Invoice</h4>
      <div style="text-align: right;font-size: 14px;">
	<div class="invoice-date-Id">		 
      <p>
			  <span style="">Invoice ID:</span> 
			  <?php printf(__('%s', 'paid-memberships-pro' ), $pmpro_invoice->code, date_i18n(get_option('date_format'), $pmpro_invoice->timestamp));?>
		 </p>
		 <p>
			  <span style="">Membership No:</span> 
			  <?php echo nstxl_get_member_id(get_current_user_id()); ?>
		 </p>
		 <p>
			  <span style="">Date:</span> 
			 <?php echo date_i18n(get_option('date_format'), $pmpro_invoice->timestamp);?>
		 </p>
	</div>
	<div class="invoice-address" style="padding-top: 20px;">	 
    <p>National Security Technology Accelerator<br>
    NSTXL<br>
    220 NW 8<span>th</span> Street<br>
    Portland, OR 97210 <br />USA</p>	 
</div>
</div>

	<div class="about-owner">
        <p style="font-size: 14px;">
          <?php
          	$companyname = $current_user->company_name;
        	if(isset($companyname) && !empty($companyname))
        	{
        		echo $companyname;
        	}
        	?>
    	</p>
       
        <?php 
        $poc = get_user_meta($current_user->ID,'poc',true);
        $user_info = get_userdata($poc);

        if (isset($user_info) && !empty($user_info)) {
         ?> 
          <p style="font-size: 14px;"><?php echo ucwords($user_info->display_name);  ?><p>
			<p style="font-weight: 600">Via email <?php echo $user_info->user_email; ?></p>
		<?php } ?>  
	
	</div>
	
<div class="table-responsive invoice-table">
			  <table class="payment-detail-table"  width="100%">
			  <tr style="text-align: left;"><td colspan="2"><h5><?php _e('Order Details','pmpro'); ?></h5></td></tr>
              <tr>
                <th style="width: 30%; color:#d2232a;padding:5px">Purchase</th>
                <?php /* ?><th style=" padding: 5px ; color:#d2232a;">Organization Type</th><?php */ ?>
                <th style="  padding: 5px; color:#d2232a;"> Amount Due</th>
              </tr>

              <tr>
                <td style="  padding: 5px">  12-month NSTXL Membership</td>
               <?php /* ?>
                <td style=" padding: 5px">
                	<?php
                	if(isset($companyname) && !empty($companyname))
                	{
                		echo $companyname;
                	}
                	?>
                </td>
                <?php */ ?>
                <td style=" padding: 5px"><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?> </td>
              </tr>
              <tr>
                <td style="  padding:5px"><strong>Total Due Upon Invoice	</strong> </td>
                <td style="  padding: 5px"> </td>
                <td style=" padding: 5px"><span class="bold"><?php echo str_replace(".00","",pmpro_formatPrice($pmpro_invoice->total));?></span> </td>
              </tr>
            </table>
 </div>
        <!--  <p style="font-size: 14px;"> Thank you!  We look forward to welcoming you as a member.</p>-->
  
	<div>Membership is good for one year from date of purchase.</div>
	<div class="thankyou-message" style="display:none">
		<h3>THANK YOU</h3>
	  <?php /*	<h4>Defense Energy Center of Excellence</h4>
		<p>d/b/a National Security Technology Accelerator</p>
	  */ ?>	
		<p>NSTXL</p>
		<p>220 NW 8th Ave</p>
		<p>Portland, OR 97210</p>
	</div>
	
</div>
	<?php 
	} else 
	  {
	//Show all invoices for user if no invoice ID is passed	
		$invoices = $wpdb->get_results("SELECT o.*, UNIX_TIMESTAMP(o.timestamp) as timestamp, l.name as membership_level_name FROM $wpdb->pmpro_membership_orders o LEFT JOIN $wpdb->pmpro_membership_levels l ON o.membership_id = l.id WHERE o.user_id = '$current_user->ID' ORDER BY timestamp DESC");
		if($invoices)
		{
			?>
			<table id="pmpro_invoices_table" class="pmpro_invoice" width="100%" cellpadding="0" cellspacing="0" border="0">
			<thead>
				<tr>
					<th><?php _e('Date', 'paid-memberships-pro' ); ?></th>
					<th><?php _e('Invoice #', 'paid-memberships-pro' ); ?></th>
					<th><?php _e('Level', 'paid-memberships-pro' ); ?></th>
					<th><?php _e('Total Billed', 'paid-memberships-pro' ); ?></th>					
				</tr>
			</thead>
			<tbody>
			<?php
				foreach($invoices as $invoice)
				{ 
					?>
					<tr>
						<td><a href="<?php echo pmpro_url("invoice", "?invoice=" . $invoice->code)?>"><?php echo date_i18n(get_option("date_format"), $invoice->timestamp)?></a></td>
						<td><a href="<?php echo pmpro_url("invoice", "?invoice=" . $invoice->code)?>"><?php echo $invoice->code; ?></a></td>
						<td><?php echo $invoice->membership_level_name;?></td>
						<td><?php echo str_replace(".00","",pmpro_formatPrice($invoice->total));?></td>											
					</tr>
					<?php
				}
			?>
			</tbody>
			</table>
			<?php
		}
		else
		{
			?>
			<p><?php _e('No invoices found.', 'paid-memberships-pro' );?></p>
			<?php
		}
	} 
?>
<nav id="nav-below" class="navigation" role="navigation">
	<div class="nav-next alignright">
		<a href="<?php echo pmpro_url("account")?>"><?php _e('View Your Membership Account &rarr;', 'paid-memberships-pro' );?></a>
	</div>
	<?php if($pmpro_invoice) { ?>
		<div class="nav-prev alignleft">
			<a href="<?php echo pmpro_url("invoice")?>"><?php _e('&larr; View All invoices', 'paid-memberships-pro' );?></a>
		</div>
	<?php } ?>
</nav>

<script type="text/javascript">
jQuery('#cmd').click(function() {
  /*var options = {
  };
  var pdf = new jsPDF('p', 'pt', 'a4');
  pdf.addHTML(jQuery(".membership-recipt"), 15, 15, options, function() {
    pdf.save('invoice.pdf');
  });*/
    var element = document.getElementById('element-to-print-invoice');
var opt = {
  margin:       1,
  filename:     'invoice.pdf',
  image:        { type: 'jpeg', quality: 0.98 },
  html2canvas:  { scale: 2 },
  jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
};

// New Promise-based usage:
html2pdf().from(element).set(opt).save();
});
</script>

<style type="text/css">
	@media print {
    @page { size: auto;  margin: 0mm; }
}
</style>