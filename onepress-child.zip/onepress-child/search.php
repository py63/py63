<?php
/**
 * The template for displaying search results pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package OnePress
 */
get_header();
?>

<div id="content" class="site-content">
  <div id="content-inside" class="container no-sidebar">
    <section id="primary" class="content-area">
      <main id="main" class="site-main" role="main">
        <div class="search_header">        
          <div class="search-form-section">
            <?php $unique_id = esc_attr(uniqid('search-form-')); ?>
            <form role="search" method="get" class="search" action="<?php echo esc_url(home_url('/')); ?>">
              <input type="search" id="<?php echo $unique_id; ?>" class="search-field" placeholder="<?php echo esc_attr_x('Search again', 'placeholder', 'polar'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
              <button type="submit" class="search-submit"><i class="fa fa-search"></i><span class="screen-reader-text"><?php echo _x('Search', 'submit button', 'polar'); ?></span></button>
            </form>
          </div>
        </div>
        <?php
        global $wp_query;
        $not_singular = $wp_query->found_posts > 1 ? '&nbsp; results' : '&nbsp; result'; // if found posts is greater than one echo results(plural) else echo result (singular)
        echo '<p class="result-found">Found&nbsp;' . $wp_query->found_posts . "$not_singular &nbsp;(" . timer_stop(0) . " seconds)</p>";
        ?>
        <?php if (have_posts()) : ?>

          <?php /* Start the Loop */ ?>
          <?php while (have_posts()) : the_post(); ?>

            <?php
            /**
             * Run the loop for the search to output the results.
             * If you want to overload this in a child theme then include a file
             * called content-search.php and that will be used instead.
             */
            get_template_part('template-parts/content', 'search');
            ?>

          <?php endwhile; ?>
          <div class="loadmore">
            <?php the_posts_pagination(array('mid_size' => 2, 'prev_text' => '<span class="meta-nav"><i class="fa fa-chevron-left" aria-hidden="true"></i></span> ' . __('Previous page', 'simple-life'), 'next_text' => __('Next page', 'simple-life') . ' <span class="meta-nav"><i class="fa fa-chevron-right" aria-hidden="true"></i></span>', 'before_page_number' => '<span class="meta-nav screen-reader-text">' . __('Page', 'simple-life') . ' </span>')); ?>
          </div>
        <?php else : ?>

          <section class="no-results not-found">	
            <article>
              <header class="entry-header">
                <h3 class="entry-title">No results found</h3>
              </header><!-- .entry-header -->
              <!-- .entry-summary -->
            </article>	
          </section>    

        <?php endif; ?>

      </main><!-- #main -->
    </section><!-- #primary -->

    <?php //get_sidebar();  ?>

  </div><!--#content-inside -->
</div><!-- #content -->

<?php get_footer(); ?>
