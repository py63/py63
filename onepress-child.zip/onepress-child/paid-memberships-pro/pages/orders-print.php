<?php
/**
 * Template for Print Invoices
 *
 * @since 1.8.6
 */
global $wpdb, $pmpro_invoice, $current_user;

$invoice_code = $order->code;
$order_userId = $order->user_id;
if(!empty($invoice_code)){
  $pmpro_invoice = new MemberOrder($invoice_code);
}
if(!empty($order_userId)){  
  if(is_user_logged_in() && function_exists('pmpro_hasMembershipLevel') && pmpro_hasMembershipLevel()) {
    $order_user_data->membership_level = pmpro_getMembershipLevelForUser($order_userId);
  }
}
?>
<!doctype html>
<html lang="en">
<head>
	<style>
   @media print {
    @page { size: auto;  margin: 0mm; }
  }
</style>
<meta charset="UTF-8">
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#F0F0F0" id="element-to-print-invoice">
  <tr>
    <td align="center"><!--[if gte mso 9]>
  <table id="tableForOutlook" align="center"><tr><td>
  <![endif]-->
  
  <div style="max-width:750px; margin:0 auto;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" style="max-width:750px; margin:0px auto;" class="contenttable">
      <tbody>
            <!--  <tr>
              <td style="background-color:#fff;" bgcolor="#fff" height="40">&nbsp;</td>
            </tr>-->
            <tr>
              <td valign="middle" style="background-color:#fff; text-align:center; border-top:3px solid #ff0000; padding-top:30px; padding-bottom:30px; " class="side-padding"><a href="https:www.nstxl.org" target="_blank"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/nstxl-large-logo.png" height="75" alt="" border="0"/></a></td>
            </tr>
            <tr>
              <td valign="middle" style="background-color:#fff; text-align:center; border-top:3px solid #ff0000;" class="side-padding"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/header-bg.jpg" height="140px" width="100%" alt="" border="0"/></td>
            </tr>
            <tr>
              <td style="background-color:#fff; padding-top:20px; padding-bottom:10px; padding-left:15px; padding-right:15px;" class="side-padding-inner"><table width="100%" border="0" cellpadding="0" cellspacing="10">
                <tbody>
                  <tr>
                   <td class="cstm-td" width="70%" style="font-family: Arial, sans-serif; font-size:16px; 
                   line-height:26px;   background-color: #fff;color: #000;padding: 8px 15px;padding-left: 0px;"><b style="  margin-bottom: 0; text-transform:uppercase;font-size:40px; color:#000; text-align:left;">
                     <?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) {
                      echo "RECEIPT"; }
                      else { echo "INVOICE"; } ?><br>   
                      <br>
                    </b>
                    <table class="cstm-tbl" width="100%" border="1" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; text-align:center;">
                      <tr>
                        <th style="padding:5px 40px">Description</th>
                        <th style="padding:5px 20px">QTY</th>
                        <th style="padding:5px 40px">Price</th>
                      </tr>
                      <tr>
                        <td>1-year NSTXL Membership</br>
                          <?php  echo $level->name; ?></td>
                          <td>1</td>
                          <td><?php echo str_replace(".00","",pmpro_formatPrice($order->total));?></td>
                        </tr>
                        <tr>
                          <th></th>
                          <th>Total</th>
                          <th><?php echo str_replace(".00","",pmpro_formatPrice($order->total));?></th>
                        </tr>
                      </table></td>
                      <td  class="cstm-td"  width="30%" style="font-family: Arial, sans-serif; font-size:16px; 
                      line-height:26px; text-align:right;  background-color: #fff;color: #fff;padding: 8px 15px;padding-right: 0px;"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0; border-left:2px solid #687279" >
                        <tr>
                          <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:50px;"><b style="    margin-bottom: 0;
                          font-size: 18px;"> <?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) {
                            echo "Amount Paid"; }
                            else { echo "Amount Due"; } ?></b> <br>
                            <span style="font-size:24px; color:#000;"><?php echo str_replace(".00","",pmpro_formatPrice($order->total));?></span></td>
                          </tr>
                          
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
                            font-size: 18px;">Billed To</b> <br>
                            <?php if(!empty($order->billing->name)) { ?>
                              <span style="font-size:16px; color:#000;"><?php echo $order->billing->name?><br>

                                <?php echo $order->billing->street?><br>
                                <?php echo $order->billing->city; ?>, <?php echo $order->billing->state; ?>, <?php echo $order->billing->zip; ?> </span>
                              <?php } ?>

                            </td>
                          </tr>
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style="    margin-bottom: 0;
                            font-size: 18px;">Invoice Number</b> <br>
                            <span style="font-size:16px; color:#000;"><?php printf(__('%s', 'paid-memberships-pro' ), $order->code, date_i18n(get_option('date_format'), $order->timestamp));?></span></td>
                          </tr>
                          <tr>
                            <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:30px;"><b style=" margin-bottom: 0;
                            font-size: 18px;"><?php if(isset($_GET['receipt']) && $_GET['receipt'] == 1) {
                              echo "Paid On"; }
                              else { echo "Start Date"; } ?></b> <br>
                              <span style="font-size:16px; color:#000;"><?php echo date_i18n(get_option('date_format'), $order->timestamp);?></span></td>
                            </tr>
                            <tr>
                              <tr>

                                <?php if($order_user_data->membership_level->enddate) { ?>
                                  <td colspan="2" style="font-family: Arial, sans-serif; font-size:13px; color:#ed193e; line-height:26px; text-align:right; padding-bottom:10px;"><b style="    margin-bottom: 0;
                                  font-size: 18px;"><?php _e('Membership Expires', 'pmpro');?></b> <br>
                                  <span style="font-size:16px; color:#000;">
                                    <?php echo date(get_option('date_format'), $order_user_data->membership_level->enddate); ?>
                                  </span></td>
                                <?php } ?>

                              </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff;padding: 0;">
                              <tbody>
                                <tr>
                                  <td colspan="2"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color: #fff; max-width: 700px;padding: 0 0 0px; margin: 0 auto">
                                    <tbody>
                                      <tr>
                                        <td style="background-color:#fff;" bgcolor="#fff" height="80">&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td colspan="2" valign="top" align="center" style="font-family:Arial, sans-serif; color:#5F5F5F; font-size:14px; padding-bottom:0px;"><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/nstxl-small-logo.png" width="30" alt="" border="0"/> | National Security Technology Accelerator | 1-800-364-1545 | <a href="https://www.nstxl.org" target="_blank" style="font-family:Arial, sans-serif; color:#ff0000; font-size:14px; text-decoration:none;">www.nstxl.org</a></td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                                </tr>
                              </tbody>
                            </table></td>
                          </tr>
                          
                          <!--table order list-->
                          
                        </tbody>
                      </table></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
      <!--[if gte mso 9]>
  </td></tr></table>
<![endif]--></td>
</tr>
</table>


</body>
</html>
