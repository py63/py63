~~ IMPORTANT ~~

If you have translated the theme, please contact us so we can add your translation into the theme and include it in future updates. This will ensure that you can update the theme automatically and not worry about losing your translations.

Thank you!
- WPExplorer Team

——————————————————

Special thanks to the following people for language translations:

ITALIAN	- http://themeforest.net/user/nightjar
SWEDISH	- http://themeforest.net/user/junkyhlm
GERMAN	- http://themeforest.net/user/birgitengelhardt