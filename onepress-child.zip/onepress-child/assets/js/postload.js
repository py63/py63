var postperpage = 6; // Post per page
pageNumber = 1;

function load_posts(){

    jQuery("#loadmore").remove();
    pageNumber++;
    var categoryfilter = jQuery('#categoryfilter').val();
    
    var str = '&pageNumber=' + pageNumber +'&categoryfilter=' + categoryfilter + '&postperpage=' + postperpage + '&check_load_more=yes&action=post_fetch';
    jQuery.ajax({
        type: "POST",
        dataType: "html",
        url: postloadajax.postload,
        data: str,
        success: function(data){
            var $data = jQuery(data);
            if($data.length){
                jQuery("#posts").append($data);
                jQuery("#loadmore").attr("disabled",false);
            }
        },
        error : function(jqXHR, textStatus, errorThrown) {
            $loader.html(jqXHR + " :: " + textStatus + " :: " + errorThrown);
        }

    });
    return false;
}

jQuery(document).on("click","#loadmore",function(){ // When btn is pressed.
    jQuery("#loadmore").attr("disabled",true); // Disable the button, temp.
    load_posts();
});