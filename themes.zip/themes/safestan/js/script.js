//(function(jQuery){

//javasctipt 
//load more click function: improved to prevent double click and fire funciton only after content has been loaded (good for slow internet connection)
//jQuery('.load_more:not(.loading)').live('click',function(e){
//jQuery('.load_more:not(.loading)').click(function(e){	
jQuery(window).data('ajaxready', true).scroll(function(e) {

    if (jQuery(window).data('ajaxready') == false) return;	
	
    if (jQuery(window).scrollTop() >= (jQuery(document).height() - jQuery(window).height())) 
    {
    	jQuery(window).data('ajaxready', false);
		e.preventDefault();

		if(jQuery('#orderByAsc').val()!='' && jQuery('#orderByDesc').val()==''){
			var order_by = jQuery('#orderByAsc').val();
		}

		if(jQuery('#orderByDesc').val()!='' && jQuery('#orderByAsc').val()==''){
			var order_by = jQuery('#orderByDesc').val();	
		}

		if(jQuery('#orderByDesc').val()=='' && jQuery('#orderByAsc').val()==''){
			var order_by = '';	
		}

		var jQueryload_more_btn = jQuery('.load_more');
		var loadingUrl = homeurl+"/wp-content/themes/safestan/images/loader.svg";

		if(jQuery('#post_id').val()!='')
		{	
			var post_id = jQuery('#post_id').val();
			var offset = jQuery('#reviesDiv .media').length;
			//alert(offset);
			var nonce = jQueryload_more_btn.attr('data-nonce');
			if(offset >= 10)
			{
				jQuery.ajax({
				        	cache: false,
				        	type : "post",
				        	context: this,
				         	dataType : "json",
				         	url : headJS.ajaxurl,
				         	data : {action: "load_more_taxonomy_func", offset:offset, nonce:nonce, post_id:post_id, posts_per_page:headJS.posts_per_page,orderBY:order_by},
				         	//data : {action: "load_more", offset:offset, nonce:nonce, post_type:post_type, posts_per_page:headJS.posts_per_page},
				         	beforeSend: function(data) {
								// here u can do some loading animation...
								jQueryload_more_btn.addClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');// good for styling and also to prevent ajax calls before content is loaded by adding loading class
				         	},
				         	success: function(response) {
								if (response['have_posts'] == 1){//if have posts:
									jQueryload_more_btn.removeClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');
									var jQuerynewElems = jQuery(response['html'].replace(/(\r\n|\n|\r)/gm, ''));// here removing extra breaklines and spaces
									jQuery('#reviesDiv').append(jQuerynewElems);
								} else {
									//end of posts (no posts found)
									jQueryload_more_btn.removeClass('loading').addClass('end_of_posts').html('<span></span>'); // change buttom styles if no more posts
								}
								jQuery(window).data('ajaxready', true);
				         	}
				      	});
			}
		}
		else
		{
			var offset = jQuery('#searchWrappper .card-box').length;
			var nonce = jQueryload_more_btn.attr('data-nonce');

			

			if( jQuery('#SearchValue').val() !='' )
			{
				var SearchValue = jQuery('#SearchValue').val();
				if(offset >= 10)
				{   
					jQuery.ajax({
			        	cache: false,
			        	type : "post",
			        	context: this,
			         	dataType : "json",
			         	url : headJS.ajaxurl,
			         	data : {action: "load_more_taxonomy_func", offset:offset, nonce:nonce,  posts_per_page:headJS.posts_per_page, SearchValue:SearchValue},
			         	//data : {action: "load_more", offset:offset, nonce:nonce, post_type:post_type, posts_per_page:headJS.posts_per_page},
			         	beforeSend: function(data) {
							// here u can do some loading animation...
							jQueryload_more_btn.addClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');// good for styling and also to prevent ajax calls before content is loaded by adding loading class
			         	},
			         	success: function(response) {
							if (response['have_posts'] == 1){//if have posts:
								jQueryload_more_btn.removeClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');
								var jQuerynewElems = jQuery(response['html'].replace(/(\r\n|\n|\r)/gm, ''));// here removing extra breaklines and spaces
								jQuery('#searchWrappper').append(jQuerynewElems);
							} else {
								//end of posts (no posts found)
								jQueryload_more_btn.removeClass('loading').addClass('end_of_posts').html('<span></span>'); // change buttom styles if no more posts
							}
							jQuery(window).data('ajaxready', true);
			         	}
			      	});
				}
			}
			else
			{	
				if(offset >= 10)
				{   
					jQuery.ajax({
			        	cache: false,
			        	type : "post",
			        	context: this,
			         	dataType : "json",
			         	url : headJS.ajaxurl,
			         	data : {action: "load_more_taxonomy_func", offset:offset, nonce:nonce,  posts_per_page:headJS.posts_per_page},
			         	//data : {action: "load_more", offset:offset, nonce:nonce, post_type:post_type, posts_per_page:headJS.posts_per_page},
			         	beforeSend: function(data) {
							// here u can do some loading animation...
							jQueryload_more_btn.addClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');// good for styling and also to prevent ajax calls before content is loaded by adding loading class
			         	},
			         	success: function(response) {
							if (response['have_posts'] == 1){//if have posts:
								jQueryload_more_btn.removeClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');
								var jQuerynewElems = jQuery(response['html'].replace(/(\r\n|\n|\r)/gm, ''));// here removing extra breaklines and spaces
								jQuery('#searchWrappper').append(jQuerynewElems);
							} else {
								//end of posts (no posts found)
								jQueryload_more_btn.removeClass('loading').addClass('end_of_posts').html('<span></span>'); // change buttom styles if no more posts
							}
							jQuery(window).data('ajaxready', true);
			         	}
			      	});
				}
			}
		}	
	}
});

function oldvalue(){
	var orderBY = 'ASC';
	jQuery('#reviesDiv').empty();
	jQuery('#orderByDesc').val('');
	jQuery('#orderByAsc').val('ASC');
	jQuery('#oldest_link_id').removeClass();
	jQuery('#oldest_link_id').addClass('sortby-active');
	jQuery('#newest_link_id').removeClass();
	jQuery('#newest_link_id').addClass('sortby');

	var srcNew = jQuery('.sort-reviewNew img').attr('src');	
	var srcOld = jQuery('.sort-reviewOld img').attr('src');
	jQuery(".sort-reviewOld img").attr("src",srcNew);
	jQuery(".sort-reviewNew img").attr("src",srcOld);

	//alert(aa.length);	
        jQuery(window).data('ajaxready', false);
		//e.preventDefault();

		var post_id = jQuery('#post_id').val();
		var jQueryload_more_btn = jQuery('.load_more');
		
		var loadingUrl = homeurl+"/wp-content/themes/safestan/images/loader.svg";
		var offset = jQuery('#reviesDiv .media').length;
		//alert(offset);
		var nonce = jQueryload_more_btn.attr('data-nonce');
		//if(offset >= 3)
		//{
			jQuery.ajax({
			        	cache: false,
			        	type : "post",
			        	context: this,
			         	dataType : "json",
			         	url : headJS.ajaxurl,
			         	data : {action: "load_more_taxonomy_func", offset:offset, nonce:nonce, post_id:post_id, posts_per_page:headJS.posts_per_page,orderBY:orderBY},
			         	//data : {action: "load_more", offset:offset, nonce:nonce, post_type:post_type, posts_per_page:headJS.posts_per_page},
			         	beforeSend: function() { 
					      jQuery("#reviesDiv").html("<spa> Loading ...</option>");
					      jQuery("#reviewEnable").css({'opacity':0.3}); // disable button
					      jQuery("#reviewEnable").prop('disabled', true);
					    },
			         	success: function(response) {
							if (response['have_posts'] == 1){//if have posts:
								jQueryload_more_btn.removeClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');
								var jQuerynewElems = jQuery(response['html'].replace(/(\r\n|\n|\r)/gm, ''));// here removing extra breaklines and spaces
								jQuery("#reviesDiv").html("");
								jQuery('#reviesDiv').append(jQuerynewElems);
								jQuery("#reviewEnable").css({'opacity':1}); // disable button
					      		jQuery("#reviewEnable").prop('disabled', false);
							} else {
								//end of posts (no posts found)
								jQueryload_more_btn.removeClass('loading').addClass('end_of_posts').html('<span></span>'); // change buttom styles if no more posts
							}
							jQuery(window).data('ajaxready', true);
			         	}
			      	});
		//}
}

function newvalue(){
	var orderBY = 'DESC';
	jQuery('#reviesDiv').empty();
	jQuery('#orderByAsc').val('');
	jQuery('#orderByDesc').val('DESC');
	jQuery('#newest_link_id').removeClass();
	jQuery('#newest_link_id').addClass('sortby-active');
	jQuery('#oldest_link_id').removeClass();
	jQuery('#oldest_link_id').addClass('sortby');

	var srcNew = jQuery('.sort-reviewNew img').attr('src');	
	var srcOld = jQuery('.sort-reviewOld img').attr('src');
	jQuery(".sort-reviewOld img").attr("src",srcNew);
	jQuery(".sort-reviewNew img").attr("src",srcOld);

	//alert(aa.length);	
        jQuery(window).data('ajaxready', false);
		//e.preventDefault();

		var post_id = jQuery('#post_id').val();
		var jQueryload_more_btn = jQuery('.load_more');
		
		var loadingUrl = homeurl+"/wp-content/themes/safestan/images/loader.svg";
		var offset = jQuery('#reviesDiv .media').length;
		//alert(offset);
		var nonce = jQueryload_more_btn.attr('data-nonce');
		//if(offset >= 3)
		//{
			jQuery.ajax({
			        	cache: false,
			        	type : "post",
			        	context: this,
			         	dataType : "json",
			         	url : headJS.ajaxurl,
			         	data : {action: "load_more_taxonomy_func", offset:offset, nonce:nonce, post_id:post_id, posts_per_page:headJS.posts_per_page,orderBY:orderBY},
			         	//data : {action: "load_more", offset:offset, nonce:nonce, post_type:post_type, posts_per_page:headJS.posts_per_page},
			         	 beforeSend: function() { 
					      jQuery("#reviesDiv").html("<spa> Loading ...</option>");
					      jQuery("#reviewEnable").css({'opacity':0.3}); // disable button
					      jQuery("#reviewEnable").prop('disabled', true); // disable button
					    },
			         	success: function(response) {
							if (response['have_posts'] == 1){//if have posts:
								jQueryload_more_btn.removeClass('loading').html('<img class="load_more" widt="32" height="30" src="'+loadingUrl+'">');
								var jQuerynewElems = jQuery(response['html'].replace(/(\r\n|\n|\r)/gm, ''));// here removing extra breaklines and spaces
								jQuery("#reviesDiv").html("");
								jQuery('#reviesDiv').append(jQuerynewElems);
								jQuery("#reviewEnable").css({'opacity':1}); // disable button
					      		jQuery("#reviewEnable").prop('disabled', false);
							} else {
								//end of posts (no posts found)
								jQueryload_more_btn.removeClass('loading').addClass('end_of_posts').html('<span></span>'); // change buttom styles if no more posts
							}
							jQuery(window).data('ajaxready', true);
			         	}
			      	});
		//}
}

//}); 
