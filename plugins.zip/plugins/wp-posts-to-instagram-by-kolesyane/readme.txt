=== WP Posts to Instagram by Kolesyane ===
Contributors: kolesyane
Tags: instagram, widget, photos, photography, hipster, sidebar, widgets, simple, autoposts
Requires at least: 3.0
Tested up to: 4.1.1
Stable tag: 1.0.0
Donate link: http://bit.ly/HvUakt
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Posts to Instagram by Kolesyane plugin allow you to publish defined WP posts to your Instargam account.

== Description ==

WP Posts to Instagram by Kolesyane plugin allow to publish defined WP posts to your Instargam account.
You can choose any post types, which can be published on Instagram. Additionally,
on post page you will have ability to manage,
if needed to publish current post to Instagram or not.
Post featured image uses for Instagram post image.
Post description uses for Instagram post caption.

== Installation ==

To install this plugin:

1. Upload the `wp-posts-to-instagram-by-kolesyane` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it!

== Frequently Asked Questions ==

= In what case I need checked "Not publish to Instagram" on post create page =
i.e. When you edit post, you no need to republish it to Instagram

== Upgrade Notice ==

== Screenshots ==

1. Plugin settings page
2. Post page with additional plugin settings

== Changelog ==

= 1.0.0 =
* Initial release
