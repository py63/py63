<?php
/*
If you would like to edit this file, copy it to your current theme's directory and edit it there.
Theme My Login will always look in your theme's directory first, before using this default template.
*/
?>
<style type="text/css">
	.loginerror {
    display: inline-block;
    margin: 15px 0 0;
    padding: 0;
    width: 100%;
}
.loginerror p{
	margin: 0;
}
</style>
<div class="login-box" id="theme-my-login<?php $template->the_instance(); ?>">
	<div class="loginerror">
		<?php $template->the_action_template_message( 'login' ); ?>
		<?php $template->the_errors(); ?>
 	</div>
 	<form name="loginform" id="loginform<?php $template->the_instance(); ?>" action="<?php $template->the_action_url( 'login', 'login_post' ); ?>" method="post" class="form1">
	    <div class="form-group">
	    	<p class="label-had">
            <?php
				if ( 'username' == $theme_my_login->get_option( 'login_type' ) ) {
					_e( 'Username', 'theme-my-login' );
				} elseif ( 'email' == $theme_my_login->get_option( 'login_type' ) ) {
					_e( 'E-mail', 'theme-my-login' );
				} else {
					_e( 'Username or E-mail', 'theme-my-login' );
				}
			?>
			<sup>*</sup></p>
          	<!-- <input type="text" class="form-control" id="email" placeholder="Enter email address"> -->
         	<input type="text" name="log" id="user_login<?php $template->the_instance(); ?>" class="input form-control" value="<?php $template->the_posted_value( 'log' ); ?>" placeholder="Enter email address" />
        </div>
  		<div class="form-group">
	        <p class="label-had"><?php _e( 'Password', 'theme-my-login' ); ?><sup>*</sup></p>
	        <input type="password" name="pwd" id="user_pass<?php $template->the_instance(); ?>" class="input form-control" value=""  autocomplete="off" placeholder="Enter password" />
	    </div>
	    <?php do_action( 'login_form' ); ?>
	            
	            <div class="tml-rememberme-submit-wrap">
		            <button type="submit" class="btn btn-primary btn-block w-100">Sign in</button>
                	
					<input type="hidden" name="redirect_to" value="<?php $template->the_redirect_url( 'login' ); ?>" />
					<input type="hidden" name="instance" value="<?php $template->the_instance(); ?>" />
					<input type="hidden" name="action" value="login" />
                </div>
                <a class="forgott" href="<?php bloginfo('url');?>/resetpass/" class="forgot-pass">Forgot password?</a>

              	<!-- <div class="forgott">
	                <div class="align-middle">
	                      <span class="not-amember"> 
	                    Not a member? 
	                    <a href="<?php bloginfo('url');?>/register/" class="signup"> Sign up</a>
	                  </span>
	                </div>
	                <div class="align-middle">
	                  <a href="<?php bloginfo('url');?>/resetpass/" class="forgot-pass">
	                    Forgot password?
	                  </a>
	                </div>
              	</div> -->
	</form>		
</div>
<center>	
    <div class="login-social fb-gplus-twit"> 
    	<span class="login-with"> OR Login with </span>
    	<?php do_action( 'wordpress_social_login' );
        		//echo do_shortcode("[wordpress_social_login]");
        	?>	
    	<!-- <a class="btn btn-fb"><img src="images/facebook-1.png" alt="..."> Login With Facebook</a> <a class="btn btn-google"><img src="images/google-1.png" alt="..."> Login With Google</a> -->
        <p class="other-option">Not a member?<a class="other-option" href="<?php bloginfo('url');?>/register/" class="signup"> Sign up</a>
        </p>
    </div>
</center>