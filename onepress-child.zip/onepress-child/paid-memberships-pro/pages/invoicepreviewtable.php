<style type="text/css">
	@media print {
		#Header,
		#Footer {
			visibility: hidden;
			display: none;
		}
		body header,
		body .step-anchor .nav-item,
		body .qualification-member,
		body .commonly_requested_corporate_info,
		body .printpdf,
		body #pmpro_payment_information_fields,
		body #accept_policy_div,
		body .pmpro_submit,
		body .sw-toolbar,
		body footer,
		.rgs_title,
		.sw-btn-prev,
		.sw-main section,
		.title-area-content-wrapper,
		.page-title {
			/*visibility: hidden;*/
			display: none;
		}
		a[href]:after {
			content: none !important;
		}
		@page {
			margin-top: 0;
			margin-bottom: 0;
		}
		body {
			padding-top: 2px;
			padding-bottom: 72px;
		}
		#invoice-preview-table,
		#invoice-preview-table .inner-table,
		#invoice-preview-table tr,
		#invoice-preview-table td table {
			display: table !important;
			width: 100%
		}
		#invoice-preview-table .inner-table,
		#invoice-preview-table .inner-table .biling-table {
			border-collapse: collapse !important;
			display: table;
			width: 100%;
		}
		#invoice-preview-table .inner-table .biling-table {
			border-collapse: collapse !important;
		}
		#invoice-preview-table .inner-table .biling-table th,
		#invoice-preview-table .inner-table .biling-table td {
			border: 1px solid #ddd !important;
			width: 30%;
			word-wrap: break-word;
		}
		.title-table {
			color: #f01c35 !important;
		}
		/*	#invoice-preview-table .inner-table .biling-table th:nth-child(2), #invoice-preview-table .inner-table .biling-table td:nth-child(2){
				border-right: 1px solid #ddd !important;
			}*/
	}
</style>
<div class="invoice_preview_section clearfix">
	<div class="printpdf clearfix">
		<a id="cmd" class="btn pull-left" href="#"><?php _e('Save Invoice', 'paid-memberships-pro' ); ?></a>
		<a class="pmpro_a-print pull-right" href="#" onclick="window.print();"><?php _e('Print Invoice', 'paid-memberships-pro' ); ?></a>
	</div>
	<style>
		table {
			border-collapse: none !important;
		}
		
		tr {
			border: 0 !important;
		}
	</style>
	<table border="0" id="invoice-preview-table" class="main-table-wrapper invoice-preview-table" cellpadding="0" cellspacing="0" style=" width: 100%; max-width: 600px; margin: 20px auto; background-color: #fff;font-family: sans-serif; padding: 10px 30px 30px; overflow-x:hidden; border:0px;">
		<tr>
			<td><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo.png" style="margin: auto; display: block; width: 220px" alt="logo">
			</td>
		</tr>
		<tr class="td-center" align="center">
			<td style="padding: 0; text-align: center;">
				<div class="wrap-logos clearfix">
					<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo-circle.png" style="width: 50px;">
					<img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/logo-trex.png" style="width: 150px; ">
				</div>
			</td>
		</tr>

		<tr align="center">
			<td align="center">
				<table align="center" cellpadding="0" cellspacing="0" border="0">
					<tr style="border:0px none;">
						<td class="title-table" align="center" style="font-size: 24px;
font-family: sans-serif;
color: #f01c35;
text-align: center;
">Membership Invoice </td>
					</tr>


				</table>


			</td>
		</tr>
		<tr>
			<td>
				<table class="inner-table" cellpadding="0" cellspacing="0" style="text-align: center;" width="100%">
					<?php /* ?>
					<tr>
						<td style="padding:10px 0 20px; line-height: 1.8;font-size:14px; text-align: left;">
							<span style="">Member ID:</span>
							<?php echo nstxl_get_member_id(get_current_user_id()); ?>
						</td>
					</tr>
					<?php */ ?>
					<?php /* ?>
					<tr>
						<td style="padding:10px 0 0; line-height: 1.8;font-size:14px; text-align: left;">
							<span style="">Date:</span> Date
						</td>
					</tr>
					<?php */ ?>
					<tr style="border-bottom: none !important;">
						<td>
							<table style="text-align: right; font-size: 14px; padding-bottom: 30px; width: 100%;" width="100%">
								<?php /* ?>
								<tr>
									<td style="width: 50%;"></td>
									<td style="">Defense Energy Center of Excellence</td>
								</tr>
								<tr>
									<td style="width: 50%;"></td>
									<td>d/b/a National Security Technology Accelerator</td>
								</tr>
								<tr>
									<td style="width: 50%;"></td>
									<td>2221 S Clark St</td>
								</tr>
								<tr>
									<td style="width: 50%;"> </td>
									<td>Suite 1200</td>
								</tr>
								<tr>
									<td style="width: 50%;"></td>
									<td>Arlington, VA 22201</td>
								</tr>
								<?php */ ?>
								<tr>
									<td style="width: 50%;"></td>
									<td style="">NSTXL</td>
								</tr>
								<tr>
									<td style="width: 50%;"></td>
									<td>220 NW 8th Ave</td>
								</tr>
								<tr>
									<td style="width: 50%;"> </td>
									<td>Portland, OR 97210<br />USA</td>
								</tr>
							</table>
						</td>
					</tr>

					<tr style="text-align: left;">

						<td style="font-size: 14px;">
							<?php
							$company_userdata = nstxl_company_additional_userdata($current_user->ID);						
							if ( isset( $company_userdata['company_name'] ) && !empty( $company_userdata['company_name'] ) ) {
							$companyname = $company_userdata['company_name'];
								echo $companyname;
							}
							//$poc = get_user_meta( $current_user->ID, 'poc', true );
							if ( isset( $company_userdata['poc_userid'] ) && !empty( $company_userdata['poc_userid'] ) ) {
								$poc = $company_userdata['poc_userid'];
								$user_info = get_userdata( $poc );
								//print_r($user_info);
							}							
							?>
						</td>
					</tr>
					<tr style="text-align: left;">
						<?php if (isset($user_info) && !empty($user_info)) { ?>
						<td style="font-size: 14px;">
							<span class="invc-prev-name"><?php echo $user_info->display_name;  ?></span><br>
							<div style="font-weight: 600">Via email <span class="invc-prev-email"><?php echo $user_info->user_email; ?></span></div>
						</td>
						<?php } ?>
					</tr>


					<tr>
						<td style="text-align: left">
							<table class="biling-table" style="border: 1px solid #ddd; border-collapse: collapse; margin: 20px 0; font-size: 14px; width: 100%" width="100%" cellpadding="0" cellspacing="0">
								<tr>
									<th style="width: 30%; border: 1px solid #ddd; padding: 5px ;color:#d2232a;">Purchase</th>
									<th style="border: 1px solid #ddd;  padding: 5px ; color:#d2232a;">Organization Type</th>
									<th style="border: 1px solid #ddd;  padding: 5px; color:#d2232a;"> Amount Due</th>
								</tr>

								<tr>
									<td style="border: 1px solid #ddd;  padding: 5px"> 12-month NSTXL Membership</td>
									<td style="border: 1px solid #ddd;  padding: 5px">
										<?php
										if ( isset( $companyname ) && !empty( $companyname ) ) {
											echo $companyname;
										}
										?>
									</td>
									<td style="border: 1px solid #ddd;  padding: 5px">
										<?php echo pmpro_formatPrice($pmpro_level->initial_payment);?> </td>
								</tr>
								<tr>
									<td style="border: 1px solid #ddd;  padding:5px"><span class="font-weight-b">Total Due Upon Invoice	</span> </td>
									<td style="border: 1px solid #ddd;  padding: 5px"> </td>
									<td style="border: 1px solid #ddd;  padding: 5px">
										<span class="font-weight-b">
											<?php echo pmpro_formatPrice($pmpro_level->initial_payment);?>
										</span>
									</td>
								</tr>
							</table>
						</td>
					</tr>

					<tr style="text-align: left;">
						<td style="font-size: 14px;"> Thank you! We look forward to welcoming you as a member.</td>

					</tr>
				</table>
			</td>
		</tr>
	</table>
</div>