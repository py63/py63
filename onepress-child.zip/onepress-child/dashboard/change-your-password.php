<?php
/**
*Template Name: Change Your Password
*/

global $current_user;

$curuserid = $current_user->ID;
if (!is_user_logged_in() ) { 
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit; }  

get_header('admin');

  $err = '';
if (isset($_POST['change-yourpass'])) {

  $currentpass = sanitize_text_field($_POST['currentpass']);
  $newpassword = sanitize_text_field($_POST['newpass']);
  $confirmpassword = sanitize_text_field($_POST['newconfirmpass']);

    if ($newpassword == "" || $confirmpassword == "" ) {
    $err =  'Please don\'t leave the required fields.';
  } else if ($newpassword <> $confirmpassword) {
    $err = 'Password do not match.';
  }

  if(!empty($currentpass))
  {
    $user = get_user_by( 'login', $current_user->user_login);
    if ( $user && wp_check_password( $currentpass, $user->data->user_pass, $curuserid) ){


      $user_info   = get_userdata($curuserid);
      $user_email  = $user_info->user_email;
      $user_name   = $user_info->display_name;

      wp_set_password( $newpassword, $curuserid);

      if(isset($newpassword) && !empty($newpassword)){    

          $start_date = date('Y-m-d H:i:s', current_time('timestamp'));  
          $end_date =  date('Y-m-d H:i:s', strtotime($start_date. ' + 90 days'));       
          if (current_user_can('administrator'))  
          {
            update_user_meta( $user_id, 'expiry-password-change', $end_date );
          }  
        }

        $to      = $user_email;
        $subject = 'Your new password';

        $message               = '<table style="width: 580px;margin-left: auto; margin-right: auto;" cellpadding="0" cellspacing="0" align="center">
    <thead>
      <tr><td style=" padding: 25px 0 0;text-align: center"><a><img src="' . site_url() . '/wp-content/uploads/logo-mailer.png" alt="logo-mailer"></a></td></tr>
    <tr>
      <td>
      <table  width="100%" style="padding:0 25px 15px; font-size: 30px; color: #fff; text-align: center; width: 100% !important;" >
      <tr>
      <td style=" text-align: center; color: #fff;">
      <p style="width: 100% !important; margin:0 ;text-align: center;  font-family: Helvetica, Arial, sans-serif; font-size: 30px; color: #ea5053;">Your new password</p>
      </td>
      </tr>
      </table>
      </td>
      </tr>
      </thead>
      <tbody >
    <tr>
    <td>
    <table style="width: 100%; padding: 0 25px 25px 25px; " cellpadding="0" align="left">
    <tr>
    <td>';
        $message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Hello ' . ucwords( $user_name ) . ',</p>';
        $message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Your password has been changed.</p>';
        $message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">Your new password is: '.$newpassword.'</p>';
        $message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-top:20px;">If this was not you please click this <a href="' . site_url() . '/login">link.</a></p>';
        $message .= '<p style="font-family: Helvetica, Arial, sans-serif; font-size: 14px; line-height: 22px;padding: 0 25px;margin-bottom:20px;">Sincerely,<br>Team NSTXL</p>';
        $message .= '</td></tr></table>
    </td>
    </tr></tbody><tfoot>
    <tr><td>
    <table cellpadding="0" style="font-size: 16px;width:100%; padding: 10px 0; background-color: #545454; text-align: center;">
    <tr><td>
    <p style="text-align: center; font-family: Helvetica, Arial, sans-serif;color: #fff;font-size: 16px;max-width: 550px; margin:0 auto ; ">NSTXL | (800) 364-1545 | <a style=" text-decoration: none; font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; font-size: 16px;" href="mailto: membership@nstxl.org" >membership@nstxl.org</a> | <a href="https://nstxl.org" style="font-family: Helvetica, Arial, sans-serif;color: #d4d4d4; text-decoration: none;"> nstxl.org</a></p>
    </td>
    </tr>
    </table>
    </td></tr>
    </tfoot></table>';
        $headers               = 'MIME-Version: 1.0' . "\r\n";
        $headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $confirmation_headers  = $headers . 'From: NSTXL <no-reply@nstxl.org>' . "\r\n";
        $mail = wp_mail( $to, $subject, $message, $confirmation_headers );

        if ( $mail ) {
          $success = 'Password Updated successfully. Check email for your new password.';
        } else {
          $error = 'Oops something went wrong updaing your account.';
        } 
       
    }
    else{
      $err = "Your current password is wrong.";
    }
  }
  else{
    $err =  'Please don\'t leave the required fields.';
  }
}
do_action('onepress_page_before_content');     
  ?> 
 
 <div id="content" class="site-content form-page">
  <?php
  onepress_breadcrumb();
// [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
    <?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">
          <?php 
        if (current_user_can('administrator')) { 
          if(isset($_REQUEST['expire']) && $_REQUEST['expire'] == '1') 
          {     
            echo '<p class="titlewel" id="expirypass">Please change your password to continue using this website.</p>';   
          }
        } 
        ?>   
     
        <p class="successerror" style="display:none; color: green;"></p>  
        <?php global $current_user;  ?>
      <div class="personal-info-container personal-profile-dashboard changepassword-container dashboard-inner-wrapper dashboard-bg-white">
         <a class="arrow-back" href="<?php echo site_url(); ?>/manage-your-users/"><img src="<?php echo get_stylesheet_directory_uri().'/images/arrow-back.png'; ?>" /></a> 

         <div class="clearfix"></div> 
          <form id="changepassword" method="post" class="pmpro_form">
         <?php
          $uploaded_doc_url = get_user_meta($current_user->ID, 'uploaded_doc', true);
          $defalut_pic_url = WP_PLUGIN_URL . '/nstxl-memberhip-extension/images/user.png';
          $user_pic = get_user_meta($current_user->ID, 'user_pic', true);
          if (!empty($user_pic)) {
            $user_pic_url = $user_pic['fullurl'];
            $avatar = '<div class="profile-pic"><img class="profile-pic-img" alt="user pic" src="' . $user_pic_url . '"></div>';
          } else {
            $avatar = '<div class="profile-pic"><img class="profile-pic-img" alt="user pic" src="' . $defalut_pic_url . '"></div>';
          }
          ?>
          <div class="user_pics circle"><?php echo $avatar; ?></div>

         <div class="wrap-apple-icon person-name">
          <?php
          $firstname = get_user_meta($current_user->ID,'first_name', true);
          $lastname = get_user_meta($current_user->ID,'last_name', true);
          
          ?>
            <?php if(!empty($firstname) && !empty($lastname)) { 
              echo '<h2 class="rgs_title">'.esc_attr(stripslashes_deep(ucfirst($firstname))).' '.esc_attr(stripslashes_deep(ucfirst($lastname))).'</h2>';
            } 
          ?> 
        </div>
         <div class="clearfix"></div>
          <div class="row">
              <div class="currentpass form-group mt-4 col-lg-6 col-md-6"> 
                <label for="currentpass"><?php _e('Current Password','paid-memberships-pro'); ?></label>
                <input required="" type="password" name="currentpass" id="currentpass" class="form-control" value="">
              </div>
            </div>
            <div class="row">
                <div class="newpass form-group col-lg-6 col-md-6"> 
                  <label for="newpass"><?php _e('New Password','paid-memberships-pro'); ?></label>
                  <input required="" type="password" name="newpass" id="newpass" class="form-control" value="">
                </div>
                <div class="form-group col-lg-6 col-md-6"> 
                  <label for="newconfirmpass"><?php _e('Confirm New Password','paid-memberships-pro'); ?></label>
                   <input required="" type="password" name="newconfirmpass" id="newconfirmpass" class="form-control" value=""> 
                </div>
            </div>

           <div class="passwordmeter">
              <span id="password-strength"></span>  
              <span class="pasindicator">
               <strong>Hint : </strong>The password should be at least nine characters long. To make it stronger,
               use upper case and lower case letters, numbers and symbols like !"?$%^&). 
             </span>
           </div>    
           <div class="passbtn">
             <input type="submit" id="changepassdisable" class="btn-txt mt-4 change-yourpass" name="change-yourpass" value="<?php _e('Update','polar'); ?>" data-datac="<?php if(isset($current_user->ID)) { 
              echo $current_user->ID;} ?>"/>
          </div>                 
      </form>
      </div>
      </main>
      </div>
      </div>
      </div>

 <!-- Modal -->
 <?php if (!empty($err)) { ?> 
  <div class="modal fade custom-popup show" id="hideerrormodal"  tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
          </button>
          <div class="update-personalinfo-box-success-container modal-body-container">
            <h4 style="color:red"><?php echo $err; ?></h4> 
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
  </div> 
  <div class="modal-backdrop fade show"></div>
   <!-- /.modal -->
<?php } if(!empty($success)) { ?>
   <div class="modal fade custom-popup show" id="hidesuccessmodal" tabindex="-1" role="dialog" aria-labelledby="update-personalinfo-modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/close-icon.svg"></span>
          </button>
          <div class="update-personalinfo-box-success-container modal-body-container">
            <h4 style="color:green"><?php echo $success; ?></h4> 
          </div>
        </div>
        <!-- /.modal-content -->
      </div>
      <!-- /.modal-dialog -->
    </div>
  </div> 
  <div class="modal-backdrop fade show"></div>
<?php } ?>


<script>
  jQuery(document).ready(function ($) {
    "use strict";
// Validation
jQuery('.change-yourpass').click(function(e){

  $("#changepassword").validate({
    rules: {
      newpass: {
        required: true,
        minlength: 5
      },
      newconfirmpass: {
        required: true,
        minlength: 5,
        equalTo: "#changepassword [name=newpass]"
      },
      
    }, messages: { 
      newconfirmpass: {
        equalTo: "Password do not match.",                
      },
    },
    errorClass: "form-invalid",
    errorPlacement: function (label, element) {
      if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
          element.parent().append(label); // this would append the label after all your checkboxes/labels (so the error-label will be the last element in <div class="controls"> )
        } else {
          //label.insertAfter(element); // standard behaviour
          element.parent().append(label);
        }
      },
  });  
});

 jQuery('.close').click(function(e){
    jQuery('div').remove('.custom-popup');
    jQuery('div').remove('.modal-backdrop');
    }); 

setTimeout(function() {
 jQuery('#expirypass').hide();
}, 20000);

});
</script>
<?php
get_footer('admin');