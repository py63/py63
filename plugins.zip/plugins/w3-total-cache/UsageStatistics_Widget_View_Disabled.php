<?php
namespace W3TC;

if ( !defined( 'W3TC' ) )
	die();
?>
<p class="ustats_p ustats_top">
    Not active. Activate <a href="?page=w3tc_general#common__track_usage">here</a>
</p>
