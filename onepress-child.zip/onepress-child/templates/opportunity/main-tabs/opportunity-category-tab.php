<?php
global $current_user;
$cusr_id = $current_user->ID;
?>
<div class='opportunity-content'>
  <!-- Blog Query  -->
  <div class="opportunity-posts opportunity-posts<?= $tab_num; ?>" data-tab="<?= $tab_num; ?>">

    <?php
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    $args = array(
        'post_type' => 'opportunity',
        'posts_per_page' => 6, 'paged' => $paged,
        'tax_query' => array(
            array(
                'taxonomy' => 'opportunity-type',
                'field' => 'term_id',
                'terms' => $termID,
            ),
        ),
    );
    $Newquery = new WP_Query($args);
    ?>
    <!-- the loop -->
    <?php
    echo '<div class="card-deck">';
    if ($Newquery->have_posts()) :
      
      while ($Newquery->have_posts()) : $Newquery->the_post();
        $submitpopup = $Newquery->ID;
        include(locate_template('templates/opportunity/main-tabs/content-opportunities.php'));
        ?>        
      <?php endwhile; ?>
      <?php else : ?>
      <h4><?php _e('No Post Found', 'onepress'); ?></h4>
    <?php endif; echo '</div>';?>
      
    <!-- End of Blog Query -->
    <div id="loadmores" class="loadmore wow animated fadeInUp" style="clear:both"><?php echo get_next_posts_link('Load more', $Newquery->max_num_pages); ?></div>		
  </div>
  <?php wp_reset_query(); ?>
</div>