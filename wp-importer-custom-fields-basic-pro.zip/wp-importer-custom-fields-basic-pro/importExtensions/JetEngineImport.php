<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\CFCSV;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class JetEngineImport {

	private static $instance = null;
	
    public static function getInstance() {		
		if (JetEngineImport::$instance == null) {
			JetEngineImport::$instance = new JetEngineImport;
		}
		return JetEngineImport::$instance;
	}

	function set_jet_engine_values($header_array ,$value_array , $map, $post_id , $type , $mode, $hash_key){
		$post_values = [];
		$helpers_instance = ImportHelpers::getInstance();
		$post_values = $helpers_instance->get_header_values($map , $header_array , $value_array);
		$this->jet_engine_import_function($post_values,$type, $post_id, $mode, $hash_key);
	}
	
	public function jet_engine_import_function($data_array, $type, $pID ,$mode, $hash_key) 
	{
		$media_instance = MediaHandling::getInstance();
		$jet_data = $this->JetEngineFields($type);
		$get_gallery_id = $gallery_ids = '';
		foreach ($data_array as $dkey => $dvalue) {
			if(array_key_exists($dkey,$jet_data['JE'])){
				if($jet_data['JE'][$dkey]['type'] == 'gallery'){
						
						$exploded_gallery_items = explode( '|', $dvalue );
						foreach ( $exploded_gallery_items as $gallery ) {
							$gallery = trim( $gallery );
							if ( preg_match_all( '/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i', $gallery ) ) {
								$get_gallery_id = $media_instance->media_handling( $gallery, $pID);	
								 if ( $get_gallery_id != '' ) {
									$gallery_ids .= $get_gallery_id.',';
								}
							} else {
								$galleryLen         = strlen( $gallery );
								$checkgalleryid     = intval( $gallery );
								$verifiedGalleryLen = strlen( $checkgalleryid );
								if ( $galleryLen == $verifiedGalleryLen ) {
									$gallery_ids .= $gallery. ',';
								}
							}
						}
						$gallery_id = rtrim($gallery_ids,',');
					$darray[$jet_data['JE'][$dkey]['name']] = $gallery_id;
				}
				else{
					$darray[$jet_data['JE'][$dkey]['name']] = $dvalue;
				}
				
			}
		}
		if($darray){
			foreach($darray as $mkey => $mval){
				update_post_meta($pID, $mkey, $mval);
			}
		}
	}
	

	public function JetEngineFields($type){
		global $wpdb;	
		$jet_field = array();
		$get_meta_fields = $wpdb->get_results( $wpdb->prepare("SELECT id, meta_fields FROM {$wpdb->prefix}jet_post_types WHERE status != 'trash' AND slug = '$type'"),ARRAY_A);
		$unserialized_meta = maybe_unserialize($get_meta_fields[0]['meta_fields']);
		foreach($unserialized_meta as $jet_key => $jet_value){
			$customFields["JE"][ $jet_value['name']]['label'] = $jet_value['title'];
			$customFields["JE"][ $jet_value['name']]['name']  = $jet_value['name'];
			$customFields["JE"][ $jet_value['name']]['type']  = $jet_value['type'];
			$jet_field[] = $jet_value['name'];
		}
		return $customFields;	
	}
}