jQuery(function($){
    jQuery('.appropriatestaff').click(function(e){
        e.preventDefault();
        var currentemail = jQuery('.currentemail').val();
        var currentusername = jQuery('.currentusername').val();
         
        if(currentemail != '')
        {
          jQuery.ajax({
            url: contractthrunstxls.ajaxurl,
            type: 'post',
            data: {action: 'contract_thru_nstxl',
            currentemail : jQuery('.currentemail').val(),
            currentusername : jQuery('.currentusername').val(),
            },
          success: function(data) {
               jQuery('.successerror').html('Thank you for your message. It has been sent.').show();
            },
          
        });
        }
    });
});
