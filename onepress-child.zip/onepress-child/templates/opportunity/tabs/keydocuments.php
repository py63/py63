<?php
global $post;
$reqforsolic = get_field('nstxl_request_for_solicitation',$post->ID);
$presentations = get_field('nstxl_presentations',$post->ID);
$qandansresponse = get_field('nstxl_q_&_a_responses',$post->ID);

echo '<strong>To view and download the request for solutions (RFS) and supplemental documents, click the following hyperlinked text.</strong>';

echo '<ul class="keydocunorder">';
if(isset($reqforsolic) && !empty($reqforsolic))
{	
 echo '<li><a target="_blank" href="'.$reqforsolic['url'].'"><img src="'.content_url().'/uploads/2018/11/key-document.png">'.$reqforsolic['filename'].'</a></li>';
}
if(isset($presentations) && !empty($presentations))
{	
 echo '<li><a target="_blank" href="'.$presentations['url'].'"><img src="'.content_url().'/uploads/2018/11/key-document.png">'.$presentations['filename'].'</a></li>';
}
if(isset($qandansresponse) && !empty($qandansresponse))
{	
 echo '<li><a target="_blank" href="'.$qandansresponse['url'].'"><img src="'.content_url().'/uploads/2018/11/key-document.png">'.$qandansresponse['filename'].'</a></li>';
}

echo '</ul>';
?>