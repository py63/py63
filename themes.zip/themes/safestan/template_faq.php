<?php
/**
 * Template Name: FAQ
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>
	<?php
	// Start the loop.
	while ( have_posts() ) : the_post();?>
	<!-- Start Head Section -->
	<div class="top-banner">
	    <div class="container">
	      	<div class="row">
				<div class="col-md-12 col-sm-12">
	        		<h1 class="banner-hadding"><?php the_title();?></h1>
				</div>
	      	</div>
	    </div>
  	</div>
	<!-- End Head Section -->
	

	<div class="faq">
		<div class="container">
			<?php
			$args = array(
			    'post_type'=> 'faq',
			    'posts_per_page'    => -1,
			    'order'    => 'DESC'
			);

			// The Query
			query_posts( $args ); 
			$count = 1;
			?>
			<div class="row">
				<div class="col-md-12 col-sm-12">
					<div class="panel-group" id="accordion" role="tablist" <?php if($count ==1) {?>aria-multiselectable="true"<?php }?>>
						<?php // The Loop
						while ( have_posts() ) : the_post(); ?>
					        <div class="panel panel-default">
					            <div class="panel-heading" role="tab" id="heading<?php echo $count;?>">
					                <h4 class="panel-title">
					                    <a <?php if($count != 1){ echo 'class="collapsed"';}?> role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $count;?>" aria-expanded="<?php if($count == 1){ echo 'true';}else{ echo 'false';}?>" aria-controls="collapse<?php echo $count;?>">
					                    	<!-- <?php 
					                    	if($count == 1)
					                    	{
					                    		?>
					                        	<i class="more-less glyphicon glyphicon-minus"></i>
					                        	<?php
					                        }
					                        else 
					                        {	?>
					                    		<i class="more-less glyphicon glyphicon-plus"></i>
					                        	<?php
					                        }?> -->
					                        <div class="faq-title"><?php the_title();?></div>
					                    </a>
					                </h4>
					            </div>
					            <div id="collapse<?php echo $count;?>" class="panel-collapse collapse <?php if($count == 1){ echo 'in';}?>" role="tabpanel" aria-labelledby="heading<?php echo $count;?>">
					                <div class="panel-body">
					                   <?php the_content();?>
					                </div>
					            </div>
					        </div>
					    	<?php $count++; 
					    endwhile;			 
						// Reset Query
						wp_reset_query(); ?>
				    </div><!-- panel-group -->
				</div>
			</div>
		</div>
	</div>
	<?php // End of the loop.
	endwhile;
	?>
<?php get_footer(); ?>