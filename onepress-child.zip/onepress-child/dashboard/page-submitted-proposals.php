<?php
/*
 * Template Name: Dashbaord Submited Proposals
 *
 * @package OnePress
 */
if (!is_user_logged_in()) {
  wp_redirect(get_bloginfo('url') . '/login', 301);
  exit;
}
get_header('admin');
static $proposalsListTable;
if (!isset($proposalsListTable)) {
  require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
  require_once(ABSPATH . 'wp-admin/includes/screen.php');
  require_once(ABSPATH . 'wp-admin/includes/class-wp-screen.php');
  require_once(ABSPATH . 'wp-admin/includes/template.php');
  if (!isset($_REQUEST['paged'])) {
    $_REQUEST['paged'] = explode('/page/', $_SERVER['REQUEST_URI'], 2);
    if (isset($_REQUEST['paged'][1]))
      list($_REQUEST['paged'], ) = explode('/', $_REQUEST['paged'][1], 2);
    if (isset($_REQUEST['paged']) and $_REQUEST['paged'] != '') {
      $_REQUEST['paged'] = intval($_REQUEST['paged']);
      if ($_REQUEST['paged'] < 2)
        $_REQUEST['paged'] = '';
    } else {
      $_REQUEST['paged'] = '';
    }
  }
  if (!class_exists('Proposal_List_Table')) {
    require_once(nstxl_extention_path . 'includes/class-Proposal-list-table.phpcredits()');
  }
  $proposalsListTable = new Proposal_List_Table();
}
?>
<?php
if (!isset($_REQUEST['uid'])) {
  $_REQUEST['uid'] = get_current_user_id();
}
if (isset($_REQUEST['sa'])) {
  $proposalsListTable->prepare_items($_REQUEST['sa']);
} else {
  $proposalsListTable->prepare_items();
}
/**
* @since 2.0.0
* @see onepress_display_page_title
*/
do_action('onepress_page_before_content');

?>
<style type="text/css">

.tablenav.top {
    display: none;
}
  table.fixed{
    table-layout:fixed
  }
  .fixed .column-rating,.fixed .column-visible{
    width:8%
  }
  .fixed .column-author,.fixed .column-date,.fixed .column-format,.fixed .column-links,.fixed .column-parent,.fixed .column-posts{
    width:10%
  }
  .fixed .column-posts{
    width:74px
  }
  .fixed .column-comment .comment-author{
    display:none
  }
  .fixed .column-categories,.fixed .column-rel,.fixed .column-response,.fixed .column-role,.fixed .column-tags{
    width:15%
  }
  .fixed .column-slug{
    width:25%
  }
  .fixed .column-locations{
    width:35%
  }
  .fixed .column-comments{
    width:5.5em;
    padding:8px 0;
    text-align:left
  }
  .fixed .column-comments .vers{
    padding-left:3px
  }
  td.column-title strong,td.plugin-title strong{
    display:block;
    margin-bottom:.2em;
    font-size:14px
  }
  td.column-title p,td.plugin-title p{
    margin:6px 0
  }
  table.media .column-title .media-icon{
    float:left;
    min-height:60px;
    margin:0 9px 0 0
  }
  table.media .column-title .media-icon img{
    max-width:60px;
    height:auto;
    vertical-align:top
  }
  table.media .column-title .has-media-icon~.row-actions{
    margin-left:70px
  }
  table.media .column-title .filename{
    margin-bottom:.2em
  }
  .wp-list-table a{
    transition:none
  }
  #the-list tr:last-child td,#the-list tr:last-child th{
    border-bottom:none!important;
    box-shadow:none
  }

  .sorting-indicator{
    display:block;
    visibility:hidden;
    width:10px;
    height:4px;
    margin-top:8px;
    margin-left:7px
  }
  .sorting-indicator:before{
    content:"\f142";
    font:400 20px/1 dashicons;
    speak:none;
    display:inline-block;
    padding:0;
    top:-4px;
    left:-8px;
    line-height:10px;
    position:relative;
    vertical-align:top;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    text-decoration:none!important;
    color:#444
  }
  .column-comments .sorting-indicator:before{
    top:0;
    left:-10px
  }
  th.desc a:focus span.sorting-indicator:before,th.desc:hover span.sorting-indicator:before,th.sorted.asc .sorting-indicator:before{
    content:"\f142"
  }
  th.asc a:focus span.sorting-indicator:before,th.asc:hover span.sorting-indicator:before,th.sorted.desc .sorting-indicator:before{
    content:"\f140"
  }
  .wp-list-table .toggle-row{
    position:absolute;
    right:8px;
    top:10px;
    display:none;
    padding:0;
    width:40px;
    height:40px;
    border:none;
    outline:0;
    background:0 0
  }
  .wp-list-table .toggle-row:hover{
    cursor:pointer
  }
  .wp-list-table .toggle-row:focus:before{
    box-shadow:0 0 0 1px #bf3737,0 0 2px 1px rgba(30,140,190,.8)
  }
  .ie8 .wp-list-table .toggle-row:focus:before{
    outline:#bf3737 solid 1px
  }
  .wp-list-table .toggle-row:active{
    box-shadow:none
  }
  .wp-list-table .toggle-row:before{
    position:absolute;
    top:5px;
    left:10px;
    border-radius:50%;
    display:block;
    padding:1px 2px 1px 0;
    color:#444;
    content:"\f140";
    font:400 20px/1 dashicons;
    line-height:1;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    speak:none
  }
  .wp-list-table .is-expanded .toggle-row:before{
    content:"\f142"
  }
  tr.wp-locked .locked-indicator{
    margin-left:6px;
    height:20px;
    width:16px
  }
  tr.wp-locked .locked-indicator-icon:before{
    color:#82878c;
    content:"\f160";
    display:inline-block;
    font:400 20px/1 dashicons;
    speak:none;
    vertical-align:middle;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale
  }
  tr.wp-locked .check-column input[type=checkbox],tr.wp-locked .check-column label,tr.wp-locked .row-actions .inline,tr.wp-locked .row-actions .trash{
    display:none
  }
  tr .locked-info{
    height:0;
    opacity:0
  }
  tr.wp-locked .locked-info{
    margin-top:4px;
    height:auto;
    opacity:1
  }
  .locked-text{
    vertical-align:top
  }
  tr.locked-info,tr.wp-locked .locked-info{
    transition:height 1s,opacity .5s
  }
  .fixed .column-comments .sorting-indicator{
    margin-top:3px
  }
  #menu-locations-wrap .widefat{
    width:60%
  }
  .widefat th.sortable,.widefat th.sorted{
    padding:0
  }
  th.sortable a,th.sorted a{
    display:block;
    overflow:hidden;
    padding:8px
  }
  .fixed .column-comments.sortable a,.fixed .column-comments.sorted a{
    padding:8px 0
  }
  th.sortable a span,th.sorted a span{
    float:left;
    cursor:pointer
  }
  th.asc a:focus span.sorting-indicator,th.asc:hover span.sorting-indicator,th.desc a:focus span.sorting-indicator,th.desc:hover span.sorting-indicator,th.sorted .sorting-indicator{
    visibility:visible
  }
  .tablenav-pages a,.tablenav-pages-navspan{
    font-weight:600;
    padding:0 2px
  }
  .tablenav-pages .current-page{
    margin:0 2px 0 0;
    padding-bottom:5px;
    font-size:13px;
    text-align:center
  }
  .tablenav .total-pages{
    margin-right:2px
  }
  .tablenav #table-paging{
    margin-left:2px
  }
  .tablenav a.button,.tablenav a.button-secondary{
    display:block;
    margin:3px 8px 0 0
  }
  .tablenav{
    clear:both;
    height:30px;
    margin:6px 0 4px;
    vertical-align:middle
  }
  .tablenav.themes{
    max-width:98%
  }
  .tablenav .tablenav-pages{
    float:right;
    height:28px;
    margin-top:3px;
    cursor:default;
    color:#555
  }
  .tablenav .no-pages,.tablenav .one-page .pagination-links{
    display:none
  }
  .tablenav .tablenav-pages a,.tablenav-pages span.current{
    text-decoration:none;
    padding:3px 6px
  }
  .tablenav .tablenav-pages a,.tablenav-pages-navspan{
    display:inline-block;
    min-width:17px;
    /*border:1px solid #ccc;*/
    padding:3px 5px 7px;
    background:tranparent;
    font-size:16px;
    line-height:1;
    font-weight:400;
    text-align:center
  }
  /*.tablenav-pages-navspan{
    height:16px;
    border-color:#ddd;
    background:#f7f7f7;
    color:#a0a5aa
  }*/
  .tablenav .tablenav-pages a:focus,.tablenav .tablenav-pages a:hover{
    border-color:#bf3737;
    color:#fff;
    background:#bf3737;
    box-shadow:none;
    outline:0
  }
  .tablenav .displaying-num{
    margin-right:7px
  }
  .tablenav .one-page .displaying-num{
    display:inline-block;
    margin-top:5px;
    margin-right:0
  }
  .tablenav .actions{
    overflow:hidden;
    padding:2px 8px 0 0
  }
  .wp-filter .actions{
    display:inline-block;
    vertical-align:middle
  }
  .tablenav .delete{
    margin-right:20px
  }
  .tablenav .dots{
    border-color:transparent
  }
  .tablenav .next,.tablenav .prev{
    border-color:transparent;
    color:#0073aa
  }
  .tablenav .next:hover,.tablenav .prev:hover{
    border-color:transparent;
    color:#00a0d2
  }
  .tablenav .view-switch{
    float:right;
    margin:0 5px;
    padding-top:3px
  }
  .wp-filter .view-switch{
    display:inline-block;
    vertical-align:middle;
    padding:12px 0;
    margin:0 8px 0 2px
  }
  .media-toolbar.wp-filter .view-switch{
    margin:0 12px 0 2px
  }
  .view-switch a{
    float:left;
    width:28px;
    height:28px;
    text-align:center;
    line-height:24px;
    text-decoration:none
  }
  .view-switch a:before{
    color:#b4b9be;
    display:inline-block;
    font:400 20px/1 dashicons;
    speak:none;
    vertical-align:middle;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale
  }
  .view-switch a:focus:before,.view-switch a:hover:before{
    color:#727272
  }
  .view-switch a.current:before{
    color:#0073aa
  }
  .view-switch .view-list:before{
    content:"\f163"
  }
  .view-switch .view-excerpt:before{
    content:"\f164"
  }
  .view-switch .view-grid:before{
    content:"\f509"
  }
  .filter{
    float:left;
    margin:-5px 0 0 10px
  }
  .filter .subsubsub{
    margin-left:-10px;
    margin-top:13px
  }
  .screen-per-page{
    width:4em
  }
  #posts-filter .wp-filter{
    margin-bottom:0
  }
  #posts-filter fieldset{
    float:left;
    margin:0 1.5ex 1em 0;
    padding:0
  }
  #posts-filter fieldset legend{
    padding:0 0 .2em 1px
  }
  .row-actions,.row-actions-visible{
    padding:2px 0 0
  }
  p.pagenav{
    margin:0;
    display:inline
  }
  .pagenav span{
    font-weight:600;
    margin:0 6px
  }
  .row-title{
    font-size:14px!important;
    font-weight:600
  }
  .column-comment .comment-author{
    margin-bottom:.6em
  }
  .column-author img,.column-comment .comment-author img,.column-username img{
    float:left;
    margin-right:10px;
    margin-top:1px
  }
  .row-actions{
    color:#ddd;
    font-size:13px;
    position:relative;
    left:-9999em
  }
  .plugins,.plugins td,.plugins th,.row-actions .network_active,.row-actions .network_only{
    color:#000
  }
  .rtl .row-actions a{
    display:inline-block
  }
  .comment-item:hover .row-actions,.mobile .row-actions,.no-js .row-actions,.row-actions.visible,tr:hover .row-actions{
    position:static
  }
  #wpbody-content .inline-edit-row fieldset{
    font-size:12px;
    float:left;
    margin:0;
    padding:0;
    width:100%
  }
  #wpbody-content .inline-edit-row fieldset .inline-edit-col,tr.inline-edit-row td{
    padding:0 .5em
  }
  #wpbody-content .quick-edit-row-post .inline-edit-col-left{
    width:40%
  }
  #wpbody-content .quick-edit-row-post .inline-edit-col-right{
    width:39%
  }
  #wpbody-content .inline-edit-row-post .inline-edit-col-center{
    width:20%
  }
  #wpbody-content .quick-edit-row-page .inline-edit-col-left{
    width:50%
  }
  #wpbody-content .bulk-edit-row-post .inline-edit-col-right,#wpbody-content .quick-edit-row-page .inline-edit-col-right{
    width:49%
  }
  #wpbody-content .bulk-edit-row .inline-edit-col-left{
    width:30%
  }
  #wpbody-content .bulk-edit-row-page .inline-edit-col-right{
    width:69%
  }
  #wpbody-content .bulk-edit-row .inline-edit-col-bottom{
    float:right;
    width:69%
  }
  #wpbody-content .inline-edit-row-page .inline-edit-col-right{
    margin-top:27px
  }
  .inline-edit-row fieldset .inline-edit-group{
    clear:both;
    line-height:2.5
  }
  .inline-edit-row .submit{
    clear:both;
    padding:.5em;
    margin:.5em 0 0
  }
  .inline-edit-row .notice-error{
    margin-top:1em
  }
  .inline-edit-row .notice-error .error{
    margin:.5em 0;
    padding:2px
  }
  #the-list .inline-edit-row .inline-edit-legend{
    margin:0;
    padding:.2em .5em 0;
    line-height:2.5;
    font-weight:600
  }
  #the-list #bulk-edit.inline-edit-row .inline-edit-legend{
    padding:.2em .5em
  }
  .inline-edit-row fieldset span.checkbox-title,.inline-edit-row fieldset span.title{
    margin:0;
    padding:0;
    font-style:italic
  }
  .inline-edit-row fieldset label,.inline-edit-row fieldset span.inline-edit-categories-label{
    display:block;
    margin:.2em 0;
    line-height:2.5
  }
  .inline-edit-row fieldset.inline-edit-date label{
    display:inline-block;
    margin:0;
    line-height:1.5;
    vertical-align:baseline
  }
  .inline-edit-row fieldset label.inline-edit-tags{
    margin-top:0
  }
  .inline-edit-row fieldset label.inline-edit-tags span.title{
    margin:.2em 0;
    width:auto
  }
  .inline-edit-row fieldset label span.title,.inline-edit-row fieldset.inline-edit-date legend{
    display:block;
    float:left;
    width:6em;
    line-height:2.5
  }
  #posts-filter fieldset.inline-edit-date legend{
    padding:0
  }
  .inline-edit-row fieldset.inline-edit-date select{
    margin:1px;
    line-height:28px
  }
  .inline-edit-row fieldset .timestamp-wrap,.inline-edit-row fieldset label span.input-text-wrap{
    display:block;
    margin-left:6em
  }
  .quick-edit-row-post fieldset.inline-edit-col-right label span.title{
    width:auto;
    padding-right:.5em
  }
  .inline-edit-row .inline-edit-or{
    margin:.2em 6px .2em 0;
    line-height:2.5
  }
  .inline-edit-row .input-text-wrap input[type=text]{
    width:100%
  }
  .inline-edit-row fieldset label input[type=checkbox]{
    vertical-align:middle
  }
  .inline-edit-row fieldset label textarea{
    width:100%;
    height:4em;
    vertical-align:top
  }
  #bulk-titles,ul.cat-checklist{
    height:12em;
    border:1px solid #ddd;
    overflow-y:scroll;
    padding:0 5px
  }
  #wpbody-content .bulk-edit-row fieldset .inline-edit-group label{
    max-width:50%
  }
  #wpbody-content .quick-edit-row fieldset .inline-edit-group label.alignleft:first-child{
    margin-right:.5em
  }
  .inline-edit-col-right .input-text-wrap input.inline-edit-menu-order-input{
    width:6em
  }
  .inline-edit-row .inline-edit-legend{
    text-transform:uppercase
  }
  .inline-edit-row fieldset .inline-edit-date{
    float:left
  }
  .inline-edit-row fieldset input[name=hh],.inline-edit-row fieldset input[name=jj],.inline-edit-row fieldset input[name=mn]{
    font-size:12px;
    width:2.3em
  }
  .inline-edit-row fieldset input[name=aa]{
    font-size:12px;
    width:3.5em
  }
  .inline-edit-row fieldset label input.inline-edit-password-input{
    width:8em
  }
  ul.cat-checklist{
    margin:0;
    background-color:#fff
  }
  #bulk-titles{
    display:block;
    margin:0 0 5px;
    line-height:140%
  }
  .inline-edit-row fieldset ul.cat-checklist input,.inline-edit-row fieldset ul.cat-checklist li{
    margin:0;
    position:relative
  }
  .inline-edit-row #bulk-titles div,.inline-edit-row fieldset ul.cat-checklist label{
    font-style:normal;
    font-size:11px
  }
  .inline-edit-row fieldset label input.inline-edit-menu-order-input{
    width:3em
  }
  .inline-edit-row fieldset label input.inline-edit-slug-input{
    width:75%
  }
  .inline-edit-row #post_parent,.inline-edit-row select[name=page_template]{
    max-width:80%
  }
  .ie8 .inline-edit-row #post_parent,.ie8 .inline-edit-row select[name=page_template]{
    width:250px
  }
  .quick-edit-row-post fieldset label.inline-edit-status{
    float:left
  }
  #bulk-titles div{
    margin:.2em .3em
  }
  #bulk-titles div a{
    cursor:pointer;
    display:block;
    float:left;
    height:18px;
    margin:0 3px 0 -2px;
    overflow:hidden;
    position:relative;
    width:20px
  }
  #bulk-titles div a:before{
    position:relative;
    top:-3px
  }

  .wp-list-table.plugins .plugin-title,.wp-list-table.plugins .theme-title{
    padding-right:12px;
    white-space:nowrap
  }
  .plugins .plugin-title .dashicons,.plugins .plugin-title img{
    float:left;
    padding:0 10px 0 0;
    width:64px;
    height:64px
  }
  .plugins .plugin-title .dashicons:before{
    padding:2px;
    background-color:#eee;
    box-shadow:inset 0 0 10px rgba(160,165,170,.15);
    font-size:60px;
    color:#B4B9BE
  }
  #update-themes-table .plugin-title .dashicons,#update-themes-table .plugin-title img{
    width:85px
  }
  .plugins .inactive .plugin-title strong{
    font-weight:400
  }
  .plugins .row-actions,.plugins .second{
    padding:0 0 5px
  }
  .plugins .update .row-actions,.plugins .update .second,.plugins .updated .row-actions,.plugins .updated .second{
    padding-bottom:0
  }
  .plugins-php .widefat tfoot td,.plugins-php .widefat tfoot th{
    border-top-style:solid;
    border-top-width:1px
  }
  .plugins .plugin-update-tr .plugin-update{
    box-shadow:inset 0 -1px 0 rgba(0,0,0,.1);
    overflow:hidden;
    padding:0
  }
  .plugins .plugin-update-tr .notice,.plugins .plugin-update-tr div[class=update-message]{
    margin:5px 20px 15px 40px
  }
  .plugins .notice p{
    margin:.5em 0
  }
  .plugin-card .update-now:before{
    color:#f56e28;
    content:"\f463";
    display:inline-block;
    font:400 20px/1 dashicons;
    margin:3px 5px 0 -2px;
    speak:none;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    vertical-align:top
  }
  .plugin-card .updating-message:before{
    content:"\f463";
    -webkit-animation:rotation 2s infinite linear;
    animation:rotation 2s infinite linear
  }
  @-webkit-keyframes rotation{
    0%{
      -webkit-transform:rotate(0);
      transform:rotate(0)
    }
    100%{
      -webkit-transform:rotate(359deg);
      transform:rotate(359deg)
    }
  }
  @keyframes rotation{
    0%{
      -webkit-transform:rotate(0);
      transform:rotate(0)
    }
    100%{
      -webkit-transform:rotate(359deg);
      transform:rotate(359deg)
    }
  }
  .plugin-card .updated-message:before{
    color:#79ba49;
    content:"\f147"
  }
  .plugin-install-php h2{
    clear:both
  }
  .plugin-install-php h3{
    margin:2.5em 0 8px
  }
  .plugin-install-php .wp-filter{
    margin-bottom:0
  }
  .plugin-group{
    overflow:hidden;
    margin-top:1.5em
  }
  .plugin-group h3{
    margin-top:0
  }
  .plugin-card{
    float:left;
    margin:0 8px 16px;
    width:48.5%;
    width:calc(50% - 8px);
    background-color:#fff;
    border:1px solid #ddd;
    box-sizing:border-box
  }
  .plugin-card:nth-child(odd){
    clear:both;
    margin-left:0
  }
  .plugin-card:nth-child(even){
    margin-right:0
  }
  @media screen and (min-width:1600px){
    .plugin-card{
      width:30%;
      width:calc(33.1% - 8px)
    }
    .plugin-card:nth-child(odd){
      clear:none;
      margin-left:8px
    }
    .plugin-card:nth-child(even){
      margin-right:8px
    }
    .plugin-card:nth-child(3n+1){
      clear:both;
      margin-left:0
    }
    .plugin-card:nth-child(3n){
      margin-right:0
    }
  }
  .plugin-card-top{
    position:relative;
    padding:20px 20px 10px;
    min-height:135px
  }
  .plugin-action-buttons,div.action-links{
    margin:0
  }
  .plugin-card h3{
    margin:0 0 12px;
    font-size:18px;
    line-height:1.3
  }
  .plugin-card .desc,.plugin-card .name{
    margin-left:148px;
    margin-right:120px
  }
  .plugin-card .action-links{
    position:absolute;
    top:20px;
    right:20px;
    width:120px
  }
  .plugin-action-buttons{
    clear:right;
    float:right;
    margin-left:2em;
    margin-bottom:1em;
    text-align:right
  }
  .plugin-action-buttons li{
    margin-bottom:10px
  }
  .plugin-card-bottom{
    clear:both;
    padding:12px 20px;
    background-color:#fafafa;
    border-top:1px solid #ddd;
    overflow:hidden
  }
  .plugin-card-bottom .star-rating{
    display:inline
  }
  .plugin-card-update-failed .update-now{
    font-weight:600
  }
  .plugin-card-update-failed .notice-error{
    margin:0;
    padding-left:16px;
    box-shadow:0 -1px 0 #ddd
  }
  .plugin-card-update-failed .plugin-card-bottom{
    display:none
  }
  .plugin-card .column-rating{
    line-height:23px
  }
  .plugin-card .column-rating,.plugin-card .column-updated{
    margin-bottom:4px
  }
  .plugin-card .column-downloaded,.plugin-card .column-rating{
    float:left;
    clear:left;
    max-width:180px
  }
  .plugin-card .column-compatibility,.plugin-card .column-updated{
    text-align:right;
    float:right;
    clear:right;
    width:65%;
    width:calc(100% - 180px)
  }
  .plugin-card .column-compatibility span:before{
    font:400 20px/.5 dashicons;
    speak:none;
    display:inline-block;
    padding:0;
    top:4px;
    left:-2px;
    position:relative;
    vertical-align:top;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    text-decoration:none!important;
    color:#444
  }
  .plugin-card .compatibility-incompatible:before{
    content:"\f158"
  }
  .plugin-card .compatibility-compatible:before{
    content:"\f147"
  }
  .plugin-icon{
    position:absolute;
    top:20px;
    left:20px;
    width:128px;
    height:128px;
    margin:0 20px 20px 0
  }
  .no-plugin-results{
    color:#666;
    font-size:18px;
    font-style:normal;
    margin:0;
    padding:100px 0 0;
    text-align:center
  }
  .wp-list-table .site-deleted,.wp-list-table tr.site-deleted{
    background:#ff8573
  }
  .wp-list-table .site-spammed,.wp-list-table tr.site-spammed{
    background:#faafaa
  }
  .wp-list-table .site-archived,.wp-list-table tr.site-archived{
    background:#ffebe8
  }
  .wp-list-table .site-mature,.wp-list-table tr.site-mature{
    background:#fecac2
  }
  .sites.fixed .column-lastupdated,.sites.fixed .column-registered{
    width:20%
  }
  .sites.fixed .column-users{
    width:80px
  }
  @media screen and (max-width:1100px) and (min-width:782px),(max-width:480px){
    .plugin-card .action-links{
      position:static;
      margin-left:148px;
      width:auto
    }
    .plugin-action-buttons{
      float:none;
      margin:1em 0 0;
      text-align:left
    }
    .plugin-action-buttons li{
      display:inline-block;
      vertical-align:middle
    }
    .plugin-action-buttons li .button{
      margin-right:20px
    }
    .plugin-card .desc,.plugin-card .name{
      margin-right:0
    }
    .plugin-card .desc p:first-of-type{
      margin-top:0
    }
    .fixed .column-date{
      width:14%
    }
  }
  @media screen and (max-width:782px){
    .plugins #the-list tr td,.plugins tr.active+tr.inactive td,.plugins tr.active+tr.inactive th.check-column{
      border-top:none
    }
    .tablenav{
      height:auto
    }
    .tablenav.top{
      margin:20px 0 5px
    }
    .tablenav.bottom{
      position:relative;
      margin-top:15px
    }
    .tablenav br{
      display:none
    }
    .tablenav br.clear{
      display:block
    }
    .form-wrap>p,.tablenav .view-switch,.tablenav.top .actions,.tablenav.top .displaying-num,.tablenav.top .tablenav-pages.one-page{
      display:none
    }
    .view-switch a{
      width:36px;
      height:36px;
      line-height:33px
    }
 /*   .tablenav.bottom .displaying-num{
      position:absolute;
      right:0;
      top:11px;
      margin:0;
      font-size:14px
    }*/
    .tablenav .tablenav-pages{
      width:100%;
      height:auto;
      text-align:center;
      margin:0 0 25px
    }
    .tablenav.bottom .tablenav-pages{
      margin-top:25px
    }
    .tablenav.bottom .tablenav-pages.one-page{
      margin:15px 0 0;
      height:0
    }
    .tablenav-pages .pagination-links{
      font-size:16px
    }
    .tablenav-pages .pagination-links a,.tablenav-pages-navspan{
    /*  padding:9px 11px 12px;
      font-size:18px*/
    }
    .tablenav-pages-navspan{
      height:18px
    }
    .tablenav-pages .pagination-links .current-page{
      padding:8px 9px 9px;
      font-size:16px
    }
    .comment-count{
      font-size:14px
    }
    .wp-list-table th.column-primary~th,.wp-list-table tr:not(.inline-edit-row):not(.no-items) td.column-primary~td:not(.check-column){
      display:none
    }
    .wp-list-table thead th.column-primary{
      width:100%
    }
    .wp-list-table tr th.check-column{
      display:table-cell;
      width:35px
    }
    .wp-list-table .column-primary .toggle-row{
      display:block
    }
    .wp-list-table tr:not(.inline-edit-row):not(.no-items) td:not(.check-column){
      position:relative;
      clear:both;
      display:block;
      width:auto!important
    }
    .wp-list-table td.column-primary{
      padding-right:50px;
    }
    .wp-list-table tr:not(.inline-edit-row):not(.no-items) td.column-primary~td:not(.check-column){
      padding:3px 8px 3px 35% !important;
    }
    .wp-list-table tr:not(.inline-edit-row):not(.no-items) td:not(.column-primary)::before{
      position:absolute;
      left:10px;
      display:block;
      overflow:hidden;
      width:32%;
      content:attr(data-colname);
      white-space:nowrap;
      text-overflow:ellipsis
    }
    .wp-list-table .is-expanded td:not(.hidden){
      display:block!important;
      overflow:hidden
    }
    .column-posts,.widefat .num{
      text-align:left
    }
    #comments-form .fixed .column-author,#commentsdiv .fixed .column-author{
      display:none!important
    }
    .fixed .column-comment .comment-author{
      display:block
    }
    #the-comment-list .is-expanded td{
      box-shadow:none
    }
    #the-comment-list .is-expanded td:last-child{
      box-shadow:inset 0 -1px 0 rgba(0,0,0,.1)
    }
    .post-com-count .screen-reader-text{
      position:static;
      -webkit-clip-path:none;
      clip-path:none;
      width:auto;
      height:auto;
      margin:0
    }
    .column-comments .post-com-count-approved:after,.column-comments .post-com-count-no-comments:after,.column-response .post-com-count-approved:after,.column-response .post-com-count-no-comments:after{
      content:none
    }
    .column-comments .post-com-count [aria-hidden=true],.column-response .post-com-count [aria-hidden=true]{
      display:none
    }
    #edithead label,.column-comments .post-com-count-wrapper>a,.column-response .post-com-count-wrapper>a{
      display:block
    }
    .column-comments .post-com-count-wrapper,.column-response .post-com-count-wrapper{
      white-space:normal
    }
    .column-comments .post-com-count-approved,.column-comments .post-com-count-no-comments,.column-response .post-com-count-approved,.column-response .post-com-count-no-comments{
      margin-top:0;
      margin-right:.5em
    }
    .column-comments .post-com-count-pending,.column-response .post-com-count-pending{
      position:static;
      height:auto;
      min-width:0;
      padding:0;
      border:none;
      border-radius:0;
      background:0 0;
      color:#bb2a2a;
      font-size:inherit;
      line-height:inherit;
      text-align:left
    }
    .column-comments .post-com-count-pending:hover,.column-response .post-com-count-pending:hover{
      color:#dc3232
    }
    .widefat tfoot td.check-column,.widefat thead td.check-column{
      padding-top:10px
    }
    .widefat *{
      word-wrap:normal
    }
    #wpbody-content .bulk-edit-row .inline-edit-col-bottom,#wpbody-content .bulk-edit-row .inline-edit-col-left,#wpbody-content .bulk-edit-row-page .inline-edit-col-right,#wpbody-content .bulk-edit-row-post .inline-edit-col-right,#wpbody-content .inline-edit-row-post .inline-edit-col-center,#wpbody-content .quick-edit-row-page .inline-edit-col-left,#wpbody-content .quick-edit-row-page .inline-edit-col-right,#wpbody-content .quick-edit-row-post .inline-edit-col-left,#wpbody-content .quick-edit-row-post .inline-edit-col-right{
      float:none;
      width:100%
    }
    #wpbody-content .bulk-edit-row fieldset .inline-edit-col label,#wpbody-content .bulk-edit-row fieldset .inline-edit-group label,#wpbody-content .quick-edit-row fieldset .inline-edit-col label,#wpbody-content .quick-edit-row fieldset .inline-edit-group label{
      max-width:none;
      float:none;
      margin-bottom:5px
    }
    #wpbody .bulk-edit-row fieldset select{
      display:block;
      width:100%;
      max-width:none;
      box-sizing:border-box
    }
    .inline-edit-row #bulk-titles div,.inline-edit-row fieldset ul.cat-checklist label{
      font-size:16px
    }
    .inline-edit-row fieldset label span.title,.inline-edit-row fieldset.inline-edit-date legend{
      float:none
    }
    .inline-edit-row fieldset label.inline-edit-tags{
      padding:0 .5em
    }
    .inline-edit-row fieldset .inline-edit-col label.inline-edit-tags{
      padding:0
    }
    .inline-edit-row fieldset .timestamp-wrap,.inline-edit-row fieldset label span.input-text-wrap{
      margin-left:0
    }
    .inline-edit-row fieldset input[name=hh],.inline-edit-row fieldset input[name=jj],.inline-edit-row fieldset input[name=mn]{
      width:3em
    }
    .inline-edit-row fieldset input[name=aa]{
      width:4.5em
    }
    .inline-edit-row .inline-edit-or{
      margin:0 6px 0 0
    }
    #commentsdiv #edithead .inside,#edithead .inside{
      float:none;
      text-align:left;
      padding:3px 5px
    }
    #commentsdiv #edithead .inside input,#edithead .inside input{
      width:100%
    }
    #bulk-titles div{
      margin:.8em .3em
    }
    .plugin-card,.plugin-update-tr .update-message,.plugins .plugin-update-tr .update-message{
      margin-left:0
    }
    #bulk-titles div a{
      height:22px
    }
    #wpbody-content .updates-table .plugin-title{
      width:auto;
      white-space:normal
    }
    .link-manager-php #posts-filter{
      margin-top:25px
    }
    .link-manager-php .tablenav.bottom{
      overflow:hidden
    }
    .comments-box .toggle-row,.wp-list-table.plugins .toggle-row{
      display:none
    }
    #wpbody-content .wp-list-table.plugins td{
      display:block;
      width:auto;
      padding:10px 9px
    }
    #wpbody-content .wp-list-table.plugins .column-description{
      padding-top:2px
    }
    #wpbody-content .wp-list-table.plugins .plugin-title,#wpbody-content .wp-list-table.plugins .theme-title{
      padding-right:12px;
      white-space:normal
    }
    .wp-list-table.plugins .plugin-title,.wp-list-table.plugins .theme-title{
      padding-top:13px;
      padding-bottom:4px
    }
    .plugins #the-list .update td,.plugins #the-list .update th,.plugins #the-list tr>td:not(:last-child),.wp-list-table.plugins #the-list .theme-title{
      box-shadow:none;
      border-top:none
    }
    .plugins tbody{
      padding:1px 0 0
    }
    .plugins .plugin-update-tr:before,.plugins tr.active+tr.inactive td.column-description,.plugins tr.active+tr.inactive th.check-column{
      box-shadow:inset 0 -1px 0 rgba(0,0,0,.1)
    }
    .plugins .plugin-update-tr:before{
      content:"";
      display:table-cell
    }
    .plugins #the-list .plugin-update-tr .plugin-update{
      border-left:none
    }
    .plugins .active.update+.plugin-update-tr:before{
      background-color:#f7fcfe;
      border-left:4px solid #00a0d2
    }
    .wp-list-table.plugins .plugin-title strong,.wp-list-table.plugins .theme-title strong{
      font-size:1.4em;
      line-height:1.5
    }
    table.plugin-install .column-description,table.plugin-install .column-name,table.plugin-install .column-rating,table.plugin-install .column-version{
      display:block;
      width:auto
    }
    table.plugin-install th.column-description,table.plugin-install th.column-name,table.plugin-install th.column-rating,table.plugin-install th.column-version{
      display:none
    }
    table.plugin-install td.column-name strong{
      font-size:1.4em;
      line-height:1.6em
    }
    table.plugin-install #the-list td{
      box-shadow:none
    }
    table.plugin-install #the-list tr{
      display:block;
      box-shadow:inset 0 -1px 0 rgba(0,0,0,.1)
    }
    .plugin-card{
      margin-right:0;
      width:100%
    }
  }
	  @media screen and (max-width:700px){
		  .wp-list-table thead,.wp-list-table tbody{width: 100%;

display: inline-table;}
	}
  @media screen and (max-width:480px){
    .tablenav-pages .current-page{
      margin:0
    }
    .tablenav-pages .tablenav-paging-text{
      float:left;
      width:100%;
      padding-top:.5em
    }
  }
  .ie7 .media-sidebar .setting .link-to-custom{
    float:left
  }

</style>
<div id="content" class="site-content">
  <?php
  onepress_breadcrumb();
  // [show_loggedin_as]
  ?>
  <div id="content-inside" class="container left-sidebar">
<?php get_sidebar('dashboard'); ?>
    <div id="primary" class="content-area">
      <main id="main" class="site-main" role="main">

<?php while (have_posts()) : the_post(); ?>

          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
  <?php //the_title( '<h1 class="entry-title">', '</h1>' );  ?>
            </header><!-- .entry-header -->

            <div class="entry-content">
  <?php the_content(); ?>
              <!--Star of container -->
              <div class="submited-proposal-container search-member dashboard-inner-wrapper dashboard-bg-white">
                <div class="row">
                  <div class="clearfix col-sm-12">
                    <h3 class="rgs_title clearfix"><?php _e(the_title(), 'paid-memberships-pro'); ?></h3>
                  </div>
                  <?php /* ?>
                    <div class="search-wrapper clearfix col-sm-12">
                    <div class="member-search-container pull-left form-01">
                    <?php $unique_id = esc_attr( uniqid( 'search-form-' ) ); ?>
                    <form role="search" method="post" class="search-form">
                    <?php
                    $proposalsListTable->search_box( 'search', 'search_id' ); ?>
                    <!--<input type="hidden" name="page" value="nstxl-proposal-list"> -->
                    <input type="hidden" name="page" value="<?php get_the_permalink(); ?>">
                    </form>
                    </div>
                    </div>
                    <?php */ ?>
                </div>
                <div class="submited-proposal-tracker-inner">
                  <div class="wrap">   
                    <div id="no-more-tables" class="table-responsive ">   
                      <?php
                      $proposalsListTable->prepare_items();
                      $proposalsListTable->display();
                      ?>
                    </div>
                  </div>
                </div>
              </div> 

            </div><!-- .entry-content -->
          </article><!-- #post-## -->

<?php endwhile; // End of the loop.  ?>

      </main><!-- #main -->
    </div><!-- #primary -->



  </div><!--#content-inside -->
</div><!-- #content -->
<script type="text/javascript">
  jQuery(document).ready(function () {
    jQuery('.toggle-row').click(function () {
      jQuery(this).closest("tr").toggleClass("is-expanded")
    });
  });
</script>
<?php get_footer('admin'); ?>
