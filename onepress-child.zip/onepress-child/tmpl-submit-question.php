<?php 
/*
/* 
Template Name: Submit Question 
/*
*/

global $post,$current_user,$wp_query;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$queans = get_field('nstxl_opportunity_answer', $post->ID);
$queimport = get_field('nstxl_answer_import', $post->ID);
$args = array( 'post_type' => 'nstxl-question', 'posts_per_page' => 5 ,'meta_query' => array( 'relation' => 'AND', 
				        array(
				            'key' => 'question_post_id',
				            'value' => $opr_id,
                     'compare'   => '=',
			    	    ),
                array(
                    'key' => 'nstxl_opportunity_answer',
                    'value' => $queans,
                    'compare'   => 'LIKE',
                ),
                array(
                    'key' => 'nstxl_answer_import',
                    'value' => 1,
                     'compare'   => '=',
                )
	   				 ), 'paged' => $paged);

          // echo '<prev>';
          // print_r($args);
          // echo '<prev>';
					//query_posts($args);
          $query = new WP_Query( $args);
?>
<section id="comments" class="polar-post-comments">
			<ul class="comment-list">
			<?php if( $query->have_posts()) : while ( $query->have_posts()) :  $query->the_post();  ?>
			<li class="comment even thread-even depth-1">
<div class="comment-wrapper clearfix">
		<div class="comment-body">
				<h5 class="author"><?php the_title(); ?></h5>
				<div class="comment-text">
          <?php $queanss = get_field('nstxl_opportunity_answer', $post->ID); ?>
					<p><?php echo $queanss; ?></p>
				</div>
				<div class="comment-meta">
					<span class="date meta-field">
						<?php 
						printf( esc_html_x( '%1$s at %2$s ago', '%1$s = normal date, %2$s = human-readable time difference', 'polar' ), get_the_date( 'M j, Y' ), human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) );
						?>				
					</span>
				</div>
		</div>
</div>
</li>

<?php endwhile; ?>
<?php else : ?>
        <!-- No posts found -->
<?php endif; ?>
<?php

// // don't display the button if there are not enough posts
 if (  $query->max_num_pages > 1 ){
?>

<div id="loadmoreans" oppid="<?php echo $opr_id; ?>" class="loadmore wow animated fadeInUp" ><a>Load more</a>
</div>
<?php } ?>
</ul>
 <?php wp_reset_query();?>
</section>


<?php
$currentdate = date("Y-m-d H:i:s", current_time("timestamp"));
$quedeadline = get_field('nstxl_question_deadline',$post->ID);
$quedeadline1 = $quedeadline;

?>
<?php if($currentdate < $quedeadline1){ ?>
<div class="question-container dashboard-inner-wrapper">
		<h2>Submit a Question</h2>
    <div class="question-form-container dashboard-form-wrapper">
      <form method="post" class="question-form" enctype="multipart/form-data" name="question" id="question">
     
        <div class="row">
          <div class="form-group col-lg-6 col-md-6">
            <input type="text" name="user_name_que" id="user_name_que" required class="user_name_que" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->display_name; ?>" readonly
           <?php } ?> >
            <label for="user_name_que"><?php _e('Name','paid-memberships-pro'); ?></label>
          </div> 
          <div class="form-group col-lg-6 col-md-6">          
            <input class="user_company_que" name="user_company_que" id="user_company_que" type="text" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->company_name; ?>" readonly
           <?php } ?>>
            <label for="user_company_que"><?php _e('Company','paid-memberships-pro'); ?></label>
          </div>
        </div>
        <div class="row">
          <div class="form-group col-lg-6 col-md-6">
            <input class="user_email_que" name="user_email_que" id="user_email_que" required type="email" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->user_email; ?>" readonly
           <?php } ?>>
            <label for="user_email_que"><?php _e('Email','paid-memberships-pro'); ?></label>
          </div>
          <div class="form-group col-lg-6 col-md-6">          
            <input class="user_phone_que" name="user_phone_que" id="user_phone_que" type="text" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->pmpro_bphone; ?>" readonly
           <?php } ?>>
            <label for="user_phone_que"><?php _e('Phone','paid-memberships-pro'); ?></label>
          </div>      
        </div>
    
        <div class="row input_fields_wrap">
          <div class="form-group col-lg-12 col-md-12"> 
            <textarea id="question_title[0]" class="question_title" tabindex="3" required name="question_title[0]" value="" cols="50" rows="6"></textarea>
            <label for="question_title"><?php _e('Question','paid-memberships-pro'); ?></label>
        </div>
        <a href="" class="add_field_button tooltip1"><img src ="<?php echo site_url(); ?>/wp-content/plugins/nstxl-memberhip-extension/images/plus.png"><span class="tooltiptext1">Add Additional Question</span></a>
        </div>    
        <input type="hidden" name="queid" value="<?php esc_attr_e( $opr_id ) ?>">
        <div class="btn-group">
          <button type="submit" class="polar_button btn btn-magenta" id="question-disable" name="question-save" ><?php _e( 'Submit Question','paid-memberships-pro'); ?></button>
        </div>
      </form>
      <div class="successmsg" style="color:green;text-align:center;   font-size: 22px;"></div>
			<div class="errormsg" style="color:red;text-align:center;   font-size: 22px;"></div>
    </div>
  </div>
 <?php }
 elseif(empty($quedeadline1))
 {
?>
<div class="question-container dashboard-inner-wrapper">
    <h2>Submit a Question</h2>
    <div class="question-form-container dashboard-form-wrapper">
      <form method="post" class="question-form" enctype="multipart/form-data" name="question" id="question">
        <div class="row">
          <div class="form-group col-lg-6 col-md-6">
            <input type="text" name="user_name_que" id="user_name_que" required class="user_name_que" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->display_name; ?>" readonly
           <?php } ?> >
            <label for="user_name_que"><?php _e('Name','paid-memberships-pro'); ?></label>
          </div> 
           <div class="form-group col-lg-6 col-md-6">          
            <input class="user_company_que" name="user_company_que" id="user_company_que" type="text" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->company_name; ?>" readonly
           <?php } ?>>
            <label for="user_company_que"><?php _e('Company','paid-memberships-pro'); ?></label>
          </div>
        </div>
       <div class="row">
       <div class="form-group col-lg-6 col-md-6">
            <input class="user_email_que" name="user_email_que" id="user_email_que" required type="email" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->user_email; ?>" readonly
           <?php } ?>>
            <label for="user_email_que"><?php _e('Email','paid-memberships-pro'); ?></label>
      </div>
       
       <div class="form-group col-lg-6 col-md-6">          
            <input class="user_phone_que" name="user_phone_que" id="user_phone_que" type="text" <?php if(is_user_logged_in()){ ?>
              value="<?php echo $current_user->pmpro_bphone; ?>" readonly
           <?php } ?>>
            <label for="user_phone_que"><?php _e('Phone','paid-memberships-pro'); ?></label>
          </div>      
        </div>
       <div class="row input_fields_wrap">
          <div class="form-group col-lg-12 col-md-12"> 
            <textarea id="question_title[0]" class="question_title" tabindex="3" required name="question_title[0]" value="" cols="50" rows="6"></textarea>
            <label for="question_title"><?php _e('Question','paid-memberships-pro'); ?></label>
        </div>
       <a href="" class="add_field_button tooltip1"><img src ="<?php echo site_url(); ?>/wp-content/plugins/nstxl-memberhip-extension/images/plus.png"><span class="tooltiptext1">Add Additional Question</span></a>
        </div> 
        <input type="hidden" name="queid" value="<?php esc_attr_e( $opr_id ) ?>">
        <div class="btn-group">
          <button type="submit" class="polar_button btn btn-magenta" id="question-disable" name="question-save"><?php _e( 'Submit Question','paid-memberships-pro'); ?></button>
        </div>
      </form>
      <div class="successmsg" style="color:green;text-align:center;   font-size: 22px;"></div>
      <div class="errormsg" style="color:red;text-align:center;   font-size: 22px;"></div>
    </div>
  </div>
  <?php
 }
 else 
    {
      echo '<p class="quesend">Questions are closed.</p>';
    }
    ?>
  <script>
    jQuery(document).ready( function($) {

      var max_fields      = 20; //maximum input boxes allowed
      var wrapper       = $(".input_fields_wrap"); //Fields wrapper
      var add_button      = $(".add_field_button"); //Add button ID
      
      var x = 1; //initlal text box count
      var inputarray = 1;
      jQuery(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
           //text box increment
          
         // jQuery(wrapper).append('<div class="form-group col-lg-12 col-md-12"><textarea id="question_title['+inputarray+']" class="question_title required" tabindex="3"  name="question_title['+inputarray+']" value="" cols="50" rows="6"></textarea><label for="question_title">Question '+x+'</label><a href="#" class="remove_field"><img src="'+siteurl+'/wp-content/plugins/nstxl-memberhip-extension/images/delete.png" ></a></div>');
         //var y = x+1;
         jQuery('<div class="form-group col-lg-12 col-md-12 multipleque"><textarea id="question_title['+x+']" class="question_title required" tabindex="3"  name="question_title['+x+']" value="" cols="50" rows="6"></textarea><label for="question_title">Question</label><a href="#" class="remove_field"><img src="'+siteurl+'/wp-content/plugins/nstxl-memberhip-extension/images/delete.png" ></a></div>').insertBefore('.add_field_button'); 
          //inputarray++;
           x++;
          
        }
        else{
          jQuery('.add_field_button').hide();
        }
    //     $('.question_title').each(function () {
    //     $(this).rules("add", {
    //         required: true,
    //         messages: {
    //             required: "Please enter question",
    //         }
    //     });
    // });
      });
      
      jQuery(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        jQuery('.add_field_button').show();
        e.preventDefault(); jQuery(this).parent('div').remove(); x--;
      });


      jQuery('.pmpro_asterisk').remove();
      var redirectUrl = siteurl+'/your-sponsored-companies';
      $("#question").validate({
        rules: {
          "question_title[]": {
            required: true,
          },
          action: "required",
          user_name_que: {
            required: true,
          },
          user_email_que: {
            required: true,    
            email: true,               
          },
          user_company_que: {
            required: true,               
          },
        },
        messages: { 
        "question_title[]": {
            required: "Please enter question",
          },
          user_name_que: {
            required: "Please enter the Name",
          },     
          user_email_que: {
            required: "Please enter Email",
            email:"Please enter the valid Email",
          },
          user_company_que: {
            required: "Please enter the Company name",
          },      
        },
        errorClass: "form-invalid",        
        errorElement: 'div',
        highlight: function(element, errorClass, validClass) {
          $(element).closest("div.field").addClass("error").removeClass("success");
        },
        unhighlight: function(element, errorClass, validClass){
          $(element).closest(".error").removeClass("error").addClass("success");
        },
        errorPlacement: function (error, element) {

          if(element.parent().find("div.help-block.with-errors").length === 0) {
            if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {         
              element.parent().append(error);
            } else {              
              error.addClass("help-block with-errors").appendTo( element.closest('div.form-group'));
            }
          } else {
            if (element.attr("type") === "checkbox" || element.attr("type") === "radio") {
              element.parent().append(error);
            } else {            
              error.appendTo(element.parent().find("div.help-block.with-errors"));
            }
          }
        },   
        submitHandler: function(form) {
          var form = jQuery('form#question')[0]; 
          var formData = new FormData(form);

          formData.append("action", "nstxl_submit_question");
          $.ajax({
            url: nstxl_ajaxurl,
            type: "POST",
            data: formData,
            beforeSend: function() {
              jQuery('#question-disable').prop('disabled',true);
              jQuery('.preloader').fadeIn();              
            },        
            success: function (response, textStatus) {
              jQuery('.preloader').fadeOut();
              jQuery('.successmsg').html('Question added successfully.').show();
              jQuery('.multipleque').hide();
              jQuery('.errormsg').hide();
              jQuery('#question-disable').prop('disabled',false);
            },
            error: function(textStatus, errorThrown) {
            	jQuery('.successmsg').hide();
            	jQuery('.errormsg').html('Question not submit.').show();
            },
            complete: function(){
            	jQuery('.successmsg').html('Question added successfully.').show();
              jQuery('.multipleque').hide();
              jQuery('.errormsg').hide();

              jQuery(".preloader").hide(); 
              form.reset();       
            },
            cache: false,
            contentType: false,
            processData: false
          });
        }    
      });

    // 	 $('body').on('click', '.loadmore a', function(e){
    //     e.preventDefault();
    //     var temphref=$(this).attr('href');
    //     $("#loadmoresque").html("<div class='loadmore wow animated fadeInUp loadmoreloading'> <img src='<?php echo get_stylesheet_directory_uri(); ?>/assets/images/ajax-loader.gif' /> Loading...</div>");

    //     $.post(temphref,function(response) {
    //         $("#loadmoresque").remove();
    //         var tempdata=$(response).find('.comment-list').html();
    //         $(".comment-list").append(tempdata);
    //     });
    // });

    var postperpage = 5;
    pageNumber = 1;
    jQuery(document).on("click","#loadmoreans",function(){ // When btn is pressed.
    jQuery("#loadmoreans").attr("disabled",true); // Disable the button, temp.
     // Post per page
    var oppid = jQuery(this).attr('oppid');

    jQuery("#loadmoreans").remove();
    pageNumber++;
  
    var str = '&pageNumber=' + pageNumber + '&postperpage=' + postperpage + '&oppid=' + oppid + '&check_load_more=yes&action=answer_fetch';
    jQuery.ajax({
        type: "POST",
        dataType: "html",
        url: nstxl_ajaxurl,
        data: str,
        beforeSend: function() {
              jQuery('.preloader').fadeIn();              
            }, 
        success: function(data){
          jQuery('.preloader').fadeOut();
            var $data = jQuery(data);
            if($data.length){
                jQuery(".comment-list").append($data);
                jQuery("#loadmoreans").attr("disabled",false);
            }
        },
        error : function(jqXHR, textStatus, errorThrown) {
            $loader.html(jqXHR + " :: " + textStatus + " :: " + errorThrown);
        },
        complete: function(){
              jQuery(".preloader").hide(); 
            },

    });
    return false;
});

  });

  </script>
  <style type="text/css">
  	.help-block {
    display: block;
    color: red;
}

  </style>
