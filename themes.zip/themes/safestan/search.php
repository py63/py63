<?php
/**
 * The template for displaying search results pages
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); 
	
?>
<?php echo do_shortcode('[wpdreams_ajaxsearchlite]'); ?>
	<?php if ( have_posts() ) : ?>

			<?php

			// Start the loop.
			while ( have_posts() ) : the_post();

				/**
				 * Run the loop for the search to output the results.
				 * If you want to overload this in a child theme then include a file
				 * called content-search.php and that will be used instead.
				 */
				?>
				<a href="<?php the_permalink();?>"><?php the_title(); ?></a>
				<?php the_content(); ?>
				<div class="col-sm-7 align-center">
				           	  	<div class="details">
				            		<h3  class="heading3"><?php the_title();?></h3> 
				            		<?php 
	                             		if(CFS()->get('_property_size'))
	                                    {
	                                        $property_size = CFS()->get('_property_size');
	                                    	echo '<div class="num-feet">'.$property_size.' sqft</div>';
	                                    }
	                             	?>
				                	<div class="property-address">
				                		<?php
	                                    if(CFS()->get('_property_address'))
	                                    {
	                                        $property_address = CFS()->get('_property_address');
	                                    }
	                                    if(CFS()->get('_property_city'))
	                                    {
	                                        $property_city = CFS()->get('_property_city');
	                                    }
	                                    if(CFS()->get('_property_state'))
	                                    {
	                                        $property_state = CFS()->get('_property_state');
	                                    }
	                                    if(CFS()->get('_property_zip_code'))
	                                    {
	                                        $property_zip_code = CFS()->get('_property_zip_code');
	                                    }                                       
	                                    echo $property_address.', '.$property_city.', '.$property_state.' '.$property_zip_code;
	                                    ?>                                        
				                	</div>
				                	<p class="para2">
				                		<?php
			                              $content = get_the_content();
			                              echo $contentnew = substr($content, 0, 200);
			                            ?>
				                	</p>
				                    <div  class="footer-details">
				                    <?php echo $post_ID ;echo get_permalink( $post_ID );?>
				                   		<a href="<?php echo get_permalink( $post_ID );?>" class="btn1">View Detail</a>
				                    	<span class="count-review">
				                        	<img src="<?php bloginfo('template_directory');?>/images/review-icon.png" class="mr-5"  alt=""/> 
				                        <a href="<?php the_permalink();?>">
				                        	<?php 
				                        		$myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id DESC");
				                        		$count_reviews = count($myrows);
				                        		if($count_reviews == 1)
				                        		{
				                        			echo '1 + Review';
				                        		}
				                        		if($count_reviews == 0)
				                        		{
				                        			echo 'No Reviews';
				                        		}
				                        		else
				                        		{
				                        			echo $count_reviews.'+ Reviews';
				                        		}
				                        	?>
				                        </a>
				                        </span>
				                  	</div>
				              	</div>
				            </div>
				<?php if (has_post_thumbnail( $post->ID ) ): ?>
			                            <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
			                            <img src="<?php echo $image[0]; ?>" class="img-responsive" alt=""/>
			                        <?php 
			                        else:
			                        	echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found.jpg" class="img-responsive feature-img" alt=""/>';
			                        endif; ?>
			                        <?php 
			// End the loop.
			endwhile;

			

		endif;
		?>
<?php get_footer(); ?>
