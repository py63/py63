/* Set readonly to "add to cart" and redirect URL Fields */

jQuery(document).ready(function(){
    /* Set readonly false if customer or visitor checkbox checked  */    
    if(jQuery('#dis_customer_product').is(':checked') || jQuery('#dis_visitors_product').is(':checked') ){
        jQuery(document).find('#label_replace_addtocart').prop('readonly',false);
    }
    else{
        jQuery(document).find('#label_replace_addtocart').prop('readonly',true);
    }

    /* Set readonly false when clicked on customer checkbox and get value checked */
    jQuery(document).find('#dis_customer_product').click(function(){
        if(jQuery('#dis_customer_product').is(':checked')){            
            jQuery(document).find('#label_replace_addtocart').prop('readonly',false);            
        }
        else if(jQuery('#dis_visitors_product').is(':checked')){
            jQuery(document).find('#label_replace_addtocart').prop('readonly',false);
        }
        else{
            jQuery(document).find('#label_replace_addtocart').prop('readonly',true);
        }
    });

    /* Set readonly false when clicked on visitor checkbox and get value checked */
    jQuery(document).find('#dis_visitors_product').click(function(){
        if(jQuery(this).is(':checked')){
            jQuery(document).find('#label_replace_addtocart').prop('readonly',false);
        }
        else if(jQuery('#dis_customer_product').is(':checked')){
            jQuery(document).find('#label_replace_addtocart').prop('readonly',false);
        }
        else{
            jQuery(document).find('#label_replace_addtocart').prop('readonly',true);
        }
    });
    
    /* Set default readonly true to the URL field */
    jQuery(document).find('#url_redirect_prod').prop('readonly',true);

    /* Click outside or URL field, set readonly false when option 1 or 2 checked */
    jQuery(window,'#label_replace_addtocart').on('click',function(){
        if(jQuery('#dis_customer_product').is(':checked') || jQuery('#dis_visitors_product').is(':checked') && jQuery('#label_replace_addtocart').val() != '' ){
            jQuery(document).find('#url_redirect_prod').prop('readonly',false);
        }
        else{
            jQuery(document).find('#url_redirect_prod').prop('readonly',true);
        }
    });

    /* Set maximum charator limit for button label */
    jQuery("#label_replace_addtocart").on('keypress',function(){   
        if(jQuery(this).val().length>30){
            setTimeout(function() {
                jQuery('.aco-mxlimit').remove();
                jQuery('#label_replace_addtocart').after('<p class="aco-mxlimit">Maximum 30 characters are allowed </p>');                
            }, 500);           
            return false;
        }
        else{
            jQuery('.aco-mxlimit').remove();
        }  
    });
});