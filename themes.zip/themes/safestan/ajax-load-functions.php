<?php
// enqueue_scripts: make sure to include ajaxurl, so we know where to send the post request
function dt_add_main_js(){
  
  wp_register_script( 'loadmain-js', get_template_directory_uri() . '/js/script.js', array( 'jquery' ), '1.0', true );
  wp_enqueue_script( 'loadmain-js' );
  wp_localize_script( 'loadmain-js', 'headJS', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ), 'templateurl' => get_template_directory_uri(), 'posts_per_page' => 10 ) );
  
}
add_action( 'wp_enqueue_scripts', 'dt_add_main_js', 90);

add_action( "wp_ajax_load_more_taxonomy_func", "load_more_taxonomy_func" ); // when logged in
add_action( "wp_ajax_nopriv_load_more_taxonomy_func", "load_more_taxonomy_func" );//when logged out 

function load_more_taxonomy_func() {
  //verifying nonce here      
  global $wpdb;
  $offset = isset($_REQUEST['offset'])?intval($_REQUEST['offset']):0;
  $posts_per_page = isset($_REQUEST['posts_per_page'])?intval($_REQUEST['posts_per_page']):10;
  //optional, if post type is not defined use regular post type
  //$post_type = isset($_REQUEST['post_type'])?$_REQUEST['post_type']:'post';

  
  $post_ID = isset($_REQUEST['post_id'])?intval($_REQUEST['post_id']):0;
  if(($post_ID)!='')
  {

    if(isset($_REQUEST['orderBY']) && $_REQUEST['orderBY']=='ASC'){
      $orderBY = 'ASC';
    }
    elseif(isset($_REQUEST['orderBY']) && $_REQUEST['orderBY']=='DESC')
    {
      $orderBY = 'DESC';
    }
    else{
      $orderBY = '';
    }

    ob_start(); // buffer output instead of echoing it

    if(isset($orderBY) && $orderBY=='ASC')
    {
      $myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id ASC limit $offset, $posts_per_page");
    }
    elseif(isset($orderBY) && $orderBY=='DESC')
    {
      $myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id DESC limit $offset, $posts_per_page");
    }
    else
    {
      $myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$post_ID' and review_status='1' ORDER BY id DESC limit $offset, $posts_per_page");
    }

    if(count($myrows) > 0)
    {
      $result['have_posts'] = true; //set result array item "have_posts" to true
      foreach ($myrows as $myrow) { ?>
        <div class="media">
          <div class="media-left">
              <?php 
                $userimg = get_wp_user_avatar_src($myrow->reviewer_id, 'large'); 
                if($userimg)
                {
                    echo '<img src="'.$userimg.'" class="img-circle" alt=""/>';
                }
                /*else
                {
                    echo '<img src="'.get_bloginfo("template_directory").'/images/user_default.png">';
                }*/
               ?>
          </div>
          <div class="media-body">
            <div class="media-heading">
              <h4 class="heading4"><?php echo $myrow->reviewer_name;?></h4>
              <span class="date">
              <?php 
              $originalDate = $myrow->date_time;
              echo $newDate = date("F d, Y", strtotime($originalDate));
              ?>
              </span>
              <div class="review">
                  <?php //$myrow->review_rating=0;?>
                  <?php if($myrow->review_rating==0)
                  {   ?>
                      <?php for($k=1; $k<=5; $k++)
                      {   ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                          <?php
                      }
                  }   
                  if($myrow->review_rating==1)
                  {   ?>
                      <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                      <?php for($k=1; $k<=4; $k++)
                      {   ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                          <?php
                      }
                  } 
                  if($myrow->review_rating==2)
                  { 
                      for($j=1; $j<=2; $j++)
                      { 
                          ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                          <?php
                      }   
                      for($k=1; $k<=3; $k++)
                      {   ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                          <?php
                      }
                  }   
                  if($myrow->review_rating==3)
                  {   
                      for($j=1; $j<=3; $j++)
                      {   ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                          <?php 
                      }   
                      for($k=1; $k<=2; $k++)
                      {   ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                          <?php
                      }
                  }  
                  if($myrow->review_rating==4)
                  {   
                      for($j=1; $j<=4; $j++)
                      { ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                          <?php
                      } 
                      for($k=1; $k<=1; $k++)
                      { ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/>
                          <?php
                      } 
                  }   
                  if($myrow->review_rating==5)
                  {   
                      for($j=1; $j<=5; $j++)
                      {   ?>
                          <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/>
                          <?php
                      }  
                  }   ?>
                   <!-- <img src="<?php bloginfo('template_directory');?>/images/star-yellow.png" alt=""/> 
                   
                   <img src="<?php bloginfo('template_directory');?>/images/star-grey.png" alt=""/> -->
              </div>          
              <p class="para1">
                  <?php echo $myrow->review_text;?>
              </p>
            </div>
          </div>
        </div>
      <?php 
      } 
      $result['html'] = ob_get_clean(); // put alloutput data into "html" item
    }
    else {
    //no posts found
    $result['have_posts'] = false; // return that there is no posts found
    }
  }
  else
  {
    //echo $_REQUEST['SearchValue'];
    if($_REQUEST['SearchValue'] !='')
    {  
        $SearchValue = $_REQUEST['SearchValue'];
        
        //String replace...
        $val = explode(' ', $SearchValue);
          $str = ''; $count = 0;
          //echo "<pre>";print_r($val);
          if( !empty($val) ) {
            foreach($val as $key => $values) {
              if( !empty($values) ) { $count++;
                if( $count == 1)
                  $str.= "search_term = '$values' ";
                else
                  $str.= "OR search_term = '$values' ";
              }
            }
          }
          $searchrows = $wpdb->get_results("SELECT search_term,term_prefix FROM wpsft_search_term WHERE $str ");
          
          if( !empty($searchrows) ) {
            foreach ($searchrows as $searchrow) { 
              $search[] = $searchrow->search_term;
              $replace[] = $searchrow->term_prefix;
            }
          }
        
        $param1 = str_replace($search, $replace, $SearchValue);

        $searchnewRows1 = $wpdb->get_results("SELECT search_term FROM wpsft_search_term WHERE term_prefix = '$param1'");

        if(count($searchnewRows1)){
          foreach($searchnewRows1 as $abc){
            $where_cond .= " OR address1 LIKE '%".$abc->search_term."% 0' OR address1 LIKE '0 %".$abc->search_term."%'";

            //$where_cond .= " OR address1 LIKE '%".$abc->search_term."% 0' OR address1 LIKE '0 %".$abc->search_term."%' OR address1 LIKE '%".$abc->search_term."%'";
          }
        }
        $where = ltrim($where_cond, " OR ");
        $where = rtrim($where, " ");

        $searchnewRows2 = $wpdb->get_results("SELECT term_prefix FROM wpsft_search_term WHERE term_prefix = '$param1'");
        //print_r($searchnewRows2);/*

        if(count($searchnewRows2)){
              foreach($searchnewRows2 as $abc){
            $array_searchTerm[] = $abc->term_prefix;
          }
        }

        if(is_array($array_searchTerm))
        { 
          if(in_array($param1, $array_searchTerm))
          {
            /*$myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') GROUP BY p.ID ) as t1 WHERE $where ORDER by post_name LIMIT $offset, $posts_per_page");*/

            $myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address1 FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') AND (p.post_type = 'property') GROUP BY p.ID ) as t1 WHERE $where ORDER by post_name LIMIT $offset, $posts_per_page");

            //echo "count result ".count($myrows);die;
          }
        }
        else {
          //$myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state' OR meta_key = 'postflag')  GROUP BY p.ID ) as t1 WHERE address LIKE '%".$SearchValue."% 0' OR address LIKE '%".$param1."% 0' OR address LIKE '0 %".$SearchValue."%' OR address LIKE '0 %".$param1."%' ORDER by post_name LIMIT $offset, $posts_per_page" );

          $myrows = $wpdb->get_results("SELECT * FROM ( SELECT *,GROUP_CONCAT(`meta_value` SEPARATOR ' ') AS address FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (meta_key = '_property_city' OR meta_key = '_property_address' OR meta_key = '_property_zip_code' OR meta_key = '_property_state') AND (p.post_type = 'property') GROUP BY p.ID ) as t1 WHERE address LIKE '%".$SearchValue."% 0' OR address LIKE '%".$param1."% 0' OR address LIKE '0 %".$SearchValue."%' OR address LIKE '0 %".$param1."%' OR address LIKE '%".$param1."%' OR address LIKE '%".$SearchValue."%' ORDER by post_name LIMIT $offset, $posts_per_page" );
          //echo "count results ".count($myrows);//die;

        }
    }
    else
    {      
      $myrows = $wpdb->get_results("SELECT * FROM `wpsft_postmeta` as pm JOIN `wpsft_posts` as p ON pm.post_id = p.ID WHERE `p`.`post_status` = 'publish' AND (p.post_type = 'property') GROUP BY p.ID DESC LIMIT $offset, $posts_per_page");
      
      //echo "count result ".count($myrows);//die;
                /*echo "<pre>";
          print_r($myrows);
          die;*/

    }
    //$myrows = query_posts( $args );
    ob_start(); // buffer output instead of echoing it

    if(count($myrows) > 0)
    {
      $result['have_posts'] = true; //set result array item "have_posts" to true
      foreach ($myrows as $myrow)
      { ?>
       <div class="card-box">
               <div class="col-md-5 col-sm-5">
                        <div class="set-map">
                    <?php 
                            $imfeatureds = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."post_slider_image WHERE post_id = ".$myrow->ID." AND image_featured_status = 1");
                              //echo '<pre>';print_r($imfeatureds);
                              /*$image = wp_get_attachment_image_src( get_post_thumbnail_id( $myrow->ID ), 'single-post-thumbnail' );*/ 
                              if($imfeatureds[0]->image_path)
                              { ?>
                                  <img src="<?php echo $imfeatureds[0]->image_path; ?>" class="img-responsive" alt=""/>
                                <?php 
                              }
                              else
                              {
                                /*echo '<img src="'.get_bloginfo("template_directory").'/images/image-not-found.jpg" class="img-responsive feature-img" alt=""/>';*/
				if(CFS()->get('_property_address',$myrow->ID))
					                        {
					                            $property_address = CFS()->get('_property_address', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_city', $myrow->ID))
					                        {
					                            $property_city = CFS()->get('_property_city', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_state', $myrow->ID))
					                        {
					                            $property_state = CFS()->get('_property_state', $myrow->ID);
					                        }
					                        if(CFS()->get('_property_zip_code', $myrow->ID))
					                        {
					                            $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
					                        }
					                    	
					    $property_fulladdr = array('property_address' => urlencode($property_address),
					                    	'property_city' => urlencode($property_city),
					                    	'property_state' => urlencode($property_state),
					                    	'_property_zip_code' => urlencode($property_zip_code)
					                    	);
					                    	//print_r($property_fulladdr);
					    				   $op = '<div class="effect google-map-embed">';
										   $op .= '<iframe width="470" height="275" frameborder="0" style="border:0" allowfullscreen ';
										   $op .= 'src="https://www.google.com/maps/embed/v1/place?q=';
										   $op .= implode(',', $property_fulladdr);
										   $op .= '&key=AIzaSyCUpXt8H-Wd6-_SHbSmnYwdBPXLDQD-gc0';  
										   $op .= '&zoom=11"></iframe></div>';

										   print $op;

                              }
                            ?>
                          <!--<div class="img-overlay">&nbsp;</div>-->
                          <?php /*
                            <div class="content"> 
                                <div class="top-content">
                                  <?php 
                                  $fields = CFS()->get('_propery_gallery', $myrow->ID);
                                  
                                  $countPhoto = count($fields);
                                  if($countPhoto > 0)
                                  {
                                    if($countPhoto == 1)
                                    { 
                                      echo '<div class="num-photo">'.$countPhoto.' Photo</div>';  
                                    }
                                    else
                                    {
                                      echo '<div class="num-photo">'.$countPhoto.' Photos</div>';
                                    }
                                  } 
                                  ?>
                                    <!-- <div class="like-dislike"><a href="javascript:" class="favorite-property">&nbsp;</a></div> -->
                                </div>
                                <div class="bottom-content">
                                    <span class="common-align-center">
                                       <img src="<?php bloginfo('template_directory');?>/images/ready-icon.png"  alt=""/>
                                     </span>
                                     <span class="common-align-center">
                                      <!--<span class="property-move">Upload Images ( New Property) </span>-->
                                      <?php 
                                        if(CFS()->get('_property_price', $myrow->ID))
                                            {
                                                $property_price = CFS()->get('_property_price', $myrow->ID);
                                              echo '<div class="property-price">$'.$property_price.'</div>';
                                            }
                                      ?>
                                     </span>
                                </div>
                        </div>
                       */  ?>
                        </div>
                    </div>
                   <div class="col-md-7 col-sm-7 mb-3">
                        <h4 class="card-hadding mt-2"><a href="<?php echo $myrow->guid;?>" class="ptl">
                            <?php echo $myrow->post_title;?>
                          </a>
                        <?php 
                            if(CFS()->get('_property_size', $myrow->ID))
                                {
                                    $property_size = CFS()->get('_property_size', $myrow->ID);
                                  echo '<br class="visible-xs"><span>'.$property_size.' sqft</span>';
                                }
                          ?>
                          </h4>
                         <p>
                            <?php
                                if(CFS()->get('_property_address',$myrow->ID))
                                {
                                    $property_address = CFS()->get('_property_address', $myrow->ID);
                                }
                                if(CFS()->get('_property_city', $myrow->ID))
                                {
                                    $property_city = CFS()->get('_property_city', $myrow->ID);
                                }
                                if(CFS()->get('_property_state', $myrow->ID))
                                {
                                    $property_state = CFS()->get('_property_state', $myrow->ID);
                                }
                                if(CFS()->get('_property_zip_code', $myrow->ID))
                                {
                                    $property_zip_code = CFS()->get('_property_zip_code', $myrow->ID);
                                    
                                    $numlength = strlen((string)$property_zip_code);
                                    if($numlength == 1)
                                    {
                                      $property_zip_code = '0000'.$property_zip_code;
                                    }
                                    elseif ($numlength == 2) {
                                      $property_zip_code = '000'.$property_zip_code;
                                    }
                                    elseif ($numlength == 3) {
                                      $property_zip_code = '00'.$property_zip_code;
                                    }
                                    elseif ($numlength == 4) {
                                      $property_zip_code = '0'.$property_zip_code;
                                    }
                                    else {
                                      $property_zip_code = $property_zip_code;
                                    }
                                }                                       
                                $pro_fulladr = array($property_address,$property_city,$property_state,$property_zip_code);
                                $pro_fulladr = array_filter($pro_fulladr);
                                echo implode(', ', $pro_fulladr);
                                ?>                                        
              
        
                            <?php
                                  $content = $myrow->post_content;
                                  echo $contentnew = substr($content, 0, 200);
                                ?>
                          </p>
                            <div class="col-md-6 col-sm-12">    
                              <div class="row">
                               <p class="m-0"><strong>Margaret</strong></p>
                              <div class="star">    
                              <!--<a href="<?php echo $myrow->guid;?>" class="btn1">View Detail</a>-->
				<?php  echo do_shortcode('[RICH_REVIEWS_SNIPPET category="post" id="'.$myrow->ID.'" stars_only="true"]');
                                ?>
                                 </div> 
                
                              <?php /*     <img src="<?php bloginfo('template_directory');?>/images/review-icon.png" class="mr-5"  alt=""/> 
                                <a href="<?php echo $myrow->guid;?>">
                                  <?php 
                                    $ID = $myrow->ID;
                                    $myrows = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."richreviews WHERE post_id='$ID' and review_status='1' ORDER BY id DESC");
                                    $count_reviews = count($myrows);
                                    if($count_reviews == 1)
                                    {
                                      echo '1 + Review';
                                    }
                                    if($count_reviews == 0)
                                    {
                                      echo 'No Reviews';
                                    }
                                    else
                                    {
                                      if($count_reviews != 1)
                                      {
                                        echo $count_reviews.'+ Reviews';
                                      }
                                    }
                                  ?>
                                </a>  */ ?>
                                </div>        
                                  </div>
                                  <div class="col-md-6 col-sm-12">
                                <a href="<?php echo $myrow->guid;?>" class="btn btn-primary btn-block pull-right w-autos">
                                Write a review
                                </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
        </div>
        <?php 
      }
      $result['html'] = ob_get_clean(); // put alloutput data into "html" item
    }
    else {
      //no posts found
      $result['have_posts'] = false; // return that there is no posts found
    }
  }   

  if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
      $result = json_encode($result); // encode result array into json feed
      echo $result; // by echo we return JSON feed on POST request sent via AJAX
  }
  else { 
      header("Location: ".$_SERVER["HTTP_REFERER"]);
  }
  die();
}

?>
