<?php
/**
 * The header for the OnePress theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package OnePress
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<div class="preloader" style="display: none"><div class="nst-ripple"><div class="nst-pos"></div></div></div>
	<?php do_action( 'onepress_before_site_start' ); ?>
	<div id="page" class="hfeed site">
		<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'onepress' ); ?></a>
		<?php
	/*	if(is_page(5580)){
		$crawler_content = get_field('crawler_content', 5580); ?>
		<script type="text/javascript">
			jQuery(document).ready(function(){
				jQuery("#header-section").removeClass("no-transparent");
				jQuery("#header-section").addClass("is-transparent");
				jQuery( "#masthead .container" ).before( '<div class="crawler-content"><marquee direction="left"><?php echo $crawler_content ?></marquee></div>');
			});
		</script>
	<?php
		} */
    /**
     * @since 2.0.0
     */
    onepress_header();

    
    ?>
